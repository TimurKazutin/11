﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-24-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-24-2014
// ***********************************************************************
// <copyright file="TableType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    /// <summary>
    /// Enum TableType
    /// </summary>
    public enum TableType
    {
        /// <summary>
        /// The master
        /// </summary>
        Master,
        /// <summary>
        /// The detail
        /// </summary>
        Detail,
        /// <summary>
        /// The dictionary
        /// </summary>
        Dictionary
    }
}
