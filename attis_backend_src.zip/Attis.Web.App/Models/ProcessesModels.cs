﻿namespace Lawyers.Web.App.Models
{
    using Resources;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Data;
    using System.Globalization;
    using System.Linq;
    using Lawyers.Common;
    using Lawyers.Common.Interfaces;
    using Lawyers.Engine.Configuration;
    using System;
    using System.Web.Mvc;

    public class CalendarEventModel
    {
        [Required]
        public string eventId { get; set; }

        [Required]
        public string eventName { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime eventStartDate { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime eventEndDate { get; set; }

        [Required]
        public string userId { get; set; }

        [Required]
        public string eventMessage { get; set; }
    }

    public class ProcessModel
    {
        public string processId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string middleName { get; set; }
        public string firstNameKz { get; set; }
        public string lastNameKz { get; set; }
        public string middleNameKz { get; set; }
        public string userId { get; set; }
        public string processCreatorId { get; set; }
    }

    //public class AddEventViewModel
    //{
    //    public IEnumerable<SelectListItem> users { get; set; }

    //    [Required]
    //    public string processName { get; set; }

    //    [Required]
    //    public string processBody { get; set; }

    //    [Required]
    //    [DataType(DataType.Date)]
    //    [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
    //    public DateTime? processStartDate { get; set; }

    //    [DataType(DataType.Date)]
    //    [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
    //    public DateTime? processEndDate { get; set; }
    //    [Required]
    //    public string userId { get; set; }
    //}

    public class EventManagementViewModel
    {
        public IEnumerable<SelectListItem> users { get; set; }

        public string processName { get; set; }
        public string processBody { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? processStartDate { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? processEndDate { get; set; }

        public string userId { get; set; }
    }

}
