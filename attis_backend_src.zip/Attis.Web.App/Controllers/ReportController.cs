﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Lawyers.Engine.Configuration;
using Lawyers.Engine.Data;
using Lawyers.Engine.Validation;
//using DocumentFormat.OpenXml;
//using DocumentFormat.OpenXml.Packaging;
//using DocumentFormat.OpenXml.Spreadsheet;
using Lawyers.Common;
using Lawyers.Common.Interfaces;
using Lawyers.Common.Model;
using Lawyers.Web.App.Helpers;
using Lawyers.Web.App.Models;
using Lawyers.Web.App.Models.Enums;
using log4net;
using Microsoft.AspNet.Identity;
using Newtonsoft.Json;
/*using Border = DocumentFormat.OpenXml.Spreadsheet.Border;
using Borders = DocumentFormat.OpenXml.Spreadsheet.Borders;
using CellFormat = DocumentFormat.OpenXml.Spreadsheet.CellFormat;
using Sheets = DocumentFormat.OpenXml.Spreadsheet.Sheets;
using Workbook = DocumentFormat.OpenXml.Spreadsheet.Workbook;
using Worksheet = DocumentFormat.OpenXml.Spreadsheet.Worksheet;
*/
namespace Lawyers.Web.App.Controllers
{
    using Excel = Microsoft.Office.Interop.Excel;

    [System.Web.Mvc.Authorize]
    public class ReportController : Controller
    {
        private readonly ILog _logger = LogManager.GetLogger(typeof(ReportController));

        //_logger.log("asd");
        private static IDataProvider Provider => GlobalContainer.Instance.Get<Configuration>().DataProvider;

        private ReportDictionary Reports
        {
            get
            {
                var templates = (ReportDictionary)HttpContext.Session["Reports"];

                if (templates != null)
                {
                    return templates;
                }

                templates = GlobalContainer.Instance.Get<Configuration>().GetReports();
                HttpContext.Session["Reports"] = templates;

                return templates;
            }
        }

        private TemplateDictionary Templates
        {
            get
            {
                var templates = (TemplateDictionary)HttpContext.Session["Templates"];

                if (templates != null)
                {
                    return templates;
                }

                templates = GlobalContainer.Instance.Get<Configuration>().GetTemplates();
                HttpContext.Session["Templates"] = templates;

                return templates;
            }
        }


        private readonly Guid _reportTemplateGuid = Guid.Parse("4D08D9C143BF410CBCD5C6ED77445427");


        private Template ReportTemplate
        {
            get
            {
                var reportTemplate = Templates[_reportTemplateGuid];

                if (reportTemplate == null)
                {
                    return null;
                }

                var ds = DataSets.ContainsKey(_reportTemplateGuid) ? DataSets[_reportTemplateGuid] : null;

                if (ds == null) // Create DataSet for template, if it's not exists
                {
                    ds = new DataSet((ClaimsIdentity)User.Identity, reportTemplate.DataSources[0]);
                    ds.Initialize(reportTemplate.Document);
                    DataSets.Add(_reportTemplateGuid, ds);
                }

                ds.FillTableData(null);
                ds.BindData(reportTemplate.Document);

                var validator = Validators.ContainsKey(_reportTemplateGuid) ? Validators[_reportTemplateGuid] : null;

                if (validator != null)
                {
                    return reportTemplate;
                }

                validator = new Validator(reportTemplate.Document, DataSets[_reportTemplateGuid], CultureManager.DefaultCulture);
                Validators.Add(_reportTemplateGuid, validator);

                return reportTemplate;
            }
        }

        private DataSetDictionary DataSets
        {
            get
            {
                var datasets = (DataSetDictionary)HttpContext.Session["DataSets"];

                if (datasets != null)
                {
                    return datasets;
                }

                datasets = new DataSetDictionary();
                HttpContext.Session["DataSets"] = datasets;

                return datasets;
            }
        }

        private ValidatorDictionary Validators
        {
            get
            {
                var validators = (ValidatorDictionary)HttpContext.Session["Validators"];

                if (validators != null)
                {
                    return validators;
                }

                validators = new ValidatorDictionary();
                HttpContext.Session["Validators"] = validators;

                return validators;
            }
        }

        private Graphics _graphics;

        private Graphics Graphics
        {
            get
            {
                _graphics = _graphics ?? Graphics.FromImage(new Bitmap(1, 1));
                return _graphics;
            }
        }

        public int GetCount()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT COUNT(*) FROM notifications WHERE notification_archived='false' AND notification_recipient ='" + user + "';";
            var reader = Provider.RunScalar(query);
            return reader;
        }

        public string GetFirmName()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunQueryStr(query);
            return result;
        }

        public ActionResult Deal(int id)
        {
            var model = new Deal { Id = id };

            string query = "SELECT t1.*, t2.subj_name FROM deal t1 LEFT JOIN subjects t2 ON t1.deal_user = t2.subj_id WHERE deal_debt_id ='" + id + "' ORDER by deal_id DESC;";
            var reader = Provider.RunQuery(query);
            int? st = 0;
            var reports = new List<Deal>();
            if (reader != null) { 
            while (reader.Read())
            {
                var rep = new Deal
                {
                    Id = (int)reader["deal_id"],
                };

                rep.additional_agreement = reader["deal_body"].ToString();
                rep.Deb = reader["subj_name"].ToString();
                rep.Agree = (int)reader["deal_status"] != 0;
                rep.state = (int)reader["deal_num"];
                rep.User = reader["deal_user"].ToString();
                rep.Date = GetDateTimeFromString(reader["deal_date"].ToString());
                reports.Add(rep);
                if (rep.state != 0 && rep.state != null) { st = rep.state; }
            }
            reader.Close();
            }
            query = $"SELECT status FROM debts WHERE debt_id = '{id}'";
            ViewBag.st = Provider.RunScalar(query);
            ViewBag.Deals = reports;
            ViewBag.Firm = GetFirmName();
            query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + User.Identity.GetUserId() + "';";
            ViewBag.type = Provider.RunScalar(query);
            if (Session["Token"] != null)
                ViewBag.login_type = Session["Token"];
            else ViewBag.login_type = "0";
            Provider.RunNonQuery(query);
            return View(model);
        }

        [HttpPost]
        public ActionResult Deal(Deal model)
        {
            var user = User.Identity.GetUserId();
            var lst = 0;
            var state = 0;
            string query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            lst = Provider.RunScalar(query);
            query = $"SELECT status FROM debts WHERE debt_id = '{model.Id}'";
            var stat = Provider.RunScalar(query);
            if (lst == 1)
            {
                query = "SELECT user_id FROM debts WHERE debt_id ='" + model.Id + "';";
                string personId = Provider.RunQueryStr(query);

                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.DebtReserved,
                    CreatorId = User.Identity.GetUserId(),
                    RecipientId = personId,
                    CreationDate = DateTime.Now,
                    ObjectId = model.Id
                });
            }
            else if (lst == 2) {
                query = "SELECT t2.user_id FROM debts t1 LEFT JOIN subjects t2 ON t1.subj_id = t2.subj_id WHERE debt_id ='" + model.Id + "';";
                string personId = Provider.RunQueryStr(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.DebtReserved,
                    CreatorId = User.Identity.GetUserId(),
                    RecipientId = personId,
                    CreationDate = DateTime.Now,
                    ObjectId = model.Id
                });
            }

            query = $"INSERT INTO deal (deal_debt_id, deal_body, deal_user, deal_status, deal_date, deal_num) VALUES ('{model.Id}', '{model.additional_agreement}', '{lst}', '{Convert.ToInt16(model.Agree)}', 'NOW()', '{state}');";
            Provider.RunNonQuery(query);
            return RedirectToAction("Orders");
        }

        public void CancelDeal(string Id)
        {
            string query = $"SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{User.Identity.GetUserId()}';";
            var lst = Provider.RunScalar(query);
            query = $"SELECT debitor_confirm FROM debts WHERE debt_id ='{Id}';";
            var st = Provider.RunScalar(query);
            if (lst == 1 || lst == 2) //check if role
            {
                if (st == 1)
                    query = $"UPDATE debts SET status='5', subj_id=null WHERE debt_id='{Id}';";
                else query = $"UPDATE debts SET status='0', subj_id=null WHERE debt_id='{Id}';";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM deal WHERE deal_debt_id ='{Id}';";
                Provider.RunNonQuery(query);
            }
            else {
                query = $"UPDATE deal SET deal_num='0' WHERE deal_debt_id='{Id}';";
                Provider.RunNonQuery(query);
            }

        }
        public int FinishDeal(string Id)
        {
            string query = $"SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{User.Identity.GetUserId()}';";
            var lst = Provider.RunScalar(query);
            query = $"SELECT status FROM debts WHERE debt_id = '{Id}'";
            var stat = Provider.RunScalar(query);

            if (lst == 2 && (stat == 1 || stat == 5))
            {
                //query = $"UPDATE deal SET deal_num='2' WHERE deal_debt_id='{Id}';";
                query = $"INSERT INTO deal (deal_debt_id, deal_user, deal_status, deal_date, deal_num) VALUES ('{Id}', '{User.Identity.GetUserId()}', 'true', 'NOW()', '2');";
                Provider.RunNonQuery(query);
                query = "SELECT t2.user_id FROM debts t1 LEFT JOIN subjects t2 ON t1.subj_id = t2.subj_id WHERE debt_id ='" + Id + "';";
                string personId = Provider.RunQueryStr(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.DebtFinal,
                    CreatorId = User.Identity.GetUserId(),
                    RecipientId = personId,
                    CreationDate = DateTime.Now,
                    ObjectId = int.Parse(Id)
                });
                query = $"UPDATE debts SET status='7' WHERE debt_id='{Id}';";
                Provider.RunNonQuery(query);
                return 7;
            }
            if (lst == 1 && (stat == 1 || stat == 5 || stat == 6))
            {
                //query = $"UPDATE deal SET deal_num='3' WHERE deal_debt_id='{Id}';";
                query = $"INSERT INTO deal (deal_debt_id, deal_user, deal_status, deal_date, deal_num) VALUES ('{Id}', '{User.Identity.GetUserId()}', 'true', 'NOW()', '3');";
                Provider.RunNonQuery(query);
                query = "SELECT user_id FROM debts WHERE debt_id ='" + Id + "';";
                string personId = Provider.RunQueryStr(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.DebtFinal,
                    CreatorId = User.Identity.GetUserId(),
                    RecipientId = personId,
                    CreationDate = DateTime.Now,
                    ObjectId = int.Parse(Id)
                });
                query = $"UPDATE debts SET status='6' WHERE debt_id='{Id}';";
                Provider.RunNonQuery(query);
                return 6;
            }
            if ((lst == 2 && stat == 6) || (lst == 1 && stat == 7))
            {
                //query = $"UPDATE deal SET deal_num='4' WHERE deal_debt_id='{Id}';";
                query = $"INSERT INTO deal (deal_debt_id, deal_user, deal_status, deal_date, deal_num) VALUES ('{Id}', '{User.Identity.GetUserId()}', 'true', 'NOW()', '4');";
                Provider.RunNonQuery(query);
                query = $"UPDATE debts SET status='4' WHERE debt_id='{Id}';";
                Provider.RunNonQuery(query);
                if (lst == 1)
                {
                    query = "SELECT t2.user_id FROM debts t1 LEFT JOIN subjects t2 ON t1.subj_id = t2.subj_id WHERE debt_id ='" + Id + "';";
                    string personId = Provider.RunQueryStr(query);
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.AccountUserUnlocked,
                        CreatorId = User.Identity.GetUserId(),
                        RecipientId = personId,
                        CreationDate = DateTime.Now,
                        ObjectId = int.Parse(Id)
                    });
                }
                if (lst == 2){ 
                    query = "SELECT t2.user_id FROM debts t1 LEFT JOIN subjects t2 ON t1.subj_id = t2.subj_id WHERE debt_id ='" + Id + "';";
                    string personId = Provider.RunQueryStr(query);
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.AccountUserUnlocked,
                        CreatorId = User.Identity.GetUserId(),
                        RecipientId = personId,
                        CreationDate = DateTime.Now,
                        ObjectId = int.Parse(Id)
                    });
                }
                query = $"SELECT debitor_id FROM debts WHERE debt_id ='{Id}';";
                var debtr = Provider.RunScalar(query);
                query = $"SELECT t1.user_id FROM persons t1 LEFT JOIN organizations t2 on t1.org_id=t2.org_id " +
                        $"WHERE org_code =(SELECT debitor_bin FROM debitors WHERE debitor_id='{debtr}');";
                var DebitorNames = new List<string> { };
                var reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        DebitorNames.Add(reader["user_id"].ToString());
                    }
                    reader.Close();
                    foreach (var dn in DebitorNames)
                    {
                        NotificationHelper.AddNotification(new Notification()
                        {
                            Type = NotificationType.RequestEditProfile,
                            CreatorId = User.Identity.GetUserId(),
                            RecipientId = dn,
                            CreationDate = DateTime.Now,
                            ObjectId = int.Parse(Id)
                        });
                    }
                }
                FinalNote(Id);  //MSG to contract
                return 4;
            }
            return 0;
        }

        public static void FinalNote(string Id)
        {
            var query = "SELECT user_id FROM debts WHERE debt_id ='" + Id + "';";
            string crId = Provider.RunQueryStr(query); //creditor
            query = "SELECT t2.user_id FROM debts t1 LEFT JOIN subjects t2 ON t1.subj_id = t2.subj_id WHERE debt_id ='" + Id + "';";
            string fcId = Provider.RunQueryStr(query); //factor

            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.RequestApprovalReportGgupRejected,
                CreatorId = fcId,
                RecipientId = crId,
                CreationDate = DateTime.Now,
                ObjectId = int.Parse(Id)
            });

            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.RequestApprovalReportGgupRejected,
                CreatorId = crId,
                RecipientId = fcId,
                CreationDate = DateTime.Now,
                ObjectId = int.Parse(Id)
            });

            query = $"INSERT INTO log (log_date, log_text, log_section, log_source_user_id, log_target_user_id, log_doc_id) " +
                        $"VALUES('NOW()', 'deal finished', 'deals', '{fcId}', '{crId}', '{Id}');";
        }

        public ActionResult Deals(int? market_id)
        {/*
            var tid = Convert.ToInt32(System.Web.HttpContext.Current.Session["Token"]);
            if (tid != 1)
            {
                ViewBag.Message = "Token required";
                return View("Error");
            }*/
            var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
            if (role == -4)
            {
                ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
                return View("Error");
            }
            var user = User.Identity.GetUserId();
            var query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunScalar(query);
            if (result == 1)
            {
                if (market_id == null)                    
                    query = "SELECT DISTINCT on (t1.debt_id) t5.deal_date, t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t8.org_name as cred, t8.org_id as kred_id, t9.org_id as dbtr_id " +
                        "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                        "LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id " +
                        "LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                        "LEFT JOIN organizations t9 ON t2.debitor_bin = t9.org_code " +
                        "LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                        "LEFT JOIN deal t5 ON t1.debt_id = t5.deal_debt_id WHERE status = '4' ORDER BY t1.debt_id DESC;";
                else query = $"SELECT DISTINCT on (t1.debt_id) t5.deal_date, t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t8.org_name as cred, t8.org_id as kred_id, t9.org_id as dbtr_id " +
                        $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                        $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id " +
                        $"LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                        "LEFT JOIN organizations t9 ON t2.debitor_bin = t9.org_code " +
                        $"LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                        $"LEFT JOIN deal t5 ON t1.debt_id = t5.deal_debt_id WHERE status = '4' AND debt_marketplace='{market_id}' ORDER BY debt_id DESC;";                
            }
            else if (result == 2)
            {
                if (market_id == null)                    
                    query = $"SELECT DISTINCT on (t1.debt_id) t5.deal_date, t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t8.org_name as cred, t8.org_id as kred_id, t9.org_id as dbtr_id  " +
                        $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                        $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id " +
                        $"LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                        $"LEFT JOIN organizations t9 ON t2.debitor_bin = t9.org_code " +
                        $"LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                        $"LEFT JOIN deal t5 ON t1.debt_id = t5.deal_debt_id WHERE status = '4' AND t1.user_id='{user}' ORDER BY debt_id DESC;";
                else query = $"SELECT DISTINCT on (t1.debt_id) t5.deal_date, t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address,  t4.org_name, t8.org_name as cred, t8.org_id as kred_id, t9.org_id as dbtr_id " +
                        $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                        $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id " +
                        $"LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                        $"LEFT JOIN organizations t9 ON t2.debitor_bin = t9.org_code " +
                        $"LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                        $"LEFT JOIN deal t5 ON t1.debt_id = t5.deal_debt_id WHERE status = '4' " +
                        $"AND t1.user_id='{user}' AND debt_marketplace='{market_id}' ORDER BY debt_id DESC;";
            }
            else
            {                
                    query = $"SELECT DISTINCT on (t1.debt_id) t9.deal_date, t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t6.org_id, t6.org_name, t8.org_name as cred, t8.org_id as kred_id, t10.org_id as dbtr_id " +
                        $"FROM debts t1 left join debitors t2 ON t1.debitor_id = t2.debitor_id " +
                        $"LEFT JOIN organizations t3 on t2.debitor_bin = t3.org_code " +
                        $"LEFT JOIN persons t4 on t3.org_id = t4.org_id " +
                        $"LEFT JOIN persons t5 ON t1.subj_id = t5.subj_id " +
                        $"LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                        $"LEFT JOIN deal t9 ON t1.debt_id = t9.deal_debt_id " +
                        $"LEFT JOIN organizations t10 ON t2.debitor_bin = t10.org_code " +
                        $"LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                        $"WHERE status = '4' AND t4.user_id = '{user}' AND t1.debt_confirmation='1' ORDER BY t1.debt_id DESC;";                
            }
            var reader = Provider.RunQuery(query);

            var reports = new List<OrderModel>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new OrderModel
                    {
                        Id = reader["debt_id"].ToString(),
                        //ReportNumber = reader["rep_number"].ToString()
                    };
                    //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                    rep.DocNo = reader["cred"].ToString();
                    rep.kred_id = reader["kred_id"].ToString();
                    rep.FirmName = reader["debitor_name"].ToString();
                    rep.dbtr_id = reader["dbtr_id"].ToString();
                    rep.Debt = GetIntFromString(reader["debt_sum"].ToString());
                    rep.status = reader["org_name"].ToString();
                    rep.fact_id = reader["org_id"].ToString();
                    rep.Reg = reader["post_time"].ToString();
                    rep.K1 = (decimal)reader["K1"];
                    rep.fund = (decimal)reader["debt_financing_ratio"];
                    rep.first = (decimal)reader["debt_first_pay_sum"];
                    rep.regrs = (int)reader["factoring_buyout_conditions"] != 0;
                    if (reader["deal_date"] != null && reader["deal_date"].ToString() != "")
                        rep.DebtDate = GetDateTimeFromString(reader["deal_date"].ToString());
                    else rep.DebtDate = DateTime.Now;
                    //rep.regrsdt = GetDateTimeFromString(reader["debt_regress_date"].ToString());                    
                    reports.Add(rep);
                }

                reader.Close();
            }
            var model = new OrdersViewModel();
            model.Orders = reports;
            ViewBag.Role = result;
            ViewBag.Mark = market_id;
            ViewBag.Count = GetCount();
            ViewBag.Firm = GetFirmName();
            return View(model);
        }

        public ActionResult Orders(int? market_id)
        {
            var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
            if (role == -4)
            {
                ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
                return View("Error");
            }
            var user = User.Identity.GetUserId();

            string query = $"SELECT t1.*, t2.condition_name FROM conditions_lights t1 LEFT JOIN conditions_list t2 ON t1.condition_id = t2.condition_list_id WHERE user_id ='{user}' AND condition_dest='0';";
            var reader = Provider.RunQuery(query);

            var ligths = new List<Light>();
            if (reader != null) { 
            while (reader.Read())
            {
                var rep = new Light
                {
                    Id = (int)reader["condition_light_id"],
                    //ReportNumber = reader["rep_number"].ToString()
                };
                //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                //rep.AgreementDate = GetDateTimeFromString(reader["post_time"].ToString());
                rep.name = reader["condition_id"].ToString();
                rep.color = reader["condition_color"].ToString();
                rep.logic = reader["condition_logical"].ToString();
                rep.value = reader["condition_value"].ToString();
                rep.is_active = (int)reader["condition_status"] != 0;
                ligths.Add(rep);
            }
            reader.Close();
            }

            query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunScalar(query);

            if (result == 1)
            {
                if (market_id == null)
                    query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    "LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    "LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    "LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    "WHERE status > '-1' AND (competition IS NULL OR competition = '0') ORDER BY debt_id DESC;";
                else query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t8.org_id as kred_id, t7.org_id as dbtr_id " +
                    $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $"LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    $"WHERE status > '-1' AND (competition IS NULL OR competition = '0') AND debt_marketplace='{market_id}' ORDER BY debt_id DESC;";
            }
            else if (result == 2)
            {                
                if (market_id == null)
                    query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id  " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    "LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    "LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    "LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    "WHERE t1.user_id ='" + user + "' AND (competition IS NULL OR competition = '0') ORDER BY post_time DESC";
                else query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id  " +
                    $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $"LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    $"WHERE t1.user_id ='{user}' AND (competition IS NULL OR competition = '0') AND debt_marketplace='{market_id}' ORDER BY post_time DESC;";
            }
            else {
                query= $"SELECT debitor_id FROM debitors WHERE debitor_bin = (SELECT org_code FROM organizations t1 LEFT JOIN persons t2 on t1.org_id = t2.org_id WHERE user_id = '{user}');";
                int dbr = Provider.RunScalar(query);
                query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t6.org_name, t8.org_name as cred, t8.org_id as kred_id, t9.org_id as dbtr_id " +
                        $"FROM debts t1 left join debitors t2 ON t1.debitor_id = t2.debitor_id left join " +
                        $"organizations t3 on t2.debitor_bin = t3.org_code left join persons t4 on " +
                        $"t3.org_id = t4.org_id LEFT JOIN persons t5 ON t1.subj_id = t5.subj_id LEFT " +
                        $"JOIN organizations t6 ON t5.org_id = t6.org_id " +
                        $"LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                        $"LEFT JOIN organizations t9 ON t2.debitor_bin = t9.org_code " +
                        $"WHERE t1.debitor_id = '{dbr}' AND (competition IS NULL OR competition = '0') AND t1.debt_confirmation='1' AND status != '-1' AND status != '-2' ORDER BY post_time DESC;";                
            }
            reader = Provider.RunQuery(query);

            var reports = new List<OrderModel>();
            if (reader != null) { 
            while (reader.Read())
            {
                var rep = new OrderModel
                {
                    Id = reader["debt_id"].ToString(),
                    //ReportNumber = reader["rep_number"].ToString()
                };
                //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                //rep.AgreementDate = GetDateTimeFromString(reader["post_time"].ToString());
                rep.FirmName = reader["debitor_name"].ToString();
                rep.dbtr_id = reader["dbtr_id"].ToString();
                rep.subj_id = reader["org_name"].ToString();
                rep.fact_id = reader["org_id"].ToString();
                rep.DocNo = reader["cred"].ToString();
                rep.kred_id = reader["kred_id"].ToString();
                rep.Debt = GetIntFromString(reader["debt_sum"].ToString());
                rep.status = reader["status"].ToString();
                rep.Reg = reader["post_time"].ToString();
                rep.K1 = (decimal)reader["K1"];
                rep.fund = (decimal)reader["debt_financing_ratio"];
                rep.first = (decimal)reader["debt_first_pay_sum"];
                rep.regrs = (int)reader["factoring_buyout_conditions"] != 0;
                rep.regrsdt = GetDateTimeFromString(reader["debt_regress_date"].ToString());
                rep.tx = (int)reader["debt_vat"] != 0;
                rep.color = setColor("1", "a");
                var dt1 = (rep.DebtDate - rep.AgreementDate.AddDays(1)).Days;
                var kom1 = rep.K1 * rep.Quant;
                var kom2 = rep.K2 * dt1 * rep.first / 36500;
                var kom3 = rep.K3 * rep.Debt / 100;
                var kom4 = rep.K4* rep.free* rep.first / 36500;
                decimal ef = 0; try { ef = (kom2 + kom1 + kom3 + (kom1 + kom3) * (rep.K2 / 100) * dt1 / 365) / (rep.first * dt1 / 365); } catch (Exception) { }
                var vat = 0; if (rep.tx) vat = 1;
                foreach (var lt in ligths)
                {
                    switch (lt.name)
                    {
                        case "1": //Сумма требований
                            if (valComp(rep.Debt, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "3": //Коэффициент финансирования
                            if (valComp(rep.fund, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "4": //Первый платеж
                            if (valComp(rep.first, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "5": //Регресс
                            if (rep.regrs && (lt.value == "да" || lt.value == "Да"))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "6": //Срок регресса, дней
                            if ((rep.regrsdt - @DateTime.Now).Days > int.Parse(lt.value))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "8": //Ставка комиссии 1
                            if (valComp(rep.K1, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "10": //ком 1
                            if (valComp(kom1, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "11": //Ставка комиссии 2
                            if (valComp(rep.K2, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "12": //DT1
                            if (valComp(dt1, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "14": //ком 2
                            if (valComp(kom2, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "15": //Ставка комиссии 3
                            if (valComp(rep.K3, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "16": //ком 3
                            if (valComp(kom3, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                        case "18": //Ставка комиссии 4
                            if (valComp(rep.K4, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "19": //ком 4
                            if (valComp(kom4, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "21": //Первый платеж за минусом удержания
                                if (valComp(rep.first-kom1-kom3, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "22": //Эффективная ставка
                                if (valComp(ef, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "23": //НДС
                                if (valComp(vat, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "24": //Сумма НДС по к2
                                if (valComp(kom2 * 12 / 100, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                       case "25": //Сумма НДС по к4
                                if (valComp(kom4 * 12 / 100, decimal.Parse(lt.value), lt.logic))
                                rep.color = setColor(lt.color, rep.color);
                            break;
                    }
                }

                reports.Add(rep);
            }

            reader.Close();
            }

            var model = new OrdersViewModel();
            model.Orders = reports;
            ViewBag.Role = result;
            ViewBag.Mark = market_id;
            ViewBag.Count = GetCount();
            ViewBag.Firm = GetFirmName();
            ViewBag.login_type = Session["Token"];
            return View(model);
        }

        public ActionResult Compet(int? market_id)
        {
            var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
            if (role == -4)
            {
                ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
                return View("Error");
            }
            var user = User.Identity.GetUserId();

            string query = $"SELECT t1.*, t2.condition_name FROM conditions_lights t1 LEFT JOIN conditions_list t2 ON t1.condition_id = t2.condition_list_id WHERE user_id ='{user}';";
            var reader = Provider.RunQuery(query);

            var ligths = new List<Light>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new Light
                    {
                        Id = (int)reader["condition_light_id"],
                        //ReportNumber = reader["rep_number"].ToString()
                    };
                    //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                    //rep.AgreementDate = GetDateTimeFromString(reader["post_time"].ToString());
                    rep.name = reader["condition_id"].ToString();
                    rep.color = reader["condition_color"].ToString();
                    rep.logic = reader["condition_logical"].ToString();
                    rep.value = reader["condition_value"].ToString();
                    rep.is_active = (int)reader["condition_status"] != 0;
                    ligths.Add(rep);
                }
                reader.Close();
            }

            query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunScalar(query);

            if (result == 1)
            {
                if (market_id == null)
                    query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    "LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    "LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    "LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    "WHERE status > '-1' AND competition = '1' ORDER BY debt_id DESC;";
                else query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t8.org_id as kred_id, t7.org_id as dbtr_id " +
                    $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $"LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    $"WHERE status > '-1' AND competition = '1' AND debt_marketplace='{market_id}' ORDER BY debt_id DESC;";
            }
            else if (result == 2)
            {
                if (market_id == null)
                    query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id  " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    "LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    "LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    "LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    "WHERE t1.user_id ='" + user + "' AND competition = '1' ORDER BY post_time DESC";
                else query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id  " +
                    $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $"LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    $"WHERE t1.user_id ='{user}' AND competition = '1' AND debt_marketplace='{market_id}' ORDER BY post_time DESC;";
            }
            else
            {
                query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t6.org_name, t8.org_name as cred, t8.org_id as kred_id, t9.org_id as dbtr_id " +
                    $"FROM debts t1 left join debitors t2 ON t1.debitor_id = t2.debitor_id left join " +
                    $"organizations t3 on t2.debitor_bin = t3.org_code left join persons t4 on " +
                    $"t3.org_id = t4.org_id LEFT JOIN persons t5 ON t1.subj_id = t5.subj_id LEFT " +
                    $"JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                    $"LEFT JOIN organizations t9 ON t2.debitor_bin = t9.org_code " +
                    $"WHERE t4.user_id = '{user}' AND AND competition = '1' t1.debt_confirmation='1' AND status != '-1' AND status != '-2' ORDER BY post_time DESC;";
            }
            reader = Provider.RunQuery(query);

            var reports = new List<OrderModel>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new OrderModel
                    {
                        Id = reader["debt_id"].ToString(),
                        //ReportNumber = reader["rep_number"].ToString()
                    };
                    //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                    //rep.AgreementDate = GetDateTimeFromString(reader["post_time"].ToString());
                    rep.FirmName = reader["debitor_name"].ToString();
                    rep.dbtr_id = reader["dbtr_id"].ToString();
                    rep.subj_id = reader["org_name"].ToString();
                    rep.fact_id = reader["org_id"].ToString();
                    rep.DocNo = reader["cred"].ToString();
                    rep.kred_id = reader["kred_id"].ToString();
                    rep.Debt = GetIntFromString(reader["debt_sum"].ToString());
                    rep.status = reader["status"].ToString();
                    rep.Reg = reader["post_time"].ToString();
                    rep.K1 = (decimal)reader["K1"];
                    rep.fund = (decimal)reader["debt_financing_ratio"];
                    rep.first = (decimal)reader["debt_first_pay_sum"];
                    rep.regrs = (int)reader["factoring_buyout_conditions"] != 0;
                    rep.regrsdt = GetDateTimeFromString(reader["debt_regress_date"].ToString());
                    rep.color = setColor("1", "a");
                    foreach (var lt in ligths)
                    {
                        switch (lt.name)
                        {
                            case "1": //Сумма требований
                                if (valComp(rep.Debt, decimal.Parse(lt.value), lt.logic))
                                    rep.color = setColor(lt.color, rep.color);
                                break;
                            case "3": //Коэффициент финансирования
                                if (valComp(rep.fund, decimal.Parse(lt.value), lt.logic))
                                    rep.color = setColor(lt.color, rep.color);
                                break;
                            case "4": //Первый платеж
                                if (valComp(rep.first, decimal.Parse(lt.value), lt.logic))
                                    rep.color = setColor(lt.color, rep.color);
                                break;
                            case "5": //Регресс
                                if (rep.regrs && (lt.value == "да" || lt.value == "Да"))
                                    rep.color = setColor(lt.color, rep.color);
                                break;
                            case "6": //Срок регресса, дней
                                if ((rep.regrsdt - @DateTime.Now).Days > int.Parse(lt.value))
                                    rep.color = setColor(lt.color, rep.color);
                                break;
                            case "8": //Ставка комиссии 1
                                if (valComp(rep.K1, decimal.Parse(lt.value), lt.logic))
                                    rep.color = setColor(lt.color, rep.color);
                                break;

                        }
                    }

                    reports.Add(rep);
                }

                reader.Close();
            }

            var model = new OrdersViewModel();
            model.Orders = reports;
            ViewBag.Role = result;
            ViewBag.Mark = market_id;
            ViewBag.Count = GetCount();
            ViewBag.Firm = GetFirmName();
            return View(model);
        }

        public static bool valComp(decimal inp, decimal col, string cmp)
        {
            int res = 0;
            switch (cmp)
            {
                case "==":
                    if (inp == col) res = 1;
                    break;
                case ">":
                    if (inp > col) res = 1;
                    break;
                case "<":
                    if (inp < col) res = 1;
                    break;
                case ">=":
                    if (inp >= col) res = 1;
                    break;
                case "<=":
                    if (inp <= col) res = 1;
                    break;
            }

            if (res == 1) return true;
            else return false;
        }

        public string setColor(string col, string comp )
        {
            if (comp == "Красный") return "Красный";
            else if (comp == "Желтый")
            {
                if (col == "2") { return "Желтый"; };
                if (col == "3") { return "Красный"; };
            } else { 
            if (col == "1") { return "Зеленый"; };
            if (col == "2") { return "Желтый"; };
            if (col == "3") { return "Красный"; };
            }
            return "Зеленый";
        }

        public ActionResult Calculator(string id, int? bid)
        {
            var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
            if (role == -4)
            {
                ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
                return View("Error");
            }
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunScalar(query);
            if (result == 1)
            {
                query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id WHERE status !='-1' ORDER BY debt_id DESC;";
            }
            else {
                query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id WHERE user_id ='" + user + "' ORDER BY debt_id DESC;";
            }
                var reader = Provider.RunQuery(query);

            var reports = new List<OrderModel>();
            if (reader != null) { 
            while (reader.Read())
            {
                var rep = new OrderModel
                {
                    Id = reader["debt_id"].ToString(),
                    //ReportNumber = reader["rep_number"].ToString()
                };
                //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                //rep.AgreementDate = GetDateTimeFromString(reader["post_time"].ToString());
                rep.FirmName = reader["debitor_name"].ToString();                
                rep.Debt = GetIntFromString(reader["debt_sum"].ToString());     
                rep.status = reader["status"].ToString();
                rep.Reg = reader["post_time"].ToString();
                reports.Add(rep);
            }
            reader.Close();
            }
            ViewBag.Orders = reports;
            ViewBag.Count = GetCount();
            ViewBag.Firm = GetFirmName();
            if (id != null)
            {
                query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id  WHERE debt_id ='" + id + "';";
                reader = Provider.RunQuery(query);
                var model = new OrderModel { Id = "" };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        model.Agreement = reader["debt_number"].ToString();
                        model.Id = reader["debt_id"].ToString();
                        model.subj_id = reader["subj_id"].ToString();
                        model.AgreementDate = GetDateTimeFromString(reader["debt_date"].ToString());
                        model.DebtDate = GetDateTimeFromString(reader["debt_pay_date"].ToString());
                        model.Debt = (decimal)reader["debt_sum"];
                        model.Reg = reader["register"].ToString();
                        model.Quant = (int)reader["quant"];
                        model.Address = reader["debitor_address"].ToString();
                        model.Contacts = reader["contact"].ToString();
                        model.Debt = GetIntFromString(reader["debt_sum"].ToString()); //, , 
                        model.proof = (int)reader["debt_confirmation"] != 0;
                        model.late = (int)reader["debt_delay"] != 0;
                        model.typic = (int)reader["debt_typical_conditions"] != 0;
                        model.regrs = (int)reader["factoring_buyout_conditions"] != 0;
                        model.revrs = (int)reader["factoring_reverse"] != 0;
                        model.opn = (int)reader["factoring_open_close"] != 0;
                        model.ratedt = GetDateTimeFromString(reader["debt_value_date"].ToString());
                        model.K1 = (decimal)reader["K1"];
                        model.K2 = (decimal)reader["K2"];
                        model.K3 = (decimal)reader["K3"];
                        model.K4 = (decimal)reader["K4"];
                        model.fund = (decimal)reader["debt_financing_ratio"];
                        model.first = (decimal)reader["debt_first_pay_sum"];
                        model.free = (int)reader["debt_grace_period"];
                        model.regrsdt = GetDateTimeFromString(reader["debt_regress_date"].ToString());
                        model.tx = (int)reader["debt_vat"] != 0;
                        model.FirmName = reader["debitor_name"].ToString();
                        model.Bin = reader["debitor_bin"].ToString();
                        model.DocNo = reader["doc_id"].ToString();
                        model.status = reader["status"].ToString();
                    }
                    reader.Close();
                }
                ViewBag.Inv = GetInvoices(model.Reg);
                ViewBag.docid = model.DocNo;
                ViewBag.Files = DisplayFiles(model.DocNo);
                if (bid != null)
                {
                    query = "SELECT t3.*, t2.org_name, t2.org_id, t7.org_id as debitor_id, t5.debitor_name FROM bidding t3 LEFT JOIN persons t1 ON t3.user_id=t1.user_id " +
                    "LEFT JOIN organizations t2 ON t1.org_id = t2.org_id LEFT JOIN debts t4 ON t3.debt_id = t4.debt_id " +
                    "LEFT JOIN debitors t5 ON t4.debitor_id = t5.debitor_id LEFT JOIN organizations t7 ON t5.debitor_bin = t7.org_code WHERE t3.debt_id ='" + id + "';";
                    //SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id = '" + user + "'; "
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            model.fund = (decimal)reader["debt_financing_ratio"];
                            //rep.debt_pay_date = GetDateTimeFromString(reader["debt_pay_date"].ToString());
                            model.late = (int)reader["debt_delay"] != 0;
                            model.typic = (int)reader["debt_typical_conditions"] != 0;
                            model.regrs = (int)reader["factoring_buyout_conditions"] != 0;
                            model.revrs = (int)reader["factoring_reverse"] != 0;
                            model.opn = (int)reader["factoring_open_close"] != 0;
                            model.ratedt = GetDateTimeFromString(reader["debt_value_date"].ToString());
                            model.K1 = (decimal)reader["k1"];
                            model.K2 = (decimal)reader["k2"];
                            model.K3 = (decimal)reader["k3"];
                            model.K4 = (decimal)reader["k4"];
                            model.first = (decimal)reader["debt_first_pay_sum"];
                            //rep.debt_regress_date = GetDateTimeFromString(reader["debt_regress_date"].ToString());
                            model.tx = (int)reader["debt_vat"] != 0;
                            //rep.debt_pay_date = GetDateTimeFromString(reader["debt_pay_date"].ToString());
                        }
                        reader.Close();
                    }
                }
                return View(model);
            }
            return View();
        }

        public static OrderModel getord(int id)
        {
            var query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_name " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    "LEFT JOIN persons t3 ON t1.user_id = t3.user_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id WHERE debt_id ='" + id + "';";
            var reader = Provider.RunQuery(query);
            var model = new OrderModel { Id = "" };
            while (reader.Read())
            {
                model.Agreement = reader["debt_number"].ToString();
                model.Id = reader["debt_id"].ToString();
                model.subj_id = reader["subj_id"].ToString();
                model.AgreementDate = GetDateTimeFromString(reader["debt_date"].ToString());
                model.DebtDate = GetDateTimeFromString(reader["debt_pay_date"].ToString());
                model.Debt = (decimal)reader["debt_sum"];
                model.Reg = reader["register"].ToString();
                model.Quant = (int)reader["quant"];
                model.Address = reader["debitor_address"].ToString();
                model.Contacts = reader["contact"].ToString();
                model.Debt = GetIntFromString(reader["debt_sum"].ToString()); //, , 
                model.proof = (int)reader["debt_confirmation"] != 0;
                model.late = (int)reader["debt_delay"] != 0;
                model.typic = (int)reader["debt_typical_conditions"] != 0;
                model.regrs = (int)reader["factoring_buyout_conditions"] != 0;
                model.revrs = (int)reader["factoring_reverse"] != 0;
                model.opn = (int)reader["factoring_open_close"] != 0;
                model.ratedt = GetDateTimeFromString(reader["debt_value_date"].ToString());
                model.K1 = (decimal)reader["K1"];
                model.K2 = (decimal)reader["K2"];
                model.K3 = (decimal)reader["K3"];
                model.K4 = (decimal)reader["K4"];
                model.fund = (decimal)reader["debt_financing_ratio"];
                model.first = (decimal)reader["debt_first_pay_sum"];
                model.free = (int)reader["debt_grace_period"];
                model.regrsdt = GetDateTimeFromString(reader["debt_regress_date"].ToString());
                model.tx = (int)reader["debt_vat"] != 0;
                model.cmp = (int)reader["competition"] != 0;
                model.FirmName = reader["debitor_name"].ToString();
                model.Bin = reader["debitor_bin"].ToString();
                model.DocNo = reader["doc_id"].ToString();
                model.status = reader["status"].ToString();
                model.debit_confirm = reader["debitor_confirm"].ToString();
                model.Creditor_name = reader["org_name"].ToString();
            }
            reader.Close();
            return model;
        }

        public ActionResult NewOrder(int? id)
        {
            var user = User.Identity.GetUserId();
            ViewBag.Count = GetCount();
            ViewBag.Firm = GetFirmName();
            var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
            if (role == -4) { 
                ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
                return View("Error");
            }
            var model = new OrderModel { Id = "" };

            string query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunScalar(query);
            query = "SELECT subj_id FROM persons WHERE user_id ='" + user + "';";
            ViewBag.subj_id = Provider.RunQueryStr(query);
            if (Session["Token"] != null)
            ViewBag.login_type = Session["Token"];
            else ViewBag.login_type = "0";
            if (id != null)
            {
                model = getord((int)id);
                ViewBag.Inv = GetInvoices(model.Id);
                ViewBag.docid = model.DocNo;
                ViewBag.Role = result;                
                ViewBag.Files = DisplayFiles(model.DocNo);
                ViewBag.Types = getTypes();
                return View(model);
            }
            else
            {
                ViewBag.docid = DateTime.Now.ToFileTime();
                ViewBag.Inv = GetInvoices(" ");
                ViewBag.Files = DisplayFiles("0");
                ViewBag.Role = result;
                ViewBag.Types = getTypes();
                return View(model);
            }            
        }

        public List<Inv> GetInvoices(string id)
        {
            //lock (Provider.Locker)
            {
                string query = "SELECT * FROM invoices WHERE debt_id ='" + id + "';";
                var reader = Provider.RunQuery(query);

                var selListMsg = new List<Inv> { new Inv { Id = new int()} };
                if (reader != null)
                {
                    while (reader.Read())
                    {                        
                        selListMsg.Add(new Inv { Id = (int)reader["invoice_id"], Deb = reader["invoice_debitor"].ToString(),
                            dDebt = (decimal)reader["invoice_sum"],
                            Debt = reader["invoice_sum"].ToString(), Num = reader["invoice_num"].ToString(), Payd = (int)reader["invoice_payed"] != 0, 
                        Date = GetDateTimeFromString(reader["invoice_date"].ToString()), DocType = reader["doc_type"].ToString(), DocNo = reader["doc_no"].ToString()
                        });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    return selListMsg;
                }
                return selListMsg;
            }

        }

        public List<string> getTypes()
        {
            var list = new List<string>();
            string query = "SELECT * FROM doc_types;";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.Add(reader["doc_type_name"].ToString());
                }
                reader.Close();
                //ViewBag.allUsers = selListMsg;
            }
            return list;

        }

        public List<NewsModel> DisplayFiles(string cid)
        {
            //lock (Provider.Locker)
            {
                string query = "SELECT id, img_file_name, doc_img_date FROM docimages WHERE doc_guid ='" + cid + "';";
                var reader = Provider.RunQuery(query);

                var selListMsg = new List<NewsModel> { new NewsModel { NewsID = new int(), Title = "", Date = new System.DateTime() } };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        selListMsg.Add(new NewsModel { NewsID = (int)reader["id"], Title = reader["img_file_name"].ToString(), Date = System.DateTime.Parse(reader["doc_img_date"].ToString()) });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    return selListMsg;
                }
                return selListMsg;
            }

        }
        public static DateTime AddBusinessDays(DateTime date, int days)
        {/*
            if (days < 0)
            {
                return date;
            }
            if (days == 0) return date;
            if (date.DayOfWeek == DayOfWeek.Saturday)
            {
                date = date.AddDays(2);
                days -= 1;
            }
            else if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                date = date.AddDays(1);
                days -= 1;
            }
            date = date.AddDays(days / 5 * 7);
            int extraDays = days % 5;
            if ((int)date.DayOfWeek + extraDays > 5)
            {
                extraDays += 2;
            }
            return date.AddDays(extraDays);*/
            if (days <= 0) return date;
            date = date.AddDays(days);
            var query = $"SELECT COUNT(*) FROM holidays WHERE holiday_date = '{date}';";
            var holy = Provider.RunScalar(query);
            if (holy > 0)
                date = date.AddDays(holy);

            if (date.DayOfWeek == DayOfWeek.Saturday)
            {
                date = date.AddDays(2);
                //days -= 1;
            }
            else if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                date = date.AddDays(1);
                //days -= 1;
            }
            query = $"SELECT COUNT(*) FROM holidays WHERE holiday_date = '{date}';";
            holy = Provider.RunScalar(query);
            if (holy > 0)
                date = date.AddDays(holy);
            return date;
        }

        public string AddWorkDays(string date, int days)
        {
            if (days <= 0) return date;
            var dt = GetDateTimeFromString(date);
            dt = dt.AddDays(days);
            var query = $"SELECT COUNT(*) FROM holidays WHERE holiday_date = '{dt}';";
            var holy = Provider.RunScalar(query);
            if (holy > 0)
            dt = dt.AddDays(holy);

            if (dt.DayOfWeek == DayOfWeek.Saturday)
            {
                dt = dt.AddDays(2);
                //days -= 1;
            }
            else if (dt.DayOfWeek == DayOfWeek.Sunday)
            {
                dt = dt.AddDays(1);
                //days -= 1;
            }
            query = $"SELECT COUNT(*) FROM holidays WHERE holiday_date = '{dt}';";
            holy = Provider.RunScalar(query);
            if (holy > 0)
                dt = dt.AddDays(holy);
            return dt.ToString("dd.MM.yyyy");
            //return "abc";
        }
        [HttpPost]
        public ActionResult NewOrder(OrderModel model, IList<Inv> list, string submitButton)
        {
            var status = submitButton;
            string query = $"SELECT debitor_id FROM debitors WHERE debitor_bin ='{model.Bin}';";
            var debtr = Provider.RunScalar(query);
            if (debtr < 0)
                { 
                query = $"INSERT INTO debitors (debitor_bin, debitor_name, debitor_address) VALUES ('{model.Bin}', '{model.FirmName}', '{model.Address}') RETURNING debitor_id;";
                debtr = Provider.RunScalar(query);
            }
            //model.Address, model.Agreement, model.Bin, model.Contacts, model.Debt, model.DebtDate, model.FirmName, model.Quant, model.Reg, model.first, model.free, model.fund
            var user = User.Identity.GetUserId();
            NumberFormatInfo nfi = new CultureInfo("nb-NO", false).NumberFormat;
            nfi.CurrencyPositivePattern = 0;
            nfi.CurrencyDecimalSeparator = ".";
            model.Debt = decimal.Parse(model.Debtstr, NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint | NumberStyles.AllowCurrencySymbol, nfi);
            query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var role = Provider.RunScalar(query);
            model.first = model.fund * model.Debt/100;
            var d1 = model.AgreementDate.ToString("yyyy.MM.dd");
            var d2 = model.DebtDate.ToString("yyyy.MM.dd");
            var d3 = model.ratedt.ToString("yyyy.MM.dd");
            var d6 = AddBusinessDays(model.DebtDate, model.free);
            var d4 = d6.ToString("yyyy.MM.dd");
            query = $"SELECT COUNT(*) FROM holidays WHERE holiday_date BETWEEN '{d2}' AND '{d4}';";
            var holy = Provider.RunScalar(query);
            if (holy > 0)
                d4 = d6.AddDays(holy).ToString("yyyy.MM.dd");
            if (role == 1 && model.Id != null)
            {
                query = $"UPDATE debts SET (factoring_buyout_conditions, factoring_reverse, factoring_open_close, debt_value_date, " +
                    $"\"K1\", \"K2\",\"K3\", \"K4\", debt_financing_ratio, debt_first_pay_sum, debt_grace_period, debt_regress_date, debt_vat, competition) " +
                $"=('{Convert.ToInt16(model.regrs)}', '{Convert.ToInt16(model.revrs)}','{Convert.ToInt16(model.opn)}', '{d3}', '{model.K1}', " +
                $"'{model.K2}', '{model.K3}', '{model.K4}', '{model.fund}','{model.first}', '{model.free}', '{d4}', '{Convert.ToInt16(model.tx)}', '{Convert.ToInt16(model.cmp)}') " +
                $"WHERE debt_id='{model.Id}';";
                Provider.RunNonQuery(query);
                return RedirectToAction("Orders");
            }
            int market = 0;

            if (model.late) market = 3;
            else if (model.proof) market = 1; else market = 2;
            if (model.proof && status == "0") status = "3";
            if (model.Id == null)
            {
                query = $"INSERT INTO debts (debt_marketplace, doc_id, debt_number, debt_date, debt_sum, debt_pay_date, register, quant, debt_confirmation, " +
                    $"debt_delay, debt_typical_conditions, factoring_buyout_conditions, status," +
                    $"factoring_reverse, factoring_open_close, debt_value_date, \"K1\", \"K2\",\"K3\", \"K4\", debt_financing_ratio, " +
                    $"debt_first_pay_sum, debt_grace_period, debt_regress_date, debt_vat, competition, user_id, debitor_id, contact, post_time) " +
                           $"VALUES('{market}', '{model.DocNo}', '{model.Agreement}', '{d1}', '{model.Debt}', '{d2}','{model.Reg}'," +
                           $"'{model.Quant}','{Convert.ToInt16(model.proof)}', '{Convert.ToInt16(model.late)}', '{Convert.ToInt16(model.typic)}'," +
                           $"'{Convert.ToInt16(model.regrs)}', '{status}', '{Convert.ToInt16(model.revrs)}','{Convert.ToInt16(model.opn)}', " +
                           $"'{d3}', '{model.K1}', '{model.K2}', '{model.K3}', '{model.K4}', " +
                           $"'{model.fund}','{model.first}', '{model.free}', '{d4}', '{Convert.ToInt16(model.tx)}', '{Convert.ToInt16(model.cmp)}', " +
                           $"'{user}', '{debtr}', '{model.Contacts}', 'NOW()') RETURNING debt_id;";
                model.Id = Provider.RunScalar(query).ToString();
                if (model.cmp == true) //bidding added
                {
                    query = $"SELECT t1.user_id FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE org_type ='1';";
                    var Names = new List<string> { };
                    var reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            Names.Add(reader["user_id"].ToString());
                        }
                        reader.Close();
                        foreach (var fn in Names)
                        {
                            NotificationHelper.AddNotification(new Notification()
                            {
                                Type = NotificationType.NewBid,
                                CreatorId = User.Identity.GetUserId(),
                                RecipientId = fn,
                                CreationDate = DateTime.Now,
                                ObjectId = int.Parse(model.Id)
                            });
                        }
                    }
                }
                if (status == "3")
                {
                    query = $"SELECT t1.user_id FROM persons t1 LEFT JOIN organizations t2 on t1.org_id=t2.org_id " +
                        $"WHERE org_code =(SELECT debitor_bin FROM debitors WHERE debitor_id='{debtr}');";
                    var DebitorNames = new List<string> { };
                    var reader = Provider.RunQuery(query);
                    if (reader != null) { 
                     while (reader.Read())
                    {
                        DebitorNames.Add(reader["user_id"].ToString());
                    }
                        reader.Close();
                    foreach (var dn in DebitorNames) { 
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.RequestApprovalProfile,
                        CreatorId = User.Identity.GetUserId(),
                        RecipientId = dn, //!!
                        CreationDate = DateTime.Now,
                        ObjectId = int.Parse(model.Id)
                    });
                    }
                    }
                }
            }
            else
            {
                string firmname = GetFirmName();
                var modelToCompare = getord(int.Parse(model.Id));/*
                if (modelToCompare.Agreement != model.Agreement)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt number', '{model.Agreement}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.Debt != model.Debt)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt sum', '{model.Debt}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.DebtDate != model.DebtDate)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt pay date', '{model.DebtDate}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.AgreementDate != model.AgreementDate)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt date', '{model.AgreementDate}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.Reg != model.Reg)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'register', '{model.Reg}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }
                if(modelToCompare.Quant != model.Quant)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'quantity', '{model.Quant}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.proof != model.proof)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt confirmation', '{model.proof}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }*/
                if (modelToCompare.late != model.late)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt delay', '{model.late}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.typic != model.typic)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt typical conditions', '{model.typic}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.regrs != model.regrs)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'factoring buyout conditions', '{model.regrs}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.revrs != model.revrs)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'factoring reverse', '{model.revrs}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if(modelToCompare.opn != model.opn)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'factoring open close', '{model.opn}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }/*
                if (modelToCompare.regrsdt != model.regrsdt)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt regress date', '{model.regrsdt}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }*/
                if (modelToCompare.K1 != model.K1)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'K1', '{model.K1}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.K2 != model.K2)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'K2', '{model.K2}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.K3 != model.K3)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'K3', '{model.K3}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.K4 != model.K4)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'K4', '{model.K4}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.fund != model.fund)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt financing ratio', '{model.fund}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.first != model.first)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt first pay sum', '{model.first}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }
                if (modelToCompare.free != model.free)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt grace period', '{model.free}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }/*
                if (modelToCompare.ratedt != model.ratedt)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt value date', '{model.ratedt}', 'NOW()', '{user}'); ";
                    Provider.RunScalar(query);
                }*/
                if (modelToCompare.tx != model.tx)
                {
                    query = $"INSERT INTO invoices_history(invoice_id, invoise_history_param, invoise_history_param_value, invoise_history_param_date, invoise_history_param_user) " +
                        $"VALUES('{model.Id}', 'debt vat', '{model.tx}', 'NOW()', '{firmname}'); ";
                    Provider.RunScalar(query);
                }

                query = $"UPDATE debts SET (debt_marketplace, debt_number, debt_date, debt_sum, debt_pay_date, register, quant, debt_confirmation, " +
    $"debt_delay, debt_typical_conditions, factoring_buyout_conditions, status," +
    $"factoring_reverse, factoring_open_close, debt_value_date, \"K1\", \"K2\",\"K3\", \"K4\", debt_financing_ratio, " +
    $"debt_first_pay_sum, debt_grace_period, debt_regress_date, debt_vat, competition, user_id, debitor_id, contact) " +
           $"=('{market}', '{model.Agreement}', '{d1}', '{model.Debt}', '{d2}','{model.Reg}'," +
           $"'{model.Quant}','{Convert.ToInt16(model.proof)}', '{Convert.ToInt16(model.late)}', '{Convert.ToInt16(model.typic)}'," +
           $"'{Convert.ToInt16(model.regrs)}', '{status}', '{Convert.ToInt16(model.revrs)}','{Convert.ToInt16(model.opn)}', " +
           $"'{d3}', '{model.K1}', '{model.K2}', '{model.K3}', '{model.K4}', " +
           $"'{model.fund}','{model.first}', '{model.free}', '{d4}', '{Convert.ToInt16(model.tx)}', '{Convert.ToInt16(model.cmp)}', " +
           $"'{user}', '{debtr}', '{model.Contacts}') WHERE debt_id='{model.Id}';";
                Provider.RunNonQuery(query);

                if (status == "3" && (model.debit_confirm == null || model.debit_confirm == ""))
                {
                    query = $"SELECT t1.user_id FROM persons t1 LEFT JOIN organizations t2 on t1.org_id=t2.org_id " +
                        $"WHERE org_code =(SELECT debitor_bin FROM debitors WHERE debitor_id='{debtr}');";
                    var DebitorNames = new List<string> { };
                    var reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            DebitorNames.Add(reader["user_id"].ToString());
                        }
                        reader.Close();
                        foreach (var dn in DebitorNames)
                        {
                            NotificationHelper.AddNotification(new Notification()
                            {
                                Type = NotificationType.RequestApprovalProfile,
                                CreatorId = User.Identity.GetUserId(),
                                RecipientId = dn, //!!
                                CreationDate = DateTime.Now,
                                ObjectId = int.Parse(model.Id)
                            });
                        }
                    }
                }
            }
            
            if (list != null)
            foreach (var ln in list)
            {   ln.dDebt = decimal.Parse(ln.Debt, NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint | NumberStyles.AllowCurrencySymbol, nfi);
                    var d5 = ln.Date.ToString("yyyy.MM.dd");
                query = $"INSERT INTO invoices (debt_id, invoice_num, invoice_sum, invoice_reestr, invoice_date, invoice_payed, invoice_debitor, doc_type, doc_no) " +
                $"VALUES('{model.Id}', '{ln.Num}', '{ln.dDebt}', '{model.Reg}', '{d5}', '{Convert.ToInt16(ln.Payd)}', '{ln.Deb}', '{ln.DocType}', '{ln.DocNo}');";
                Provider.RunNonQuery(query);
            }
            //if (status < 0) return View(); 
            //else
            //{
            query = $"INSERT INTO log (log_date, log_text, log_section, log_source_user_id, log_doc_id) " +
                        $"VALUES('NOW()', 'new order created', 'orders', '{user}', '{model.Id}');";
            Provider.RunNonQuery(query);
                return RedirectToAction("Orders");
            //}
            
        }

        [HttpPost]
        public string CopyOrder(OrderModel model, IList<Inv> list, string path)
        { 
            var status = "-2";
            string query = $"SELECT debitor_id FROM debitors WHERE debitor_bin ='{model.Bin}';";
            var debtr = Provider.RunScalar(query);
            if (debtr < 0)
            {
                query = $"INSERT INTO debitors (debitor_bin, debitor_name, debitor_address) VALUES ('{model.Bin}', '{model.FirmName}', '{model.Address}') RETURNING debitor_id;";
                debtr = Provider.RunScalar(query);
            }
            var copyinv = GetInvoices(model.Id);
            var user = User.Identity.GetUserId();
            int market = 0;
            var d1 = model.AgreementDate.ToString("yyyy.MM.dd");
            var d2 = model.DebtDate.ToString("yyyy.MM.dd");
            var d3 = model.ratedt.ToString("yyyy.MM.dd");
            var d4 = model.regrsdt.ToString("yyyy.MM.dd");
            if (model.late) market = 3;
            else if (model.proof) market = 1; else market = 2;
            if (model.proof && status == "0") status = "3";
            if (true)
            {
                query = $"INSERT INTO debts (debt_marketplace, doc_id, debt_number, debt_date, debt_sum, debt_pay_date, register, quant, debt_confirmation, " +
                    $"debt_delay, debt_typical_conditions, factoring_buyout_conditions, status," +
                    $"factoring_reverse, factoring_open_close, debt_value_date, \"K1\", \"K2\",\"K3\", \"K4\", debt_financing_ratio, " +
                    $"debt_first_pay_sum, debt_grace_period, debt_regress_date, debt_vat, user_id, debitor_id, contact, post_time, competition) " +
                           $"VALUES('{market}', '{model.DocNo}', '{model.Agreement}', '{d1}', '{model.Debt}', '{d2}','{model.Reg}'," +
                           $"'{model.Quant}','{Convert.ToInt16(model.proof)}', '{Convert.ToInt16(model.late)}', '{Convert.ToInt16(model.typic)}'," +
                           $"'{Convert.ToInt16(model.regrs)}', '{status}', '{Convert.ToInt16(model.revrs)}','{Convert.ToInt16(model.opn)}', " +
                           $"'{d3}', '{model.K1}', '{model.K2}', '{model.K3}', '{model.K4}', " +
                           $"'{model.fund}','{model.first}', '{model.free}', '{d4}', '{Convert.ToInt16(model.tx)}', " +
                           $"'{user}', '{debtr}', '{model.Contacts}', 'NOW()', '{model.cmp}') RETURNING debt_id;";
                model.Id = Provider.RunScalar(query).ToString();
            }

            if (list != null)
                foreach (var ln in list)
                {
                    var d5 = ln.Date.ToString("yyyy.MM.dd");
                    query = $"INSERT INTO invoices (debt_id, invoice_num, invoice_sum, invoice_reestr, invoice_date, invoice_payed, invoice_debitor) " +
                    $"VALUES('{model.Id}', '{ln.Num}', '{ln.Debt}', '{model.Reg}', '{d5}', '{Convert.ToInt16(ln.Payd)}', '{ln.Deb}');";
                    Provider.RunNonQuery(query);
                }
            if(copyinv.Count > 0)
                foreach (var ln in copyinv)
                {
                    var d5 = ln.Date.ToString("yyyy.MM.dd");
                    query = $"INSERT INTO invoices (debt_id, invoice_num, invoice_sum, invoice_reestr, invoice_date, invoice_payed, invoice_debitor) " +
                    $"VALUES('{model.Id}', '{ln.Num}', '{ln.Debt}', '{model.Reg}', '{d5}', '{Convert.ToInt16(ln.Payd)}', '{ln.Deb}');";
                    if (ln.Debt != "" && ln.Debt != null)
                    Provider.RunNonQuery(query);
                }
            query = $"INSERT INTO log (log_date, log_text, log_section, log_source_user_id, log_doc_id) " +
                        $"VALUES('NOW()', 'order copy created', 'orders', '{user}', '{model.Id}');";
            Provider.RunNonQuery(query);
            return model.Id;
            //}

        }

        public ActionResult Book(string id)
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT persons.subj_id FROM persons WHERE user_id ='" + user + "';";
            var readr = Provider.RunQueryStr(query);

            query = $"UPDATE debts SET subj_id='{readr}', status='1' WHERE debt_id='{id}' RETURNING user_id;";
            string personId = Provider.RunQueryStr(query);

            query = $"SELECT user_id FROM persons WHERE org_id =(SELECT org_id FROM persons WHERE user_id='{personId}');";
            var KredNames = new List<string> { };
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    KredNames.Add(reader["user_id"].ToString());
                }
                reader.Close();
                foreach (var kn in KredNames)
                {
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.RequestEditProfileAccepted,
                        CreatorId = User.Identity.GetUserId(),
                        RecipientId = kn,
                        CreationDate = DateTime.Now,
                        ObjectId = int.Parse(id)
                    });
                }
            }

            query = $"INSERT INTO log (log_date, log_text, log_section, log_source_user_id, log_doc_id) " +
                        $"VALUES('NOW()', 'order booked', 'orders', '{user}', '{id}');";
            Provider.RunNonQuery(query);

            return RedirectToAction("Orders");
        }

        public ActionResult declineDebt(string id, string res)
        {
            var query = $"UPDATE debts SET status='-3', debitor_confirm='0', debitor_reject_reason='{res}' WHERE debt_id='{id}' RETURNING user_id;";
            string personId = Provider.RunQueryStr(query);
            var user = User.Identity.GetUserId();

            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.RequestApprovalPreviouslyRejectedReportGgup,
                CreatorId = user,
                RecipientId = personId,
                CreationDate = DateTime.Now,
                ObjectId = int.Parse(id)
            });

            query = $"INSERT INTO log (log_date, log_text, log_section, log_source_user_id, log_target_user_id, log_doc_id) " +
                        $"VALUES('NOW()', 'order declined', 'orders', '{user}', '{personId}', '{id}');";
            Provider.RunNonQuery(query);

            return RedirectToAction("Orders");
        }

        public ActionResult SignDebt(string id)
        {                                   
            var query = $"UPDATE debts SET status='5', debitor_confirm='1' WHERE debt_id='{id}' RETURNING user_id;";
            string personId = Provider.RunQueryStr(query);
            var user = User.Identity.GetUserId();

            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.AccountLockedTka,
                CreatorId = user,
                RecipientId = personId,
                CreationDate = DateTime.Now,
                ObjectId = int.Parse(id)
            });

            query = $"INSERT INTO log (log_date, log_text, log_section, log_source_user_id, log_target_user_id, log_doc_id) " +
                        $"VALUES('NOW()', 'order signed', 'orders', '{user}', '{personId}', '{id}');";
            Provider.RunNonQuery(query);

            return RedirectToAction("Orders");
        }
        //old code deprecated
        public ActionResult Sign(string id)
        {
            var query = $"UPDATE debts SET status='2' WHERE debt_id='{id}';";
            Provider.RunNonQuery(query);
            /*
            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.RequestEditProfileAccepted,
                CreatorId = User.Identity.GetUserId(),
                RecipientId = personId,
                CreationDate = DateTime.Now,
                ObjectId = int.Parse(id)
            });*/
            return RedirectToAction("Orders");
        }

        [Authorize]
        public JsonResult LoadOrders(string market_id)
        {
            var user = User.Identity.GetUserId();
            var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
            if (role == -4)
            {
                return Json("error");
            } else
            { 
            var query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunScalar(query);

            if (result == 1)
            {
                if (market_id == null)
                    query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    "LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    "LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    "LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    "WHERE status > '-1' ORDER BY debt_id DESC;";
                else query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t8.org_id as kred_id, t7.org_id as dbtr_id " +
                    $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $"LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    $"WHERE status > '-1' AND debt_marketplace='{market_id}' ORDER BY debt_id DESC;";
            }
            else if (result == 2)
            {
                if (market_id == null)
                    query = "SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id  " +
                    "FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    "LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    "LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    "LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    "WHERE t1.user_id ='" + user + "' ORDER BY post_time DESC";
                else query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t4.org_name, t6.org_name as cred, t6.org_id as kred_id, t7.org_id as dbtr_id  " +
                    $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
                    $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $"LEFT JOIN persons t5 ON t1.user_id = t5.user_id LEFT JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN organizations t7 ON t2.debitor_bin = t7.org_code " +
                    $"WHERE t1.user_id ='{user}' AND debt_marketplace='{market_id}' ORDER BY post_time DESC;";
            }
            else
            {
                query = $"SELECT t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, t4.org_id, t6.org_name, t8.org_name as cred, t8.org_id as kred_id, t9.org_id as dbtr_id " +
                    $"FROM debts t1 left join debitors t2 ON t1.debitor_id = t2.debitor_id left join " +
                    $"organizations t3 on t2.debitor_bin = t3.org_code left join persons t4 on " +
                    $"t3.org_id = t4.org_id LEFT JOIN persons t5 ON t1.subj_id = t5.subj_id LEFT " +
                    $"JOIN organizations t6 ON t5.org_id = t6.org_id " +
                    $"LEFT JOIN persons t7 ON t1.user_id = t7.user_id LEFT JOIN organizations t8 ON t7.org_id = t8.org_id " +
                    $"LEFT JOIN organizations t9 ON t2.debitor_bin = t9.org_code " +
                    $"WHERE t4.user_id = '{user}' AND t1.debt_confirmation='1' AND status != '-1' AND status != '-2' ORDER BY post_time DESC;";
            }
            var reader = Provider.RunQuery(query);

            var orders = new List<OrderModel>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new OrderModel
                    {
                        Id = reader["debt_id"].ToString(),
                        //ReportNumber = reader["rep_number"].ToString()
                    };
                    //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                    //rep.AgreementDate = GetDateTimeFromString(reader["post_time"].ToString());
                    rep.FirmName = reader["debitor_name"].ToString();
                    rep.dbtr_id = reader["dbtr_id"].ToString();
                    rep.subj_id = reader["org_name"].ToString();
                    rep.fact_id = reader["org_id"].ToString();
                    rep.DocNo = reader["cred"].ToString();
                    rep.kred_id = reader["kred_id"].ToString();
                    rep.Debt = GetIntFromString(reader["debt_sum"].ToString());
                    rep.status = reader["status"].ToString();
                    rep.Reg = reader["post_time"].ToString();
                    rep.K1 = (decimal)reader["K1"];
                    rep.fund = (decimal)reader["debt_financing_ratio"];
                    rep.first = (decimal)reader["debt_first_pay_sum"];
                    rep.regrs = (int)reader["factoring_buyout_conditions"] != 0;
                    rep.regrsdt = GetDateTimeFromString(reader["debt_regress_date"].ToString());
                    rep.color = setColor("1", "a");

                    orders.Add(rep);
                }

                reader.Close();                
                }
                return Json(orders, JsonRequestBehavior.AllowGet);
            }
        }
            public JsonResult GetDebitorsList(string Areas, string term = "")
        {
            var DebitorNames = new List<string> { };
            var query = "";
            //var query = @"SELECT ""Email"" FROM public.""AspNetUsers"" WHERE ""EmailConfirmed"" = true AND ""Email"" LIKE '"+ term + "%';";
            if (term == "")
            {
                query = @"SELECT * FROM public.debitors ORDER BY LOWER(debitor_name) ASC;";
            }
            else
            {
                query = @"SELECT * FROM public.debitors WHERE LOWER(debitor_bin) 
            LIKE LOWER('%" + term + "%') ORDER BY LOWER(debitor_name) ASC;";
            }
            var reader = Provider.RunQuery(query);
            if (reader != null) { 
            while (reader.Read())
            {
                var bin = reader["debitor_bin"].ToString();
                var name = reader["debitor_name"].ToString();
                var address = reader["debitor_address"].ToString();

                DebitorNames.Add(bin + "; " + name + "; " + address);
            }
            reader.Close();
            }
            return Json(DebitorNames, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteInvoice(string id)
        {
            var query = @"DELETE FROM public.invoices WHERE invoice_id = " + id + ";";
            var result = "OK";
            try
            {
                Provider.RunNonQuery(query);
            }
            catch (Exception ex)
            {
                result = "Error" + ex;
            }
            return Json(result);
        }

        public ActionResult Competitions()
        {
            var user = User.Identity.GetUserId();
            string role = "";

            var query = "SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunScalar(query);
            if (result == 1)
            { role = "Фактор"; }
            else if (result == 2)
            { role = "Кредитор"; }
            else if (result == 3)
            { role = "Дебитор"; }
            ViewBag.Firm = GetFirmName();
            ViewBag.Role = role;
            ViewBag.User = user;
            if (Session["Token"] != null)
                ViewBag.login_type = Session["Token"];
            else ViewBag.login_type = "0";
            return View();
        }

        public ActionResult RegisterCharges(string id)
        {
            return View(int.Parse(id));
        }

        [AllowAnonymous]
        public void Excel(string sheetName, int row, int col, string data)
        {
            Microsoft.Office.Interop.Excel.Application oXL = null;
            Microsoft.Office.Interop.Excel._Workbook oWB = null;
            Microsoft.Office.Interop.Excel._Worksheet oSheet = null;

            try
            {
                oXL = new Microsoft.Office.Interop.Excel.Application();
                oWB = oXL.Workbooks.Open("c:\\MyExcel.xlsx");
                oSheet = String.IsNullOrEmpty(sheetName) ? (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet : (Microsoft.Office.Interop.Excel._Worksheet)oWB.Worksheets[sheetName];

                oSheet.Cells[row, col] = data;

                oWB.Save();

                //MessageBox.Show("Done!");
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());
            }
            finally
            {
                if (oWB != null)
                    oWB.Close();
            }
        }

        [AllowAnonymous]
        public void xCel(string id)
        {
            Microsoft.Office.Interop.Excel.Application oXL;
            Microsoft.Office.Interop.Excel._Workbook oWB = null;
            Microsoft.Office.Interop.Excel._Worksheet oSheet;
            Microsoft.Office.Interop.Excel.Range oRng;
            object misvalue = System.Reflection.Missing.Value;
            try
            {
                //Start Excel and get Application object.
                oXL = new Microsoft.Office.Interop.Excel.Application();
                oXL.Visible = false;

                //Get a new workbook.
                oWB = (Microsoft.Office.Interop.Excel._Workbook)(oXL.Workbooks.Add(""));
                oSheet = (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet;

                //Add table headers going cell by cell.
                oSheet.Cells[1, 1] = "First Name";
                oSheet.Cells[1, 2] = "Last Name";
                oSheet.Cells[1, 3] = "Full Name";
                oSheet.Cells[1, 4] = "Salary";

                //Format A1:D1 as bold, vertical alignment = center.
                oSheet.get_Range("A1", "D1").Font.Bold = true;
                oSheet.get_Range("A1", "D1").VerticalAlignment =
                    Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;

                // Create an array to multiple values at once.
                string[,] saNames = new string[5, 2];

                saNames[0, 0] = "John";
                saNames[0, 1] = "Smith";
                saNames[1, 0] = "Tom";

                saNames[4, 1] = "Johnson";

                //Fill A2:B6 with an array of values (First and Last Names).
                oSheet.get_Range("A2", "B6").Value2 = saNames;

                //Fill C2:C6 with a relative formula (=A2 & " " & B2).
                oRng = oSheet.get_Range("C2", "C6");
                oRng.Formula = "=A2 & \" \" & B2";

                //Fill D2:D6 with a formula(=RAND()*100000) and apply format.
                oRng = oSheet.get_Range("D2", "D6");
                oRng.Formula = "=RAND()*100000";
                oRng.NumberFormat = "$0.00";

                //AutoFit columns A:D.
                oRng = oSheet.get_Range("A1", "D1");
                oRng.EntireColumn.AutoFit();

                oXL.Visible = false;
                oXL.UserControl = false;
                oWB.SaveAs("c:\\intel\\test505.xls", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
                    false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange,
                    Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                oWB.Close();
                oXL.Quit();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());
            }
            finally
            {
                if (oWB != null)
                    oWB.Close();
            }


        }
            /*
            public string RegisterChargesList(string id)
            {
                lock (Provider.Locker)
                {
                    var sqlQuery = $@"select
                  c.record_date,
                  r.roll_number || ' - ' || i.invoice_number as roll_number,
                  ct.name,
                  c.value,
                  n.note
                from CHARGES c
                join Notes n on n.id = c.note_id
                join charge_types ct on ct.id = c.type_id
                join invoices i on i.id = c.invoice_id
                join registers r on r.id = i.register_id
                where r.id = {id} and c.STATUS = 0
                order by c.Record_Date, c.type_id, r.roll_number, i.invoice_number";

                    var reader = Provider.RunQuery(sqlQuery);
                    var isRecordsFound = false;
                    var jsonResult = "{\"Result\":\"OK\",\"Records\":[";

                    while (reader.Read())
                    {
                        isRecordsFound = true;
                        jsonResult += "{\"Guid\":\"" + Guid.NewGuid() + "\",";
                        for (var i = 0; i < reader.FieldCount; i++)
                        {
                            jsonResult += "\"" + reader.GetName(i) + "\":";
                            jsonResult += reader[i] == null ? "null," : $"\"{HttpUtility.JavaScriptStringEncode(i == 0 ? ((DateTime)reader[i]).ToString("dd.MM.yyyy") : reader[i].ToString())}\",";
                        }
                        jsonResult = jsonResult.Remove(jsonResult.Length - 1);
                        jsonResult += "},";
                    }
                    reader.Close();
                    if (isRecordsFound) jsonResult = jsonResult.Remove(jsonResult.Length - 1);
                    jsonResult += "]}";
                    return jsonResult;
                }

            }

            private string Report(string id, string parameters)
            {
                lock (Provider.Locker)
                {
                    var result = string.Empty;
                    var query = string.Empty;

                    var reportID = int.Parse(id);

                    var report = Reports.First(r => r.Key == reportID).Value;
                    report.ClearParametersValues();

                    // 4 - территориальная коллегия.
                    // Чтобы показать коллегии все отчёты подчинённых адвокатов, а не только отчёты самого клиента
                    var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);

                    switch (role)
                    {
                        case 4:
                            query = WebUtility.HtmlDecode(report.QueryCollegium);
                            break;
                        case 2:
                            query = WebUtility.HtmlDecode(report.QueryLawyer);
                            break;
                    }

                    if (!string.IsNullOrEmpty(parameters))
                    {
                        var ps = parameters.Split('/');

                        for (var i = 0; i < ps.Length; i++)
                        {
                            report.Parameters[i].Value = ps[i];
                        }

                        foreach (var param in report.Parameters)
                        {
                            if ((param.Name == "StartDate" || param.Name == "EndDate") && (string.IsNullOrEmpty(param.Value) || param.Value == "null"))
                            {
                                param.Value = DateTime.Now.ToString("yyyyMMdd");
                            }
                            if (param.Name == "PartnerID" && (string.IsNullOrEmpty(param.Value) || param.Value == "null"))
                            {
                                param.Value = "p.id";
                            }
                            if (param.Name == "FactorPactID" && (string.IsNullOrEmpty(param.Value) || param.Value == "null"))
                            {
                                param.Value = "fp.id";
                            }
                            if (param.Name == "SupplyPactID" && (string.IsNullOrEmpty(param.Value) || param.Value == "null"))
                            {
                                param.Value = "sp.id";
                            }
                            if (param.Name == "RegisterID" && (string.IsNullOrEmpty(param.Value) || param.Value == "null"))
                            {
                                param.Value = "r.id";
                            }
                            if (param.Name == "CurrentUserName")
                            {
                                param.Value = User.Identity.GetUserId();
                            }
                            if (param.Name == "CurrentCollegiumId")
                            {

                                var collegiumId = string.Empty;

                                var subQuery = @"SELECT law_collegium_id
                                      FROM subjects_law_suppliers
                                     WHERE person_id = '" + User.Identity.GetUserId() + "';";

                                var reader = Provider.RunQuery(subQuery);

                                while (reader.Read())
                                {
                                    collegiumId = reader["law_collegium_id"].ToString();
                                }
                                reader.Close();
                                param.Value = collegiumId;
                            }
                            if (param.Name == "ReportId")
                            {
                                param.Value = parameters;
                            }


                            query = query.Replace("{" + param.Name + "}", param.Value);
                        }
                    }

                    using (var reader = Provider.RunQuery(query))
                    {
                        if (!reader.Read())
                        {
                            return result;
                        }
                        var xmlString = reader.GetString(0);
                        var xpdoc = new XPathDocument(new StringReader(xmlString));

                        using (var sw = new StringWriter())
                        {
                            using (var xmlWriter = XmlWriter.Create(sw))
                            {
                                // Execute the transformation.
                                report.XsltTransform.Transform(xpdoc, null, xmlWriter);

                                result = sw.ToString();
                            }
                        }

                    }

                    return result;
                }
            }

            public ActionResult ReportExcel(string id, string parameters)
            {
                var sw = Report(id, parameters);
                return Excel(sw);
            }

            public ActionResult SignReport(string id)
            {
                try
                {
                    ViewBag.Message = TempData["Message"]?.ToString();
                }
                catch (NullReferenceException)
                {
                    ViewBag.Message = null;
                }

                if (id != null)
                {
                    ViewBag.Id = id;
                }

                return View();
            }

            [HttpPost]
            [System.Web.Mvc.Authorize]
            public ActionResult SigningReport()
            {
                var fileName = Request["filename"]; //имя Excel файла  
                var xlApp = new Excel.Application();
                var xlWb = xlApp.Workbooks.Open(fileName);
                Excel.Worksheet xlSht = xlWb.Sheets[1];

                var last = xlSht.Cells.SpecialCells(Microsoft.Office.Interop.Excel.XlCellType.xlCellTypeLastCell, Type.Missing);

                var lastUsedRow = last.Row + 5;

                xlSht.Cells[lastUsedRow, "A"].Value = "Электронная цифровая подпись: " + Request["key"];

                xlWb.Close(true); //закрыть и сохранить книгу
                xlApp.Quit();

                //TempData["Message"] = "Документ был подписан вашей ЭЦП";

                return RedirectToAction("SignReport", "Report");
            }

            [HttpPost]
            [System.Web.Mvc.Authorize]
            public ActionResult SigningReportToDb()
            {
                var query = "UPDATE public.rep_law_state_aid" +
                                    " SET rep_law_state_sign='" + Request["key"] + "', rep_status = 3" +
                                    " WHERE rep_law_state_aid.user_id = '" + User.Identity.GetUserId() + "' and rep_law_state_aid.rep_law_state_aid_id = " + Request["Id"] + " and (rep_law_state_aid.rep_status = 1 OR rep_law_state_aid.rep_status = 4); ";

                Provider.RunNonQuery(query);

                // Логгирование.
                // Получение наименования текущего клиента.
                var lawyerName = string.Empty;
                query = @"select p.last_name || ' ' || p.given_name || ' ' || p.middle_name as lawyer_name from persons p where p.user_id = '" + User.Identity.GetUserId() + "';";
                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    lawyerName = reader["lawyer_name"].ToString();
                }

                reader.Close();

                var logText = $"Отчёт был подписан адвокатом \"{lawyerName}\"";
                Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - подписан", User.Identity.GetUserId(), User.Identity.GetUserId(), Request["Id"], "rep_law_state_aid");
                //TempData["Message"] = "Документ был подписан вашей ЭЦП";

                return RedirectToAction("MyReports", "Report");
            }

            private double GetWidth(System.Drawing.Font stringFont, string text)
            {
                // This formula is based on this article plus a nudge ( + 0.2M )
                // http://msdn.microsoft.com/en-us/library/documentformat.openxml.spreadsheet.column.width.aspx
                // Truncate(((256 * Solve_For_This + Truncate(128 / 7)) / 256) * 7) = DeterminePixelsOfString

                var textSize = Graphics.MeasureString(text, stringFont);
                var width = (textSize.Width / (double)7 * 256 - 128 / 7) / 256;
                width = (double)decimal.Round((decimal)width + 0.2M, 2);

                return width;
            }
            /*
            private Stylesheet GenerateStyleSheet()
            {
                return new Stylesheet(
                    new Fonts(
                        new DocumentFormat.OpenXml.Spreadsheet.Font(                                                               // Index 0 - The default font.
                            new FontSize() { Val = 11 },
                            new DocumentFormat.OpenXml.Spreadsheet.Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                            new FontName() { Val = "Calibri" }),
                        new DocumentFormat.OpenXml.Spreadsheet.Font(                                                               // Index 1 - The bold font.
                            new Bold(),
                            new FontSize() { Val = 11 },
                            new DocumentFormat.OpenXml.Spreadsheet.Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                            new FontName() { Val = "Calibri" }),
                        new DocumentFormat.OpenXml.Spreadsheet.Font(                                                               // Index 2 - The Italic font.
                            new Italic(),
                            new FontSize() { Val = 11 },
                            new DocumentFormat.OpenXml.Spreadsheet.Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                            new FontName() { Val = "Calibri" }),
                        new DocumentFormat.OpenXml.Spreadsheet.Font(                                                               // Index 2 - The Times Roman font. with 16 size
                            new FontSize() { Val = 16 },
                            new DocumentFormat.OpenXml.Spreadsheet.Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                            new FontName() { Val = "Times New Roman" })
                    ),
                    new Fills(
                        new Fill(                                                           // Index 0 - The default fill.
                            new PatternFill() { PatternType = PatternValues.None }),
                        new Fill(                                                           // Index 1 - The default fill of gray 125 (required)
                            new PatternFill() { PatternType = PatternValues.Gray125 }),
                        new Fill(                                                           // Index 2 - The yellow fill.
                            new PatternFill(
                                new ForegroundColor() { Rgb = new HexBinaryValue() { Value = "FFFFFF00" } }
                            )
                            { PatternType = PatternValues.Solid })
                    ),
                    new Borders(
                        new Border(                                                         // Index 0 - The default border.
                            new LeftBorder(),
                            new RightBorder(),
                            new TopBorder(),
                            new BottomBorder(),
                            new DiagonalBorder()),
                        new Border(                                                         // Index 1 - Applies a Left, Right, Top, Bottom border to a cell
                            new LeftBorder(
                                new DocumentFormat.OpenXml.Spreadsheet.Color() { Auto = true }
                            )
                            { Style = BorderStyleValues.Thin },
                            new RightBorder(
                                new DocumentFormat.OpenXml.Spreadsheet.Color() { Auto = true }
                            )
                            { Style = BorderStyleValues.Thin },
                            new TopBorder(
                                new DocumentFormat.OpenXml.Spreadsheet.Color() { Auto = true }
                            )
                            { Style = BorderStyleValues.Thin },
                            new BottomBorder(
                                new DocumentFormat.OpenXml.Spreadsheet.Color() { Auto = true }
                            )
                            { Style = BorderStyleValues.Thin },
                            new DiagonalBorder())
                    ),
                    new CellFormats(
                        new CellFormat() { FontId = 0, FillId = 0, BorderId = 0 },                          // Index 0 - The default cell style.  If a cell does not have a style index applied it will use this style combination instead
                        new CellFormat() { FontId = 1, FillId = 0, BorderId = 0, ApplyFont = true },       // Index 1 - Bold 
                        new CellFormat() { FontId = 2, FillId = 0, BorderId = 0, ApplyFont = true },       // Index 2 - Italic
                        new CellFormat() { FontId = 3, FillId = 0, BorderId = 0, ApplyFont = true },       // Index 3 - Times Roman
                        new CellFormat() { FontId = 0, FillId = 2, BorderId = 0, ApplyFill = true },       // Index 4 - Yellow Fill
                        new CellFormat(                                                                   // Index 5 - Alignment + bold
                            new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }
                        )
                        { FontId = 1, FillId = 0, BorderId = 0, ApplyAlignment = true, ApplyFont = true },
                        new CellFormat() { FontId = 0, FillId = 0, BorderId = 1, ApplyBorder = true }      // Index 6 - Border
                    )
                ); // return
            }

    */


            public ActionResult Parameters(string id)
        {
            var reportID = int.Parse(id);

            var report = Reports.First(r => r.Key == reportID).Value;

            ReportTemplate.Document.Children[0].Caption = report.Name;

            foreach (var widget in ReportTemplate.Document.GetSimpleChildren(ReportTemplate.Document.TableName))
            {
                var rp = report.Parameters.FirstOrDefault(p => p.Name == widget.Name);
                if (rp != null)
                {
                    widget.Visible = true;
                    widget.Caption = rp.Caption;
                }
                else
                {
                    widget.Visible = false;
                }
            }

            ViewBag.id = id;

            return View(ReportTemplate);
        }
        /*
        public ActionResult BankReport()
        {

            lock (Provider.Locker)
            {
                var claim = int.Parse(((ClaimsIdentity)this.User.Identity).Claims.First(c => c.Type == "user_role").Value);

                if (claim == 42)
                {
                    string query = @"SELECT t1.*, t2.*
                                    FROM rep_law_state_aid t1
                                    LEFT JOIN  public.subjects_law_suppliers t2 on t1.user_id = t2.person_id;";

                    var reader = Provider.RunQuery(query);

                    var reports = new List<ReportModel>();

                    while (reader.Read())
                    {
                        var rep = new ReportModel
                        {
                            ReportId = reader["rep_law_state_aid_id"].ToString(),
                            ReportNumber = reader["rep_number"].ToString()
                        };
                        rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                        rep.BeginDate = GetDateTimeFromString(reader["rep_date_begin"].ToString());
                        rep.EndDate = GetDateTimeFromString(reader["rep_date_end"].ToString());
                        rep.ReportPeriod =
                            $"?month={rep.BeginDate.Month:00}/{rep.BeginDate.Year.ToString()}";
                        rep.SendDate = GetDateTimeFromString(reader["rep_send_date"].ToString());
                        rep.ConfirmDate = GetDateTimeFromString(reader["rep_confirm_date"].ToString());
                        rep.ReportStatus = GetIntFromString(reader["rep_status"].ToString());
                        rep.Comment = reader["comment"].ToString();
                        reports.Add(rep);
                    }

                    reader.Close();

                    var model = new ReportsViewModels();

                    // Выпадающий список на прошлый, текущий, следующий месяц.
                    var periods = new List<SelectListItem>
                    {
                        new SelectListItem {Text = DateTime.Now.AddMonths(-1).ToString("MMMM", CultureInfo.CreateSpecificCulture("ru")) + @" " + DateTime.Now.AddMonths(-1).Year, Value = "?month=" + DateTime.Now.AddMonths(-1).Month.ToString().PadLeft(2, '0') + "/" + DateTime.Now.AddMonths(-1).Year },
                        new SelectListItem {Text = DateTime.Now.ToString("MMMM", CultureInfo.CreateSpecificCulture("ru")) + @" " + DateTime.Now.Year, Value = "?month=" + DateTime.Now.Month.ToString().PadLeft(2, '0') + "/" + DateTime.Now.Year },
                        new SelectListItem {Text = DateTime.Now.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("ru")) + @" " + DateTime.Now.AddMonths(1).Year, Value = "?month=" + DateTime.Now.AddMonths(1).Month.ToString().PadLeft(2, '0') + "/" + DateTime.Now.AddMonths(1).Year }
                    };

                    // Исключение отчётов, которые уже созданы
                    foreach (var report in reports)
                    {
                        periods.RemoveAll(item => report.ReportPeriod == item.Value);
                    }

                    ViewBag.Periods = periods;
                    ViewBag.AvailibleCount = periods.Count;
                    model.Reports = reports;
                    return View(model);
                }
            }
            ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
            return View("Error");
        }

        public ActionResult MyReports()
        {

            lock (Provider.Locker)
            {
                var query = @"SELECT law_state_aids
                                    FROM subjects_law_suppliers
                                    WHERE person_id = '" + User.Identity.GetUserId() + "';";
                var reader = Provider.RunQuery(query);
                var isGgup = "0";

                while (reader.Read())
                {
                    isGgup = reader["law_state_aids"].ToString();
                }

                reader.Close();

                if (isGgup == "1")
                {
                    query = @"SELECT t1.""ClaimValue""
                                    FROM ""AspNetUserClaims"" t1
                                    WHERE t1.""UserId"" = '" + User.Identity.GetUserId() + "' and t1.\"ClaimType\" = 'user_role';";

                    reader = Provider.RunQuery(query);

                    // Проверка не заблокирован ли пользователь (Claims обновляются только после перезахода)
                    var claimfromDb = "1";

                    while (reader.Read())
                    {
                        claimfromDb = reader["ClaimValue"].ToString();
                    }

                    reader.Close();
                    //var claimFromStorage = ((ClaimsIdentity)this.User.Identity).Claims.First(c => c.Type == "user_role").Value;
                    if (claimfromDb == "-100") return RedirectToAction("LogOut", "Account");

                    query = @"SELECT t1.*, t2.*
                                    FROM rep_law_state_aid t1
                                    LEFT JOIN  public.subjects_law_suppliers t2 on t1.user_id = t2.person_id
                                    WHERE t1.user_id = '" + User.Identity.GetUserId() + "';";

                    reader = Provider.RunQuery(query);

                    var reports = new List<ReportModel>();

                    while (reader.Read())
                    {
                        var rep = new ReportModel
                        {
                            ReportId = reader["rep_law_state_aid_id"].ToString(),
                            ReportNumber = reader["rep_number"].ToString()
                        };
                        rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                        rep.BeginDate = GetDateTimeFromString(reader["rep_date_begin"].ToString());
                        rep.EndDate = GetDateTimeFromString(reader["rep_date_end"].ToString());
                        rep.ReportPeriod =
                            $"?month={rep.BeginDate.Month:00}/{rep.BeginDate.Year.ToString()}";
                        rep.SendDate = GetDateTimeFromString(reader["rep_send_date"].ToString());
                        rep.ConfirmDate = GetDateTimeFromString(reader["rep_confirm_date"].ToString());
                        rep.ReportStatus = GetIntFromString(reader["rep_status"].ToString());
                        rep.Comment = reader["comment"].ToString();
                        reports.Add(rep);
                    }

                    reader.Close();

                    var model = new ReportsViewModels();

                    // Выпадающий список на прошлый, текущий, следующий месяц.
                    var periods = new List<SelectListItem>
                    {
                        new SelectListItem {Text = DateTime.Now.AddMonths(-1).ToString("MMMM", CultureInfo.CreateSpecificCulture("ru")) + @" " + DateTime.Now.AddMonths(-1).Year, Value = "?month=" + DateTime.Now.AddMonths(-1).Month.ToString().PadLeft(2, '0') + "/" + DateTime.Now.AddMonths(-1).Year },
                        new SelectListItem {Text = DateTime.Now.ToString("MMMM", CultureInfo.CreateSpecificCulture("ru")) + @" " + DateTime.Now.Year, Value = "?month=" + DateTime.Now.Month.ToString().PadLeft(2, '0') + "/" + DateTime.Now.Year },
                        new SelectListItem {Text = DateTime.Now.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("ru")) + @" " + DateTime.Now.AddMonths(1).Year, Value = "?month=" + DateTime.Now.AddMonths(1).Month.ToString().PadLeft(2, '0') + "/" + DateTime.Now.AddMonths(1).Year }
                    };

                    // Исключение отчётов, которые уже созданы
                    foreach (var report in reports)
                    {
                        periods.RemoveAll(item => report.ReportPeriod == item.Value);
                    }

                    ViewBag.Periods = periods;
                    ViewBag.AvailibleCount = periods.Count;
                    model.Reports = reports;
                    return View(model);
                }
            }
            ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
            return View("Error");
        }

        public ActionResult LawyersReports()
        {
            var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

            if (claim != "4" && claim != "42")
            {
                ViewBag.Message = "Недостаточно прав!";
                return View("Error");
            }

            var collegiumId = string.Empty;

            lock (Provider.Locker)
            {
                var query = @"SELECT law_collegium_id
                                    FROM subjects_law_suppliers
                                    WHERE person_id = '" + User.Identity.GetUserId() + "';";

                var reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    collegiumId = reader["law_collegium_id"].ToString();
                }
                reader.Close();
                if (claim != "42")
                query = $@"SELECT
	p.last_name,
	p.given_name,
	p.middle_name,
	sls.subj_law_supplier_id,
	sls.subj_law_supplier_name,
	sls.subj_law_supplier_lic_num,
	sls.subj_law_supplier_phone,
	sls.subj_law_supplier_mobile,
	sls.subj_law_supplier_fax,
	sls.person_id,
	lat.legal_advise_type_name_ru,
	r.rep_law_state_aid_id,
	r.rep_number,
	r.rep_date_begin,
	r.rep_send_date,
	r.rep_date_end,
	r.rep_confirm_date,
	r.rep_status,
	r.""comment""
FROM subjects_law_suppliers sls
LEFT JOIN legal_advise_types lat on lat.legal_advise_type_id = sls.law_supp_org_type
LEFT JOIN persons p on sls.person_id = p.user_id
LEFT JOIN rep_law_state_aid r ON sls.subj_law_supplier_id = r.subj_law_supplier_id and (r.rep_status = 2 or r.rep_status = 4 or r.rep_status = 5 or r.rep_status = 6 or r.rep_status = 7 or r.rep_status = 8 or r.rep_status = 9)
WHERE sls.law_collegium_id = {collegiumId} and sls.subj_law_supplier_status = 1
ORDER BY sls.subj_law_supplier_id, r.rep_date_begin;";
                else query = $@"SELECT
	p.last_name,
	p.given_name,
	p.middle_name,
	sls.subj_law_supplier_id,
	sls.subj_law_supplier_name,
	sls.subj_law_supplier_lic_num,
	sls.subj_law_supplier_phone,
	sls.subj_law_supplier_mobile,
	sls.subj_law_supplier_fax,
	sls.person_id,
	lat.legal_advise_type_name_ru,
	r.rep_law_state_aid_id,
	r.rep_number,
	r.rep_date_begin,
	r.rep_send_date,
	r.rep_date_end,
	r.rep_confirm_date,
	r.rep_status,
	r.""comment""
FROM subjects_law_suppliers sls
LEFT JOIN legal_advise_types lat on lat.legal_advise_type_id = sls.law_supp_org_type
LEFT JOIN persons p on sls.person_id = p.user_id
LEFT JOIN rep_law_state_aid r ON sls.subj_law_supplier_id = r.subj_law_supplier_id and (r.rep_status = 5 or r.rep_status = 9)
WHERE sls.law_collegium_id = {collegiumId} and sls.subj_law_supplier_status = 1 and (r.rep_status=5 or r.rep_status=9)
ORDER BY sls.subj_law_supplier_id, r.rep_date_begin;";
                reader = Provider.RunQuery(query);

                var model = new LawyersReportsViewModel { Lawyers = new List<Lawyer>() };

                var lid = "-1";
                Lawyer lawyer = null;

                while (reader.Read())
                {
                    if (lid != reader["subj_law_supplier_id"].ToString())
                    {
                        lid = reader["subj_law_supplier_id"].ToString();

                        lawyer = new Lawyer
                        {
                            FIO = reader["last_name"] + " " + reader["given_name"] + " " +
                                  reader["middle_name"],
                            LawyerOrgFormaName = reader["legal_advise_type_name_ru"].ToString(),
                            LawyerId = lid,
                            LawyerName = reader["subj_law_supplier_name"].ToString(),
                            LawyerLicenseCode = reader["subj_law_supplier_lic_num"].ToString(),
                            LawyerPhone = reader["subj_law_supplier_phone"].ToString(),
                            LawyerMobilePhone = reader["subj_law_supplier_mobile"].ToString(),
                            LawyerUserId = reader["person_id"].ToString(),
                            LawyerFax = reader["subj_law_supplier_fax"].ToString(),
                            Reports = new List<ReportModel>()
                        };

                        model.Lawyers.Add(lawyer);
                    }

                    if (reader.IsDBNull(reader.GetOrdinal("rep_law_state_aid_id")))
                    {
                        continue;
                    }

                    var rep = new ReportModel
                    {
                        ReportId = reader["rep_law_state_aid_id"].ToString(),
                        ReportNumber = reader["rep_number"].ToString(),
                        BeginDate = reader.IsDBNull(reader.GetOrdinal("rep_date_begin"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_date_begin")),
                        SendDate = reader.IsDBNull(reader.GetOrdinal("rep_send_date"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_send_date")),
                        EndDate = reader.IsDBNull(reader.GetOrdinal("rep_date_end"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_date_end")),
                        ConfirmDate =
                            reader.IsDBNull(reader.GetOrdinal("rep_confirm_date"))
                                ? default
                                : reader.GetDateTime(reader.GetOrdinal("rep_confirm_date")),
                        ReportStatus = int.Parse(reader["rep_status"].ToString()),
                        Comment = reader["comment"].ToString(),
                        lawyerFIO = $"{reader["last_name"]} {reader["given_name"]} {reader["middle_name"]}"
                    };

                    rep.ReportPeriod = rep.BeginDate.ToString("MMMM yyyy", new CultureInfo("ru-RU"));

                    lawyer.Reports.Add(rep);
                }

                reader.Close();

                //var json = new JavaScriptSerializer().Serialize(model);
                return View(model);
            }
        }

        public ActionResult LawyersReportsPeriod()
        {
            var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

            if (claim != "4")
            {
                ViewBag.Message = "Недостаточно прав!";
                return View("Error");
            }

            var collegiumId = string.Empty;

            lock (Provider.Locker)
            {
                var query = @"SELECT law_collegium_id
                                    FROM subjects_law_suppliers
                                    WHERE person_id = '" + User.Identity.GetUserId() + "';";

                var reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    collegiumId = reader["law_collegium_id"].ToString();
                }
                reader.Close();

                query = $@"SELECT
	p.last_name,
	p.given_name,
	p.middle_name,
	sls.subj_law_supplier_id,
	sls.subj_law_supplier_name,
	sls.subj_law_supplier_lic_num,
	sls.subj_law_supplier_phone,
	sls.subj_law_supplier_mobile,
	sls.subj_law_supplier_fax,
	sls.person_id,
	lat.legal_advise_type_name_ru,
	r.rep_law_state_aid_id,
	r.rep_number,
	r.rep_date_begin,
	r.rep_send_date,
	r.rep_date_end,
	r.rep_confirm_date,
	r.rep_status,
	r.""comment""
FROM subjects_law_suppliers sls
LEFT JOIN legal_advise_types lat on lat.legal_advise_type_id = sls.law_supp_org_type
LEFT JOIN persons p on sls.person_id = p.user_id
JOIN rep_law_state_aid r ON sls.subj_law_supplier_id = r.subj_law_supplier_id and r.rep_status = 5
JOIN rep_aid_pay_request rr ON rr.rep_law_state_aid_id = r.rep_law_state_aid_id
WHERE sls.law_collegium_id = {collegiumId} and sls.subj_law_supplier_status = 1
ORDER BY r.rep_date_begin, p.last_name,	p.given_name, p.middle_name; ";
                reader = Provider.RunQuery(query);

                var model = new List<ReportModel>();

                while (reader.Read())
                {
                    var report = new ReportModel
                    {
                        ReportId = reader["rep_law_state_aid_id"].ToString(),
                        ReportNumber = reader["rep_number"].ToString(),
                        BeginDate = reader.IsDBNull(reader.GetOrdinal("rep_date_begin"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_date_begin")),
                        SendDate = reader.IsDBNull(reader.GetOrdinal("rep_send_date"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_send_date")),
                        EndDate = reader.IsDBNull(reader.GetOrdinal("rep_date_end"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_date_end")),
                        ConfirmDate =
                            reader.IsDBNull(reader.GetOrdinal("rep_confirm_date"))
                                ? default
                                : reader.GetDateTime(reader.GetOrdinal("rep_confirm_date")),
                        ReportStatus = int.Parse(reader["rep_status"].ToString()),
                        Comment = reader["comment"].ToString(),
                        lawyerFIO = reader["last_name"] + " " + reader["given_name"] + " " +
                                    reader["middle_name"]
                    };

                    report.ReportPeriodName = report.BeginDate.ToString("MMMM yyyy", new CultureInfo("ru-RU"));
                    report.ReportPeriod = report.BeginDate.ToString("yyyyMM");
                    model.Add(report);
                }

                reader.Close();

                return View(model);
            }
        }

        public ActionResult CollegialReports()
        {
            var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

            if (claim != "4")
            {
                ViewBag.Message = "Недостаточно прав!";
                return View("Error");
            }

            var collegiumId = string.Empty;

            var query = @"SELECT law_collegium_id
                                 FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";

            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                collegiumId = reader["law_collegium_id"].ToString();
            }

            reader.Close();

            query = @"SELECT t1.*
                                FROM rep_law_state_aid_colleg t1
                                WHERE t1.law_collegium_id = " + collegiumId + ";";
            reader = Provider.RunQuery(query);

            var model = new List<CollegialReportModel>();

            while (reader.Read())
            {
                var rep = new CollegialReportModel
                {
                    ReportId = reader["rep_law_state_aid_colleg_id"].ToString(),
                    ReportNumber = reader["rep_number"].ToString(),
                    BeginDate = reader.IsDBNull(reader.GetOrdinal("rep_date_begin"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_date_begin")),
                    SendDate = reader.IsDBNull(reader.GetOrdinal("rep_send_date"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_send_date")),
                    EndDate = reader.IsDBNull(reader.GetOrdinal("rep_date_end"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_date_end")),
                    Comment = reader["comment"].ToString()
                };

                model.Add(rep);
            }

            reader.Close();

            foreach (var collegiumReport in model)
            {
                var reports = new List<ReportModel>();
                query = @"SELECT t1.*, lc.law_collegium_name_ru  
                                FROM rep_law_state_aid t1
                        JOIN law_collegiums lc on lc.law_collegium_id = t1.law_collegium_id
                                WHERE t1.law_collegium_id = " + collegiumId + " and t1.rep_status = 5 and t1.rep_date_begin >= '" + collegiumReport.BeginDate.ToString("yyyyMMdd") + "' and t1.rep_date_end <= '" + collegiumReport.EndDate.ToString("yyyyMMdd") + "';";
                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    var report = new ReportModel
                    {
                        ReportId = reader["rep_law_state_aid_id"].ToString(),
                        ReportNumber = reader["rep_number"].ToString(),
                        BeginDate = reader.IsDBNull(reader.GetOrdinal("rep_date_begin"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_date_begin")),
                        SendDate = reader.IsDBNull(reader.GetOrdinal("rep_send_date"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_send_date")),
                        EndDate = reader.IsDBNull(reader.GetOrdinal("rep_date_end"))
                            ? default
                            : reader.GetDateTime(reader.GetOrdinal("rep_date_end")),
                        Comment = reader["comment"].ToString()
                    };

                    reports.Add(report);
                }

                reader.Close();

                collegiumReport.Reports = reports;
            }

            return View(new CollegialReportViewModel { Reports = model });

        }

        [HttpPost]
        public ActionResult SendReport()
        {
            lock (Provider.Locker)
            {
                var query =
                    $@"select rep_date_end from public.rep_law_state_aid WHERE rep_law_state_aid_id = {Request["reportId"]};";
                var reader = Provider.RunQuery(query);

                var lastDate = DateTime.MinValue;

                if (reader.Read())
                {
                    lastDate = reader.GetFieldValueOrDefault<DateTime>("rep_date_end");
                }

                reader.Close();

                lastDate = lastDate.AddDays(lastDate.Month == 12 ? -15 : 6);

                if (lastDate < DateTime.Now)
                {
                    return Json(new
                    {
                        message = $"Отчет не может быть отправлен. Крайний срок {lastDate.AddDays(-1):dd MMMM yyyy}"
                    });
                }

                // rep_status == 2 - принят
                query = $@"UPDATE public.rep_law_state_aid
                               SET rep_status=2, rep_send_date=current_date
                             WHERE rep_law_state_aid_id = {Request["reportId"]};";

                Provider.RunNonQuery(query);

                // Логгирование.
                // Получение наименования текущего клиента/секретаря.
                var lawyerName = string.Empty;
                query =
                    @"select p.last_name || ' ' || p.given_name || ' ' || p.middle_name as lawyer_name from persons p where p.user_id =  '" +
                    User.Identity.GetUserId() + "';";
                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    lawyerName = reader["lawyer_name"].ToString();
                }

                reader.Close();

                var logText = $"Отчёт был отправлен адвокатом \"{lawyerName}\"";
                Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - отправка",
                    User.Identity.GetUserId(), User.Identity.GetUserId(), Request["reportId"], "rep_law_state_aid");

                if (Request.UrlReferrer != null && Request.UrlReferrer.AbsoluteUri.EndsWith("Report/MyReports"))
                {
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.RequestApprovalReportGgup,
                        CreatorId = User.Identity.GetUserId(),
                        CreationDate = DateTime.Now,
                        ObjectId = int.Parse(Request["reportId"])
                    });
                }

                return Json(new
                {
                    message = $"Отчет успешно отправлен."
                }); ;
            }
        }

        [HttpPost]
        public ActionResult RefuseReport()
        {
            // rep_status == 4 - отклонён
            var query = @"UPDATE public.rep_law_state_aid
                               SET rep_status=4, comment = '" + Request["comment"] + "' WHERE rep_law_state_aid_id = " + Request["reportId"] + " and rep_status = 2;";

            Provider.RunNonQuery(query);

            // Логгирование.
            // Получение наименования текущего клиента/секретаря.
            var secretaryName = string.Empty;
            query = @"SELECT subj_law_supplier_name
                                  FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                secretaryName = reader["subj_law_supplier_name"].ToString();
            }

            reader.Close();
            // Получение ID клиента, создавшего отчёт
            //string lawyerName = string.Empty;
            var lawyerUserId = string.Empty;
            query = @"SELECT t1.subj_law_supplier_name, t1.person_id
                                  FROM subjects_law_suppliers t1
                                  LEFT JOIN rep_law_state_aid t2 ON t2.subj_law_supplier_id = t1.subj_law_supplier_id
                                  WHERE rep_law_state_aid_id = " + Request["reportId"] + ";";
            reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                //lawyerName = reader["subj_law_supplier_name"].ToString();
                lawyerUserId = reader["person_id"].ToString();
            }

            reader.Close();

            var logText = $"Отчёт был отклонён секретарём \"{secretaryName}\" с комментарием \"{Request["comment"]}\"";
            Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - отклонён", lawyerUserId, User.Identity.GetUserId(), Request["reportId"], "rep_law_state_aid");

            if (Request.UrlReferrer != null && Request.UrlReferrer.AbsoluteUri.EndsWith("Report/LawyersReports"))
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.RequestApprovalReportGgupRejected,
                    CreatorId = User.Identity.GetUserId(),
                    CreationDate = DateTime.Now,
                    ObjectId = int.Parse(Request["reportId"]),
                    Comment = Request["comment"],
                    RecipientId = lawyerUserId
                });
            }

            return null;
        }

        [HttpPost]
        public ActionResult ConfirmReport()
        {
            // rep_status == 5 - согласован
            var query = @"UPDATE public.rep_law_state_aid
                               SET rep_status=5, rep_confirm_date = current_date WHERE rep_law_state_aid_id = " + Request["reportId"] + " and rep_status=2;";

            Provider.RunNonQuery(query);

            // Логгирование.
            // Получение наименования текущего клиента/секретаря.
            var secretaryName = string.Empty;
            query = @"SELECT subj_law_supplier_name
                                  FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                secretaryName = reader["subj_law_supplier_name"].ToString();
            }

            reader.Close();

            var logText = $"Отчёт был согласован секретарём \"{secretaryName}\"";
            // Получение ID клиента, создавшего отчёт
            //string lawyerName = string.Empty;
            var lawyerUserId = string.Empty;
            query = @"SELECT t1.subj_law_supplier_name, t1.person_id
                                  FROM subjects_law_suppliers t1
                                  LEFT JOIN rep_law_state_aid t2 ON t2.subj_law_supplier_id = t1.subj_law_supplier_id
                                  WHERE rep_law_state_aid_id = " + Request["reportId"] + ";";
            reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                //lawyerName = reader["subj_law_supplier_name"].ToString();
                lawyerUserId = reader["person_id"].ToString();
            }

            reader.Close();

            Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - согласован", lawyerUserId, User.Identity.GetUserId(), Request["reportId"], "rep_law_state_aid");

            if (Request.UrlReferrer != null && Request.UrlReferrer.AbsoluteUri.EndsWith("Report/LawyersReports"))
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.RequestApprovalReportGgupAccepted,
                    CreatorId = User.Identity.GetUserId(),
                    CreationDate = DateTime.Now,
                    ObjectId = int.Parse(Request["reportId"]),
                    RecipientId = lawyerUserId
                });
            }

            return null;
        }

        [HttpPost]
        public ActionResult TrySignReport()
        {
            // rep_status == 7 - Запрос корректировки
            var query = @"UPDATE public.rep_law_state_aid
                               SET rep_status=9 WHERE rep_law_state_aid_id = " + Request["reportId"] + " and (rep_status = 2 or rep_status = 5);";

            Provider.RunNonQuery(query);

            // Логгирование.
            // Получение ID клиента, создавшего отчёт
            /*var lawyerName = string.Empty;
            query = @"SELECT t1.subj_law_supplier_name
                                  FROM subjects_law_suppliers t1
                                  LEFT JOIN rep_law_state_aid t2 ON t2.subj_law_supplier_id = t1.subj_law_supplier_id
                                  WHERE rep_law_state_aid_id = " + Request["reportId"] + ";";
            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                lawyerName = reader["subj_law_supplier_name"].ToString();
            }

            reader.Close();

            var logText =
                $"Клиент \"{lawyerName}\" запросил отчёт на корректировку с комментарием \"{Request["comment"]}\"";
            Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - запрос на корректировку", User.Identity.GetUserId(), User.Identity.GetUserId(), Request["reportId"], "rep_law_state_aid");
            
            return null;
        }

        [HttpPost]
        public ActionResult TryReturnReport()
        {
            // rep_status == 7 - Запрос корректировки
            var query = @"UPDATE public.rep_law_state_aid
                               SET rep_status=7, comment='" + Request["comment"] + "' WHERE rep_law_state_aid_id = " + Request["reportId"] + " and (rep_status = 2 or rep_status = 5);";

            Provider.RunNonQuery(query);

            // Логгирование.
            // Получение ID клиента, создавшего отчёт
            var lawyerName = string.Empty;
            query = @"SELECT t1.subj_law_supplier_name
                                  FROM subjects_law_suppliers t1
                                  LEFT JOIN rep_law_state_aid t2 ON t2.subj_law_supplier_id = t1.subj_law_supplier_id
                                  WHERE rep_law_state_aid_id = " + Request["reportId"] + ";";
            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                lawyerName = reader["subj_law_supplier_name"].ToString();
            }

            reader.Close();

            var logText =
                $"Клиент \"{lawyerName}\" запросил отчёт на корректировку с комментарием \"{Request["comment"]}\"";
            Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - запрос на корректировку", User.Identity.GetUserId(), User.Identity.GetUserId(), Request["reportId"], "rep_law_state_aid");

            return null;
        }

        [HttpPost]
        public ActionResult ConfirmReturnReport()
        {
            // rep_status == 8 - Возвращен 
            var query = @"UPDATE public.rep_law_state_aid
                               SET rep_status=8 WHERE rep_law_state_aid_id = " + Request["reportId"] + " and rep_status=7;";

            Provider.RunNonQuery(query);

            // Логгирование.
            // Получение наименования текущего клиента/секретаря.
            var secretaryName = string.Empty;
            query = @"SELECT subj_law_supplier_name
                                  FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                secretaryName = reader["subj_law_supplier_name"].ToString();
            }

            reader.Close();
            var logText = $"Отчёт был отдан на корректировку секретарём \"{secretaryName}\"";
            // Получение ID клиента, создавшего отчёт
            //string lawyerName = string.Empty;
            var lawyerUserId = string.Empty;
            query = @"SELECT t1.subj_law_supplier_name, t1.person_id
                                  FROM subjects_law_suppliers t1
                                  LEFT JOIN rep_law_state_aid t2 ON t2.subj_law_supplier_id = t1.subj_law_supplier_id
                                  WHERE rep_law_state_aid_id = " + Request["reportId"] + ";";
            reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                //lawyerName = reader["subj_law_supplier_name"].ToString();
                lawyerUserId = reader["person_id"].ToString();
            }

            reader.Close();

            Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - отдан на корректировку", lawyerUserId, User.Identity.GetUserId(), Request["reportId"], "rep_law_state_aid");

            return null;
        }

        [HttpPost]
        public ActionResult RefuseReturnReport()
        {
            // rep_status == 5 - Возвращен 
            var query = @"UPDATE public.rep_law_state_aid
                               SET rep_status=5, comment = '" + Request["comment"] + "' WHERE rep_law_state_aid_id = " + Request["reportId"] + " and rep_status=7;";


            Provider.RunNonQuery(query);
            // Логгирование.
            // Получение наименования текущего клиента/секретаря.
            var secretaryName = string.Empty;
            query = @"SELECT subj_law_supplier_name
                                  FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                secretaryName = reader["subj_law_supplier_name"].ToString();
            }

            reader.Close();

            // Получение ID клиента, создавшего отчёт
            //string lawyerName = string.Empty;
            var lawyerUserId = string.Empty;
            query = @"SELECT t1.subj_law_supplier_name, t1.person_id
                                  FROM subjects_law_suppliers t1
                                  LEFT JOIN rep_law_state_aid t2 ON t2.subj_law_supplier_id = t1.subj_law_supplier_id
                                  WHERE rep_law_state_aid_id = " + Request["reportId"] + ";";
            reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                //lawyerName = reader["subj_law_supplier_name"].ToString();
                lawyerUserId = reader["person_id"].ToString();
            }

            reader.Close();

            var logText =
                $"Секретарь \"{secretaryName}\" отказал в корректировке отчёта  с комментарием \"{Request["comment"]}\" (отчёт согласован)";
            Provider.RunScalarStoredProcedure("add_to_log", logText, "Отчёт клиента - отказ в корректировке", lawyerUserId, User.Identity.GetUserId(), Request["reportId"], "rep_law_state_aid");

            if (Request.UrlReferrer != null && Request.UrlReferrer.AbsoluteUri.EndsWith("Report/LawyersReports"))
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.RequestEditReportGgupRejected,
                    CreatorId = User.Identity.GetUserId(),
                    CreationDate = DateTime.Now,
                    ObjectId = int.Parse(Request["reportId"]),
                    Comment = Request["comment"],
                    RecipientId = lawyerUserId
                });
            }

            return null;
        }

        public ActionResult CollegialReport(string id)
        {
            lock (Provider.Locker)
            {

                var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

                if (claim != "4")
                {
                    ViewBag.Message = "Недостаточно прав!";
                    return View("Error");
                }

                var collegiumId = string.Empty;

                var query = @"SELECT law_collegium_id
                                 FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";

                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    collegiumId = reader["law_collegium_id"].ToString();
                }

                reader.Close();

                query = @"SELECT rc.*, lc.law_collegium_name_ru                         
                        FROM rep_law_state_aid_colleg rc
                        JOIN law_collegiums lc on lc.law_collegium_id = rc.law_collegium_id
                                WHERE rc.law_collegium_id = " + collegiumId + " and rc.rep_law_state_aid_colleg_id = " + id + " ;";
                reader = Provider.RunQuery(query);
                var rep = new CollegialReportModel();
                var collegium_name = string.Empty;

                while (reader.Read())
                {
                    rep.ReportId = reader["rep_law_state_aid_colleg_id"].ToString();
                    rep.ReportNumber = reader["rep_number"].ToString();
                   rep.BeginDate = reader.IsDBNull(reader.GetOrdinal("rep_date_begin"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_date_begin"));
                    rep.SendDate = reader.IsDBNull(reader.GetOrdinal("rep_send_date"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_send_date"));
                    rep.EndDate = reader.IsDBNull(reader.GetOrdinal("rep_date_end"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_date_end"));
                    rep.Comment = reader["comment"].ToString();
                    collegium_name = reader["law_collegium_name_ru"].ToString();

                }

                reader.Close();

                //xmlelement(name current_date, to_char(current_timestamp, 'DD.MM.YYYY')),
                query = $@"SELECT REPLACE(REPLACE(REPLACE(REPLACE(xmlelement(name root, query_to_xml('SELECT SUM(rep_row_1) as rep_row_1, SUM(rep_row_2) as rep_row_2, SUM(rep_row_3) as rep_row_3, SUM(rep_row_4) as rep_row_4,
                SUM(rep_row_5) as rep_row_5, SUM(rep_row_6) as rep_row_6, SUM(rep_row_7) as rep_row_7, SUM(rep_row_8) as rep_row_8,
                SUM(rep_row_9) as rep_row_9, SUM(rep_row_10) as rep_row_10, SUM(rep_row_11) as rep_row_11, SUM(rep_row_12) as rep_row_12,
                SUM(rep_row_13) as rep_row_13, SUM(rep_row_14) as rep_row_14, SUM(rep_row_15) as rep_row_15, SUM(rep_row_16) as rep_row_16,
                SUM(rep_row_17) as rep_row_17, SUM(rep_row_18) as rep_row_18, SUM(rep_row_19) as rep_row_19, SUM(rep_row_20) as rep_row_20,
                SUM(rep_row_21) as rep_row_21, SUM(rep_row_1_2) as rep_row_1_2, SUM(rep_row_2_2) as rep_row_2_2, SUM(rep_row_3_2) as rep_row_3_2,
                SUM(rep_row_4_2) as rep_row_4_2, SUM(rep_row_5_2) as rep_row_5_2, SUM(rep_row_6_2) as rep_row_6_2, SUM(rep_row_7_2) as rep_row_7_2,
                SUM(rep_row_8_2) as rep_row_8_2, SUM(rep_row_9_2) as rep_row_9_2, SUM(rep_row_10_2) as rep_row_10_2, SUM(rep_row_11_2) as rep_row_11_2,
                SUM(rep_row_12_2) as rep_row_12_2, SUM(rep_row_13_2) as rep_row_13_2, SUM(rep_row_14_2) as rep_row_14_2, SUM(rep_row_15_2) as rep_row_15_2,
                SUM(rep_row_16_2) as rep_row_16_2, SUM(rep_row_17_2) as rep_row_17_2, SUM(rep_row_18_2) as rep_row_18_2, SUM(rep_row_19_2) as rep_row_19_2,
                SUM(rep_row_20_2) as rep_row_20_2, SUM(rep_row_21_2) as rep_row_21_2, SUM(rep_row_22_1) as rep_row_22_1, SUM(rep_row_22_2) as rep_row_22_2,
                SUM(rep_row_22_3) as rep_row_22_3, SUM(rep_row_22_4) as rep_row_22_4, SUM(rep_row_23_1) as rep_row_23_1, SUM(rep_row_23_2) as rep_row_23_2,
                SUM(rep_row_23_3) as rep_row_23_3, SUM(rep_row_23_4) as rep_row_23_4, SUM(rep_row_24_1) as rep_row_24_1, SUM(rep_row_24_2) as rep_row_24_2,
                SUM(rep_row_24_3) as rep_row_24_3, SUM(rep_row_24_4) as rep_row_24_4, SUM(rep_row_25_1) as rep_row_25_1, SUM(rep_row_25_2) as rep_row_25_2,
                SUM(rep_row_25_3) as rep_row_25_3, SUM(rep_row_25_4) as rep_row_25_4, SUM(rep_row_26_1) as rep_row_26_1, SUM(rep_row_26_2) as rep_row_26_2,
                SUM(rep_row_26_3) as rep_row_26_3, SUM(rep_row_26_4) as rep_row_26_4, SUM(rep_row_27_1) as rep_row_27_1, SUM(rep_row_27_2) as rep_row_27_2,
                SUM(rep_row_27_3) as rep_row_27_3, SUM(rep_row_27_4) as rep_row_27_4, SUM(rep_row_28_1) as rep_row_28_1, SUM(rep_row_28_2) as rep_row_28_2,
                SUM(rep_row_28_3) as rep_row_28_3, SUM(rep_row_28_4) as rep_row_28_4, SUM(rep_row_29_1) as rep_row_29_1, SUM(rep_row_29_2) as rep_row_29_2,
                SUM(rep_row_29_3) as rep_row_29_3, SUM(rep_row_29_4) as rep_row_29_4, SUM(rep_row_30_1) as rep_row_30_1, SUM(rep_row_30_2) as rep_row_30_2,
                SUM(rep_row_30_3) as rep_row_30_3, SUM(rep_row_30_4) as rep_row_30_4, SUM(rep_row_31_1) as rep_row_31_1, SUM(rep_row_31_2) as rep_row_31_2,
                SUM(rep_row_31_3) as rep_row_31_3, SUM(rep_row_31_4) as rep_row_31_4,
                SUM(CASE WHEN COALESCE(rep_row_1, 0) > 0 THEN 1 ELSE 0 END) as rep_row_51_1,
                SUM(CASE WHEN COALESCE(rep_row_1_2, 0) > 0 THEN 1 ELSE 0 END) as rep_row_51_2,
                SUM(CASE WHEN (COALESCE(rep_row_4, 0) > 0 OR COALESCE(rep_row_6, 0) > 0) THEN 1 ELSE 0 END) as rep_row_52_1,
                SUM(CASE WHEN (COALESCE(rep_row_4_2, 0) > 0 OR COALESCE(rep_row_6_2, 0) > 0) THEN 1 ELSE 0 END) as rep_row_52_2,
                SUM(CASE WHEN COALESCE(rep_row_7, 0) > 0 THEN 1 ELSE 0 END) as rep_row_53_1,
                SUM(CASE WHEN COALESCE(rep_row_7_2, 0) > 0 THEN 1 ELSE 0 END) as rep_row_53_2,
                SUM(CASE WHEN COALESCE(rep_row_9, 0) > 0 THEN 1 ELSE 0 END) as rep_row_54_1,
                SUM(CASE WHEN COALESCE(rep_row_9_2, 0) > 0 THEN 1 ELSE 0 END) as rep_row_54_2
                FROM rep_law_state_aid
                WHERE law_collegium_id = {collegiumId} and rep_date_begin >= ''{rep.BeginDate.ToString("yyyyMMdd")}'' and rep_date_end <= ''{rep.EndDate.ToString("yyyyMMdd")}'' and rep_status = 5', false, false, ''),
                        query_to_xml('SELECT COUNT(*) as rep_row_32_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId}', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_32_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and subj_law_supp_is_rural = 1', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_33_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_33_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M'' and subj_law_supp_is_rural = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_34_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_34_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_35_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_35_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_36_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_36_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_37_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_37_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F'' and subj_law_supp_is_rural = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_38_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_38_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_39_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_39_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_40_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_40_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_41_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_41_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and law_state_aids = 1 and subj_law_supp_is_rural = 1', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_42_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_42_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M'' and subj_law_supp_is_rural = 1 and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_43_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_43_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_44_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_44_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_45_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_45_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_46_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_46_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F'' and subj_law_supp_is_rural = 1 and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_47_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_47_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_48_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_48_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_49_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_49_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, '')" +
                        ")::text, '<table xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">',  ' '), '</table>',  ' '), '<row>',  ' '), '</row>',  ' ');";

                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    var xml = reader["replace"].ToString();
                    var doc = XDocument.Parse(xml);
                    var reportFields = doc.Element("root")?.Elements().ToDictionary(repRow => repRow.Name.ToString(), repRow => repRow.Value.ToString());

                    if (reportFields == null)
                    {
                        continue;
                    }

                    reportFields.Add("rep_law_state_colleg_id", id);
                    ViewBag.Report = reportFields;
                }

                reader.Close();

                query = @"select rep_row_50_1, rep_row_50_2, rep_row_51_1, rep_row_51_2, rep_row_52_1, rep_row_52_2, rep_row_53_1, rep_row_53_2, rep_row_54_1, rep_row_54_2,
                            rep_row_55_1, rep_row_55_2, rep_row_56_1, rep_row_56_2 from rep_law_state_aid_colleg where rep_law_state_aid_colleg_id = " + id + ";";
                reader = Provider.RunQuery(query);
                var model = new CollegialReportDBModel();

                while (reader.Read())
                {
                    model.rep_row_50_1 = reader["rep_row_50_1"] is DBNull ? 0 : int.Parse(reader["rep_row_50_1"].ToString());
                    model.rep_row_50_2 = reader["rep_row_50_2"] is DBNull ? 0 : int.Parse(reader["rep_row_50_2"].ToString());
                    model.rep_row_51_1 = reader["rep_row_51_1"] is DBNull ? 0 : int.Parse(reader["rep_row_51_1"].ToString());
                    model.rep_row_51_2 = reader["rep_row_51_2"] is DBNull ? 0 : int.Parse(reader["rep_row_51_2"].ToString());
                    model.rep_row_52_1 = reader["rep_row_52_1"] is DBNull ? 0 : int.Parse(reader["rep_row_52_1"].ToString());
                    model.rep_row_52_2 = reader["rep_row_52_2"] is DBNull ? 0 : int.Parse(reader["rep_row_52_2"].ToString());
                    model.rep_row_53_1 = reader["rep_row_53_1"] is DBNull ? 0 : int.Parse(reader["rep_row_53_1"].ToString());
                    model.rep_row_53_2 = reader["rep_row_53_2"] is DBNull ? 0 : int.Parse(reader["rep_row_53_2"].ToString());
                    model.rep_row_54_1 = reader["rep_row_54_1"] is DBNull ? 0 : int.Parse(reader["rep_row_54_1"].ToString());
                    model.rep_row_54_2 = reader["rep_row_54_2"] is DBNull ? 0 : int.Parse(reader["rep_row_54_2"].ToString());
                    model.rep_row_55_1 = reader["rep_row_55_1"] is DBNull ? 0 : int.Parse(reader["rep_row_55_1"].ToString());
                    model.rep_row_55_2 = reader["rep_row_55_2"] is DBNull ? 0 : int.Parse(reader["rep_row_55_2"].ToString());
                    model.rep_row_56_1 = reader["rep_row_56_1"] is DBNull ? 0 : int.Parse(reader["rep_row_56_1"].ToString());
                    model.rep_row_56_2 = reader["rep_row_56_2"] is DBNull ? 0 : int.Parse(reader["rep_row_56_2"].ToString());
                }

                reader.Close();

                model.rep_period = $"{rep.BeginDate:MMMM yyyy} - {rep.EndDate:MMMM yyyy}";
                model.comment = collegium_name;

                return View(model);
            }
        }

        public ActionResult SaveCollegialReport(CollegialReportDBModel model)
        {
            var query = @"UPDATE public.rep_law_state_aid_colleg " +
               "SET rep_row_55_1 =" + model.rep_row_55_1 + "," +
               "rep_row_55_2 =" + model.rep_row_55_2 + ", rep_row_56_1 =" + model.rep_row_56_1 + ", rep_row_56_2 =" + model.rep_row_56_2 +
               " WHERE rep_law_state_aid_colleg_id = " + model.rep_law_state_colleg_id + "; ";

            Provider.RunNonQuery(query);

            return RedirectToAction("CollegialReport", "Report", new { id = model.rep_law_state_colleg_id });
        }

        public ActionResult DeleteReport(string id)
        {
            var query = @"DELETE FROM public.rep_aid_pay_request WHERE rep_law_state_aid_id = " + id + " AND (rep_status = 1 OR rep_status = 2 OR rep_status = 3 OR rep_status = 4) ;";

            Provider.RunNonQuery(query);

            query = @"DELETE FROM public.rep_law_state_aid WHERE rep_law_state_aid_id = " + id + " ;";
            Provider.RunNonQuery(query);

            return RedirectToAction("MyReports", "Report");
        }

        public ActionResult PrintCollegialReport(string id)
        {
            lock (Provider.Locker)
            {
                var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

                if (claim != "4")
                {
                    return View("Error");
                }

                var collegiumId = string.Empty;

                var query = @"SELECT law_collegium_id
                                 FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";

                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    collegiumId = reader["law_collegium_id"].ToString();
                }

                reader.Close();

                query = @"SELECT rc.*, lc.law_collegium_name_ru                         
                        FROM rep_law_state_aid_colleg rc
                        JOIN law_collegiums lc on lc.law_collegium_id = rc.law_collegium_id
                                WHERE rc.law_collegium_id = " + collegiumId + " and rc.rep_law_state_aid_colleg_id = " + id + " ;";
                reader = Provider.RunQuery(query);
                var rep = new CollegialReportModel();
                var collegium_name = string.Empty;

                while (reader.Read())
                {
                    rep.ReportId = reader["rep_law_state_aid_colleg_id"].ToString();
                    rep.ReportNumber = reader["rep_number"].ToString();
                    rep.BeginDate = reader.IsDBNull(reader.GetOrdinal("rep_date_begin"))
                         ? default
                         : reader.GetDateTime(reader.GetOrdinal("rep_date_begin"));
                    rep.SendDate = reader.IsDBNull(reader.GetOrdinal("rep_send_date"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_send_date"));
                    rep.EndDate = reader.IsDBNull(reader.GetOrdinal("rep_date_end"))
                        ? default
                        : reader.GetDateTime(reader.GetOrdinal("rep_date_end"));
                    rep.Comment = reader["comment"].ToString();
                    collegium_name = reader["law_collegium_name_ru"].ToString();

                }

                reader.Close();

                //xmlelement(name current_date, to_char(current_timestamp, 'DD.MM.YYYY')),
                query = $@"SELECT REPLACE(REPLACE(REPLACE(REPLACE(xmlelement(name root, query_to_xml('SELECT SUM(rep_row_1) as rep_row_1, SUM(rep_row_2) as rep_row_2, SUM(rep_row_3) as rep_row_3, SUM(rep_row_4) as rep_row_4,
                SUM(rep_row_5) as rep_row_5, SUM(rep_row_6) as rep_row_6, SUM(rep_row_7) as rep_row_7, SUM(rep_row_8) as rep_row_8,
                SUM(rep_row_9) as rep_row_9, SUM(rep_row_10) as rep_row_10, SUM(rep_row_11) as rep_row_11, SUM(rep_row_12) as rep_row_12,
                SUM(rep_row_13) as rep_row_13, SUM(rep_row_14) as rep_row_14, SUM(rep_row_15) as rep_row_15, SUM(rep_row_16) as rep_row_16,
                SUM(rep_row_17) as rep_row_17, SUM(rep_row_18) as rep_row_18, SUM(rep_row_19) as rep_row_19, SUM(rep_row_20) as rep_row_20,
                SUM(rep_row_21) as rep_row_21, SUM(rep_row_1_2) as rep_row_1_2, SUM(rep_row_2_2) as rep_row_2_2, SUM(rep_row_3_2) as rep_row_3_2,
                SUM(rep_row_4_2) as rep_row_4_2, SUM(rep_row_5_2) as rep_row_5_2, SUM(rep_row_6_2) as rep_row_6_2, SUM(rep_row_7_2) as rep_row_7_2,
                SUM(rep_row_8_2) as rep_row_8_2, SUM(rep_row_9_2) as rep_row_9_2, SUM(rep_row_10_2) as rep_row_10_2, SUM(rep_row_11_2) as rep_row_11_2,
                SUM(rep_row_12_2) as rep_row_12_2, SUM(rep_row_13_2) as rep_row_13_2, SUM(rep_row_14_2) as rep_row_14_2, SUM(rep_row_15_2) as rep_row_15_2,
                SUM(rep_row_16_2) as rep_row_16_2, SUM(rep_row_17_2) as rep_row_17_2, SUM(rep_row_18_2) as rep_row_18_2, SUM(rep_row_19_2) as rep_row_19_2,
                SUM(rep_row_20_2) as rep_row_20_2, SUM(rep_row_21_2) as rep_row_21_2, SUM(rep_row_22_1) as rep_row_22_1, SUM(rep_row_22_2) as rep_row_22_2,
                SUM(rep_row_22_3) as rep_row_22_3, SUM(rep_row_22_4) as rep_row_22_4, SUM(rep_row_23_1) as rep_row_23_1, SUM(rep_row_23_2) as rep_row_23_2,
                SUM(rep_row_23_3) as rep_row_23_3, SUM(rep_row_23_4) as rep_row_23_4, SUM(rep_row_24_1) as rep_row_24_1, SUM(rep_row_24_2) as rep_row_24_2,
                SUM(rep_row_24_3) as rep_row_24_3, SUM(rep_row_24_4) as rep_row_24_4, SUM(rep_row_25_1) as rep_row_25_1, SUM(rep_row_25_2) as rep_row_25_2,
                SUM(rep_row_25_3) as rep_row_25_3, SUM(rep_row_25_4) as rep_row_25_4, SUM(rep_row_26_1) as rep_row_26_1, SUM(rep_row_26_2) as rep_row_26_2,
                SUM(rep_row_26_3) as rep_row_26_3, SUM(rep_row_26_4) as rep_row_26_4, SUM(rep_row_27_1) as rep_row_27_1, SUM(rep_row_27_2) as rep_row_27_2,
                SUM(rep_row_27_3) as rep_row_27_3, SUM(rep_row_27_4) as rep_row_27_4, SUM(rep_row_28_1) as rep_row_28_1, SUM(rep_row_28_2) as rep_row_28_2,
                SUM(rep_row_28_3) as rep_row_28_3, SUM(rep_row_28_4) as rep_row_28_4, SUM(rep_row_29_1) as rep_row_29_1, SUM(rep_row_29_2) as rep_row_29_2,
                SUM(rep_row_29_3) as rep_row_29_3, SUM(rep_row_29_4) as rep_row_29_4, SUM(rep_row_30_1) as rep_row_30_1, SUM(rep_row_30_2) as rep_row_30_2,
                SUM(rep_row_30_3) as rep_row_30_3, SUM(rep_row_30_4) as rep_row_30_4, SUM(rep_row_31_1) as rep_row_31_1, SUM(rep_row_31_2) as rep_row_31_2,
                SUM(rep_row_31_3) as rep_row_31_3, SUM(rep_row_31_4) as rep_row_31_4,
                SUM(CASE WHEN COALESCE(rep_row_1, 0) > 0 THEN 1 ELSE 0 END) as rep_row_51_1,
                SUM(CASE WHEN (COALESCE(rep_row_4, 0) > 0 OR COALESCE(rep_row_6, 0) > 0) THEN 1 ELSE 0 END) as rep_row_52_1,
                SUM(CASE WHEN (COALESCE(rep_row_4_2, 0) > 0 OR COALESCE(rep_row_6_2, 0) > 0) THEN 1 ELSE 0 END) as rep_row_52_2,
                SUM(CASE WHEN COALESCE(rep_row_7, 0) > 0 THEN 1 ELSE 0 END) as rep_row_53_1,
                SUM(CASE WHEN COALESCE(rep_row_7_2, 0) > 0 THEN 1 ELSE 0 END) as rep_row_53_2,
                SUM(CASE WHEN COALESCE(rep_row_9, 0) > 0 THEN 1 ELSE 0 END) as rep_row_54_1,
                SUM(CASE WHEN COALESCE(rep_row_9_2, 0) > 0 THEN 1 ELSE 0 END) as rep_row_54_2

                FROM rep_law_state_aid
                WHERE law_collegium_id = {collegiumId} and rep_date_begin >= ''{rep.BeginDate.ToShortDateString()}'' and rep_date_end <= ''{rep.EndDate.ToShortDateString()}'' and rep_status = 5', false, false, ''),
                        query_to_xml('SELECT COUNT(*) as rep_row_32_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId}', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_32_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and subj_law_supp_is_rural = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_33_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_33_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M'' and subj_law_supp_is_rural = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_34_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_34_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_35_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_35_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_36_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_36_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_37_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_37_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F'' and subj_law_supp_is_rural = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_38_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_38_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_39_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_39_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_40_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_40_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years''', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_41_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_41_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and law_state_aids = 1 and subj_law_supp_is_rural = 1', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_42_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_42_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''M'' and subj_law_supp_is_rural = 1 and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_43_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_43_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_44_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_44_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_45_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_45_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''M'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, ''),

                query_to_xml('SELECT COUNT(*) as rep_row_46_1 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_46_2 FROM subjects_law_suppliers_persons WHERE law_collegium_id = {collegiumId} and gender=''F'' and subj_law_supp_is_rural = 1 and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_47_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_47_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) <= interval ''35 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_48_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_48_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''36 years'' and age(current_date, date_of_birth) <= interval ''60 years'' and law_state_aids = 1 ', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_49_1 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, ''),
                query_to_xml('SELECT COUNT(*) as rep_row_49_2 from subjects_law_suppliers_persons where law_collegium_id = {collegiumId} and gender = ''F'' and subj_law_supp_is_rural = 1 and age(current_date, date_of_birth) >= interval ''61 years'' and law_state_aids = 1', false, false, '')" +
                        ")::text, '<table xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">',  ' '), '</table>',  ' '), '<row>',  ' '), '</row>',  ' ');";

                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    var xml = reader["replace"].ToString();
                    var doc = XDocument.Parse(xml);
                    var reportFields = doc.Element("root")?.Elements().ToDictionary(repRow => repRow.Name.ToString(), repRow => repRow.Value.ToString());

                    if (reportFields == null)
                    {
                        continue;
                    }

                    reportFields.Add("rep_law_state_colleg_id", id);
                    ViewBag.Report = reportFields;
                }

                reader.Close();

                query = @"select rep_row_50_1, rep_row_50_2, rep_row_51_1, rep_row_51_2, rep_row_52_1, rep_row_52_2, rep_row_53_1, rep_row_53_2, rep_row_54_1, rep_row_54_2,
                            rep_row_55_1, rep_row_55_2, rep_row_56_1, rep_row_56_2 from rep_law_state_aid_colleg where rep_law_state_aid_colleg_id = " + id + ";";
                reader = Provider.RunQuery(query);
                var model = new CollegialReportDBModel();

                while (reader.Read())
                {
                    model.rep_row_50_1 = reader["rep_row_50_1"] is DBNull ? 0 : int.Parse(reader["rep_row_50_1"].ToString());
                    model.rep_row_50_2 = reader["rep_row_50_2"] is DBNull ? 0 : int.Parse(reader["rep_row_50_2"].ToString());
                    model.rep_row_51_1 = reader["rep_row_51_1"] is DBNull ? 0 : int.Parse(reader["rep_row_51_1"].ToString());
                    model.rep_row_51_2 = reader["rep_row_51_2"] is DBNull ? 0 : int.Parse(reader["rep_row_51_2"].ToString());
                    model.rep_row_52_1 = reader["rep_row_52_1"] is DBNull ? 0 : int.Parse(reader["rep_row_52_1"].ToString());
                    model.rep_row_52_2 = reader["rep_row_52_2"] is DBNull ? 0 : int.Parse(reader["rep_row_52_2"].ToString());
                    model.rep_row_53_1 = reader["rep_row_53_1"] is DBNull ? 0 : int.Parse(reader["rep_row_53_1"].ToString());
                    model.rep_row_53_2 = reader["rep_row_53_2"] is DBNull ? 0 : int.Parse(reader["rep_row_53_2"].ToString());
                    model.rep_row_54_1 = reader["rep_row_54_1"] is DBNull ? 0 : int.Parse(reader["rep_row_54_1"].ToString());
                    model.rep_row_54_2 = reader["rep_row_54_2"] is DBNull ? 0 : int.Parse(reader["rep_row_54_2"].ToString());
                    model.rep_row_55_1 = reader["rep_row_55_1"] is DBNull ? 0 : int.Parse(reader["rep_row_55_1"].ToString());
                    model.rep_row_55_2 = reader["rep_row_55_2"] is DBNull ? 0 : int.Parse(reader["rep_row_55_2"].ToString());
                    model.rep_row_56_1 = reader["rep_row_56_1"] is DBNull ? 0 : int.Parse(reader["rep_row_56_1"].ToString());
                    model.rep_row_56_2 = reader["rep_row_56_2"] is DBNull ? 0 : int.Parse(reader["rep_row_56_2"].ToString());
                }

                reader.Close();

                model.rep_period = $"{rep.BeginDate:MMMM yyyy} - {rep.EndDate:MMMM yyyy}";
                model.comment = collegium_name;

                return View(model);
            }
        }

        public ActionResult LawyerReport(string id, string month)
        {
            var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

            lock (Provider.Locker)
            {
                if (claim == "2" || claim == "4" || claim == "42") // Проверка роли
                {
                    var model = new CollegialReportDBModel();

                    var addSecure = string.Empty;

                    if (claim == "2")
                    {
                        addSecure = $" and t2.person_id = '{User.Identity.GetUserId()}'";
                    }

                    if (id != null) // Редактирование старого отчёта
                    {
                        var query = $@"SELECT t1.*, t2.subj_law_supplier_name, t3.subj_name, t4.*, lc.law_collegium_name_ru
                                    FROM rep_law_state_aid t1
                                    INNER JOIN subjects_law_suppliers t2 on t1.subj_law_supplier_id = t2.subj_law_supplier_id
                                    INNER JOIN subjects t3 on t1.user_id = t3.user_id
                                    LEFT JOIN rep_aid_pay_request t4 on t4.rep_law_state_aid_id = t1.rep_law_state_aid_id
                                    LEFT JOIN law_collegiums lc on lc.law_collegium_id = t2.law_collegium_id
                                    WHERE t1.rep_law_state_aid_id = {id}{addSecure};";

                        var reader = Provider.RunQuery(query);

                        while (reader.Read())
                        {
                            model.subj_law_supplier_id = reader["subj_law_supplier_name"].ToString();
                            model.collegium_name = reader["law_collegium_name_ru"].ToString();
                            model.rep_date_begin = reader.GetFieldValueOrDefault<DateTime>("rep_date_begin").ToString("MMMM yyyy");
                            model.rep_date_end = reader["rep_date_end"].ToString();
                            try
                            {
                                model.rep_period = Convert.ToDateTime(reader["rep_date_begin"]).ToString("dd.MM.yyyy") +
                                                   "/" + Convert.ToDateTime(reader["rep_date_end"]).ToString("dd.MM.yyyy");
                            }
                            catch (InvalidCastException)
                            {
                                model.rep_period = null;
                            }
                            model.rep_number = reader["rep_number"].ToString();
                            model.rep_status = reader["rep_status"].ToString();
                            model.person_id = reader["subj_name"].ToString();
                            model.rep_row_1 = reader["rep_row_1"].ToString();
                            model.rep_row_1_2 = reader["rep_row_1_2"].ToString();
                            model.rep_row_2 = reader["rep_row_2"].ToString();
                            model.rep_row_2_2 = reader["rep_row_2_2"].ToString();
                            //model.rep_row_2 = reader.GetInt32(reader.GetOrdinal("rep_row_2"));
                            //model.rep_row_2_2 = reader.GetInt32(reader.GetOrdinal("rep_row_2_2"));
                            model.rep_row_3 = reader["rep_row_3"].ToString();
                            model.rep_row_3_2 = reader["rep_row_3_2"].ToString();
                            model.rep_row_4 = reader["rep_row_4"].ToString();
                            model.rep_row_4_2 = reader["rep_row_4_2"].ToString();
                            model.rep_row_5 = reader["rep_row_5"].ToString();
                            model.rep_row_5_2 = reader["rep_row_5_2"].ToString();
                            model.rep_row_6 = reader["rep_row_6"].ToString();
                            model.rep_row_6_2 = reader["rep_row_6_2"].ToString();
                            model.rep_row_7 = reader["rep_row_7"].ToString();
                            model.rep_row_7_2 = reader["rep_row_7_2"].ToString();
                            model.rep_row_8 = reader["rep_row_8"].ToString();
                            model.rep_row_8_2 = reader["rep_row_8_2"].ToString();
                            model.rep_row_9 = reader["rep_row_9"].ToString();
                            model.rep_row_9_2 = reader["rep_row_9_2"].ToString();
                            model.rep_row_10 = reader["rep_row_10"].ToString();
                            model.rep_row_10_2 = reader["rep_row_10_2"].ToString();
                            model.rep_row_11 = reader["rep_row_11"].ToString();
                            model.rep_row_11_2 = reader["rep_row_11_2"].ToString();
                            model.rep_row_12 = reader["rep_row_12"].ToString();
                            model.rep_row_12_2 = reader["rep_row_12_2"].ToString();
                            model.rep_row_13 = reader["rep_row_13"].ToString();
                            model.rep_row_13_2 = reader["rep_row_13_2"].ToString();
                            model.rep_row_14 = reader["rep_row_14"].ToString();
                            model.rep_row_14_2 = reader["rep_row_14_2"].ToString();
                            model.rep_row_15 = reader["rep_row_15"].ToString();
                            model.rep_row_15_2 = reader["rep_row_15_2"].ToString();
                            model.rep_row_16 = reader["rep_row_16"].ToString();
                            model.rep_row_16_2 = reader["rep_row_16_2"].ToString();
                            model.rep_row_17 = reader["rep_row_17"].ToString();
                            model.rep_row_17_2 = reader["rep_row_17_2"].ToString();
                            model.rep_row_18 = reader["rep_row_18"].ToString();
                            model.rep_row_18_2 = reader["rep_row_18_2"].ToString();
                            model.rep_row_19 = reader["rep_row_19"].ToString();
                            model.rep_row_19_2 = reader["rep_row_19_2"].ToString();
                            model.rep_row_20 = reader["rep_row_20"].ToString();
                            model.rep_row_20_2 = reader["rep_row_20_2"].ToString();
                            model.rep_row_21 = reader["rep_row_21"].ToString();
                            model.rep_row_21_2 = reader["rep_row_21_2"].ToString();
                            model.rep_row_22_1 = reader["rep_row_22_1"].ToString();
                            model.rep_row_22_2 = reader["rep_row_22_2"].ToString();
                            model.rep_row_22_3 = reader["rep_row_22_3"].ToString();
                            model.rep_row_22_4 = reader["rep_row_22_4"].ToString();
                            model.rep_row_23_1 = reader["rep_row_23_1"].ToString();
                            model.rep_row_23_2 = reader["rep_row_23_2"].ToString();
                            model.rep_row_23_3 = reader["rep_row_23_3"].ToString();
                            model.rep_row_23_4 = reader["rep_row_23_4"].ToString();
                            model.rep_row_24_1 = reader["rep_row_24_1"].ToString();
                            model.rep_row_24_2 = reader["rep_row_24_2"].ToString();
                            model.rep_row_24_3 = reader["rep_row_24_3"].ToString();
                            model.rep_row_24_4 = reader["rep_row_24_4"].ToString();
                            model.rep_row_25_1 = reader["rep_row_25_1"].ToString();
                            model.rep_row_25_2 = reader["rep_row_25_2"].ToString();
                            model.rep_row_25_3 = reader["rep_row_25_3"].ToString();
                            model.rep_row_25_4 = reader["rep_row_25_4"].ToString();
                            model.rep_row_26_1 = reader["rep_row_26_1"].ToString();
                            model.rep_row_26_2 = reader["rep_row_26_2"].ToString();
                            model.rep_row_26_3 = reader["rep_row_26_3"].ToString();
                            model.rep_row_26_4 = reader["rep_row_26_4"].ToString();
                            model.rep_row_27_1 = reader["rep_row_27_1"].ToString();
                            model.rep_row_27_2 = reader["rep_row_27_2"].ToString();
                            model.rep_row_27_3 = reader["rep_row_27_3"].ToString();
                            model.rep_row_27_4 = reader["rep_row_27_4"].ToString();
                            model.rep_row_28_1 = reader["rep_row_28_1"].ToString();
                            model.rep_row_28_2 = reader["rep_row_28_2"].ToString();
                            model.rep_row_28_3 = reader["rep_row_28_3"].ToString();
                            model.rep_row_28_4 = reader["rep_row_28_4"].ToString();
                            model.rep_row_29_1 = reader["rep_row_29_1"].ToString();
                            model.rep_row_29_2 = reader["rep_row_29_2"].ToString();
                            model.rep_row_29_3 = reader["rep_row_29_3"].ToString();
                            model.rep_row_29_4 = reader["rep_row_29_4"].ToString();
                            model.rep_row_30_1 = reader["rep_row_30_1"].ToString();
                            model.rep_row_30_2 = reader["rep_row_30_2"].ToString();
                            model.rep_row_30_3 = reader["rep_row_30_3"].ToString();
                            model.rep_row_30_4 = reader["rep_row_30_4"].ToString();
                            model.rep_row_31_1 = reader["rep_row_31_1"].ToString();
                            model.rep_row_31_2 = reader["rep_row_31_2"].ToString();
                            model.rep_row_31_3 = reader["rep_row_31_3"].ToString();
                            model.rep_row_31_4 = reader["rep_row_31_4"].ToString();
                            model.rep_law_state_aid_id = reader["rep_law_state_aid_id"].ToString();

                            model.r2_docs_legal_adv_count = GetIntFromString(reader["r2_docs_legal_adv_count"].ToString());
                            model.r2_docs_legal_adv_hourses = GetIntFromString(reader["r2_docs_legal_adv_hourses"].ToString());
                            model.r2_docs_legal_adv_sum = GetIntFromString(reader["r2_docs_legal_adv_sum"].ToString());
                            model.r2_oral_legal_adv_count = GetIntFromString(reader["r2_oral_legal_adv_count"].ToString());
                            model.r2_oral_legal_adv_hourses = GetIntFromString(reader["r2_oral_legal_adv_hourses"].ToString());
                            model.r2_oral_legal_adv_sum = GetIntFromString(reader["r2_oral_legal_adv_sum"].ToString());
                            model.r2_total = GetIntFromString(reader["r2_total"].ToString());
                            model.r41_law_adv_esp_grave_before_count = GetIntFromString(reader["r41_law_adv_esp_grave_before_count"].ToString());
                            model.r41_law_adv_esp_grave_before_hourses = GetIntFromString(reader["r41_law_adv_esp_grave_before_hourses"].ToString());
                            model.r41_law_adv_esp_grave_before_sum = GetIntFromString(reader["r41_law_adv_esp_grave_before_sum"].ToString());
                            model.r41_law_adv_esp_grave_before_total = GetIntFromString(reader["r41_law_adv_esp_grave_before_total"].ToString());
                            model.r42_law_adv_grave_before_count = GetIntFromString(reader["r42_law_adv_grave_before_count"].ToString());
                            model.r42_law_adv_grave_before_hourses = GetIntFromString(reader["r42_law_adv_grave_before_hourses"].ToString());
                            model.r42_law_adv_grave_before_sum = GetIntFromString(reader["r42_law_adv_grave_before_sum"].ToString());
                            model.r43_law_adv_not_grave_before_count = GetIntFromString(reader["r43_law_adv_not_grave_before_count"].ToString());
                            model.r43_law_adv_not_grave_before_hourses = GetIntFromString(reader["r43_law_adv_not_grave_before_hourses"].ToString());
                            model.r43_law_adv_not_grave_before_sum = GetIntFromString(reader["r43_law_adv_not_grave_before_sum"].ToString());
                            model.r44_law_adv_esp_grave_court_count = GetIntFromString(reader["r44_law_adv_esp_grave_court_count"].ToString());
                            model.r44_law_adv_esp_grave_court_hourses = GetIntFromString(reader["r44_law_adv_esp_grave_court_hourses"].ToString());
                            model.r44_law_adv_esp_grave_court_sum = GetIntFromString(reader["r44_law_adv_esp_grave_court_sum"].ToString());
                            model.r44_law_adv_esp_grave_court_total = GetIntFromString(reader["r44_law_adv_esp_grave_court_total"].ToString());
                            model.r45_law_adv_grave_court_count = GetIntFromString(reader["r45_law_adv_grave_court_count"].ToString());
                            model.r45_law_adv_grave_court_hourses = GetIntFromString(reader["r45_law_adv_grave_court_hourses"].ToString());
                            model.r45_law_adv_grave_court_sum = GetIntFromString(reader["r45_law_adv_grave_court_sum"].ToString());
                            model.r46_law_adv_not_grave_court_count = GetIntFromString(reader["r46_law_adv_not_grave_court_count"].ToString());
                            model.r46_law_adv_not_grave_court_hourses = GetIntFromString(reader["r46_law_adv_not_grave_court_hourses"].ToString());
                            model.r46_law_adv_not_grave_court_sum = GetIntFromString(reader["r46_law_adv_not_grave_court_sum"].ToString());
                            model.r61_rep_adv_esp_grave_before_count = GetIntFromString(reader["r61_rep_adv_esp_grave_before_count"].ToString());
                            model.r61_rep_adv_esp_grave_before_hourses = GetIntFromString(reader["r61_rep_adv_esp_grave_before_hourses"].ToString());
                            model.r61_rep_adv_esp_grave_before_sum = GetIntFromString(reader["r61_rep_adv_esp_grave_before_sum"].ToString());
                            model.r61_rep_adv_esp_grave_before_total = GetIntFromString(reader["r61_rep_adv_esp_grave_before_total"].ToString());
                            model.r62_rep_adv_grave_before_count = GetIntFromString(reader["r62_rep_adv_grave_before_count"].ToString());
                            model.r62_rep_adv_grave_before_hourses = GetIntFromString(reader["r62_rep_adv_grave_before_hourses"].ToString());
                            model.r62_rep_adv_grave_before_sum = GetIntFromString(reader["r62_rep_adv_grave_before_sum"].ToString());
                            model.r63_rep_adv_not_grave_before_count = GetIntFromString(reader["r63_rep_adv_not_grave_before_count"].ToString());
                            model.r63_rep_adv_not_grave_before_hourses = GetIntFromString(reader["r63_rep_adv_not_grave_before_hourses"].ToString());
                            model.r63_rep_adv_not_grave_before_sum = GetIntFromString(reader["r63_rep_adv_not_grave_before_sum"].ToString());
                            model.r64_rep_adv_esp_grave_court_count = GetIntFromString(reader["r64_rep_adv_esp_grave_court_count"].ToString());
                            model.r64_rep_adv_esp_grave_court_hourses = GetIntFromString(reader["r64_rep_adv_esp_grave_court_hourses"].ToString());
                            model.r64_rep_adv_esp_grave_court_sum = GetIntFromString(reader["r64_rep_adv_esp_grave_court_sum"].ToString());
                            model.r64_rep_adv_esp_grave_court_total = GetIntFromString(reader["r64_rep_adv_esp_grave_court_total"].ToString());
                            model.r65_rep_adv_grave_court_count = GetIntFromString(reader["r65_rep_adv_grave_court_count"].ToString());
                            model.r65_rep_adv_grave_court_hourses = GetIntFromString(reader["r65_rep_adv_grave_court_hourses"].ToString());
                            model.r65_rep_adv_grave_court_sum = GetIntFromString(reader["r65_rep_adv_grave_court_sum"].ToString());
                            model.r66_rep_adv_not_grave_court_count = GetIntFromString(reader["r66_rep_adv_not_grave_court_count"].ToString());
                            model.r66_rep_adv_not_grave_court_hourses = GetIntFromString(reader["r66_rep_adv_not_grave_court_hourses"].ToString());
                            model.r66_rep_adv_not_grave_court_sum = GetIntFromString(reader["r66_rep_adv_not_grave_court_sum"].ToString());
                            model.r7_law_adm_count = GetIntFromString(reader["r7_law_adm_count"].ToString());
                            model.r7_law_adm_hourses = GetIntFromString(reader["r7_law_adm_hourses"].ToString());
                            model.r7_law_adm_sum = GetIntFromString(reader["r7_law_adm_sum"].ToString());
                            model.r7_law_adm_total = GetIntFromString(reader["r7_law_adm_total"].ToString());
                            model.r8_law_civil_112_count = GetIntFromString(reader["r8_law_civil_112_count"].ToString());
                            model.r8_law_civil_112_hourses = GetIntFromString(reader["r8_law_civil_112_hourses"].ToString());
                            model.r8_law_civil_112_sum = GetIntFromString(reader["r8_law_civil_112_sum"].ToString());
                            model.r8_law_civil_total = GetIntFromString(reader["r8_law_civil_total"].ToString());
                            model.r9_law_civil_325_count = GetIntFromString(reader["r9_law_civil_325_count"].ToString());
                            model.r9_law_civil_325_hourses = GetIntFromString(reader["r9_law_civil_325_hourses"].ToString());
                            model.r9_law_civil_325_sum = GetIntFromString(reader["r9_law_civil_325_sum"].ToString());
                        }

                        reader.Close();

                        switch (claim)
                        {
                            case "4": // Смотрит секретарь
                                switch (model.rep_status)
                                {
                                    case "2": // Отправлен в коллегию
                                    case "5": // Согласован 
                                    case "7": // Запрос на корректировку
                                    case "4": // Откронён
                                    case "8": // На доработке
                                        return View("ReadOnlyLawyerReport", model);
                                    case "9": // Принято БУ 
                                        return View("ReadOnlyLawyerReport", model);
                                    default:
                                        ViewBag.Message = "Ошибка доступа к отчёту";
                                        return View("Error");
                                }
                            case "42": // Смотрит секретарь
                                switch (model.rep_status)
                                {
                                    case "2": // Отправлен в коллегию
                                    case "5": // Согласован 
                                        return View("ReadOnlyLawyerReport", model);
                                    case "7": // Запрос на корректировку
                                    case "4": // Откронён
                                    case "9": // Принято БУ 
                                        return View("ReadOnlyLawyerReport", model);
                                    default:
                                        ViewBag.Message = "Ошибка доступа к отчёту";
                                        return View("Error");
                                }
                            case "2": // Смотрит Клиент
                                switch (model.rep_status)
                                {
                                    case "1": // Новый
                                    case "3": // Подписан
                                    case "4": // Откронён
                                    case "8": // На доработке
                                        return View(model);
                                    case "2": // Отправлен в коллегию
                                    case "5": // Согласован 
                                    case "7": // Запрос на корректировку
                                        return View("ReadOnlyLawyerReport", model);
                                    case "9": // Принято БУ 
                                        return View("ReadOnlyLawyerReport", model);
                                    default:
                                        ViewBag.Message = "Ошибка доступа к отчёту";
                                        return View("Error");
                                }

                        }
                    }
                    else // Новый отчёт
                    {
                        // Получение номера коллегии и имени клиента

                        var collegiumId = string.Empty;
                        var lawyerName = string.Empty;
                        var query = @"SELECT subj_law_supplier_name, law_collegium_id
                                      FROM subjects_law_suppliers
                                     WHERE person_id = '" + User.Identity.GetUserId() + "';";
                        var reader = Provider.RunQuery(query);

                        while (reader.Read())
                        {
                            collegiumId = reader["law_collegium_id"].ToString();
                            lawyerName = reader["subj_law_supplier_name"].ToString();
                        }

                        reader.Close();

                        var subjLawSupplId = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "subject_law_supplier_id").Value;
                        var userId = User.Identity.GetUserId();

                        var repDate = month.Split('/');

                        // Проверка на инъекцию или изменение HTML содержимого
                        if ((repDate[0] == DateTime.Now.AddMonths(-1).Month.ToString().PadLeft(2, '0') ||
                             repDate[0] == DateTime.Now.AddMonths(1).Month.ToString().PadLeft(2, '0') ||
                             repDate[0] == DateTime.Now.Month.ToString().PadLeft(2, '0')) &&
                            (repDate[1] == DateTime.Now.AddMonths(-1).Year.ToString() ||
                             repDate[1] == DateTime.Now.AddMonths(1).Year.ToString() ||
                             repDate[1] == DateTime.Now.Year.ToString()))
                        {
                            //Добавить 0, если месяц меньше 10
                            if (repDate[0].Length == 1)
                            {
                                repDate[0].Insert(0, "0");
                            }

                            var beginDate = DateTime.Parse($"01.{repDate[0]}.{repDate[1]}");
                            var daysInMonth = DateTime.DaysInMonth(int.Parse(repDate[1]), int.Parse(repDate[0]));
                            var iyear = int.Parse(repDate[1]);
                            var imonth = int.Parse(repDate[0]);
                            //var endDate = DateTime.Parse($"{daysInMonth}.{repDate[0]}.{repDate[1]}");
                            var endDate = new DateTime(iyear, imonth, daysInMonth);
                            var iin = string.Empty;

                            //Получение ИИН для формирования номера отчёта
                            query = "SELECT person_code FROM persons where user_id = '" + User.Identity.GetUserId() + "'";
                            reader = Provider.RunQuery(query);

                            while (reader.Read())
                            {
                                iin = reader["person_code"].ToString();
                            }

                            reader.Close();

                            var reportNumber = $"{iin}-1-{beginDate.Month}-{beginDate.Year}";

                            var newId = Provider.AddNewReport(subjLawSupplId, userId, collegiumId, beginDate.ToShortDateString(), endDate.ToShortDateString(), reportNumber);

                            query = "INSERT INTO public.rep_aid_pay_request(rep_law_state_aid_id) VALUES(" + newId + ")";
                            var readerNon = Provider.RunNonQuery(query);
                            // Логгирование.
                            // Получение наименования текущего клиента/секретаря.
                            var logText = $"Отчёт был создан адвокатом \"{lawyerName}\"";
                            Provider.RunScalarStoredProcedure("add_to_log",
                                logText,
                                "Отчёт клиента - создание",
                                User.Identity.GetUserId(),
                                User.Identity.GetUserId(),
                                newId,
                                "rep_law_state_aid");

                            return RedirectToAction("LawyerReport", new { id = newId });
                        }

                        ViewBag.Message = "Возникла ошибка с созданием отчёта.";

                        return View("Error");
                    }
                }
            }

            ViewBag.Message("Недостаточно прав");

            return View("Error");
        }

        public ActionResult SaveLawyerReport(CollegialReportDBModel model)
        {
            model.rep_row_1 = model.rep_row_1 ?? "0";
            model.rep_row_2 = model.rep_row_2 ?? "0";
            model.rep_row_3 = model.rep_row_3 ?? "0";
            model.rep_row_4 = model.rep_row_4 ?? "0";
            model.rep_row_5 = model.rep_row_5 ?? "0";
            model.rep_row_6 = model.rep_row_6 ?? "0";
            model.rep_row_7 = model.rep_row_7 ?? "0";
            model.rep_row_8 = model.rep_row_8 ?? "0";
            model.rep_row_9 = model.rep_row_9 ?? "0";
            model.rep_row_10 = model.rep_row_10 ?? "0";
            model.rep_row_11 = model.rep_row_11 ?? "0";
            model.rep_row_12 = model.rep_row_12 ?? "0";
            model.rep_row_13 = model.rep_row_13 ?? "0";
            model.rep_row_14 = model.rep_row_14 ?? "0";
            model.rep_row_15 = model.rep_row_15 ?? "0";
            model.rep_row_16 = model.rep_row_16 ?? "0";
            model.rep_row_17 = model.rep_row_17 ?? "0";
            model.rep_row_18 = model.rep_row_18 ?? "0";
            model.rep_row_19 = model.rep_row_19 ?? "0";
            model.rep_row_20 = model.rep_row_20 ?? "0";
            model.rep_row_21 = model.rep_row_21 ?? "0";
            model.rep_row_1_2 = model.rep_row_1_2 ?? "0";
            model.rep_row_2_2 = model.rep_row_2_2 ?? "0";
            model.rep_row_3_2 = model.rep_row_3_2 ?? "0";
            model.rep_row_4_2 = model.rep_row_4_2 ?? "0";
            model.rep_row_5_2 = model.rep_row_5_2 ?? "0";
            model.rep_row_6_2 = model.rep_row_6_2 ?? "0";
            model.rep_row_7_2 = model.rep_row_7_2 ?? "0";
            model.rep_row_8_2 = model.rep_row_8_2 ?? "0";
            model.rep_row_9_2 = model.rep_row_9_2 ?? "0";
            model.rep_row_10_2 = model.rep_row_10_2 ?? "0";
            model.rep_row_11_2 = model.rep_row_11_2 ?? "0";
            model.rep_row_12_2 = model.rep_row_12_2 ?? "0";
            model.rep_row_13_2 = model.rep_row_13_2 ?? "0";
            model.rep_row_14_2 = model.rep_row_14_2 ?? "0";
            model.rep_row_15_2 = model.rep_row_15_2 ?? "0";
            model.rep_row_16_2 = model.rep_row_16_2 ?? "0";
            model.rep_row_17_2 = model.rep_row_17_2 ?? "0";
            model.rep_row_18_2 = model.rep_row_18_2 ?? "0";
            model.rep_row_19_2 = model.rep_row_19_2 ?? "0";
            model.rep_row_20_2 = model.rep_row_20_2 ?? "0";
            model.rep_row_21_2 = model.rep_row_21_2 ?? "0";
            model.rep_row_22_1 = model.rep_row_22_1 ?? "0";
            model.rep_row_22_2 = model.rep_row_22_2 ?? "0";
            model.rep_row_22_3 = model.rep_row_22_3 ?? "0";
            model.rep_row_22_4 = model.rep_row_22_4 ?? "0";
            model.rep_row_23_1 = model.rep_row_23_1 ?? "0";
            model.rep_row_23_2 = model.rep_row_23_2 ?? "0";
            model.rep_row_23_3 = model.rep_row_23_3 ?? "0";
            model.rep_row_23_4 = model.rep_row_23_4 ?? "0";
            model.rep_row_24_1 = model.rep_row_24_1 ?? "0";
            model.rep_row_24_2 = model.rep_row_24_2 ?? "0";
            model.rep_row_24_3 = model.rep_row_24_3 ?? "0";
            model.rep_row_24_4 = model.rep_row_24_4 ?? "0";
            model.rep_row_25_1 = model.rep_row_25_1 ?? "0";
            model.rep_row_25_2 = model.rep_row_25_2 ?? "0";
            model.rep_row_25_3 = model.rep_row_25_3 ?? "0";
            model.rep_row_25_4 = model.rep_row_25_4 ?? "0";
            model.rep_row_26_1 = model.rep_row_26_1 ?? "0";
            model.rep_row_26_2 = model.rep_row_26_2 ?? "0";
            model.rep_row_26_3 = model.rep_row_26_3 ?? "0";
            model.rep_row_26_4 = model.rep_row_26_4 ?? "0";
            model.rep_row_27_1 = model.rep_row_27_1 ?? "0";
            model.rep_row_27_2 = model.rep_row_27_2 ?? "0";
            model.rep_row_27_3 = model.rep_row_27_3 ?? "0";
            model.rep_row_27_4 = model.rep_row_27_4 ?? "0";
            model.rep_row_28_1 = model.rep_row_28_1 ?? "0";
            model.rep_row_28_2 = model.rep_row_28_2 ?? "0";
            model.rep_row_28_3 = model.rep_row_28_3 ?? "0";
            model.rep_row_28_4 = model.rep_row_28_4 ?? "0";
            model.rep_row_29_1 = model.rep_row_29_1 ?? "0";
            model.rep_row_29_2 = model.rep_row_29_2 ?? "0";
            model.rep_row_29_3 = model.rep_row_29_3 ?? "0";
            model.rep_row_29_4 = model.rep_row_29_4 ?? "0";
            model.rep_row_30_1 = model.rep_row_30_1 ?? "0";
            model.rep_row_30_2 = model.rep_row_30_2 ?? "0";
            model.rep_row_30_3 = model.rep_row_30_3 ?? "0";
            model.rep_row_30_4 = model.rep_row_30_4 ?? "0";
            model.rep_row_31_1 = model.rep_row_31_1 ?? "0";
            model.rep_row_31_2 = model.rep_row_31_2 ?? "0";
            model.rep_row_31_3 = model.rep_row_31_3 ?? "0";
            model.rep_row_31_4 = model.rep_row_31_4 ?? "0";
            model.rep_number = model.rep_number ?? "0";

            var query = @"UPDATE public.rep_law_state_aid " +
                "SET rep_row_1 =" + model.rep_row_1 + ", rep_row_2 =" + model.rep_row_2 + ", rep_row_3 =" + model.rep_row_3 + ", rep_row_4 =" + model.rep_row_4 +
                ", rep_row_5 =" + model.rep_row_5 + ", rep_row_6 =" + model.rep_row_6 + ", rep_row_7 =" + model.rep_row_7 + ", rep_row_8 = " + model.rep_row_8 +
                ", rep_row_9 = " + model.rep_row_9 + ", rep_row_10 =" + model.rep_row_10 + ", rep_row_11 =" + model.rep_row_11 + ", rep_row_12 =" + model.rep_row_12 +
                ", rep_row_13 =" + model.rep_row_13 + ", rep_row_14 =" + model.rep_row_14 + ", rep_row_15 =" + model.rep_row_15 + ", rep_row_16 =" + model.rep_row_16 +
                ", rep_row_17 =" + model.rep_row_17 + ", rep_row_18 =" + model.rep_row_18 + ", rep_row_19 =" + model.rep_row_19 + ", rep_row_20 =" + model.rep_row_20 +
                ", rep_row_21 =" + model.rep_row_21 + ", rep_row_1_2 =" + model.rep_row_1_2 + ", rep_row_2_2 =" + model.rep_row_2_2 + ", rep_row_3_2 =" + model.rep_row_3_2 +
                ", rep_row_4_2 =" + model.rep_row_4_2 + ", rep_row_5_2 =" + model.rep_row_5_2 + ", rep_row_6_2 =" + model.rep_row_6_2 + ", rep_row_7_2 =" + model.rep_row_7_2 +
                ", rep_row_8_2 =" + model.rep_row_8_2 + ", rep_row_9_2 =" + model.rep_row_9_2 + ", rep_row_10_2 =" + model.rep_row_10_2 + ", rep_row_11_2 =" + model.rep_row_11_2 +
                ", rep_row_12_2 =" + model.rep_row_12_2 + ", rep_row_13_2 =" + model.rep_row_13_2 + ", rep_row_14_2 =" + model.rep_row_14_2 + ", rep_row_15_2 =" + model.rep_row_15_2 +
                ", rep_row_16_2 =" + model.rep_row_16_2 + ", rep_row_17_2 =" + model.rep_row_17_2 + ", rep_row_18_2 =" + model.rep_row_18_2 + ", rep_row_19_2 =" + model.rep_row_19_2 +
                ", rep_row_20_2 =" + model.rep_row_20_2 + ", rep_row_21_2 =" + model.rep_row_21_2 + ", rep_row_22_1 =" + model.rep_row_22_1 + ", rep_row_22_2 =" + model.rep_row_22_2 +
                ", rep_row_22_3 =" + model.rep_row_22_3 + ", rep_row_22_4 =" + model.rep_row_22_4 + ", rep_row_23_1 =" + model.rep_row_23_1 + ", rep_row_23_2 =" + model.rep_row_23_2 +
                ", rep_row_23_3 =" + model.rep_row_23_3 + ", rep_row_23_4 =" + model.rep_row_23_4 + ", rep_row_24_1 =" + model.rep_row_24_1 + ", rep_row_24_2 =" + model.rep_row_24_2 +
                ", rep_row_24_3 =" + model.rep_row_24_3 + ", rep_row_24_4 =" + model.rep_row_24_4 + ", rep_row_25_1 =" + model.rep_row_25_1 + ", rep_row_25_2 =" + model.rep_row_25_2 +
                ", rep_row_25_3 =" + model.rep_row_25_3 + ", rep_row_25_4 =" + model.rep_row_25_4 + ", rep_row_26_1 =" + model.rep_row_26_1 + ", rep_row_26_2 =" + model.rep_row_26_2 +
                ", rep_row_26_3 =" + model.rep_row_26_3 + ", rep_row_26_4 =" + model.rep_row_26_4 + ", rep_row_27_1 =" + model.rep_row_27_1 + ", rep_row_27_2 =" + model.rep_row_27_2 +
                ", rep_row_27_3 =" + model.rep_row_27_3 + ", rep_row_27_4 =" + model.rep_row_27_4 + ", rep_row_28_1 =" + model.rep_row_28_1 + ", rep_row_28_2 =" + model.rep_row_28_2 +
                ", rep_row_28_3 =" + model.rep_row_28_3 + ", rep_row_28_4 =" + model.rep_row_28_4 + ", rep_row_29_1 =" + model.rep_row_29_1 + ", rep_row_29_2 =" + model.rep_row_29_2 +
                ", rep_row_29_3 =" + model.rep_row_29_3 + ", rep_row_29_4 =" + model.rep_row_29_4 + ", rep_row_30_1 =" + model.rep_row_30_1 + ", rep_row_30_2 =" + model.rep_row_30_2 +
                ", rep_row_30_3 =" + model.rep_row_30_3 + ", rep_row_30_4 =" + model.rep_row_30_4 + ", rep_row_31_1 =" + model.rep_row_31_1 + ", rep_row_31_2 =" + model.rep_row_31_2 +

                ", rep_row_31_3 =" + model.rep_row_31_3 + ", rep_row_31_4 =" + model.rep_row_31_4 +
                " WHERE rep_law_state_aid_id = " + model.rep_law_state_aid_id + ";";
            Provider.RunNonQuery(query);

            query = @"UPDATE public.rep_aid_pay_request " +
                "SET r2_docs_legal_adv_count =" + (model.r2_docs_legal_adv_count ?? 0) +
                ", r2_docs_legal_adv_hourses =" + (model.r2_docs_legal_adv_hourses ?? 0) +
                ", r2_docs_legal_adv_sum =" + (model.r2_docs_legal_adv_sum ?? 0) +
                ", r2_oral_legal_adv_count =" + (model.r2_oral_legal_adv_count ?? 0) +
                ", r2_oral_legal_adv_hourses =" + (model.r2_oral_legal_adv_hourses ?? 0) +
                ", r2_oral_legal_adv_sum =" + (model.r2_oral_legal_adv_sum ?? 0) +
                ", r2_total =" + ((model.r2_docs_legal_adv_sum ?? 0) + (model.r2_oral_legal_adv_sum ?? 0)) +
                ", r41_law_adv_esp_grave_before_count =" + (model.r41_law_adv_esp_grave_before_count ?? 0) +
                ", r41_law_adv_esp_grave_before_hourses =" + (model.r41_law_adv_esp_grave_before_hourses ?? 0) +
                ", r41_law_adv_esp_grave_before_sum =" + (model.r41_law_adv_esp_grave_before_sum ?? 0) +
                ", r41_law_adv_esp_grave_before_total =" + ((model.r41_law_adv_esp_grave_before_sum ?? 0) + (model.r42_law_adv_grave_before_sum ?? 0) + (model.r43_law_adv_not_grave_before_sum ?? 0)) +
                ", r42_law_adv_grave_before_count =" + (model.r42_law_adv_grave_before_count ?? 0) +
                ", r42_law_adv_grave_before_hourses =" + (model.r42_law_adv_grave_before_hourses ?? 0) +
                ", r42_law_adv_grave_before_sum =" + (model.r42_law_adv_grave_before_sum ?? 0) +
                ", r43_law_adv_not_grave_before_count =" + (model.r43_law_adv_not_grave_before_count ?? 0) +
                ", r43_law_adv_not_grave_before_hourses =" + (model.r43_law_adv_not_grave_before_hourses ?? 0) +
                ", r43_law_adv_not_grave_before_sum =" + (model.r43_law_adv_not_grave_before_sum ?? 0) +
                ", r44_law_adv_esp_grave_court_count =" + (model.r44_law_adv_esp_grave_court_count ?? 0) +
                ", r44_law_adv_esp_grave_court_hourses =" + (model.r44_law_adv_esp_grave_court_hourses ?? 0) +
                ", r44_law_adv_esp_grave_court_sum =" + (model.r44_law_adv_esp_grave_court_sum ?? 0) +
                ", r44_law_adv_esp_grave_court_total =" +((model.r44_law_adv_esp_grave_court_sum ?? 0) + (model.r45_law_adv_grave_court_sum ?? 0) + (model.r46_law_adv_not_grave_court_sum ?? 0)) +
                ", r45_law_adv_grave_court_count =" + (model.r45_law_adv_grave_court_count ?? 0) +
                ", r45_law_adv_grave_court_hourses =" + (model.r45_law_adv_grave_court_hourses ?? 0) +
                ", r45_law_adv_grave_court_sum =" + (model.r45_law_adv_grave_court_sum ?? 0) +
                ", r46_law_adv_not_grave_court_count =" + (model.r46_law_adv_not_grave_court_count ?? 0) +
                ", r46_law_adv_not_grave_court_hourses =" + (model.r46_law_adv_not_grave_court_hourses ?? 0) +
                ", r46_law_adv_not_grave_court_sum =" + (model.r46_law_adv_not_grave_court_sum ?? 0) +
                ", r61_rep_adv_esp_grave_before_count =" + (model.r61_rep_adv_esp_grave_before_count ?? 0) +
                ", r61_rep_adv_esp_grave_before_hourses =" + (model.r61_rep_adv_esp_grave_before_hourses ?? 0) +
                ", r61_rep_adv_esp_grave_before_sum =" + (model.r61_rep_adv_esp_grave_before_sum ?? 0) +
                ", r61_rep_adv_esp_grave_before_total =" + ((model.r61_rep_adv_esp_grave_before_sum ?? 0) + (model.r62_rep_adv_grave_before_sum ?? 0) + (model.r63_rep_adv_not_grave_before_sum ?? 0)) +
                ", r62_rep_adv_grave_before_count =" + (model.r62_rep_adv_grave_before_count ?? 0) +
                ", r62_rep_adv_grave_before_hourses =" + (model.r62_rep_adv_grave_before_hourses ?? 0) +
                ", r62_rep_adv_grave_before_sum =" + (model.r62_rep_adv_grave_before_sum ?? 0) +
                ", r63_rep_adv_not_grave_before_count =" + (model.r63_rep_adv_not_grave_before_count ?? 0) +
                ", r63_rep_adv_not_grave_before_hourses =" + (model.r63_rep_adv_not_grave_before_hourses ?? 0) +
                ", r63_rep_adv_not_grave_before_sum =" + (model.r63_rep_adv_not_grave_before_sum ?? 0) +
                ", r64_rep_adv_esp_grave_court_count =" + (model.r64_rep_adv_esp_grave_court_count ?? 0) +
                ", r64_rep_adv_esp_grave_court_hourses =" + (model.r64_rep_adv_esp_grave_court_hourses ?? 0) +
                ", r64_rep_adv_esp_grave_court_sum =" + (model.r64_rep_adv_esp_grave_court_sum ?? 0) +
                ", r64_rep_adv_esp_grave_court_total =" + ((model.r64_rep_adv_esp_grave_court_sum ?? 0) + (model.r65_rep_adv_grave_court_sum ?? 0) + (model.r66_rep_adv_not_grave_court_sum ?? 0)) +
                ", r65_rep_adv_grave_court_count =" + (model.r65_rep_adv_grave_court_count ?? 0) +
                ", r65_rep_adv_grave_court_hourses =" + (model.r65_rep_adv_grave_court_hourses ?? 0) +
                ", r65_rep_adv_grave_court_sum =" + (model.r65_rep_adv_grave_court_sum ?? 0) +
                ", r66_rep_adv_not_grave_court_count =" + (model.r66_rep_adv_not_grave_court_count ?? 0) +
                ", r66_rep_adv_not_grave_court_hourses =" + (model.r66_rep_adv_not_grave_court_hourses ?? 0) +
                ", r66_rep_adv_not_grave_court_sum =" + (model.r66_rep_adv_not_grave_court_sum ?? 0) +
                ", r7_law_adm_count =" + (model.r7_law_adm_count ?? 0) +
                ", r7_law_adm_hourses =" + (model.r7_law_adm_hourses ?? 0) +
                ", r7_law_adm_sum =" + (model.r7_law_adm_sum ?? 0) +
                ", r7_law_adm_total =" + (model.r7_law_adm_sum ?? 0) +
                ", r8_law_civil_112_count =" + (model.r8_law_civil_112_count ?? 0) +
                ", r8_law_civil_112_hourses =" + (model.r8_law_civil_112_hourses ?? 0) +
                ", r8_law_civil_112_sum =" + (model.r8_law_civil_112_sum ?? 0) +
                ", r8_law_civil_total =" + ((model.r8_law_civil_112_sum ?? 0) + (model.r9_law_civil_325_sum ?? 0)) +
                ", r9_law_civil_325_count =" + (model.r9_law_civil_325_count ?? 0) +
                ", r9_law_civil_325_hourses =" + (model.r9_law_civil_325_hourses ?? 0) +
                ", r9_law_civil_325_sum =" + (model.r9_law_civil_325_sum ?? 0) +
                " WHERE rep_law_state_aid_id = " + model.rep_law_state_aid_id + ";";

            Provider.RunNonQuery(query);

            //return RedirectToAction("LawyerReport", "Report", new { id = model.rep_law_state_aid_id });
            return RedirectToAction("MyReports", "Report");
        }

        public ActionResult PrintLawyerReport(string id)
        {
            lock (Provider.Locker)
            {
                var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

                if (claim != "2" && claim != "4")
                {
                    return View("Error");
                }

                var model = new CollegialReportDBModel();

                var query = @"SELECT t1.*, t2.*, t3.subj_name, lc.law_collegium_name_ru
                            FROM rep_law_state_aid t1
                            INNER JOIN subjects_law_suppliers t2 on t1.subj_law_supplier_id = t2.subj_law_supplier_id
                            JOIN subjects t3 ON t2.person_id = t3.user_id
							join law_collegiums lc on lc.law_collegium_id = t2.law_collegium_id
                            WHERE rep_law_state_aid_id = " + id + ";";

                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    model.subj_law_supplier_id = reader["subj_law_supplier_name"].ToString();
                    model.rep_date_begin = Convert.ToDateTime(reader["rep_date_begin"]).ToString("MMMM yyyy");
                    model.rep_date_end = Convert.ToDateTime(reader["rep_date_end"]).ToString("MMMM yyyy");
                    model.rep_number = reader["rep_number"].ToString();
                    model.rep_status = reader["rep_status"].ToString();
                    model.person_id = reader["subj_name"].ToString();
                    model.rep_row_1 = reader["rep_row_1"].ToString() ?? "0";
                    model.rep_row_2 = reader["rep_row_2"].ToString() ?? "0";
                    model.rep_row_3 = reader["rep_row_3"].ToString() ?? "0";
                    model.rep_row_4 = reader["rep_row_4"].ToString() ?? "0";
                    model.rep_row_5 = reader["rep_row_5"].ToString() ?? "0";
                    model.rep_row_6 = reader["rep_row_6"].ToString() ?? "0";
                    model.rep_row_7 = reader["rep_row_7"].ToString() ?? "0";
                    model.rep_row_8 = reader["rep_row_8"].ToString() ?? "0";
                    model.rep_row_9 = reader["rep_row_9"].ToString() ?? "0";
                    model.rep_row_10 = reader["rep_row_10"].ToString() ?? "0";
                    model.rep_row_11 = reader["rep_row_11"].ToString() ?? "0";
                    model.rep_row_12 = reader["rep_row_12"].ToString() ?? "0";
                    model.rep_row_13 = reader["rep_row_13"].ToString() ?? "0";
                    model.rep_row_14 = reader["rep_row_14"].ToString() ?? "0";
                    model.rep_row_15 = reader["rep_row_15"].ToString() ?? "0";
                    model.rep_row_16 = reader["rep_row_16"].ToString() ?? "0";
                    model.rep_row_17 = reader["rep_row_17"].ToString() ?? "0";
                    model.rep_row_18 = reader["rep_row_18"].ToString() ?? "0";
                    model.rep_row_19 = reader["rep_row_19"].ToString() ?? "0";
                    model.rep_row_20 = reader["rep_row_20"].ToString() ?? "0";
                    model.rep_row_21 = reader["rep_row_21"].ToString() ?? "0";
                    model.rep_row_1_2 = reader["rep_row_1_2"].ToString() ?? "0";
                    model.rep_row_2_2 = reader["rep_row_2_2"].ToString() ?? "0";
                    model.rep_row_3_2 = reader["rep_row_3_2"].ToString() ?? "0";
                    model.rep_row_4_2 = reader["rep_row_4_2"].ToString() ?? "0";
                    model.rep_row_5_2 = reader["rep_row_5_2"].ToString() ?? "0";
                    model.rep_row_6_2 = reader["rep_row_6_2"].ToString() ?? "0";
                    model.rep_row_7_2 = reader["rep_row_7_2"].ToString() ?? "0";
                    model.rep_row_8_2 = reader["rep_row_8_2"].ToString() ?? "0";
                    model.rep_row_9_2 = reader["rep_row_9_2"].ToString() ?? "0";
                    model.rep_row_10_2 = reader["rep_row_10_2"].ToString() ?? "0";
                    model.rep_row_11_2 = reader["rep_row_11_2"].ToString() ?? "0";
                    model.rep_row_12_2 = reader["rep_row_12_2"].ToString() ?? "0";
                    model.rep_row_13_2 = reader["rep_row_13_2"].ToString() ?? "0";
                    model.rep_row_14_2 = reader["rep_row_14_2"].ToString() ?? "0";
                    model.rep_row_15_2 = reader["rep_row_15_2"].ToString() ?? "0";
                    model.rep_row_16_2 = reader["rep_row_16_2"].ToString() ?? "0";
                    model.rep_row_17_2 = reader["rep_row_17_2"].ToString() ?? "0";
                    model.rep_row_18_2 = reader["rep_row_18_2"].ToString() ?? "0";
                    model.rep_row_19_2 = reader["rep_row_19_2"].ToString() ?? "0";
                    model.rep_row_20_2 = reader["rep_row_20_2"].ToString() ?? "0";
                    model.rep_row_21_2 = reader["rep_row_21_2"].ToString() ?? "0";
                    model.rep_row_22_1 = reader["rep_row_22_1"].ToString() ?? "0";
                    model.rep_row_22_2 = reader["rep_row_22_2"].ToString() ?? "0";
                    model.rep_row_22_3 = reader["rep_row_22_3"].ToString() ?? "0";
                    model.rep_row_22_4 = reader["rep_row_22_4"].ToString() ?? "0";
                    model.rep_row_23_1 = reader["rep_row_23_1"].ToString() ?? "0";
                    model.rep_row_23_2 = reader["rep_row_23_2"].ToString() ?? "0";
                    model.rep_row_23_3 = reader["rep_row_23_3"].ToString() ?? "0";
                    model.rep_row_23_4 = reader["rep_row_23_4"].ToString() ?? "0";
                    model.rep_row_24_1 = reader["rep_row_24_1"].ToString() ?? "0";
                    model.rep_row_24_2 = reader["rep_row_24_2"].ToString() ?? "0";
                    model.rep_row_24_3 = reader["rep_row_24_3"].ToString() ?? "0";
                    model.rep_row_24_4 = reader["rep_row_24_4"].ToString() ?? "0";
                    model.rep_row_25_1 = reader["rep_row_25_1"].ToString() ?? "0";
                    model.rep_row_25_2 = reader["rep_row_25_2"].ToString() ?? "0";
                    model.rep_row_25_3 = reader["rep_row_25_3"].ToString() ?? "0";
                    model.rep_row_25_4 = reader["rep_row_25_4"].ToString() ?? "0";
                    model.rep_row_26_1 = reader["rep_row_26_1"].ToString() ?? "0";
                    model.rep_row_26_2 = reader["rep_row_26_2"].ToString() ?? "0";
                    model.rep_row_26_3 = reader["rep_row_26_3"].ToString() ?? "0";
                    model.rep_row_26_4 = reader["rep_row_26_4"].ToString() ?? "0";
                    model.rep_row_27_1 = reader["rep_row_27_1"].ToString() ?? "0";
                    model.rep_row_27_2 = reader["rep_row_27_2"].ToString() ?? "0";
                    model.rep_row_27_3 = reader["rep_row_27_3"].ToString() ?? "0";
                    model.rep_row_27_4 = reader["rep_row_27_4"].ToString() ?? "0";
                    model.rep_row_28_1 = reader["rep_row_28_1"].ToString() ?? "0";
                    model.rep_row_28_2 = reader["rep_row_28_2"].ToString() ?? "0";
                    model.rep_row_28_3 = reader["rep_row_28_3"].ToString() ?? "0";
                    model.rep_row_28_4 = reader["rep_row_28_4"].ToString() ?? "0";
                    model.rep_row_29_1 = reader["rep_row_29_1"].ToString() ?? "0";
                    model.rep_row_29_2 = reader["rep_row_29_2"].ToString() ?? "0";
                    model.rep_row_29_3 = reader["rep_row_29_3"].ToString() ?? "0";
                    model.rep_row_29_4 = reader["rep_row_29_4"].ToString() ?? "0";
                    model.rep_row_30_1 = reader["rep_row_30_1"].ToString() ?? "0";
                    model.rep_row_30_2 = reader["rep_row_30_2"].ToString() ?? "0";
                    model.rep_row_30_3 = reader["rep_row_30_3"].ToString() ?? "0";
                    model.rep_row_30_4 = reader["rep_row_30_4"].ToString() ?? "0";
                    model.rep_row_31_1 = reader["rep_row_31_1"].ToString() ?? "0";
                    model.rep_row_31_2 = reader["rep_row_31_2"].ToString() ?? "0";
                    model.rep_row_31_3 = reader["rep_row_31_3"].ToString() ?? "0";
                    model.rep_row_31_4 = reader["rep_row_31_4"].ToString() ?? "0";
                    model.rep_law_state_aid_id = reader["rep_law_state_aid_id"].ToString();
                    model.collegium_name = reader["law_collegium_name_ru"].ToString();
                    model.ECP = reader["rep_law_state_sign"].ToString() ?? "";
                }

                reader.Close();

                return View("PrintLawyerReport", model);
            }
        }

        public ActionResult PrintApplicationsLawyerReport(string id, string parameters)
        {
            return PrintApplicationsLawyerReportRo(id, parameters);
        }

        public ActionResult PrintApplicationsLawyerReportRo(string id, string parameters)
        {
            lock (Provider.Locker)
            {
                var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

                if (claim != "2" && claim != "4")
                {
                    return View("Error");
                }

                ViewBag.ToPrint = parameters == "1";

                var model = new CollegialReportDBModel();

                var query = @"SELECT  
                                        t1.*,
	                                    t2.rep_date_begin,
                                        t3.subj_name,
                                        sls.subj_law_supplier_name, 
                                        lc.law_collegium_name_ru,
                                        t1.r2_docs_legal_adv_count + t1.r2_oral_legal_adv_count + t1.r41_law_adv_esp_grave_before_count +
                                        t1.r42_law_adv_grave_before_count + t1.r43_law_adv_not_grave_before_count + t1.r44_law_adv_esp_grave_court_count +
                                        t1.r45_law_adv_grave_court_count + t1.r46_law_adv_not_grave_court_count +t1.r61_rep_adv_esp_grave_before_count +
                                        t1.r62_rep_adv_grave_before_count +t1.r63_rep_adv_not_grave_before_count + t1.r64_rep_adv_esp_grave_court_count +
                                        t1.r65_rep_adv_grave_court_count + t1.r66_rep_adv_not_grave_court_count +t1.r7_law_adm_count + 
                                        t1.r8_law_civil_112_count + t1.r9_law_civil_325_count as total_count,
                                        t1.r2_docs_legal_adv_hourses + t1.r2_oral_legal_adv_hourses + t1.r41_law_adv_esp_grave_before_hourses +
                                        t1.r42_law_adv_grave_before_hourses + t1.r43_law_adv_not_grave_before_hourses + t1.r44_law_adv_esp_grave_court_hourses +
                                        t1.r45_law_adv_grave_court_hourses + t1.r46_law_adv_not_grave_court_hourses +t1.r61_rep_adv_esp_grave_before_hourses +
                                        t1.r62_rep_adv_grave_before_hourses +t1.r63_rep_adv_not_grave_before_hourses + t1.r64_rep_adv_esp_grave_court_hourses +
                                        t1.r65_rep_adv_grave_court_hourses + t1.r66_rep_adv_not_grave_court_hourses +t1.r7_law_adm_hourses + 
                                        t1.r8_law_civil_112_hourses + t1.r9_law_civil_325_hourses as total_hourses,
                                        t1.r2_docs_legal_adv_sum + t1.r2_oral_legal_adv_sum + t1.r41_law_adv_esp_grave_before_sum +
                                        t1.r42_law_adv_grave_before_sum + t1.r43_law_adv_not_grave_before_sum + t1.r44_law_adv_esp_grave_court_sum +
                                        t1.r45_law_adv_grave_court_sum + t1.r46_law_adv_not_grave_court_sum +t1.r61_rep_adv_esp_grave_before_sum +
                                        t1.r62_rep_adv_grave_before_sum +t1.r63_rep_adv_not_grave_before_sum + t1.r64_rep_adv_esp_grave_court_sum +
                                        t1.r65_rep_adv_grave_court_sum + t1.r66_rep_adv_not_grave_court_sum +t1.r7_law_adm_sum + 
                                        t1.r8_law_civil_112_sum + t1.r9_law_civil_325_sum as total_sum
                                    FROM rep_aid_pay_request t1
                                    JOIN rep_law_state_aid t2 ON t1.rep_law_state_aid_id = t2.rep_law_state_aid_id
                                    JOIN subjects t3 ON t2.person_id = t3.user_id
                                    JOIN law_collegiums lc ON t2.law_collegium_id = lc.law_collegium_id 
                                    JOIN subjects_law_suppliers sls ON t2.subj_law_supplier_id = sls.subj_law_supplier_id
                                    WHERE t1.rep_law_state_aid_id = " + id + ";";

                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    model.person_id = reader["subj_name"].ToString();
                    model.rep_date_begin = Convert.ToDateTime(reader["rep_date_begin"].ToString()).ToString("MMMM yyyy");
                    model.collegium_name = reader["law_collegium_name_ru"].ToString();
                    model.subj_law_supplier_id = reader["subj_law_supplier_name"].ToString();
                    model.r2_docs_legal_adv_count = reader.GetFieldValueOrDefault<int>("r2_docs_legal_adv_count");
                    model.r2_docs_legal_adv_hourses = reader.GetFieldValueOrDefault<int>("r2_docs_legal_adv_hourses");
                    model.r2_docs_legal_adv_sum = reader.GetFieldValueOrDefault<int>("r2_docs_legal_adv_sum");
                    model.r2_oral_legal_adv_count = reader.GetFieldValueOrDefault<int>("r2_oral_legal_adv_count");
                    model.r2_oral_legal_adv_hourses = reader.GetFieldValueOrDefault<int>("r2_oral_legal_adv_hourses");
                    model.r2_oral_legal_adv_sum = reader.GetFieldValueOrDefault<int>("r2_oral_legal_adv_sum");
                    model.r2_total = reader.GetFieldValueOrDefault<int>("r2_total");
                    model.r41_law_adv_esp_grave_before_count = reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_count");
                    model.r41_law_adv_esp_grave_before_hourses = reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_hourses");
                    model.r41_law_adv_esp_grave_before_sum = reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_sum");
                    model.r41_law_adv_esp_grave_before_total = reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_total");
                    model.r42_law_adv_grave_before_count = reader.GetFieldValueOrDefault<int>("r42_law_adv_grave_before_count");
                    model.r42_law_adv_grave_before_hourses = reader.GetFieldValueOrDefault<int>("r42_law_adv_grave_before_hourses");
                    model.r42_law_adv_grave_before_sum = reader.GetFieldValueOrDefault<int>("r42_law_adv_grave_before_sum");
                    model.r43_law_adv_not_grave_before_count = reader.GetFieldValueOrDefault<int>("r43_law_adv_not_grave_before_count");
                    model.r43_law_adv_not_grave_before_hourses = reader.GetFieldValueOrDefault<int>("r43_law_adv_not_grave_before_hourses");
                    model.r43_law_adv_not_grave_before_sum = reader.GetFieldValueOrDefault<int>("r43_law_adv_not_grave_before_sum");
                    model.r44_law_adv_esp_grave_court_count = reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_count");
                    model.r44_law_adv_esp_grave_court_hourses = reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_hourses");
                    model.r44_law_adv_esp_grave_court_sum = reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_sum");
                    model.r44_law_adv_esp_grave_court_total = reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_total");
                    model.r45_law_adv_grave_court_count = reader.GetFieldValueOrDefault<int>("r45_law_adv_grave_court_count");
                    model.r45_law_adv_grave_court_hourses = reader.GetFieldValueOrDefault<int>("r45_law_adv_grave_court_hourses");
                    model.r45_law_adv_grave_court_sum = reader.GetFieldValueOrDefault<int>("r45_law_adv_grave_court_sum");
                    model.r46_law_adv_not_grave_court_count = reader.GetFieldValueOrDefault<int>("r46_law_adv_not_grave_court_count");
                    model.r46_law_adv_not_grave_court_hourses = reader.GetFieldValueOrDefault<int>("r46_law_adv_not_grave_court_hourses");
                    model.r46_law_adv_not_grave_court_sum = reader.GetFieldValueOrDefault<int>("r46_law_adv_not_grave_court_sum");
                    model.r61_rep_adv_esp_grave_before_count = reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_count");
                    model.r61_rep_adv_esp_grave_before_hourses = reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_hourses");
                    model.r61_rep_adv_esp_grave_before_sum = reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_sum");
                    model.r61_rep_adv_esp_grave_before_total = reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_total");
                    model.r62_rep_adv_grave_before_count = reader.GetFieldValueOrDefault<int>("r62_rep_adv_grave_before_count");
                    model.r62_rep_adv_grave_before_hourses = reader.GetFieldValueOrDefault<int>("r62_rep_adv_grave_before_hourses");
                    model.r62_rep_adv_grave_before_sum = reader.GetFieldValueOrDefault<int>("r62_rep_adv_grave_before_sum");
                    model.r63_rep_adv_not_grave_before_count = reader.GetFieldValueOrDefault<int>("r63_rep_adv_not_grave_before_count");
                    model.r63_rep_adv_not_grave_before_hourses = reader.GetFieldValueOrDefault<int>("r63_rep_adv_not_grave_before_hourses");
                    model.r63_rep_adv_not_grave_before_sum = reader.GetFieldValueOrDefault<int>("r63_rep_adv_not_grave_before_sum");
                    model.r64_rep_adv_esp_grave_court_count = reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_count");
                    model.r64_rep_adv_esp_grave_court_hourses = reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_hourses");
                    model.r64_rep_adv_esp_grave_court_sum = reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_sum");
                    model.r64_rep_adv_esp_grave_court_total = reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_total");
                    model.r65_rep_adv_grave_court_count = reader.GetFieldValueOrDefault<int>("r65_rep_adv_grave_court_count");
                    model.r65_rep_adv_grave_court_hourses = reader.GetFieldValueOrDefault<int>("r65_rep_adv_grave_court_hourses");
                    model.r65_rep_adv_grave_court_sum = reader.GetFieldValueOrDefault<int>("r65_rep_adv_grave_court_sum");
                    model.r66_rep_adv_not_grave_court_count = reader.GetFieldValueOrDefault<int>("r66_rep_adv_not_grave_court_count");
                    model.r66_rep_adv_not_grave_court_hourses = reader.GetFieldValueOrDefault<int>("r66_rep_adv_not_grave_court_hourses");
                    model.r66_rep_adv_not_grave_court_sum = reader.GetFieldValueOrDefault<int>("r66_rep_adv_not_grave_court_sum");
                    model.r7_law_adm_count = reader.GetFieldValueOrDefault<int>("r7_law_adm_count");
                    model.r7_law_adm_hourses = reader.GetFieldValueOrDefault<int>("r7_law_adm_hourses");
                    model.r7_law_adm_sum = reader.GetFieldValueOrDefault<int>("r7_law_adm_sum");
                    model.r7_law_adm_total = reader.GetFieldValueOrDefault<int>("r7_law_adm_total");
                    model.r8_law_civil_112_count = reader.GetFieldValueOrDefault<int>("r8_law_civil_112_count");
                    model.r8_law_civil_112_hourses = reader.GetFieldValueOrDefault<int>("r8_law_civil_112_hourses");
                    model.r8_law_civil_112_sum = reader.GetFieldValueOrDefault<int>("r8_law_civil_112_sum");
                    model.r8_law_civil_total = reader.GetFieldValueOrDefault<int>("r8_law_civil_total");
                    model.r9_law_civil_325_count = reader.GetFieldValueOrDefault<int>("r9_law_civil_325_count");
                    model.r9_law_civil_325_hourses = reader.GetFieldValueOrDefault<int>("r9_law_civil_325_hourses");
                    model.r9_law_civil_325_sum = reader.GetFieldValueOrDefault<int>("r9_law_civil_325_sum");
                    model.rep_law_state_aid_id = reader["rep_law_state_aid_id"].ToString();
                    model.total_sum = reader.GetFieldValueOrDefault<int>("total_sum");
                    model.total_docs = reader.GetFieldValueOrDefault<int>("total_count");
                    model.total_hours = reader.GetFieldValueOrDefault<int>("total_hourses");
                }

                reader.Close();

                return View(model);
            }
        }

        [HttpPost]
        public string GetReportHistory()
        {
            lock (Provider.Locker)
            {
                var query = @"SELECT log_date, log_text
                                  FROM log
                                 WHERE log_doc_id = '" + Request["reportId"] + "' and log_doc_table = 'rep_law_state_aid';";


                var reader = Provider.RunQuery(query);

                var logs = new List<LogModel>();

                while (reader.Read())
                {
                    var log = new LogModel
                    {
                        LogText = reader["log_text"].ToString(),
                        LogDateString =
                            Convert.ToDateTime(reader["log_date"].ToString()).ToString("dd.MM.yyyy HH:mm:ss")
                    };

                    logs.Add(log);
                }

                reader.Close();

                return JsonConvert.SerializeObject(logs);
            }
        }

        [System.Web.Mvc.Authorize]
        public ActionResult GetLawyerList()
        {
            lock (Provider.Locker)
            {
                var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
                if (role == 63)
                {
                    var query = "SELECT xmlelement(name root, REPLACE(REPLACE(xmlelement(name reestr_date, query_to_xml('select current_date, current_time as time', true, true, ''))::text, '<row xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">', chr(10)), '</row>', ' ')::xml, REPLACE(REPLACE(query_to_xml('SELECT t1.last_name || '' '' || t1.given_name || '' '' || coalesce (t1.middle_name,'''') as name, t1.last_name || '' '' || t1.given_name || '' '' || coalesce (t1.middle_name,'''') as full_name, t1.date_of_birth, t1.person_code as iin, t1.post_address as address, t2.subj_law_contract_date as oferta_date, t3.legal_advise_type_name_ru, t2.subj_law_contract_offer as oferta_number, CASE WHEN t3.legal_advise_type = 1 THEN null else t2.subj_law_supplier_name END, CASE WHEN t2.subj_law_supplier_status = 1 THEN 0 else 1 END as is_blocked FROM persons t1 LEFT JOIN subjects_law_suppliers t2 ON t1.user_id = t2.person_id LEFT JOIN legal_advise_types t3 ON t2.law_supp_org_type = t3.legal_advise_type_id LEFT JOIN \"AspNetUserClaims\" t4 ON t1.user_id = t4.\"UserId\" WHERE (t2.subj_law_supplier_status = 1 and t4.\"ClaimType\" = ''user_role'' and t4.\"ClaimValue\" = ''2'') or  (t2.subj_law_supplier_status = 5 and t4.\"ClaimType\" = ''user_role'' and t4.\"ClaimValue\" = ''1'');', true, false, '')::text, '<table xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">', ' '), '</table>', ' ')::xml) as xml;";
                    var reader = Provider.RunQuery(query);
                    var xml = "<?xml version = \"1.0\" ?>";

                    while (reader.Read())
                    {
                        xml += reader["xml"].ToString();
                    }

                    reader.Close();
                    //Убираем лишние символы новой строки
                    xml = xml.Replace("\n\n", "\n");
                    //Добавляет новую строку перед датой
                    xml = xml.Replace("<reestr_date>", "\n<reestr_date>");
                    xml = xml.Replace("<root>", "\n<root xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
                    xml = xml.Replace("\n</reestr_date> ", "</reestr_date> ");
                    // Создание XML файла
                    var byteArray = Encoding.UTF8.GetBytes(xml);
                    var stream = new MemoryStream(byteArray);

                    return File(stream, "text/xml", "lawyers_1C_reestr.xml");
                }
                else
                {
                    ViewBag.Message = "Не хватает прав!";
                    return View("Error");
                }
            }
        }
        */
        [HttpPost]
        public ActionResult EcpSign()
        {
            //var KalkanCOM = new KalkanCryptCOMLib.KalkanCryptCOM();
            //KalkanCOM.Init();

            var guid = Request.Unvalidated["guid"];
            var data = Request.Unvalidated["data"];
            var serIndex = guid.IndexOf("SERIALNUMBER");
            var iino = guid.Substring(serIndex + 16, 12);
            /*var outVerifyInfo = " ";
            uint err;
            var errStr = " ";*/
            if (data == "")
            {
                ViewBag.Message = "Возникла ошибка";
                return View("Error");
            }
            return View();
        }

        public void GetCheck(string md, string orders)
        {
            if (orders != "")
            {
                var a = orders.Split(',');

                for (int i = 0; i < a.Length; i++) { 
                var result = "";
                string query = "SELECT status FROM debts WHERE debt_id ='" + a[i] + "';";
                var reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    result = reader["status"].ToString();
                }
                reader.Close();
                    if (result == "0")
                    {
                        if (md == "rem")
                        {
                            query = $"UPDATE debts SET status='-1' WHERE debt_id='{a[i]}';";
                            Provider.RunNonQuery(query);
                        }
                        else if (md == "res")
                        {
                            //query = $"UPDATE debts SET subj_id='{result}', status='1' WHERE debt_id='{a[i]}';";
                            //Provider.RunNonQuery(query);
                            Book(a[i]);
                        }
                        //Provider.RunNonQuery(query);
                    }
                }
            }
        }

        public static DateTime GetDateTimeFromString(string inputDate)
        {
            var success = DateTime.TryParse(inputDate, out var tempDt);
            return success ? tempDt.Date : default;
        }

        public static int GetIntFromString(string inputDate)
        {
            var success = int.TryParse(inputDate, out var tempInt);
            return success ? tempInt : default;
        }

        public DateTime? GetNullableDateTimeFromString(string inputDate)
        {
            var success = DateTime.TryParse(inputDate, out var tempDt);

            if (success)
            {
                return tempDt;
            }

            return null;
        }
        /*
        public ActionResult PrintApplicationsLawyerReportPeriod(string id, string parameters)
        {
            lock (Provider.Locker)
            {
                var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

                if (claim != "4")
                {
                    ViewBag.Message = "Недостаточно прав!";
                    return View("Error");
                }

                ViewBag.ToPrint = parameters == "1";

                var periodDate = $"{id.Substring(0, 4)}-{id.Substring(4)}-01";

                var collegiumId = string.Empty;

                var query = @"SELECT law_collegium_id
                                    FROM subjects_law_suppliers
                                    WHERE person_id = '" + User.Identity.GetUserId() + "';";

                var reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    collegiumId = reader["law_collegium_id"].ToString();
                }

                reader.Close();

                var model = new CollegialReportDBModel();

                query = $@"select
    min(rep_date_begin) AS rep_date_begin,
    min(c.law_collegium_name_ru) AS law_collegium_name_ru,
    sum (r2_oral_legal_adv_count) AS r2_oral_legal_adv_count,
    sum (r2_oral_legal_adv_hourses) AS r2_oral_legal_adv_hourses,
    sum (r2_docs_legal_adv_count) AS r2_docs_legal_adv_count,
    sum (r2_docs_legal_adv_hourses) AS r2_docs_legal_adv_hourses,
    sum (r2_total) AS r2_total,
    sum (r3_law_legal_docs_total) AS r3_law_legal_docs_total,
    sum (r41_law_adv_esp_grave_before_count) AS r41_law_adv_esp_grave_before_count,
    sum (r41_law_adv_esp_grave_before_hourses) AS r41_law_adv_esp_grave_before_hourses,
    sum (r41_law_adv_esp_grave_before_total) AS r41_law_adv_esp_grave_before_total,
    sum (r42_law_adv_grave_before_count) AS r42_law_adv_grave_before_count,
    sum (r42_law_adv_grave_before_hourses) AS r42_law_adv_grave_before_hourses,
    sum (r43_law_adv_not_grave_before_count) AS r43_law_adv_not_grave_before_count,
    sum (r43_law_adv_not_grave_before_hourses) AS r43_law_adv_not_grave_before_hourses,
    sum (r44_law_adv_esp_grave_court_count) AS r44_law_adv_esp_grave_court_count,
    sum (r44_law_adv_esp_grave_court_hourses) AS r44_law_adv_esp_grave_court_hourses,
    sum (r44_law_adv_esp_grave_court_total) AS r44_law_adv_esp_grave_court_total,
    sum (r45_law_adv_grave_court_count) AS r45_law_adv_grave_court_count,
    sum (r45_law_adv_grave_court_hourses) AS r45_law_adv_grave_court_hourses,
    sum (r46_law_adv_not_grave_court_count) AS r46_law_adv_not_grave_court_count,
    sum (r46_law_adv_not_grave_court_hourses) AS r46_law_adv_not_grave_court_hourses,
    sum (r61_rep_adv_esp_grave_before_count) AS r61_rep_adv_esp_grave_before_count,
    sum (r61_rep_adv_esp_grave_before_hourses) AS r61_rep_adv_esp_grave_before_hourses,
    sum (r61_rep_adv_esp_grave_before_total) AS r61_rep_adv_esp_grave_before_total,
    sum (r62_rep_adv_grave_before_count) AS r62_rep_adv_grave_before_count,
    sum (r62_rep_adv_grave_before_hourses) AS r62_rep_adv_grave_before_hourses,
    sum (r63_rep_adv_not_grave_before_count) AS r63_rep_adv_not_grave_before_count,
    sum (r63_rep_adv_not_grave_before_hourses) AS r63_rep_adv_not_grave_before_hourses,
    sum (r64_rep_adv_esp_grave_court_count) AS r64_rep_adv_esp_grave_court_count,
    sum (r64_rep_adv_esp_grave_court_hourses) AS r64_rep_adv_esp_grave_court_hourses,
    sum (r64_rep_adv_esp_grave_court_total) AS r64_rep_adv_esp_grave_court_total,
    sum (r65_rep_adv_grave_court_count) AS r65_rep_adv_grave_court_count,
    sum (r65_rep_adv_grave_court_hourses) AS r65_rep_adv_grave_court_hourses,
    sum (r66_rep_adv_not_grave_court_count) AS r66_rep_adv_not_grave_court_count,
    sum (r66_rep_adv_not_grave_court_hourses) AS r66_rep_adv_not_grave_court_hourses,
    sum (r7_law_adm_count) AS r7_law_adm_count,
    sum (r7_law_adm_hourses) AS r7_law_adm_hourses,
    sum (r7_law_adm_total) AS r7_law_adm_total,
    sum (r8_law_civil_112_count) AS r8_law_civil_112_count,
    sum (r8_law_civil_112_hourses) AS r8_law_civil_112_hourses,
    sum (r8_law_civil_total) AS r8_law_civil_total,
    sum (r9_law_civil_325_count) AS r9_law_civil_325_count,
    sum (r9_law_civil_325_hourses) AS r9_law_civil_325_hourses,
    sum (r2_oral_legal_adv_sum) AS r2_oral_legal_adv_sum,
    sum (r2_docs_legal_adv_sum) AS r2_docs_legal_adv_sum,
    sum (r41_law_adv_esp_grave_before_sum) AS r41_law_adv_esp_grave_before_sum,
    sum (r42_law_adv_grave_before_sum) AS r42_law_adv_grave_before_sum,
    sum (r43_law_adv_not_grave_before_sum) AS r43_law_adv_not_grave_before_sum,
    sum (r44_law_adv_esp_grave_court_sum) AS r44_law_adv_esp_grave_court_sum,
    sum (r45_law_adv_grave_court_sum) AS r45_law_adv_grave_court_sum,
    sum (r46_law_adv_not_grave_court_sum) AS r46_law_adv_not_grave_court_sum,
    sum (r61_rep_adv_esp_grave_before_sum) AS r61_rep_adv_esp_grave_before_sum,
    sum (r62_rep_adv_grave_before_sum) AS r62_rep_adv_grave_before_sum,
    sum (r63_rep_adv_not_grave_before_sum) AS r63_rep_adv_not_grave_before_sum,
    sum (r64_rep_adv_esp_grave_court_sum) AS r64_rep_adv_esp_grave_court_sum,
    sum (r65_rep_adv_grave_court_sum) AS r65_rep_adv_grave_court_sum,
    sum (r66_rep_adv_not_grave_court_sum) AS r66_rep_adv_not_grave_court_sum,
    sum (r7_law_adm_sum) AS r7_law_adm_sum,
    sum (r8_law_civil_112_sum) AS r8_law_civil_112_sum,
    sum (r9_law_civil_325_sum) AS r9_law_civil_325_sum,
    sum (r3_law_legal_docs_count) AS r3_law_legal_docs_count,
    sum (r3_law_legal_docs_hourses) AS r3_law_legal_docs_hourses,
    sum (r3_total) AS r3_total,
    sum (r2_total+ r41_law_adv_esp_grave_before_total+ r44_law_adv_esp_grave_court_total +
    	r61_rep_adv_esp_grave_before_total+ r64_rep_adv_esp_grave_court_total+ 
    	r64_rep_adv_esp_grave_court_total+ r7_law_adm_total+ r8_law_civil_total) as total_sum
from rep_aid_pay_request p
JOIN rep_law_state_aid r ON p.rep_law_state_aid_id  = r.rep_law_state_aid_id
JOIN law_collegiums c on c.law_collegium_id = r.law_collegium_id
where 
    r.law_collegium_id = {collegiumId}
    AND r.rep_status = 5
    AND r.rep_date_begin = '{periodDate}';";

                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    model.collegium_name = reader.GetFieldValueOrDefault<string>("law_collegium_name_ru");
                    model.rep_date_begin = reader.GetFieldValueOrDefault<DateTime>("rep_date_begin").ToString("MMMM yyyy");
                    model.r2_docs_legal_adv_count = reader.GetFieldValueOrDefault<int>("r2_docs_legal_adv_count");
                    model.r2_docs_legal_adv_hourses =
                        reader.GetFieldValueOrDefault<int>("r2_docs_legal_adv_hourses");
                    model.r2_docs_legal_adv_sum = reader.GetFieldValueOrDefault<int>("r2_docs_legal_adv_sum");
                    model.r2_oral_legal_adv_count = reader.GetFieldValueOrDefault<int>("r2_oral_legal_adv_count");
                    model.r2_oral_legal_adv_hourses =
                        reader.GetFieldValueOrDefault<int>("r2_oral_legal_adv_hourses");
                    model.r2_oral_legal_adv_sum = reader.GetFieldValueOrDefault<int>("r2_oral_legal_adv_sum");
                    model.r2_total = reader.GetFieldValueOrDefault<int>("r2_total");
                    model.r41_law_adv_esp_grave_before_count =
                        reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_count");
                    model.r41_law_adv_esp_grave_before_hourses =
                        reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_hourses");
                    model.r41_law_adv_esp_grave_before_sum =
                        reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_sum");
                    model.r41_law_adv_esp_grave_before_total =
                        reader.GetFieldValueOrDefault<int>("r41_law_adv_esp_grave_before_total");
                    model.r42_law_adv_grave_before_count =
                        reader.GetFieldValueOrDefault<int>("r42_law_adv_grave_before_count");
                    model.r42_law_adv_grave_before_hourses =
                        reader.GetFieldValueOrDefault<int>("r42_law_adv_grave_before_hourses");
                    model.r42_law_adv_grave_before_sum =
                        reader.GetFieldValueOrDefault<int>("r42_law_adv_grave_before_sum");
                    model.r43_law_adv_not_grave_before_count =
                        reader.GetFieldValueOrDefault<int>("r43_law_adv_not_grave_before_count");
                    model.r43_law_adv_not_grave_before_hourses =
                        reader.GetFieldValueOrDefault<int>("r43_law_adv_not_grave_before_hourses");
                    model.r43_law_adv_not_grave_before_sum =
                        reader.GetFieldValueOrDefault<int>("r43_law_adv_not_grave_before_sum");
                    model.r44_law_adv_esp_grave_court_count =
                        reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_count");
                    model.r44_law_adv_esp_grave_court_hourses =
                        reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_hourses");
                    model.r44_law_adv_esp_grave_court_sum =
                        reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_sum");
                    model.r44_law_adv_esp_grave_court_total =
                        reader.GetFieldValueOrDefault<int>("r44_law_adv_esp_grave_court_total");
                    model.r45_law_adv_grave_court_count =
                        reader.GetFieldValueOrDefault<int>("r45_law_adv_grave_court_count");
                    model.r45_law_adv_grave_court_hourses =
                        reader.GetFieldValueOrDefault<int>("r45_law_adv_grave_court_hourses");
                    model.r45_law_adv_grave_court_sum =
                        reader.GetFieldValueOrDefault<int>("r45_law_adv_grave_court_sum");
                    model.r46_law_adv_not_grave_court_count =
                        reader.GetFieldValueOrDefault<int>("r46_law_adv_not_grave_court_count");
                    model.r46_law_adv_not_grave_court_hourses =
                        reader.GetFieldValueOrDefault<int>("r46_law_adv_not_grave_court_hourses");
                    model.r46_law_adv_not_grave_court_sum =
                        reader.GetFieldValueOrDefault<int>("r46_law_adv_not_grave_court_sum");
                    model.r61_rep_adv_esp_grave_before_count =
                        reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_count");
                    model.r61_rep_adv_esp_grave_before_hourses =
                        reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_hourses");
                    model.r61_rep_adv_esp_grave_before_sum =
                        reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_sum");
                    model.r61_rep_adv_esp_grave_before_total =
                        reader.GetFieldValueOrDefault<int>("r61_rep_adv_esp_grave_before_total");
                    model.r62_rep_adv_grave_before_count =
                        reader.GetFieldValueOrDefault<int>("r62_rep_adv_grave_before_count");
                    model.r62_rep_adv_grave_before_hourses =
                        reader.GetFieldValueOrDefault<int>("r62_rep_adv_grave_before_hourses");
                    model.r62_rep_adv_grave_before_sum =
                        reader.GetFieldValueOrDefault<int>("r62_rep_adv_grave_before_sum");
                    model.r63_rep_adv_not_grave_before_count =
                        reader.GetFieldValueOrDefault<int>("r63_rep_adv_not_grave_before_count");
                    model.r63_rep_adv_not_grave_before_hourses =
                        reader.GetFieldValueOrDefault<int>("r63_rep_adv_not_grave_before_hourses");
                    model.r63_rep_adv_not_grave_before_sum =
                        reader.GetFieldValueOrDefault<int>("r63_rep_adv_not_grave_before_sum");
                    model.r64_rep_adv_esp_grave_court_count =
                        reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_count");
                    model.r64_rep_adv_esp_grave_court_hourses =
                        reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_hourses");
                    model.r64_rep_adv_esp_grave_court_sum =
                        reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_sum");
                    model.r64_rep_adv_esp_grave_court_total =
                        reader.GetFieldValueOrDefault<int>("r64_rep_adv_esp_grave_court_total");
                    model.r65_rep_adv_grave_court_count =
                        reader.GetFieldValueOrDefault<int>("r65_rep_adv_grave_court_count");
                    model.r65_rep_adv_grave_court_hourses =
                        reader.GetFieldValueOrDefault<int>("r65_rep_adv_grave_court_hourses");
                    model.r65_rep_adv_grave_court_sum =
                        reader.GetFieldValueOrDefault<int>("r65_rep_adv_grave_court_sum");
                    model.r66_rep_adv_not_grave_court_count =
                        reader.GetFieldValueOrDefault<int>("r66_rep_adv_not_grave_court_count");
                    model.r66_rep_adv_not_grave_court_hourses =
                        reader.GetFieldValueOrDefault<int>("r66_rep_adv_not_grave_court_hourses");
                    model.r66_rep_adv_not_grave_court_sum =
                        reader.GetFieldValueOrDefault<int>("r66_rep_adv_not_grave_court_sum");
                    model.r7_law_adm_count = reader.GetFieldValueOrDefault<int>("r7_law_adm_count");
                    model.r7_law_adm_hourses = reader.GetFieldValueOrDefault<int>("r7_law_adm_hourses");
                    model.r7_law_adm_sum = reader.GetFieldValueOrDefault<int>("r7_law_adm_sum");
                    model.r7_law_adm_total = reader.GetFieldValueOrDefault<int>("r7_law_adm_total");
                    model.r8_law_civil_112_count = reader.GetFieldValueOrDefault<int>("r8_law_civil_112_count");
                    model.r8_law_civil_112_hourses = reader.GetFieldValueOrDefault<int>("r8_law_civil_112_hourses");
                    model.r8_law_civil_112_sum = reader.GetFieldValueOrDefault<int>("r8_law_civil_112_sum");
                    model.r8_law_civil_total = reader.GetFieldValueOrDefault<int>("r8_law_civil_total");
                    model.r9_law_civil_325_count = reader.GetFieldValueOrDefault<int>("r9_law_civil_325_count");
                    model.r9_law_civil_325_hourses = reader.GetFieldValueOrDefault<int>("r9_law_civil_325_hourses");
                    model.r9_law_civil_325_sum = reader.GetFieldValueOrDefault<int>("r9_law_civil_325_sum");
                    model.total_sum = reader.GetFieldValueOrDefault<int>("total_sum");
                }

                reader.Close();

                return View(model);
            }
        }*/
    }
}