﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Web.Mvc;
using Lawyers.Common;
using Lawyers.Common.Classes;
using Lawyers.Common.Interfaces;
using Lawyers.Web.App.Helpers;
using Lawyers.Web.App.Models;
using Lawyers.Web.App.Models.Enums;
using Microsoft.AspNet.Identity;
using QRCoder;
using System.Drawing;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Web.SessionState;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers    
{
    [Authorize]
    [SessionState(SessionStateBehavior.Disabled)]
    public class NotificationController : Controller
    {
        private IDataProvider Provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

        //public ActionResult AllNotifications()
        //{
        //    var role = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

        //    return role == "4" ? View(NotificationHelper.GetAllNotificationsCollegium()) : View(NotificationHelper.GetAllNotifications());
        //}

        //[Authorize]
        //public ActionResult PrintForm(OrderModel model, int? id)
        //{
        //    var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
        //    if (role == -4)
        //    {
        //        ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса, обратитесь к администрации портала support@finplatform.kz.";
        //        return View("Error");
        //    }
        //    var user = "";
        //    //ViewBag.Firm = GetFirmName();

        //    var query = $"SELECT notification_creation_date FROM notifications  WHERE notification_type = '5' AND notification_object_id ='{id}';";
        //    var dt = Provider.RunQueryStr(query);
        //    if (dt == "-10")
        //        ViewBag.DbtrDat = DateTime.Now;
        //    else ViewBag.DbtrDat = GetDateTimeFromString(dt);
        //    //ViewBag.Role = result;
        //    query = $"SELECT DISTINCT t5.deal_date, t1.*, t2.debitor_bin, t2.debitor_name, t2.debitor_address, " +
        //        $"t3.given_name, t3.middle_name, t3.last_name, t4.org_name, t4.org_code, t4.org_address " +
        //                $"FROM debts t1 LEFT JOIN debitors t2 ON t1.debitor_id = t2.debitor_id " +
        //                $"LEFT JOIN persons t3 ON t1.subj_id = t3.subj_id " +
        //                $"LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
        //                $"LEFT JOIN deal t5 ON t1.debt_id = t5.deal_debt_id WHERE debt_id='{id}';";
        //    var reader = Provider.RunQuery(query);
        //    if (reader != null)
        //    {
        //        while (reader.Read())
        //        {
        //            user = reader["user_id"].ToString();
        //            model.Agreement = reader["debt_number"].ToString();
        //            model.Id = reader["debt_id"].ToString();
        //            model.subj_id = reader["subj_id"].ToString();
        //            model.AgreementDate = GetDateTimeFromString(reader["debt_date"].ToString());
        //            model.DebtDate = GetDateTimeFromString(reader["post_time"].ToString());
        //            ViewBag.FFio = reader["last_name"].ToString() + " " + reader["given_name"].ToString() + " " + reader["middle_name"].ToString();
        //            ViewBag.FName = reader["org_name"].ToString();
        //            ViewBag.FCode = reader["org_code"].ToString();
        //            ViewBag.FAdr = reader["org_address"].ToString();
        //            ViewBag.Dbtr = reader["debitor_name"].ToString();
        //            ViewBag.DbtrBin = reader["debitor_bin"].ToString();
        //            ViewBag.DbtrAdr = reader["debitor_address"].ToString();
        //            if (reader["deal_date"] != null && reader["deal_date"].ToString() != "")
        //                ViewBag.DealDt = GetDateTimeFromString(reader["deal_date"].ToString());
        //            else ViewBag.DealDt = DateTime.Now;
        //            model.Debt = (decimal)reader["debt_sum"];
        //            model.Reg = reader["register"].ToString();
        //            model.Quant = (int)reader["quant"];
        //            model.Address = reader["debitor_address"].ToString();
        //            model.Contacts = reader["contact"].ToString();
        //            model.proof = (int)reader["debt_confirmation"] != 0;
        //            model.late = (int)reader["debt_delay"] != 0;
        //            model.typic = (int)reader["debt_typical_conditions"] != 0;
        //            model.regrs = (int)reader["factoring_buyout_conditions"] != 0;
        //            model.revrs = (int)reader["factoring_reverse"] != 0;
        //            model.opn = (int)reader["factoring_open_close"] != 0;
        //            model.ratedt = GetDateTimeFromString(reader["debt_value_date"].ToString());
        //            model.K1 = (decimal)reader["K1"];
        //            model.K2 = (decimal)reader["K2"];
        //            model.K3 = (decimal)reader["K3"];
        //            model.K4 = (decimal)reader["K4"];
        //            model.fund = (decimal)reader["debt_financing_ratio"];
        //            model.first = (decimal)reader["debt_first_pay_sum"];
        //            model.free = (int)reader["debt_grace_period"];
        //            model.regrsdt = GetDateTimeFromString(reader["debt_regress_date"].ToString());
        //            model.tx = (int)reader["debt_vat"] != 0;
        //            model.FirmName = reader["debitor_name"].ToString();
        //            model.Bin = reader["debitor_bin"].ToString();
        //            model.DocNo = reader["doc_id"].ToString();
        //            model.status = reader["status"].ToString();
        //            model.debit_confirm = reader["debitor_confirm"].ToString();
        //        }
        //        reader.Close();
        //    }

        //    query = $"SELECT t1.*, t2.org_name, t2.org_code, t2.org_address FROM persons t1 " +
        //        $"LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}';";
        //    reader = Provider.RunQuery(query);
        //    if (reader != null)
        //    {
        //        while (reader.Read())
        //        {
        //            ViewBag.CFio = reader["last_name"].ToString() + " " + reader["given_name"].ToString() + " " + reader["middle_name"].ToString();
        //            ViewBag.CName = reader["org_name"].ToString();
        //            ViewBag.CCode = reader["org_code"].ToString();
        //            ViewBag.CAdr = reader["org_address"].ToString();
        //        }
        //        reader.Close();
        //    }

        //    QRCodeGenerator qrGenerator = new QRCodeGenerator();
        //    QRCodeData qrCodeData = qrGenerator.CreateQrCode(ViewBag.CFio, QRCodeGenerator.ECCLevel.Q);
        //    QRCode qrCode = new QRCode(qrCodeData);
        //    ViewBag.QR1 = BitmapToBytes(qrCode.GetGraphic(20));

        //    qrCodeData = qrGenerator.CreateQrCode(ViewBag.FFio, QRCodeGenerator.ECCLevel.Q);
        //    qrCode = new QRCode(qrCodeData);
        //    ViewBag.QR2 = BitmapToBytes(qrCode.GetGraphic(20));

        //    return new PartialViewAsPdf(model);
        //}

        //private static Byte[] BitmapToBytes(Bitmap img)
        //{
        //    using (MemoryStream stream = new MemoryStream())
        //    {
        //        img.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
        //        return stream.ToArray();
        //    }
        //}

        //public ActionResult PrintPDF(int id)
        //{
        //    //var file = SelPage(id);
        //    return new ActionAsPdf("PrintForm", new { id }) { FileName = "FIP-"+ DateTime.Now.ToFileTime() + ".pdf" };
        //}

        public class Note
        {
            public int Id { get; set; }
            public string CreatorName { get; set; }//: 
            public string CreatorCode { get; set; }//: 
            public DateTime CreationDate { get; set; }//:
            public string Type { get; set; }//: "xxx@xxxx.com",
            public int ObjectId { get; set; }//: "Проиводство 1",
            public string ContractId { get; set; }//: 
            public string OrgName { get; set; }
            public bool Archived { get; set; }//: false
        }

        public string All(string id)
        {
            var notifications = new List<Note>();

            var user = User.Identity.GetUserId();
            var firn = GetFirmName();
            string query = "";
            /*if (id == "2") { 
                query = $"SELECT * FROM notifications WHERE notification_recipient ='{user}' AND notification_type BETWEEN '22' AND '29' ORDER BY notification_creation_date DESC;";
                //ViewBag.cat3 = true;
            }
            if (id == "1")
            { 
                query = $"SELECT * FROM notifications WHERE notification_recipient ='{user}' AND (notification_type = '3' OR  notification_type = '20') ORDER BY notification_creation_date DESC;";
                //ViewBag.cat2 = true;
            }
            else if (id == null || id == "0")*/
            lock (Provider.Locker)
            {
                query = $"SELECT t1.*, t3.* FROM notifications t1 LEFT JOIN persons t2 ON t1.notification_creator=t2.user_id LEFT JOIN organizations t3 ON t2.org_id = t3.org_id WHERE notification_recipient ='{user}' ORDER BY notification_creation_date DESC;";
                //ViewBag.cat1 = true;

                var reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var not = new Note
                        {
                            Id = (int)reader["notification_id"],
                            //ReportNumber = reader["rep_number"].ToString()
                        };
                        //var tt = not.Type.GetType();
                        //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                        not.CreatorName = reader["org_name"].ToString();
                        not.CreatorCode = reader["org_code"].ToString();
                        not.Type = reader["notification_type"].ToString();//reader.GetFieldValueOrDefault<int>("notification_type");
                        not.CreationDate = GetDateTimeFromString(reader["notification_creation_date"].ToString());
                        not.Archived = (bool)reader["notification_archived"];
                        not.ObjectId = reader.GetFieldValueOrDefault<int>("notification_object_id"); 
                        not.ContractId = reader["notification_comment"].ToString();
                        not.OrgName = firn;/*
                        int nd = int.Parse(not.Type);
                        var type = (NotificationType)nd;
                        not.Type = type.ToName();*/
                        notifications.Add(not);
                    }

                    reader.Close();
                }
                //ViewBag.Firm = GetFirmName();
                return JsonConvert.SerializeObject(notifications);
            }
            //return View();
            //return role == "4" ? View(NotificationHelper.GetAllNotificationsCollegium()) : View(NotificationHelper.GetAllNotifications());
        }

        public string GetFirmName()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunQueryStr(query);
            return result;
        }

        public DateTime GetDateTimeFromString(string inputDate)
        {
            var success = DateTime.TryParse(inputDate, out var tempDt);
            return success ? tempDt : default;
        }

        public void Unread(string id)
        {
            var query = "UPDATE notifications SET notification_archived='false' WHERE notification_id ='" + id + "';";
            var result = Provider.RunNonQuery(query);
        }

        public void Delete(string id)
        {
            var query = "DELETE FROM notifications WHERE notification_id ='" + id + "';";
            var result = Provider.RunNonQuery(query);
        }
        
        public string Read(int id)
        {/*
            var notification = NotificationHelper.NotificationById(id);

            if (notification == null)
            {
                // TODO: 
                ViewBag.Error = "Что-то произошло и надо бы показать ошибку";
            }
            else
            {
                NotificationHelper.ReadNotification(id);
            }
            */
            var firn = GetFirmName();

            var query = "SELECT t1.*, t3.* FROM notifications t1 LEFT JOIN persons t2 ON t1.notification_creator=t2.user_id LEFT JOIN organizations t3 ON t2.org_id = t3.org_id WHERE notification_id ='" + id + "';";
            var reader = Provider.RunQuery(query);
            var model = new Note { Id = id };
            while (reader.Read())
            {
                //model.Id = reader["debt_id"].ToString();
                model.CreatorName = reader["org_name"].ToString();
                model.CreatorCode = reader["org_code"].ToString();
                model.Type = reader["notification_type"].ToString(); //reader.GetFieldValueOrDefault<int>("notification_type");
                model.ObjectId = reader.GetFieldValueOrDefault<int>("notification_object_id");
                model.ContractId = reader["notification_comment"].ToString();
                model.CreationDate = GetDateTimeFromString(reader["notification_creation_date"].ToString());
                model.OrgName = firn;//reader["notification_comment"].ToString();

            }
            reader.Close();
                //query = $"SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{model.CreatorName}';";
                //var result = Provider.RunQueryStr(query);
                //query = $"SELECT debt_sum FROM debts WHERE debt_id ='{model.Comment}';";
                //result = Provider.RunQueryStr(query);
                //query = $"SELECT debitor_reject_reason FROM debts WHERE debt_id ='{model.Comment}';";
                //result = Provider.RunQueryStr(query);
                //query = $"SELECT t3.org_name FROM debts t1 left join persons t2 on t1.subj_id=t2.subj_id left join organizations t3 on t2.org_id=t3.org_id WHERE debt_id ='{model.Comment}';";
                //result = Provider.RunQueryStr(query);
                query = "UPDATE notifications SET notification_archived='true' WHERE notification_id ='" + id + "';";
            Provider.RunNonQuery(query);
  
            return JsonConvert.SerializeObject(model);                
            //return View(notification);
        }
        public string getTypeName(int aa)
        {
            var Type = (NotificationType)aa;//getType(reader["notification_type"].ToString());
            string res = Type.ToName();
            return res;
        }
        /*
        [HttpPost]
        public ActionResult GetCount()
        {
            var user = User.Identity.GetUserId();
            //var result = "";
            string query = "SELECT COUNT(*) FROM notifications WHERE notification_recipient ='" + user + "';";
            var reader = Provider.RunScalar(query);
            //var role = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;
            return Json(new { count = reader });
            //return role == "4" ? Json(new { count = NotificationHelper.GetCountCollegium() }) : Json(new { count = NotificationHelper.GetCount() });
        }
        */
        public string GetCount()
        {
            var user = User.Identity.GetUserId();
            lock (Provider.Locker)
            {
                string query = "SELECT COUNT(*) FROM notifications WHERE notification_archived='false' AND notification_recipient ='" + user + "';";
                var count = Provider.RunScalar(query);
                return "{\"count\":\"" + count + "\"}";
            }
        }
        /*
        public ActionResult Reject()
        {
            var id = 0;
            var lawyerId = Request["lawyer_id"];
            var comment = Request["message_text"];
            var notificationType = (NotificationType)int.Parse(Request["notification_type"]);
            var objectId = int.Parse(Request["object_id"]);

            var guid = Guid.NewGuid();


            if (Request.Files != null && Request.Files.Count > 0)
            {
                var file = Request.Files[0];
                var target = new MemoryStream();
                file?.InputStream.CopyTo(target);

                var toSave = new ImageFile()
                {
                    ID = 0,
                    EntityId = guid.ToString(),
                    Type = file?.ContentType,
                    Name = file?.FileName,
                    Length = file?.ContentLength ?? 0,
                    Date = DateTime.Now,
                    Image = target,
                    WidgetId = "notification"
                };

                Provider.SaveFile(toSave);
            }

            var notification = new Notification()
            {
                Type = notificationType,
                ObjectId = objectId,
                CreationDate = DateTime.Now,
                CreatorId = User.Identity.GetUserId(),
                RecipientId = lawyerId,
                Comment = comment,
                DocumentId = (Request.Files != null && Request.Files.Count > 0) ? guid.ToString() : string.Empty
            };

            id = NotificationHelper.AddNotification(notification);

            return Json(new {id});
        }*/
    }
}