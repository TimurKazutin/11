﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 03-09-2015
//
// Last Modified By : Victor Skakun
// Last Modified On : 18-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Controllers namespace.
/// </summary>
namespace Lawyers.Web.App.Controllers
{
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Helpers;
    using System.Web.Mvc;
    using Lawyers.Common;
    using Lawyers.Common.Classes;
    using Lawyers.Common.Interfaces;
    using Lawyers.Engine.Configuration;
    using Newtonsoft.Json;
    using Lawyers.Web.App.Helpers;
    using System.IO;

    //using Lawyers.Database.Posgres;

    /// <summary>
    /// Class AdminController.
    /// </summary>
    //[Authorize(Roles = "Administrator")]
    public class AdminController : Controller
    {
        // GET: Admin
        private static IDataProvider Provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }
        public static DateTime GetDateTimeFromString(string inputDate)
        {
            var success = DateTime.TryParse(inputDate, out var tempDt);
            return success ? tempDt.Date : default;
        }
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Gets the hash.
        /// </summary>
        /// <returns>ActionResult.</returns>
        /// 
        public class license
        {
            public int? id { get; set; }
            public int? status { get; set; }
            public DateTime? start_date { get; set; }
            public DateTime? end_date { get; set; }
            public string offer_file { get; set; }
            public string offer_diff { get; set; }
        }
        public string Offers()
        {
            var result = new List<license>();
            string query = $"SELECT * FROM licenses;";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var lc = new license();
                    lc.id = reader.GetFieldValueOrDefault<int>("id");
                    lc.status = reader.GetFieldValueOrDefault<int>("id");
                    lc.start_date = GetDateTimeFromString(reader["start_date"].ToString());
                    if (!string.IsNullOrEmpty(reader["end_date"].ToString()))
                        lc.end_date = GetDateTimeFromString(reader["end_date"].ToString());
                    lc.offer_file = reader["offer_file"].ToString();
                    lc.offer_diff = reader["offer_diff"].ToString();
                    result.Add(lc);

                }
                reader.Close();
                return JsonConvert.SerializeObject(result);
            }
            return "";
        }

        [AllowAnonymous]
        public string getActiveOffer()
        {
            var query = "SELECT offer_file FROM licenses WHERE status=1;";
                var res = Provider.RunQueryStr(query);
            return res;
        }

        [HttpPost]
        public string offer_upload(license post)
        {
            var r = new List<ImageFile>();
            int ii = 1, fid = 0;
            string ofr = "", dif = "";
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = "1",
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "license"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);
                if (ii == 1)
                {
                    fid = imgFile.ID;
                    ofr = "/picture/getfile/" + imgFile.ID;
                }
                else dif = "/picture/getfile/" + imgFile.ID;
                r.Add(imgFile); ii++;
            }
            if (r.Count > 0)
            {
                //var doc = r[0].ID;
                var query = $"UPDATE licenses SET status=0, end_date='now()' WHERE status = 1;";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO licenses (file_id, offer_file, offer_diff, status, start_date) VALUES({fid}, '{ofr}', '{dif}', '1', 'now()');";
                Provider.RunNonQuery(query);
                return "ok";
            }
            else return "error no file attached";
        }

        /// <summary>
        /// Gets the hashed password.
        /// </summary>
        /// <returns>System.String.</returns>
        //[HttpPost]
        //public string GetHashedPassword()
        //{
        //    string jsonResult = "{\"Result\":\"Error\"}";

        //    dynamic json = JValue.Parse(this.HttpContext.Request.Params[0]);

        //    JValue jt = json.pwd;

        //    if(jt.Value.ToString().Length > 7)
        //    {
        //        jsonResult = "{\"Result\":\"OK\", \"Hash\":\"" + Crypto.HashPassword(jt.Value.ToString()) + "\"}";
        //    }

        //    return jsonResult;
        //}
    }
}