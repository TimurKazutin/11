﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using Newtonsoft.Json;
    using System.Net.Http;

    public class FileremoveController : Controller
    {
        private IDataProvider provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

         public string Index(string doc_id, string doc_guid, string token)
        {         
            var result = "OK";

            try
            {
                provider.DeleteFile(int.Parse(doc_guid));
                var query = $"UPDATE attis_contract_docs SET doc_guid='', file_type='' WHERE attis_contract_doc_id='{doc_id}'";
                provider.RunNonQuery(query);
            }
            catch (Exception ex)
            {
                result = "Error" + ex;
            }

            return JsonConvert.SerializeObject(result); 
        }
    }
}