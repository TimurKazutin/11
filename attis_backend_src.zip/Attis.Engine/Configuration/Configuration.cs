﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-22-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-22-2015
// ***********************************************************************
// <copyright file="Configuration.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Configuration namespace.
/// </summary>
namespace Lawyers.Engine.Configuration
{
	using Common.Enums;
	using Common.Interfaces;
	using System.Collections.Generic;
	using System.Configuration;
	using Common.Classes;
	using System.Data;
	using Common.Model;
	using System.IO;
	using System.Xml.Serialization;
    using Database.Oracle;
    using Lawyers.Database.Postgres;

	/// <summary>
	/// Class Configuration.
	/// </summary>
	public class Configuration
	{
		/// <summary>
		/// The section
		/// </summary>
		private Section section;

		/// <summary>
		/// The data provider
		/// </summary>
		private IDataProvider dataProvider;

		/// <summary>
		/// Initializes a new instance of the <see cref="Configuration"/> class.
		/// </summary>
		public Configuration()
		{
			this.section = (Section)ConfigurationManager.GetSection("templates/templates.engine");
			this.dataProvider = new PG_DataProvider(section.MainConnection.ConnectionString);
			//this.dataProvider = new PG_DataProvider("host=18.196.173.90:5432;database=attis;user id=postgres;password=HAmGqjNZRvLY;character set=utf8");
		}

		/// <summary>
		/// Gets the section.
		/// </summary>
		/// <value>The section.</value>
		public Section Section { get { return this.section; } }

		/// <summary>
		/// Gets the data provider.
		/// </summary>
		/// <value>The data provider.</value>
		public IDataProvider DataProvider { get { return this.dataProvider; } }

		public List<ImageFile> GetPictures(System.Guid guid)
		{
			/// TODO here
			return this.dataProvider.GetFiles(guid);
		}

		public void SavePicture(ImageFile imgFile)
		{
			/// TODO here
			this.dataProvider.SaveFile(imgFile);
		}

        public void UploadBlockDoc(ImageFile imgFile)
        {
            /// TODO here
            this.dataProvider.UploadBlockDoc(imgFile);
        }

        public TemplateDictionary GetTemplates()
		{
			TemplateDictionary dictionary = new TemplateDictionary();

			string query = string.Format("select id, {0}, {1} from {2}", this.section.TemplatesTable.TemplateField, this.section.TemplatesTable.RoleField, this.section.TemplatesTable.Name);

			XmlSerializer serializer = new XmlSerializer(typeof(Template));

			using (IDataReader reader = this.dataProvider.RunQuery(query))
			{
				while (reader.Read())
				{
					string xml = reader.GetString(1);
					Template template = null;

					using (TextReader sr = new StringReader(xml))
					{
						template = (Template)serializer.Deserialize(sr);
					}

					template.Document.SetParent(null);
					template.Document.SetChecks(template.Document);
					template.Roles = reader.GetInt32(2);
					dictionary.Add(template.Guid, template);
				}

				reader.Close();
			}

			return dictionary;
		}

		public ReportDictionary GetReports()
		{
			ReportDictionary dictionary = new ReportDictionary();

			string query = string.Format("select id, Name, {0} from {1}", this.section.ReportsTable.TemplateField, this.section.ReportsTable.Name);
			XmlSerializer serializer = new XmlSerializer(typeof(Report));

			using (IDataReader reader = this.dataProvider.RunQuery(query))
			{
				while (reader.Read())
				{
					string xml = reader.GetString(2);
					Report template = null;

					using (TextReader sr = new StringReader(xml))
					{
						template = (Report)serializer.Deserialize(sr);
					}

					template.Name = reader.GetString(1);
					dictionary.Add(reader.GetInt32(0), template);
				}

				reader.Close();
			}
			return dictionary;
		}
	}
}
