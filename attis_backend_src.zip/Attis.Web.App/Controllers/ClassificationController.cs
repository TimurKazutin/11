﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using Newtonsoft.Json;
    using System.Net.Http;

    public class ClassificationController : Controller
    {
        private IDataProvider provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

        public class LibModel
        {
            public string display_text { get; set; }
            public string value { get; set; }
            public string level_1 { get; set; }
            public string level_2 { get; set; }
            public string level_3 { get; set; }
            public string level_4 { get; set; }
            public string level_1_text { get; set; }
            public string level_2_text { get; set; }
            public string level_3_text { get; set; }
            public string level_4_text { get; set; }

            //public HttpPostedFileBase Image { get; set; }    
        }
        public class LibModel0
        {
            public string display_text { get; set; }
            public string value { get; set; }

            //public HttpPostedFileBase Image { get; set; }    
        }

        // GET: Library
        public string Index(string type, string level, string level_1, string level_2, string level_3, string level_4, string query, int qty, string token)
        { 
            var news = new List<LibModel> ();
            //news.Add(new LibModel { display_text = "Furniture Production", value= "funrinture_production" });
            //news.Add(new LibModel { display_text = "Financial Sector", value = "finance" });
            //news.Add(new LibModel { display_text = "Insurance", value = "insurance_h" });
            /* oked и subj_statuses
             */
            if (type == "kpved" && level == "1")
            {
                //lock (provider.Locker)
                {
                    //string query1 = $"SELECT kpved_section, kpved_name_ru FROM kpved WHERE LOWER(kpved_name_ru) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    string query1 = $"SELECT * from kpved where kpved_subkind = kpved_department order by kpved_section, kpved_department LIMIT '{qty}'";
                      var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_department"].ToString(), display_text = reader["kpved_section"].ToString() +" - "+ reader["kpved_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            if (type == "kpved" && level == "2")
            {
                //lock (provider.Locker)
                {
                    //string query1 = $"SELECT kpved_department, kpved_name_ru FROM kpved WHERE LOWER(kpved_name_ru) ~ '{query}' AND kpved_section='{level_1}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    string query1 = $"select kpved_department,kpved_name_ru from kpved where length(kpved_subkind)=2 and kpved_department = '{level_1}' order by kpved_section LIMIT '{qty}'";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_department"].ToString(), display_text = reader["kpved_department"].ToString() + " - " + reader["kpved_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            if (type == "kpved" && level == "3")
            {
                //lock (provider.Locker)
                {
                    //string query1 = $"SELECT kpved_group, kpved_name_ru FROM kpved WHERE LOWER(kpved_name_ru) ~ '{query}' AND kpved_section='{level_1}' AND kpved_department='{level_2}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    string query1 = $"SELECT kpved_group,kpved_name_ru FROM kpved WHERE length(kpved_subkind)=3 AND kpved_department='{level_2}' order by kpved_id LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_group"].ToString(), display_text = reader["kpved_group"].ToString() + " - " + reader["kpved_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            if (type == "kpved" && level == "4")
            {
                //lock (provider.Locker)
                {
                    //string query1 = $"SELECT kpved_class, kpved_name_ru FROM kpved WHERE LOWER(kpved_name_ru) ~ '{query}' AND kpved_section='{level_1}' AND kpved_department='{level_2}' AND kpved_group='{level_3}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    string query1 = $"SELECT kpved_class,kpved_name_ru FROM kpved WHERE length(kpved_subkind)=4 AND kpved_group='{level_3}' order by kpved_id LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_class"].ToString(), display_text = reader["kpved_class"].ToString() + " - " + reader["kpved_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            if (type == "kpved" && level == "5")
            {
                //lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM kpved WHERE length(kpved_subkind)=5 AND kpved_class='{level_4}' order by kpved_id LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_subkind"].ToString(), display_text = reader["kpved_subkind"].ToString() + " - " + reader["kpved_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            if (type == "kpved" && level == "search")
            {
                //lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM kpved WHERE length(kpved_subkind)=5 AND LOWER(kpved_subkind) ~ LOWER('{query}') order by kpved_id LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_subkind"].ToString(), display_text = reader["kpved_subkind"].ToString() +" - " + reader["kpved_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            if (type == "kpved" && level == "names")
            {
                //lock (provider.Locker)
                {                    
                    string newList = string.Join(",", query.Split(',').Select(x => string.Format("'{0}'", x)).ToList());
                    string query1 = $"SELECT * FROM kpved where kpved_subkind IN({newList}) order by kpved_id LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_subkind"].ToString(), display_text = reader["kpved_subkind"].ToString() + " - " + reader["kpved_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            if (type == "kpved" && level == "last")
            {
                //lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM kpved WHERE LOWER(kpved_name_ru) ~ '{query}' AND kpved_section='{level_1}' AND kpved_department='{level_2}' AND kpved_group='{level_3}' kpved_class='{level_4}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            string disp = reader["kpved_name_ru"].ToString();
                            news.Add(new LibModel { value = reader["kpved_subkind"].ToString(), display_text = disp,
                            level_1 = reader["kpved_section"].ToString(), level_1_text=disp, level_2 = reader["kpved_department"].ToString(), level_2_text= disp, level_3= reader["kpved_group"].ToString(), level_3_text= disp, level_4= reader["kpved_class"].ToString(), level_4_text= disp
                            });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            return JsonConvert.SerializeObject(news); 
        }
    }
}