﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 03-05-2015
//
// Last Modified By : Victor Skakun
// Last Modified On : 19-12-2016
// ***********************************************************************
// <copyright file="ReportParameters.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Xml.Serialization;
    using System.Threading;

    /// <summary>
    /// Class ReportParameter.
    /// </summary>
    [XmlType]
    public class ReportParameter
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [XmlAttribute("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the caption.
        /// </summary>
        /// <value>The caption.</value>
        public string Caption
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(CaptionRu))
                    return CaptionRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(CaptionKk))
                    return CaptionKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(CaptionEn))
                    return CaptionEn;
                return CaptionRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    CaptionRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    CaptionKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    CaptionEn = value;
                    return;
                }
                CaptionRu = value;
            }
        }

        /// <summary>
        /// Gets or sets the caption en.
        /// </summary>
        /// <value>
        /// The caption en.
        /// </value>
        [XmlAttribute(AttributeName = "caption_en")]
        public string CaptionEn { get; set; }

        /// <summary>
        /// Kazakh language Caption.
        /// </summary>
        [XmlAttribute(AttributeName = "caption_kz")]
        public string CaptionKk { get; set; }

        /// <summary>
        /// Chinese language Caption.
        /// </summary>
        [XmlAttribute(AttributeName = "caption_ru")]
        public string CaptionRu { get; set; }

        //[XmlAttribute("caption")]
        //public string Caption { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        [XmlIgnore]
        public string Value { get; set; }
    }
}
