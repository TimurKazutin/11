﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-23-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 04-27-2015
// ***********************************************************************
// <copyright file="DataSet.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Data namespace.
/// </summary>
namespace Lawyers.Engine.Data
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Linq;
	using System.Security.Claims;
	using Common;
	using Lawyers.Common.Classes;
	using Lawyers.Common.Enums;
	using Common.Model;
	using Common.Interfaces;

	/// <summary>
	/// Class DataSet.
	/// </summary>
	public class DataSet
	{
		/// <summary>
		/// Gets the tables.
		/// </summary>
		/// <value>The tables.</value>
		public SortedDictionary<string, Table> Tables { get; private set; }

		/// <summary>
		/// Gets the identity.
		/// </summary>
		/// <value>The identity.</value>
		public ClaimsIdentity Identity { get; private set; }

		/// <summary>
		/// Gets the data source.
		/// </summary>
		/// <value>The data source.</value>
		public DataSource DataSource { get; private set; }

		/// <summary>
		/// Gets the provider.
		/// </summary>
		/// <value>The provider.</value>
        public List<string> Errors { get; private set; }

        /// <summary>
        /// Gets the log table name.
        /// </summary>
        /// <value>The log table name.</value>
        public Table LogTable { get; private set; }

        /// <summary>
        /// List of errors.
        /// </summary>
        /// <value>List of errors.</value>
        public IDataProvider Provider { get { return GlobalContainer.Instance.Get<DataProviderDictionary>()[DataSource.ConnectionString]; } }

		/// <summary>
		/// Initializes a new instance of the <see cref="DataSet"/> class.
		/// </summary>
		/// <param name="identity">The identity.</param>
		public DataSet(ClaimsIdentity identity, DataSource ds)
		{
			this.Tables = new SortedDictionary<string, Table>();
			this.Identity = identity;
			this.DataSource = ds;
            this.Errors = new List<string>();
			var kvProvider = GlobalContainer.Instance.Get<DataProviderDictionary>().FirstOrDefault(p=>p.Key == ds.ConnectionString);

			if (kvProvider.Key == null)
			{
				switch (ds.Type)
				{
					case DataSourceType.Oracle:
						GlobalContainer.Instance.Get<DataProviderDictionary>().Add(ds.ConnectionString, new Database.Oracle.DataProvider(ds.ConnectionString));
                        break;
                    case DataSourceType.Postgres:
                        GlobalContainer.Instance.Get<DataProviderDictionary>().Add(ds.ConnectionString, new Database.Postgres.PG_DataProvider(ds.ConnectionString));
                        break;
                    default:
						break;
				}
			}
		}

        /// <summary>
        /// Gets errors count.
        /// </summary>
        /// <param name="document"></param>
        public int errorsCount()
        {
            return Errors.Count;
        }

		/// <summary>
		/// Initializes the specified document.
		/// </summary>
		/// <param name="document">The document.</param>
		public void Initialize(Document document)
		{
			// Get table structure
			GetStructure(document);

			Widget dataWidget = document.FirstChildWithDataTable();

            if (dataWidget.Logged && LogTable == null)  //create a table for logging
            {
                LogTable = new Table(String.IsNullOrEmpty(dataWidget.DefaultValue) ? dataWidget.TableName + "_log" : dataWidget.DefaultValue);
                LogTable.PrimaryKeys.Add("id", new FieldPrimaryKey() { Name = "id", Position = 0, Parameter = "" });
                LogTable.AddField(new Field("id", DataType.Integer, FieldType.PrimaryKey, 0, string.Empty));  //id
                LogTable.AddField(new Field("record_id", DataType.Integer, FieldType.None, 0, string.Empty));  //record_id
                LogTable.AddField(new Field("operation_type", DataType.Integer, FieldType.None, 0, string.Empty));  //operation_type: 0 - insert, 1 - update, 2 - delete
                LogTable.AddField(new Field("log_date", DataType.DateTime, FieldType.None, 8, string.Empty));  //log_date
                LogTable.AddField(new Field("user_id", DataType.Integer, FieldType.None, 0, string.Empty));  //user_id
                LogTable.AddField(new Field("log_field", DataType.Varchar, FieldType.None, 100, string.Empty));  //log_field
                LogTable.AddField(new Field("old_value", DataType.Varchar, FieldType.None, 500, string.Empty));  //old_value
                LogTable.AddField(new Field("new_value", DataType.Varchar, FieldType.None, 500, string.Empty));  //new_value
            }

			// Set master table
			Tables[dataWidget.TableName].Type = TableType.Master;

			// Set dictionaries
			foreach (Table table in Tables.Values.Where(t => t.Type == TableType.Detail && t.ForeignKeys.Count == 0))
				table.Type = TableType.Dictionary;
		}

		/// <summary>
		/// Gets the structure.
		/// </summary>
		/// <param name="widget">The widget.</param>
		private void GetStructure(Widget widget)
		{
			if (!string.IsNullOrEmpty(widget.TableName))
			{
				// Table getting logic
				Table table = null;

				if (Tables.ContainsKey(widget.TableName))
					table = Tables[widget.TableName];
				else
				{
					table = new Table(widget.TableName);
					Tables.Add(widget.TableName, table);
				}

				// Primary keys getting logic
				foreach (FieldPrimaryKey pk in widget.PrimaryKeys)
				{
					if (!table.PrimaryKeys.ContainsKey(pk.Name))
					{
						table.PrimaryKeys.Add(pk.Name, new FieldPrimaryKey() { Name = pk.Name, Position = pk.Position, Parameter = pk.Parameter });
					}

					if (!table.ContainsField(pk.Name))
					{
						table.AddField(new Field(pk.Name, DataType.Integer, FieldType.PrimaryKey, 0, string.Empty));
					}
				}

				// Foreign keys getting logic
				foreach (FieldForeignKey fk in widget.ForeignKeys)
				{
					if (!table.ForeignKeys.ContainsKey(fk.Name))
					{
						table.ForeignKeys.Add(fk.Name, new FieldForeignKey() { Name = fk.Name, Position = fk.Position, FieldName = fk.FieldName, TableName = fk.TableName });
					}

					if (!table.ContainsField(fk.Name))
					{
						table.AddField(new Field(fk.Name, DataType.Integer, FieldType.ForeignKey, 0, string.Empty));
					}
				}

				// Field getting logic   
				if (!string.IsNullOrEmpty(widget.Field) && !table.ContainsField(widget.Field))
				{
					table.AddField(new Field(widget.Field, widget.DataType, FieldType.None, widget.Length, widget.DefaultValue ?? string.Empty));
				}
                //To account all languages query also all national Fields: FieldEn, FieldKk, FieldRu 
                if (!string.IsNullOrEmpty(widget.FieldRu) && !table.ContainsField(widget.FieldRu))
                {
                    table.AddField(new Field(widget.FieldRu, widget.DataType, FieldType.None, widget.Length, widget.DefaultValue ?? string.Empty));
                }
                if (!string.IsNullOrEmpty(widget.FieldKk) && !table.ContainsField(widget.FieldKk))
                {
                    table.AddField(new Field(widget.FieldKk, widget.DataType, FieldType.None, widget.Length, widget.DefaultValue ?? string.Empty));
                }
                if (!string.IsNullOrEmpty(widget.FieldEn) && !table.ContainsField(widget.FieldEn))
                {
                    table.AddField(new Field(widget.FieldEn, widget.DataType, FieldType.None, widget.Length, widget.DefaultValue ?? string.Empty));
                }

                //add filtered field
				if (!string.IsNullOrEmpty(widget.FilterFieldName) && !table.ContainsField(widget.FilterFieldName))
				{
					table.AddField(new Field(widget.FilterFieldName, widget.DataType, FieldType.None, widget.Length, widget.DefaultValue ?? string.Empty));
				}

				// Filters logic
				if (!string.IsNullOrEmpty(widget.FilterFieldName) && !widget.Filters.Any(f => f.Name == widget.FilterFieldName))
				{
					widget.Filters.Add(new FieldFilter() { Name = widget.FilterFieldName, Value = widget.FilterFieldValue, OperationType = ConditionOperationType.Equal, Apply = true });
				}

				// PrimaryKey Editable logic
                if (!string.IsNullOrEmpty(widget.Field) && table.Type != TableType.Dictionary && table.PrimaryKeys.ContainsKey(widget.Field) && (widget.Visible && !widget.ReadOnly))
				{
					table[table.GetFieldIndex(widget.Field)].Editable = true;
				}
			}

			// Recursive logic 
			foreach (Widget child in widget.Children)
			{
				this.GetStructure(child);
			}
		}

		/// <summary>
		/// Fills the table data. Invoked from Document 
		/// </summary>
		/// <param name="provider">The provider.</param>
		/// <param name="id">The identifier.</param>
		public void FillTableData(int? id)
		{
            this.Errors.Clear();
            //Dictionary only here. Master table and Details tables are populated in DataGridList invoked from JS. Master table Select ID is populated in Initialize().
            foreach (Table table in Tables.Values.Where(t => t.Type != TableType.Detail))
			{
                if(table.Type == TableType.Master)
                {
                   //Set master table SelectID
                   table.SelectID = id;
                }
				//FillTableData(table, table.Type == TableType.Master ? id : null);
                FillTableData(table, (int?)null);
			}
		}

		/// <summary>
		/// Fills the table data. Invoked from templates controller actions External and Document
		/// </summary>
		/// <param name="provider">The provider.</param>
		/// <param name="table">The table.</param>
		/// <param name="id">The identifier.</param>
        public void FillTableData(Table table, int? id)
		{
			table.Records.Clear();

			string query;
            if(id.HasValue && table.ForeignKeys.Count > 0)
                query = string.Format("{0} where {1}={2}", table.SqlQuery(SqlQueryType.Select), table.ForeignKeys.First().Key, id.Value);
            else if (id.HasValue && table.PrimaryKeys.Count > 0)
                query = string.Format("{0} where {1}={2}", table.SqlQuery(SqlQueryType.Select), table.PrimaryKeys.First().Key, id.Value);
            else
				query = table.SqlQuery(SqlQueryType.Select);

			IDataReader reader = this.Provider.RunQuery(query);
            if (!String.IsNullOrEmpty(this.Provider.lastError))
                this.Errors.Add(this.Provider.lastError);
            if(reader != null)
            {
			    while (reader.Read())
			    {
				    Record record = new Record(table);

				    for (int i = 0; i < reader.FieldCount; i++)
				    {
					    record[i].Value = reader[i];
				    }

				    table.Records.Add(record);
			    }

                reader.Close();
            }
		}

		/// <summary>
		/// Fills the table data.
		/// </summary>
		/// <param name="provider">The provider.</param>
		/// <param name="table">The table.</param>
		/// <param name="filters">The filters.</param>
		public void FillTableData(Table table, TableFilters filters)
		{
			table.Records.Clear();

            if (table.SelectID.HasValue && table.ForeignKeys.Count > 0)
                filters.Add(new TableFilter(table, table.ForeignKeys.First().Key, ConditionOperationType.Equal, table.SelectID.ToString()));
            else if (table.SelectID.HasValue && table.PrimaryKeys.Count > 0)
                filters.Add(new TableFilter(table, table.PrimaryKeys.First().Key, ConditionOperationType.Equal, table.SelectID.ToString()));

            string query = filters.Count > 0 ? string.Format("{0} where {1}", table.SqlQuery(SqlQueryType.Select), filters.FilterString)
            	: table.SqlQuery(SqlQueryType.Select);

			IDataReader reader = this.Provider.RunQuery(query);
            if (!String.IsNullOrEmpty(this.Provider.lastError))
                this.Errors.Add(this.Provider.lastError);

			while (reader.Read())
			{
				Record record = new Record(table);

				for (int i = 0; i < reader.FieldCount; i++)
				{
					record[i].Value = reader[i];
				}

				table.Records.Add(record);
			}

            reader.Close();
		}

		/// <summary>
		/// Fills the table data reverse.
		/// </summary>
		/// <param name="provider">The provider.</param>
		/// <param name="table">The table.</param>
		/// <param name="id">The identifier.</param>
		//public void FillTableDataReverse(Table table, decimal id)
        public void FillTableDataReverse(Table table, int id)
		{
            this.Errors.Clear();
			table.Records.Clear();

			string query = string.Format("{0} where {1}={2}", table.SqlQuery(SqlQueryType.Select), table.PrimaryKeys.First().Key, id);

			using (IDataReader reader = this.Provider.RunQuery(query))
			{
				while (reader.Read())
				{
					Record record = new Record(table);

					for (int i = 0; i < reader.FieldCount; i++)
					{
						record[i].Value = reader[i];
					}

					table.Records.Add(record);
				}

                reader.Close();
			}
            if (!String.IsNullOrEmpty(this.Provider.lastError))
                this.Errors.Add(this.Provider.lastError);

			// fill one level up table with another child
			if (!string.IsNullOrEmpty(table.ParentTableName))
			{
				Table parentTable = this.Tables[table.ParentTableName];

				if (parentTable.Type != TableType.Master && table.Records.Count > 0)
				{
					string queryParent = string.Format("{0} where {1}={2}",
						parentTable.SqlQuery(SqlQueryType.Select), parentTable.PrimaryKeys.First().Key,
						table.Records[0].Values[table.GetFieldIndex(table.ForeignKeys.First().Key)]);

					parentTable.Records.Clear();

					using (IDataReader readerParent = this.Provider.RunQuery(queryParent))
					{
						while (readerParent.Read())
						{
							Record record = new Record(parentTable);

							for (int i = 0; i < readerParent.FieldCount; i++)
							{
								record[i].Value = readerParent[i];
							}

							parentTable.Records.Add(record);
						}

					    readerParent.Close();

                    }
                    if (!String.IsNullOrEmpty(this.Provider.lastError))
                        this.Errors.Add(this.Provider.lastError);

					var tables = this.Tables.Where(t => t.Key != table.Name && t.Value.ForeignKeys.Values.Any(fk => fk.TableName == parentTable.Name)).Select(t => t.Value).ToList();

					if (tables.Count > 0 && parentTable.Records.Count > 0)
					{
						foreach (Table childTable in tables)
						{
							string queryChild = string.Format("{0} where {1}={2}",
								childTable.SqlQuery(SqlQueryType.Select), childTable.ForeignKeys.First().Key,
								parentTable.Records[0].Values[table.PrimaryKeyIndexes[0]]);

							childTable.Records.Clear();

							using (IDataReader readerChild = this.Provider.RunQuery(queryChild))
							{
								while (readerChild.Read())
								{
									Record record = new Record(childTable);

									for (int i = 0; i < readerChild.FieldCount; i++)
									{
										record[i].Value = readerChild[i];
									}

									childTable.Records.Add(record);
								}

                                readerChild.Close();
							}

                            if (!String.IsNullOrEmpty(this.Provider.lastError))
                                this.Errors.Add(this.Provider.lastError);
						}
					}
				}
			}
		}

        /// <summary>
        /// Fills the log table with data.
        /// </summary>
        /// <param name="provider">The provider.</param>
        /// <param name="table">The user id.</param>
        /// <param name="id">The record guid.</param>
        public void FillLogTableData(int? user_id, string guid)
        {
            LogTable.Records.Clear();

            string query;
            if (user_id.HasValue && !String.IsNullOrEmpty(guid))
                query = string.Format("{0} where user_id={1} and record_guid={2}", LogTable.SqlQuery(SqlQueryType.Select), user_id.Value, guid);
            else if (user_id.HasValue && String.IsNullOrEmpty(guid))
                query = string.Format("{0} where user_id={1}", LogTable.SqlQuery(SqlQueryType.Select), user_id.Value);
            else if (!user_id.HasValue && !String.IsNullOrEmpty(guid))
                query = string.Format("{0} where record_guid={1}", LogTable.SqlQuery(SqlQueryType.Select), guid);
            else
                query = LogTable.SqlQuery(SqlQueryType.Select);

            IDataReader reader = this.Provider.RunQuery(query);
            if (!String.IsNullOrEmpty(this.Provider.lastError))
                this.Errors.Add(this.Provider.lastError);
            if (reader != null)
            {
                while (reader.Read())
                {
                    Record record = new Record(LogTable);

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        record[i].Value = reader[i];
                    }

                    LogTable.Records.Add(record);
                }

                reader.Close();
            }
        }

		/// <summary>
		/// Sets the table filtered.
		/// </summary>
		/// <param name="widget">The widget.</param>
		/// <param name="table">The table.</param>
		public void SetTableFiltered(Widget widget, Table table)
		{
			table.SetRecords(table.ApplyFilters(widget, null, this));
		}

		/// <summary>
		/// Binds the data.
		/// </summary>
		/// <param name="widget">The widget.</param>
		public void BindData(Widget widget)
		{
            if (widget.Type == WidgetType.Array || widget.Type == WidgetType.DataGrid || widget.Type == WidgetType.Form)
			{
				Table table = Tables[widget.TableName];
				if (widget.Parent != null && widget.Parent.Type == WidgetType.DBComboBox)
				{
					widget.Parent.Items = (widget.Filters.Count == 0 ? table.Records : table.ApplyFilters(widget, null, this))
						.Select(r =>
							new KeyValueData(
								r[table.GetFieldIndex(widget.Field)].ToString(),
                                //r[table.GetFieldIndex(widget.FieldView)].ToString(),
                                //if FieldView was not localized (i.e. empty) query FieldViewRu 
                                string.IsNullOrEmpty(r[table.GetFieldIndex(widget.FieldView)].ToString()) ? r[table.GetFieldIndex(widget.FieldViewRu)].ToString() : r[table.GetFieldIndex(widget.FieldView)].ToString(),
								widget.Children.Where(w => w.Visible).ToDictionary(ws => ws.MvcType + "_" + ws.Name, ws => r[table.GetFieldIndex(ws.Field)].ToString()))
							).OrderBy(k => k.Key).ToList();
				}
				else // other table types
				{
					widget.DataFields = table.FieldList;

					//if (widget.Type == WidgetType.DataGrid && widget.Filters.Count > 0)
					//{
					//    table.SetRecords(table.ApplyFilters(widget, null, this));
					//}
				}
			}

			if (widget.Type == WidgetType.List)
			{
				widget.Items = widget.Children.Select(c => new KeyValueData(c.Key, c.DefaultValue, new Dictionary<string, string>())).OrderBy(k => k.Key).ToList();
			}

			foreach (Widget child in widget.Children)
			{
				BindData(child);
			}
		}

		/// <summary>
		/// Saves the table data.
		/// </summary>
		/// <param name="provider">The provider.</param>
		/// <param name="table">The table.</param>
		/// <param name="dataset">The dataset.</param>
		public void SaveTableData(Table table, DataSet dataset)
		{
            this.Errors.Clear();
			this.SaveData(table);

			foreach (Table detailTable in this.Tables.Values.Where(t => t.Type == TableType.Detail && t.ForeignKeys.Values.Any(fk => fk.TableName == table.Name)))
			{
				SaveTableData(detailTable, dataset);
			}
		}

		/// <summary>
		/// Sets the detail table foreign key.
		/// </summary>
		/// <param name="table">The table.</param>
		/// <param name="p">The p.</param>
		public void SetDetailTableForeignKey(Table table, object p)
		{
			foreach (Table detailTable in this.Tables.Values.Where(t => t.Type == TableType.Detail && t.ForeignKeys.Values.Any(fk => fk.TableName == table.Name)))
			{
				foreach (Record record in detailTable.Records.Where(r => r.State == RecordState.Insert))
				{
					record.Values[detailTable.GetFieldIndex(detailTable.ForeignKeys.First().Key)].Value = p;
				}
			}
		}

		/// <summary>
		/// Deletes the table data.
		/// </summary>
		/// <param name="provider">The provider.</param>
		/// <param name="table">The table.</param>
		/// <param name="id">The identifier.</param>
		public void DeleteTableData(Table table, Guid id)
		{
            this.Errors.Clear();
			Record parentRecord = table.Records.FirstOrDefault(r => r.Guid == id);
			if (parentRecord == null) return;

			object pid = parentRecord.Values[table.PrimaryKeyIndexes[0]].Value;
            if (pid == null) return;

			foreach (Table detailTable in Tables.Values.Where(t => t.Type == TableType.Detail && t.ForeignKeys.Values.Any(fk => fk.TableName == table.Name)))
			{
				int fkIndex = detailTable.GetFieldIndex(detailTable.ForeignKeys.First().Key);
				Record detailRecord = detailTable.Records.Where(r => r.Values[fkIndex].ToString() == pid.ToString()).FirstOrDefault();
				while (detailRecord != null)
				{
					DeleteTableData(detailTable, detailRecord.Guid);
					detailRecord = detailTable.Records.Where(r => r.Values[fkIndex].ToString() == pid.ToString()).FirstOrDefault();
				}
			}

			if (this.DeleteData(table, pid))
			{
				table.Records.Remove(parentRecord);
			}
		}

		public bool SaveData(Table table)
		{
			int[] paramIndexes = null;
			object paramOut = null;
            this.Provider.clearError();

			for (int recInd = 0; recInd < table.Records.Count; recInd++)
			{ 
				switch (table.Records[recInd].State)
				{
					case RecordState.Insert:
						paramIndexes = table.ParameterIndexes(SqlQueryType.Insert);

						this.Provider.RunNonQuery(table.SqlQuery(SqlQueryType.Insert), table.Records[recInd].Values.Select(c => c.Value).ToArray(), paramIndexes, null, table.FieldList.ToArray(), out paramOut);
                        if (paramOut != null)
                        {
                            table.Records[recInd].Values[table.PrimaryKeyIndexes[0]].Value = paramOut.ToString();
                            this.SetDetailTableForeignKey(table, table.Records[recInd].Values[table.PrimaryKeyIndexes[0]].Value);
                            table.Records[recInd].State = RecordState.None;
                        }
						break;
					case RecordState.Update:
						paramIndexes = table.ParameterIndexes(SqlQueryType.Update);
						int[] pkIndexes = table.PrimaryKeyIndexes;
						this.Provider.RunNonQuery(table.SqlQuery(SqlQueryType.Update), table.Records[recInd].Values.Select(c => c.Value).ToArray(), paramIndexes, pkIndexes, table.FieldList.ToArray());
						this.SetDetailTableForeignKey(table, table.Records[recInd].Values[table.PrimaryKeyIndexes[0]].Value);
						table.Records[recInd].State = RecordState.None;
						break;
					default:
						break;
				}
                if (!String.IsNullOrEmpty(this.Provider.lastError))
                {
                    this.Errors.Add(this.Provider.lastError);
                    break;
                }
			}
            return this.errorsCount() == 0;
		}

		/// <summary>
		/// Deletes the data.
		/// </summary>
		/// <param name="table">The table.</param>
		/// <param name="id">The identifier.</param>
		/// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
		public bool DeleteData(Engine.Data.Table table, object id)
		{
			if (id == null) return true;

            bool result = this.Provider.RunNonQuery(table.SqlQuery(SqlQueryType.Delete) + id.ToString()) >= 0;
            if (!String.IsNullOrEmpty(this.Provider.lastError))
                this.Errors.Add(this.Provider.lastError);
			return result;
		}
	}
}