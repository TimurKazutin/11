﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Text;
using System.Web.Mvc;
using System.Security.Cryptography;
using Lawyers.Engine.Configuration;
using Lawyers.Common;
using Lawyers.Common.Enums;
using Lawyers.Common.Interfaces;
using Lawyers.Web.App.Helpers;
using Lawyers.Web.App.Models;
using Lawyers.Web.App.Models.Enums;
using log4net;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using Lawyers.Common.Classes;
using System.Xml.Serialization;
using System.Xml;

namespace Lawyers.Web.App.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly ILog log = LogManager.GetLogger("Account"); //log to file
        private ApplicationUserManager _userManager;

        public AccountController()
        {
        }

        public AccountController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        private static IDataProvider Provider => GlobalContainer.Instance.Get<Configuration>().DataProvider;
        /*
        private string SessionToken
        {
            get
            {
                //object value = HttpContext.Session["Token"];
                return value == null ? "" : (string)value;
            }
            set
            {
                HttpContext.Session["Token"] = value;
            }
        }
        */
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            var isAuth = (System.Web.HttpContext.Current.User != null) && System.Web.HttpContext.Current.User.Identity.IsAuthenticated;
            if (!isAuth)
            {
                ViewBag.ReturnUrl = returnUrl;
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        private ApplicationSignInManager _signInManager;

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set { _signInManager = value; }
        }
        /*
        [AllowAnonymous]
        public String getguid()
        {
            string guid = Guid.NewGuid().ToString("N");
            SessionToken = guid;
            Response.Cookies["token"].Value = guid;
            return guid;
        }*/

        [HttpPost]
        [AllowAnonymous]
        //[ValidateAntiForgeryToken]
        public JsonResult Login(string customer_email, string customer_password, string token)
        {
            //var dd = SessionToken;

            //var ee = Request.Cookies["token"].Value.ToString(); /doa
            var isAuth = (System.Web.HttpContext.Current.User != null) && System.Web.HttpContext.Current.User.Identity.IsAuthenticated;
            statusmsg nas = new statusmsg { statusCode = 419 };
            nas.user = new loginuser();
            if (!isAuth)
            {
                if (customer_email == null || customer_password == null)
                {
                    nas.statusCode = 200;
                    nas.statusMessage = "OK";
                    return Json(nas);
                }
                var user = UserManager.FindByName(customer_email);

                if (user != null)
                {
                    if (!UserManager.IsEmailConfirmed(user.Id))
                    {
                        //ViewBag.Message = "Вы не можете войти в свой личный кабинет, так как Вы не завершили процесс регистрации. Вам необходимо войти в авторизационное письмо, отправленное на указанный Вами адрес электронной почты и нажать на ссылку, помещенную в данном письме.";
                        nas.statusCode = 201;
                        nas.statusMessage = "Ваш запрос на регистрацию еще не прошел проверку";
                        return Json(nas);
                    }
                }
                else
                {
                    nas.statusCode = 201;
                    nas.statusMessage = "Пользователь не найден";
                    return Json(nas);
                }
                // This doesn't count login failures towards account lockout
                // To enable password failures to trigger account lockout, change to shouldLockout: true
                var result = SignInManager.PasswordSignIn(customer_email, customer_password, isPersistent: true, shouldLockout: false);
                Session["Token"] = "0";
                switch (result)
                {
                    case SignInStatus.Success:

                        string rols = "";
                        int active = 0;
                        string qr = $"SELECT org_is_broker, org_is_carrier, org_is_bank, org_is_insurer, org_is_twh, active FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user.Id}';";
                        var reader = Provider.RunQuery(qr);
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                active = reader.GetFieldValueOrDefault<int>("active");
                                int br = reader.GetFieldValueOrDefault<int>("org_is_broker");
                                if (br > 0) rols = "\"broker\"";
                                int cr = reader.GetFieldValueOrDefault<int>("org_is_carrier");
                                if (cr > 0 && string.IsNullOrEmpty(rols)) rols = "\"carrier\"";
                                else if (cr > 0) rols = rols + ",\"carrier\"";
                                int bk = reader.GetFieldValueOrDefault<int>("org_is_bank");
                                if (bk > 0 && string.IsNullOrEmpty(rols)) rols = "\"bank\"";
                                else if (bk > 0) rols = rols + ",\"bank\"";
                                int ins = reader.GetFieldValueOrDefault<int>("org_is_insurer");
                                if (ins > 0 && string.IsNullOrEmpty(rols)) rols = "\"insurer\"";
                                else if (ins > 0) rols = rols + ",\"insurer\"";

                                int twh = reader.GetFieldValueOrDefault<int>("org_is_twh");
                                if (twh > 0 && string.IsNullOrEmpty(rols)) rols = "\"twh\"";
                                else if (twh > 0) rols = rols + ",\"twh\"";
                            }
                            reader.Close();
                        }
                        if (active == 0)
                        {
                            nas.statusCode = 201;
                            nas.statusMessage = "Пользователь заблокирован";
                            logOut();
                            return Json(nas);
                        }
                        nas.statusCode = 200;
                        nas.statusMessage = "OK";
                        string query = $@"SELECT ""ClaimValue"" FROM ""AspNetUserClaims""  WHERE ""UserId"" = '{user.Id}' AND ""ClaimType"" = 'user_role';";
                        int role = Provider.RunScalar(query);
                        nas.user.id = user.Id;
                        nas.user.firstName = user.UserName;
                        nas.user.lastName = user.UserName;
                        nas.user.Roles = "[" + rols + "]";
                        nas.user.role_id = role;
                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.Login}', '{LogAccount.Login}', '{LogSection.Account}', '{user.Id}', '0');";
                        Provider.RunNonQuery(query);
                        log.Info("login " + user.Id);
                        return Json(nas);//RedirectToLocal(string.IsNullOrEmpty(returnUrl) ? "~/" + Cultures.GetLanguage() + "/Home/Index" : returnUrl);
                    //return RedirectToLocal(string.IsNullOrEmpty(returnUrl) ? "~/" + Cultures.GetLanguage() + "/Account/Personal" : returnUrl);
                    case SignInStatus.LockedOut:
                        nas.statusCode = 201;
                        nas.statusMessage = "Пользователь заблокирован";
                        return Json(nas);
                    case SignInStatus.RequiresVerification:

                        var res = SignInManager.SendTwoFactorCode("Код по электронной почте");
                        nas.statusCode = 200;
                        nas.statusMessage = "Нужна верификация";
                        return Json(nas);
                    case SignInStatus.Failure:
                        nas.statusCode = 201;
                        nas.statusMessage = "Неверный логин или пароль";
                        return Json(nas);
                    default:
                        nas.statusCode = 201;
                        nas.statusMessage = "Неверный логин или пароль";
                        return Json(nas);
                }
            }
            else
            {
                nas.statusCode = 200;
                string usr = User.Identity.GetUserId();
                //nas.user = "\"user\": {\"firstName\": " + customer_email + ", \"id\": " + System.Web.HttpContext.Current.User + ",\"lastName\": " + customer_email + "}";
                nas.user.firstName = customer_email;
                nas.user.lastName = customer_email;
                nas.user.Roles = "[" + "]";
                nas.user.role_id = 0;
                nas.statusMessage = "OK";
                return Json(nas);
                //return RedirectToAction("Personal");
            }
        }
        /*
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login0(LoginViewModel model, string returnUrl)
        {
            var isAuth = (System.Web.HttpContext.Current.User != null) && System.Web.HttpContext.Current.User.Identity.IsAuthenticated;

            if (!isAuth)
            {
                if (!ModelState.IsValid)
                {
                    return View(model);
                }

                var user = await UserManager.FindByNameAsync(model.Email);

                if (user != null)
                {
                    if (!await UserManager.IsEmailConfirmedAsync(user.Id))
                    {
                        ViewBag.Message = "Вы не можете войти в свой личный кабинет, так как Вы не завершили процесс регистрации. Вам необходимо войти в авторизационное письмо, отправленное на указанный Вами адрес электронной почты и нажать на ссылку, помещенную в данном письме.";
                        return View("Error");
                    }
                }

                // This doesn't count login failures towards account lockout
                // To enable password failures to trigger account lockout, change to shouldLockout: true
                var result = await SignInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, shouldLockout: false);
                Session["Token"] = "0";
                switch (result)
                {
                    case SignInStatus.Success:
                        return RedirectToLocal(string.IsNullOrEmpty(returnUrl) ? "~/" + Cultures.GetLanguage() + "/Home/Index" : returnUrl);
                    //return RedirectToLocal(string.IsNullOrEmpty(returnUrl) ? "~/" + Cultures.GetLanguage() + "/Account/Personal" : returnUrl);
                    case SignInStatus.LockedOut:
                        return View("Lockout");
                    case SignInStatus.RequiresVerification:
                        return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, model.RememberMe });
                    case SignInStatus.Failure:
                        ModelState.AddModelError("", "Неверный логин или пароль.");
                        return View(model);
                    default:
                        ModelState.AddModelError("", "Неверный логин или пароль.");
                        return View(model);
                }
            }
            else
            {
                return RedirectToAction("Index", "Home");
                //return RedirectToAction("Personal");
            }
        }
        
        [HttpPost]
        [Authorize(Users = "admin@alsy.by, admin_test@nitec.kz")]
        public ActionResult SetVal(string area)
        {
            var view = area;
            string query = $@"UPDATE ""AspNetUserClaims"" SET ""ClaimValue"" = 4  WHERE ""UserId"" = '{area}' AND ""ClaimType"" = 'user_role';";
            Provider.RunNonQuery(query);
            //int id = SelPage(area);
            return RedirectToAction("Validate", "Account");
        }

        public ActionResult Lights()
        {
            //var viewModel = new RegisterViewModel();conditions_list
            string query = "SELECT t1.*, t2.condition_name FROM conditions_lights t1 LEFT JOIN conditions_list t2 ON t1.condition_id = t2.condition_list_id WHERE user_id ='" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);

            var ligths = new List<Light>();
            if (reader != null)
                while (reader.Read())
                {
                    var rep = new Light
                    {
                        Id = (int)reader["condition_light_id"],
                        //ReportNumber = reader["rep_number"].ToString()
                    };
                    //rep.ReportPeriodName = $"{rep.BeginDate:MMMM}";
                    //rep.AgreementDate = GetDateTimeFromString(reader["post_time"].ToString());
                    rep.name = reader["condition_name"].ToString();
                    rep.color = reader["condition_color"].ToString();
                    rep.logic = reader["condition_logical"].ToString();
                    rep.value = reader["condition_value"].ToString();
                    rep.dest = reader["condition_dest"].ToString();
                    rep.is_active = (int)reader["condition_status"] != 0;
                    ligths.Add(rep);
                }
            reader.Close();
            ViewBag.Count = GetCount();
            ViewBag.Lights = ligths;
            return View();
        }
        [HttpPost]
        public ActionResult Lights(Light model)
        {
            var user = User.Identity.GetUserId();

            var query = $"INSERT INTO conditions_lights (condition_color, condition_logical, condition_id, condition_value, condition_dest, condition_status, user_id) VALUES ('{model.color}', '{model.logic}', '{model.condition}', '{model.value}', '{model.dest}', '{Convert.ToInt16(model.is_active)}', '{user}');";
            var ts = Provider.RunNonQuery(query);
            if (ts < 0)
            {
                ViewBag.Message = "Условия уже есть";
                return View("Error");
            }
            else return RedirectToAction("Lights");
        }


        public JsonResult deLight(string id)
        {
            var query = @"DELETE FROM conditions_lights WHERE condition_light_id = " + id + ";";
            var result = "OK";
            try
            {
                Provider.RunNonQuery(query);
            }
            catch (Exception ex)
            {
                result = "Error" + ex;
            }
            return Json(result);
        }

        public ActionResult Validate()
        {
            var model = new PersonalViewModel();
            lock (Provider.Locker)
            {
                string query = $@"SELECT t1.*, t2.""ClaimType"", t3.org_name
                FROM  public.persons t1
                LEFT JOIN  public.""AspNetUserClaims"" t2 on t1.user_id = t2.""UserId""
                LEFT JOIN organizations t3 on t1.org_id=t3.org_id
                where t2.""ClaimType""='user_role' and t2.""ClaimValue"" ='-4';";
                IDataReader reader = Provider.RunQuery(query);

                var selListMsg = new List<SubjectAddress> { new SubjectAddress { Address = "", Geocode = "" } };

                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var user = reader["given_name"].ToString() + " " + reader["last_name"].ToString() + " " + reader["org_name"].ToString();
                        selListMsg.Add(new SubjectAddress { Address = user, Geocode = reader["user_id"].ToString() });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    model.Addresses = selListMsg;
                }
            }
            ViewBag.Count = GetCount();
            return View(model);
        }

        public ActionResult Company(string comp_id)
        {
            var role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);
            if (role == -4)
            {
                ViewBag.Message = "Вы не являетесь авторизованным участником площадки. Вам будут доступны действия только после подтверждения вашего статуса.";
                return View("Error");
            }
            string query = "";
            if (comp_id == null || comp_id == "")
            {
                query = "SELECT t2.* FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + User.Identity.GetUserId() + "';";
                ViewBag.Visitor = 0;
            }
            else { query = "SELECT * FROM organizations WHERE org_id = '" + comp_id + "';";
                ViewBag.Visitor = 1;
            }
            var reader = Provider.RunQuery(query);
            var model = new RegisterViewModel { Agree = true };
            if (reader != null) {
                while (reader.Read())
                {
                    model.Bin = reader["org_code"].ToString();
                    model.Surname = reader["org_name"].ToString();
                    model.GivenName = reader["org_type"].ToString();
                    model.Address = reader["org_address"].ToString();
                    model.Phone = reader["org_phone"].ToString();
                    model.Gender = reader["org_id"].ToString();
                }
                reader.Close();
            }
            query = "SELECT id FROM docimages WHERE doc_guid='logo' and doc_widget_id ='" + model.Gender + "' ORDER BY id DESC LIMIT 1;";
            ViewBag.logo = Provider.RunScalar(query);

            query = $"SELECT * FROM persons WHERE org_id = '{model.Gender}';";
            reader = Provider.RunQuery(query);
            var reports = new List<RegisterViewModel>();
            if (reader != null) {
                while (reader.Read())
                {
                    var rep = new RegisterViewModel
                    {
                        Agree = true,
                    };
                    rep.PesonId = reader["person_id"].ToString();
                    rep.GivenName = reader["given_name"].ToString();
                    rep.Surname = reader["last_name"].ToString();
                    rep.MiddleName = reader["middle_name"].ToString();
                    rep.PersonCode = reader["person_code"].ToString();
                    rep.Phone = reader["phone"].ToString();
                    rep.Gender = reader["gender"].ToString();
                    reports.Add(rep);
                }
                reader.Close();
            }
            ViewBag.Works = reports;
            return View(model);
        }

        public ActionResult Org()
        {
            var user = User.Identity.GetUserId(); //User.Identity.Name
            string query = "SELECT t2.* FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var reader = Provider.RunQuery(query);
            var model = new RegisterViewModel { Agree = true };
            if (reader != null)
            {
                while (reader.Read())
                {
                    model.Bin = reader["org_code"].ToString();
                    model.FirmName = reader["org_name"].ToString();
                    model.GivenName = reader["org_type"].ToString();
                    model.Address = reader["org_address"].ToString();
                    model.FirmPhone = reader["org_phone"].ToString();
                    model.Gender = reader["org_id"].ToString();
                }
                reader.Close();
            }
            query = "SELECT id FROM docimages WHERE doc_guid='logo' and doc_widget_id ='" + model.Gender + "' ORDER BY id DESC LIMIT 1;";
            ViewBag.logo = Provider.RunScalar(query);
            return View(model);
        }

        [HttpPost]
        public ActionResult Org(RegisterViewModel model)
        {
            var user = User.Identity.GetUserId();
            ViewBag.Count = GetCount();
            //var model = new RegisterViewModel { Agree = true };
            string query = $"UPDATE organizations SET org_code='{model.Bin}', org_name='{model.FirmName}', " +
                $"org_address='{model.Address}', org_phone='{model.FirmPhone}' WHERE org_id ='{model.Gender}';";
            var result = Provider.RunNonQuery(query);
            return RedirectToAction("Company", "Account");
        }

        public ActionResult Person()
        {
            var user = User.Identity.GetUserId(); //User.Identity.Name
            ViewBag.Count = GetCount();
            var model = new RegisterViewModel { Agree = true };
            string query = "SELECT * FROM persons WHERE user_id ='" + user + "';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    model.PersonCode = reader["person_code"].ToString();
                    model.Surname = reader["last_name"].ToString();
                    model.GivenName = reader["given_name"].ToString();
                    model.MiddleName = reader["middle_name"].ToString();
                    model.Phone = reader["phone"].ToString();
                    model.Faceb = reader["faceb"].ToString();
                    model.Instag = reader["instag"].ToString();
                    model.Skype = reader["skype"].ToString();
                }
                model.FullName = user;
                reader.Close();

                query = "SELECT id FROM docimages WHERE doc_guid='logo' and doc_widget_id ='" + User.Identity.Name + "' ORDER BY id DESC LIMIT 1;";
                ViewBag.logo = Provider.RunScalar(query);
                return View(model);
            }
            else return View();
        }
        */
        [HttpPost]
        public string Save(person model)
        {
            var user = User.Identity.GetUserId();
            ViewBag.Count = GetCount();
            string dt = GetDateTimeFromString(model.date_of_birth).ToString("yyyy.MM.dd");

            string query = $"UPDATE persons SET person_code='{model.person_code}', last_name='{model.last_name}', " +
                $"given_name='{model.given_name}', middle_name='{model.middle_name}', country='{model.country}', " +
                $"date_of_birth='{dt}', post_address='{model.post_address}', " +
                $"gender='{model.gender}', position='{model.position}', image_id={model.image_id} WHERE user_id ='{user}' RETURNING person_id;";
            var pid = Provider.RunScalar(query);
            query = $"UPDATE persons_emails SET person_email='{model.person_email}' WHERE person_id={pid} RETURNING person_email_id";
            int eid = Provider.RunScalar(query);
            query = $"INSERT INTO persons_emails (person_id, person_email) VALUES ({pid}, '{model.person_email}');";
            if (eid < 0) Provider.RunNonQuery(query);
            if (!string.IsNullOrEmpty(Provider.lastError))
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.ChangeUserProfile}', '{LogAccount.ChangeUserProfile}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            query = $"UPDATE persons_phones SET person_phone_number='{model.person_phone_number}' WHERE person_id={pid} RETURNING person_phone_id";
            int hid = Provider.RunScalar(query);
            query = $"INSERT INTO persons_phones (person_phone_number, person_id) VALUES ('{model.person_phone_number}', {pid});";
            if (hid < 0) Provider.RunNonQuery(query);
            if (!string.IsNullOrEmpty(Provider.lastError))
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.ChangeUserProfile}', '{LogAccount.ChangeUserProfile}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            log.Info("change user profile " + user + JsonConvert.SerializeObject(model));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeUserProfile}', '{LogAccount.ChangeUserProfile}', '{LogSection.Account}', '{user}', '0');";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string save_organization(comp model)
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            string dt = GetDateTimeFromString(model.org_reg_date).ToString("yyyy.MM.dd");
            string dt1 = GetDateTimeFromString(model.org_reregdate).ToString("yyyy.MM.dd");
            string dt2 = GetDateTimeFromString(model.company_ceo_date).ToString("yyyy.MM.dd");
            int tp = 9; int.TryParse(model.org_type, out tp); if (tp < 9) tp = 9;
            query = $"UPDATE organizations SET(org_name,country, org_code,org_custom_code,org_type,org_oked,organization_kpveds,company_contacts,org_reg_date," +
                $"org_reregdate,company_status, org_residency, company_filials,company_ceo,company_ceo_date,company_website,org_is_broker,org_is_carrier," +
                $"org_is_bank, org_is_insurer, secondary_oked, company_founder)=('{model.org_name}'," +
                $"'{model.country}','{model.org_code}','{model.org_custom_code}',{tp},'{model.org_oked}', '{model.organization_kpveds}'," +
                $"'{model.company_contacts}','{dt}','{dt1}','{model.company_status}', '{model.org_residency}'," +
                $"'{model.company_filials}','{model.company_ceo}','{dt2}','{model.company_website}', {model.org_is_broker}, {model.org_is_carrier}, {model.org_is_bank}," +
                $"'{model.org_is_insurer}','{model.secondary_oked}', '{model.company_founder}') WHERE org_id={oid} RETURNING org_id;";
            Provider.RunNonQuery(query);
            if (!string.IsNullOrEmpty(Provider.lastError))
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.ChangeOrganizationDetails}', '{LogAccount.ChangeOrganizationDetails}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            log.Info("change organization details " + user + JsonConvert.SerializeObject(model));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeOrganizationDetails}', '{LogAccount.ChangeOrganizationDetails}', '{LogSection.Account}', '{user}');";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string save_socials(social model)
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            query = $"UPDATE organization_networks SET (skype,linkedin,fb,instagram,vk,wechat)= ('{model.skype}','{model.linkedin}','{model.fb}','{model.instagram}','{model.vk}','{model.wechat}') WHERE org_id='{oid}' RETURNING org_networks_id;";
            int? nid = Provider.RunScalar(query);
            query = $"INSERT INTO organization_networks (skype,linkedin,fb,instagram,vk,wechat, org_id) VALUES ('{model.skype}','{model.linkedin}','{model.fb}','{model.instagram}','{model.vk}','{model.wechat}', {oid}) RETURNING org_networks_id;";
            if (nid < 0) Provider.RunNonQuery(query);
            if (!string.IsNullOrEmpty(Provider.lastError))
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.ChangeSocialNetworks}', '{LogAccount.ChangeSocialNetworks}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            log.Info("change social networks " + user + JsonConvert.SerializeObject(model));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeSocialNetworks}', '{LogAccount.ChangeSocialNetworks}', '{LogSection.Account}', '{user}');";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string save_socials_personal(social model)
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT person_id FROM persons WHERE user_id ='" + user + "';";
            int pid = Provider.RunScalar(query);
            query = $"UPDATE person_networks SET (skype,linkedin,fb,instagram,vk,wechat)= ('{model.skype}','{model.linkedin}','{model.fb}','{model.instagram}','{model.vk}','{model.wechat}') WHERE person_id='{pid}' RETURNING person_networks_id;";
            int? nid = Provider.RunScalar(query);
            query = $"INSERT INTO person_networks (skype,linkedin,fb,instagram,vk,wechat, person_id) VALUES ('{model.skype}','{model.linkedin}','{model.fb}','{model.instagram}','{model.vk}','{model.wechat}', {pid}) RETURNING person_networks_id;";
            if (nid < 0) Provider.RunNonQuery(query);
            if (!string.IsNullOrEmpty(Provider.lastError))
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.ChangeUserDetails}', '{LogAccount.ChangeUserDetails}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            log.Info("change user details " + user + JsonConvert.SerializeObject(model));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeUserDetails}', '{LogAccount.ChangeUserDetails}', '{LogSection.Account}', '{user}');";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        //[AllowAnonymous]
        public string save_banks(string[] subj_bank, string[] subj_bank_acc_number, string[] subj_bank_acc_curr, string[] subj_bank_acc_status)
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            query = $"DELETE FROM subj_bank_accounts WHERE org_id='{oid}'";
            Provider.RunNonQuery(query);
            int ln = subj_bank.Length;
            for (int i = 0; i < ln; i++)
            {
                string aa = "", bb = "", cc = "";
                try { aa = subj_bank_acc_number[i]; }
                catch (Exception) { }
                try { bb = subj_bank_acc_curr[i]; }
                catch (Exception) { }
                try { cc = subj_bank_acc_status[i].Trim(); }
                catch (Exception) { }
                if (cc.Equals("true")) cc = "1"; else cc = "0";
                query = $"INSERT INTO subj_bank_accounts (org_id, subj_bank_name,subj_bank_acc_number,subj_bank_acc_curr,subj_bank_acc_status) VALUES ({oid},'{subj_bank[i]}','{aa}','{bb}',{cc});";
                Provider.RunNonQuery(query);
                if (!string.IsNullOrEmpty(Provider.lastError))
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeBank}', '{LogAccount.ChangeBank}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
            }
            log.Info("change bank details " + user + subj_bank + subj_bank_acc_number);
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeBank}', '{LogAccount.ChangeBank}', '{LogSection.Account}', '{user}');";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        //[AllowAnonymous]
        public string save_founders(string[] org_founders_person_name, string[] org_founders_company, string[] org_founders_country, string[] org_founders_share)
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            int ln = org_founders_person_name.Length;
            if (oid > 0)
            {
                query = $"DELETE FROM organizations_founders where org_id = '{oid}'";
                Provider.RunNonQuery(query);
            }
            for (int i = 0; i < ln; i++)
            {
                string aa = "", bb = "", cc = "";
                try { aa = org_founders_company[i]; }
                catch (Exception) { }
                try { bb = org_founders_country[i]; }
                catch (Exception) { }
                try { cc = org_founders_share[i].Trim(); }
                catch (Exception) { }
                query = $"INSERT INTO organizations_founders (org_id, org_founders_person_name,org_founders_company,org_founders_country,org_founders_share) VALUES ({oid},'{org_founders_person_name[i]}','{aa}','{bb}',{cc});";
                int? bid = Provider.RunScalar(query);
                if (!string.IsNullOrEmpty(Provider.lastError))
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeFounders}', '{LogAccount.ChangeFounders}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
            }
            log.Info("change founders " + user + org_founders_company + org_founders_country + org_founders_share);
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeFounders}', '{LogAccount.ChangeFounders}', '{LogSection.Account}', '{user}');";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        public string save_addresses(string[] subj_post_addr_type, string[] post_addr_index, string[] post_addr_country,
            string[] post_addr_region, string[] post_addr_district, string[] post_addr_town, string[] post_addr_city,
            string[] post_addr_streethouse, string[] post_addr_house, string[] post_addr_room, string[] post_addr_comm_kind,
            string[] post_addr_comm_number)
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            query = $"DELETE FROM subj_post_addresses WHERE org_id='{oid}'";
            Provider.RunNonQuery(query);
            int ln = 0; try { ln = subj_post_addr_type.Length; } catch (Exception) { }

            for (int i = 0; i < ln; i++)
            {
                string aa = "", bb = "", cc = "", dd = "", ee = "", ff = "", gg = "", ii = "", hh = "", jj = "", kk = "";
                try { aa = post_addr_index[i]; }
                catch (Exception) { }
                try { bb = post_addr_country[i]; }
                catch (Exception) { }
                try { cc = post_addr_region[i]; }
                catch (Exception) { }
                try { dd = post_addr_district[i]; }
                catch (Exception) { }
                try { ee = post_addr_town[i]; }
                catch (Exception) { }
                try { ff = post_addr_city[i]; }
                catch (Exception) { }
                try { gg = post_addr_streethouse[i]; }
                catch (Exception) { }
                try { ii = post_addr_house[i]; }
                catch (Exception) { }
                try { hh = post_addr_room[i]; }
                catch (Exception) { }
                try { jj = post_addr_comm_kind[i]; }
                catch (Exception) { }
                try { kk = post_addr_comm_number[i]; }
                catch (Exception) { }
                query = $"INSERT INTO subj_post_addresses (org_id,subj_post_addr_type,post_addr_index,post_addr_country," +
                    $" post_addr_region,post_addr_district,post_addr_town,post_addr_city,post_addr_streethouse,post_addr_house," +
                    $"post_addr_room,post_addr_comm_kind,post_addr_comm_number) VALUES ({oid},'{subj_post_addr_type[i]}','{aa}','{bb}','{cc}'," +
                    $"'{dd}', '{ee}', '{ff}', '{gg}','{hh}', '{ii}', '{jj}', '{kk}');";
                int? bid = Provider.RunScalar(query);
                if (!string.IsNullOrEmpty(Provider.lastError))
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeAddress}', '{LogAccount.ChangeAddress}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
            }
            log.Info("change address details " + user + post_addr_city + post_addr_comm_kind + post_addr_comm_number + post_addr_country);
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.ChangeAddress}', '{LogAccount.ChangeAddress}', '{LogSection.Account}', '{user}');";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string savePassword(string old_password, string new_password, string token)
        {
            var result = UserManager.ChangePassword(User.Identity.GetUserId(), old_password, new_password);

            if (result.Succeeded)
            {
                var user = UserManager.FindById(User.Identity.GetUserId());
                if (user != null)
                {
                    SignInManager.SignIn(user, true, true);
                }
                string query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.PasswordChange}', '{LogAccount.PasswordChange}', '{LogSection.Account}', '{user.Id}', '0');";
                Provider.RunNonQuery(query);
                log.Info("change user password " + user);
                return "{\"status\":\"ok\"}";
            }
            return "{\"status\":\"" + result.Errors.FirstOrDefault() + "\"}";
        }

        public string load_socials()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.* FROM persons t1 LEFT JOIN organization_networks t2 ON t1.org_id=t2.org_id WHERE t1.user_id ='" + user + "' LIMIT 1;";
            var list = new social();
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.skype = reader["skype"].ToString();
                    list.linkedin = reader["linkedin"].ToString();
                    list.fb = reader["fb"].ToString();
                    list.instagram = reader["instagram"].ToString();
                    list.vk = reader["vk"].ToString();
                    list.wechat = reader["wechat"].ToString();
                }
                reader.Close();
                return JsonConvert.SerializeObject(list);
            }
            return "[]";
        }

        public string load_socials_personal()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.* FROM persons t1 LEFT JOIN person_networks t2 ON t1.person_id=t2.person_id WHERE t1.user_id ='" + user + "' LIMIT 1;";

            var list = new social();
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.skype = reader["skype"].ToString();
                    list.linkedin = reader["linkedin"].ToString();
                    list.fb = reader["fb"].ToString();
                    list.instagram = reader["instagram"].ToString();
                    list.vk = reader["vk"].ToString();
                    list.wechat = reader["wechat"].ToString();
                }
                reader.Close();
                return JsonConvert.SerializeObject(list);
            }
            return "[]";
        }

        public string load_banks()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.* FROM persons t1 LEFT JOIN subj_bank_accounts t2 ON t1.org_id=t2.org_id WHERE t1.user_id ='" + user + "';";
            var bnk = new List<BankModel>();
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new BankModel
                    {
                        subj_bank = reader1["subj_bank_name"].ToString(),
                    };
                    rep1.subj_bank_acc_number = reader1["subj_bank_acc_number"].ToString();
                    rep1.subj_bank_acc_curr = reader1["subj_bank_acc_curr"].ToString();
                    rep1.subj_bank_acc_status = reader1["subj_bank_acc_status"].ToString();
                    bnk.Add(rep1);
                }
                reader1.Close();
                return JsonConvert.SerializeObject(bnk);
            }
            return "[]";
        }

        public string load_addresses()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.* FROM persons t1 LEFT JOIN subj_post_addresses t2 ON t1.org_id=t2.org_id WHERE t1.user_id ='" + user + "';";
            var adr = new List<OrgAdress>();
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new OrgAdress
                    {
                        subj_post_addr_type = reader1["subj_post_addr_type"].ToString(),
                    };
                    rep1.subj_post_addr_type = reader1["subj_post_addr_type"].ToString();
                    rep1.post_addr_index = reader1["post_addr_index"].ToString();
                    rep1.post_addr_country = reader1["post_addr_country"].ToString();
                    rep1.post_addr_region = reader1["post_addr_region"].ToString();
                    rep1.post_addr_district = reader1["post_addr_district"].ToString();
                    rep1.post_addr_town = reader1["post_addr_town"].ToString();
                    rep1.post_addr_city = reader1["post_addr_city"].ToString();
                    rep1.post_addr_streethouse = reader1["post_addr_streethouse"].ToString();
                    rep1.post_addr_house = reader1["post_addr_house"].ToString();
                    rep1.post_addr_room = reader1["post_addr_room"].ToString();
                    rep1.post_addr_comm_kind = reader1["post_addr_comm_kind"].ToString();
                    rep1.post_addr_comm_number = reader1["post_addr_comm_number"].ToString();
                    adr.Add(rep1);
                }
                reader1.Close();
                return JsonConvert.SerializeObject(adr);
            }
            return "[]";
        }
        public string load_founders()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.* FROM persons t1 LEFT JOIN organizations_founders t2 ON t1.org_id=t2.org_id WHERE t1.user_id ='" + user + "';";
            var fnd = new List<Founders>();
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new Founders
                    {
                        org_founders_person_name = reader1["org_founders_person_name"].ToString(),
                    };
                    rep1.org_founders_company = reader1["org_founders_company"].ToString();
                    rep1.org_founders_country = reader1["org_founders_country"].ToString();
                    rep1.org_founders_share = reader1["org_founders_share"].ToString();
                    fnd.Add(rep1);
                }
                reader1.Close();
                return JsonConvert.SerializeObject(fnd);
            }
            return "[]";
        }

        [AllowAnonymous]
        public async Task<ActionResult> VerifyCode(string provider, string returnUrl, bool rememberMe)
        {
            // Require that the user has already logged in via username/password or external login
            if (!await SignInManager.HasBeenVerifiedAsync())
            {
                return View("Error");
            }
            return View(new VerifyCodeViewModel { Provider = provider, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // The following code protects for brute force attacks against the two factor codes. 
            // If a user enters incorrect codes for a specified amount of time then the user account 
            // will be locked out for a specified amount of time. 
            // You can configure the account lockout settings in IdentityConfig
            var result = await SignInManager.TwoFactorSignInAsync(model.Provider, model.Code, isPersistent: model.RememberMe, rememberBrowser: model.RememberBrowser);
            switch (result)
            {
                case SignInStatus.Success:
                    //return RedirectToAction("Personal", "Account");
                    return RedirectToAction("Index", "Home");
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.Failure:
                    ModelState.AddModelError("", "Invalid code.");
                    return View(model);
                default:
                    ModelState.AddModelError("", "Invalid code.");
                    return View(model);
            }
        }

        //generates token for user
        public string GenerateToken(string doc_id)
        {
            //return "ok"; //used for testing
            var user = UserManager.FindById(User.Identity.GetUserId());

            byte[] _time = BitConverter.GetBytes(DateTime.UtcNow.ToBinary());
            byte[] _key = Guid.Parse(user.SecurityStamp).ToByteArray();
            byte[] _Id = GetBytes(user.Id.ToString());
            //byte[] _reason = GetBytes(reason);
            //byte[] data = new byte[_time.Length + _key.Length + _reason.Length + _Id.Length];
            byte[] data = new byte[_time.Length + _Id.Length];

            System.Buffer.BlockCopy(_time, 0, data, 0, _time.Length);
            System.Buffer.BlockCopy(_Id, 0, data, _time.Length, _Id.Length);
            //System.Buffer.BlockCopy(_key, 0, data, _time.Length, _key.Length);
            //System.Buffer.BlockCopy(_reason, 0, data, _time.Length + _key.Length, _reason.Length);
            //System.Buffer.BlockCopy(_Id, 0, data, _time.Length + _key.Length + _reason.Length, _Id.Length);

            var cd = Convert.ToBase64String(data.ToArray());
            var name = "";
            var query = $"SELECT given_name, last_name FROM persons WHERE user_id='{user.Id}'";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    name = reader["given_name"].ToString() + " " + reader["last_name"].ToString();
                }
            }
            reader.Close();

            var host = System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"];
            var port = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]);
            var sender = System.Configuration.ConfigurationManager.AppSettings["EmailSender"];
            var password = System.Configuration.ConfigurationManager.AppSettings["EmailSenderPass"];
            var mlclient = new SmtpClient(host, port);
            mlclient.EnableSsl = false;
            mlclient.UseDefaultCredentials = false;
            mlclient.Credentials = new NetworkCredential(sender, password);
            try
            {
                MailMessage message1 = new MailMessage();
                // Add receiver
                message1.To.Add(user.Email);
                message1.From = new MailAddress(sender);
                message1.Subject = "Ваш секретный код для портала Attis/Your secret code for Attis portal";
                message1.Body = "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>Уважаемый пользователь АТТИС " + name + "</p>" +
                "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>Вы подписываете электронный документ " + doc_id + ".</p>" +
                "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>Для этого Система автоматически сформировала уникальный код " + cd + "</p>" +
                "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>Вам необходимо ввести полученный код в Систему для подтверждения своего согласия с его содержимым. Помните, что, введя данный код в Систему, вы принимаете условия применения электронно-цифровой подписи в документообороте.&nbsp;</p></br></br></br></br>" +
                "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>Dear ATTIS User " + name + "</p>" +
                "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>You are signing an electronic document " + doc_id + ".</p>" +
                "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>For this reason, the System automatically generated the unique code " + cd + "</p>" +
                "<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:'Calibri',sans-serif;'>You need to enter the received code into the System to confirm you are agree with its content. Please, be aware that by entering this code into the System, you accept electronic digital signature terms in the document flow.&nbsp;</p>";
                //message1.Body = "<p>Ваш секретный код для портала Attis: '" + Convert.ToBase64String(data.ToArray()) + "'</p><p> Your secret code for Attis portal: '" + Convert.ToBase64String(data.ToArray()) + "'</p> ";

                message1.IsBodyHtml = true;
                mlclient.Send(message1);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            return "ok";
        }

        public class TokenValidation
        {
            public bool Validated { get { return Errors.Count == 0; } }
            public readonly List<TokenValidationStatus> Errors = new List<TokenValidationStatus>();
        }

        public enum TokenValidationStatus
        {
            Expired,
            WrongUser,
            WrongPurpose,
            WrongGuid
        }

        //validates user token
        public TokenValidation ValidateToken(string token)
        {
            token = token.Trim();
            var user = UserManager.FindById(User.Identity.GetUserId());
            var result = new TokenValidation();
            byte[] data = new byte[] { 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20 };
            byte[] _time = data;
            //byte[] _key = data;
            //byte[] _reason = data;
            byte[] _Id = data;
            try
            {
                data = Convert.FromBase64String(token);
                _time = data.Take(8).ToArray();
                //_key = data.Skip(8).Take(16).ToArray();
                //_reason = data.Skip(24).Take(2).ToArray();
                _Id = data.Skip(8).ToArray();
            }
            catch (Exception) { result.Errors.Add(TokenValidationStatus.WrongGuid); }
            DateTime when = DateTime.FromBinary(BitConverter.ToInt64(_time, 0));
            if (when < DateTime.UtcNow.AddHours(-1))
            {
                result.Errors.Add(TokenValidationStatus.Expired);
            }
            try
            {/*
                Guid gKey = new Guid(_key);
                if (gKey.ToString() != user.SecurityStamp)
                {
                    result.Errors.Add(TokenValidationStatus.WrongGuid);
                }

                if (reason != GetString(_reason))
                {
                    result.Errors.Add(TokenValidationStatus.WrongPurpose);
                }
                */
                if (user.Id.ToString() != GetString(_Id))
                {
                    result.Errors.Add(TokenValidationStatus.WrongUser);
                }
            }
            catch (Exception) { result.Errors.Add(TokenValidationStatus.Expired); }
            return result;
        }
        private static string GetString(byte[] reason) => Encoding.UTF8.GetString(reason);

        private static byte[] GetBytes(string reason) => Encoding.UTF8.GetBytes(reason);

        //encrypt data with key
        public static string EncryptString(string key, string Text)
        {
            byte[] iv = new byte[16];
            byte[] array;
            byte[] ks = Encoding.UTF8.GetBytes(key);

            using (Aes aes = Aes.Create())
            {
                aes.Key = ks.Take(32).ToArray();
                aes.IV = iv;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                        {
                            streamWriter.Write(Text);
                        }

                        array = memoryStream.ToArray();
                    }
                }
            }

            return Convert.ToBase64String(array);
        }

        //deencrypt data with key
        public static string DecryptString(string key, string data)
        {
            key = key.Trim();
            byte[] iv = new byte[16];
            byte[] buffer = Convert.FromBase64String(data);
            byte[] ks = Encoding.UTF8.GetBytes(key);

            using (Aes aes = Aes.Create())
            {
                aes.Key = ks.Take(32).ToArray();
                aes.IV = iv;
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream(buffer))
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                        {
                            return streamReader.ReadToEnd();
                        }
                    }
                }
            }
        }

        [HttpPost]
        public string SignData(string token, string data)
        {
            var check = ValidateToken(token);
            if (check.Validated)
            {
                var user = UserManager.FindById(User.Identity.GetUserId());
                token = user.SecurityStamp;

                return EncryptString(token, data);
                //var res = DecryptString(token, cf);
            }
            return "token invalid";

        }

        public class loginuser
        {
            public string id { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string Roles { get; set; }
            public int role_id { get; set; }
        }
        public class users
        {
            public string user_id { get; set; }
            public string given_name { get; set; }
            public string last_name { get; set; }
            public string middle_name { get; set; }
            public string org_name { get; set; }
            public string org_code { get; set; }
            public string login { get; set; }
            public string email { get; set; }
            public int active { get; set; }
            public string reg_date { get; set; }
            public string lock_date { get; set; }
            public string country { get; set; }
            public int is_accepted { get; set; }
        }
        //get user list
        public string GetUsers()
        {
            var list = new List<users>();
            var query = $"SELECT t1.*, t2.org_name, t2.org_code, t3.\"Email\", t3.\"UserName\", t4.country_name_ru FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id= t2.org_id" +
                $" LEFT JOIN \"AspNetUsers\" t3 ON t1.user_id = t3.\"Id\" LEFT JOIN countries t4 ON t1.country= t4.country_2a_code ORDER BY reg_date ASC;";
            var reader = Provider.RunQuery(query);
            if (reader != null) {
                while (reader.Read())
                {
                    var model = new users
                    {
                        given_name = reader["given_name"].ToString(),
                    };
                    model.user_id = reader["user_id"].ToString();
                    model.last_name = reader["last_name"].ToString();
                    model.middle_name = reader["middle_name"].ToString();
                    model.login = reader["UserName"].ToString();
                    model.email = reader["Email"].ToString();
                    model.org_name = reader["org_name"].ToString();
                    model.org_code = reader["org_code"].ToString();
                    model.reg_date = reader["reg_date"].ToString();
                    model.lock_date = reader["lock_date"].ToString();
                    model.country = reader["country_name_ru"].ToString();
                    model.active = reader.GetFieldValueOrDefault<int>("active");
                    if (model.email != "admin@attistrade.kz")
                        list.Add(model);
                }
                reader.Close();
            }

            return JsonConvert.SerializeObject(list);
        }

        public string GetUnconfirmedUsers()
        {
            var list = new List<users>();
            var query = $"SELECT t1.*, t2.org_name, t2.org_code, t3.\"Email\", t3.\"UserName\", t4.country_name_ru FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id= t2.org_id" +
                $" LEFT JOIN \"AspNetUsers\" t3 ON t1.user_id = t3.\"Id\" LEFT JOIN countries t4 ON t1.country= t4.country_2a_code WHERE \"EmailConfirmed\" = false ORDER BY reg_date ASC;";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var model = new users
                    {
                        given_name = reader["given_name"].ToString(),
                    };
                    model.user_id = reader["user_id"].ToString();
                    model.last_name = reader["last_name"].ToString();
                    model.middle_name = reader["middle_name"].ToString();
                    model.login = reader["UserName"].ToString();
                    model.email = reader["Email"].ToString();
                    model.org_name = reader["org_name"].ToString();
                    model.org_code = reader["org_code"].ToString();
                    model.reg_date = reader["reg_date"].ToString();
                    model.lock_date = reader["lock_date"].ToString();
                    model.country = reader["country_name_ru"].ToString();
                    model.active = reader.GetFieldValueOrDefault<int>("active");
                    model.is_accepted = reader.GetFieldValueOrDefault<int>("accepted");
                    list.Add(model);
                }
                reader.Close();
            }

            return JsonConvert.SerializeObject(list);
        }

        public int CheckBin(string bin)
        {
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id='{User.Identity.GetUserId()}';";
            var cod = Provider.RunQueryStr(query);
            if (cod == bin) return 1;
            else return 0;
        }

        [HttpPost]
        public string LockUser(string user_id)
        {
            string query = $"UPDATE persons set active=0, lock_date=now() WHERE user_id='{user_id}'";
            Provider.RunNonQuery(query);
            if (!string.IsNullOrEmpty(Provider.lastError))
                return Provider.lastError;
            return "ok";
        }

        [HttpPost]
        public string UnlockUser(string user_id)
        {
            string query = $"UPDATE persons set active=1, lock_date=null WHERE user_id='{user_id}'";
            Provider.RunNonQuery(query);
            if (!string.IsNullOrEmpty(Provider.lastError))
                return Provider.lastError;
            return "ok";
        }

        public string GetLogs()
        {
            var list = new List<logs>();
            var query = $"SELECT t1.log_id, t1.log_data, t1.log_date, t1. is_error, t1.log_text, t1.log_target_user_id, t1.doc_id, t2.given_name as name1, " +
                $"t2.last_name as lname1, t3.org_name as onm1 FROM attis_logs t1 LEFT JOIN persons t2 ON " +
                $"t2.user_id= t1.log_source_user_id LEFT JOIN organizations t3 ON t2.org_id= t3.org_id ORDER BY log_id DESC;";
            //$"LEFT JOIN persons t4 ON t4.user_id= t1.log_target_user_id LEFT JOIN organizations t5 ON t5.org_id= t5.org_id ORDER BY log_date DESC;";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var model = new logs
                    {
                        id = reader["log_id"].ToString(),
                    };
                    model.oper_code = reader["log_text"].ToString();
                    model.log_source_user_id = reader["name1"].ToString() + " " + reader["lname1"].ToString() + " " + reader["onm1"].ToString();
                    model.log_target_user_id = "";
                    //if (!String.IsNullOrEmpty(reader["log_target_user_id"].ToString()))
                    //model.log_target_user_id = reader["name2"].ToString() + " " + reader["lname2"].ToString() + " " + reader["onm2"].ToString();
                    model.doc_id = reader["doc_id"].ToString();
                    model.log_data = reader["log_data"].ToString();
                    model.log_date = reader["log_date"].ToString();
                    model.is_error = reader.GetFieldValueOrDefault<int>("is_error");

                    list.Add(model);
                }
                reader.Close();
            }
            //log_source_user_id, log_target_user_id - показать ФИО + наименование компании
            return JsonConvert.SerializeObject(list);
        }

        public class logs
        {
            public string log_data { get; set; }
            public string log_date { get; set; }
            public int is_error { get; set; }
            public string oper_code { get; set; }
            public string log_source_user_id { get; set; }
            public string log_target_user_id { get; set; }
            public string doc_id { get; set; }
            //public string date_of_birth { get; set; }
            public string id { get; set; }
        }

        /*
        public ActionResult _UserMenu(PersonalViewModel model)
        {
            var query = $"SELECT * FROM persons WHERE user_id ='{User.Identity.GetUserId()}';";
            var reader = Provider.RunQuery(query);
            if (reader != null) {
                while (reader.Read())
                {
                    model.Name = reader["given_name"].ToString();
                    model.Surname = reader["last_name"].ToString();
                    model.Middlename = reader["middle_name"].ToString();
                    //model.Name_KZ = reader["given_name_kz"].ToString();
                    //model.Surname_KZ = reader["last_name_kz"].ToString();
                    //model.Middlename_KZ = reader["middle_name_kz"].ToString();
                    //model.Country = reader["country"].ToString();
                    //model.Address = reader["post_address"].ToString();
                    //model.Phone = reader["phone"].ToString();
                    //model.Region = reader["org_name"].ToString();
                    //model.PersonalCode = reader["person_code"].ToString();
                    //model.Birthday = GetDateTimeFromString(reader["date_of_birth"].ToString());
                    //model.DocGuid = reader["doc_guid"].ToString();
                    model.Gender = reader["gender"].ToString();
                    model.UserID = reader["user_id"].ToString();
                }
                reader.Close();
            }
            if (model.Gender == "1") model.Gender = "Фактор";
            else if (model.Gender == "2") model.Gender = "Кредитор";
            else if (model.Gender == "3") model.Gender = "Дебитор";
            ViewBag.Count = GetCount();
            return PartialView(model);
        }

        [AllowAnonymous]
        public ActionResult Register()
        {
            var viewModel = new RegisterViewModel();
            return View(viewModel);
        }

        public ActionResult RegisterLawyer()
        {
            lock (Provider.Locker)
            {
                var claim = (User.Identity as ClaimsIdentity).Claims.First(c => c.Type == "user_role").Value;

                if (claim == "63")
                {
                    var viewModel = new RegisterViewModel();

                    // Get Collegiums list from DB
                    const string query = @"SELECT * FROM public.law_collegiums;";
                    var reader = Provider.RunQuery(query);
                    var selListCollegiums = new List<SelectListItem> { new SelectListItem { Text = "", Value = "" } };

                    while (reader.Read())
                    {
                        selListCollegiums.Add(new SelectListItem { Text = reader["law_collegium_name_ru"].ToString(), Value = reader["law_collegium_id"].ToString() });
                    }
                    reader.Close();

                    viewModel.Collegiums = selListCollegiums;

                    try
                    {
                        ViewBag.Message = TempData["Message"] != null ? TempData["Message"].ToString() : null;
                    }
                    catch (NullReferenceException)
                    {
                        ViewBag.Message = null;
                    }

                    return View(viewModel);
                }

                ViewBag.Message = "У вас не хватает прав";
                return View("Error");
            }

        }
        */
        public class RegUser
        {
            public string customer_id { get; set; }
            public string customer_last_name { get; set; }
            public string customer_first_name { get; set; }
            public string customer_middlename { get; set; }
            public string customer_email { get; set; }
            public string customer_password { get; set; }
            public DateTime customer_birthdate { get; set; }
            public string customer_address { get; set; }
            public string customer_position { get; set; }
            public string customer_phone { get; set; }
            public string customer_gender { get; set; }
            public string company_id { get; set; }
            public string company_title { get; set; }
            public DateTime? company_regdate { get; set; }
            public string company_status { get; set; }
            public DateTime? company_reregdate { get; set; }
            public string company_oked { get; set; }
            public string company_contacts { get; set; }
            public string company_region { get; set; }
            public string company_main_sphere { get; set; }
            public string company_additional_sphere { get; set; }
            public string company_filials { get; set; }
            public string company_ceo { get; set; }
            public DateTime? company_ceo_date { get; set; }
            public string company_founder { get; set; }
            public string company_number_of_founders { get; set; }
            public string company_social_networks { get; set; }
            public string company_website { get; set; }
            public string company_address { get; set; }
            public string company_accept { get; set; }

            public string company_residency { get; set; }
            public string secondary_oked { get; set; }

            public string org_residency { get; set; }

        }

        public class UserResp
        {
            public int statusCode { get; set; }
            public string statusMessage { get; set; }
            public UserProp usr { get; set; }
        }


        public class UserProp
        {
            public string firstName { get; set; }
            public string id { get; set; }
            public string lastName { get; set; }
            public string Roles { get; set; }
        }
        /*
        [HttpPost]
        //[AllowAnonymous]
        public JsonResult Register(RegUser rgu, string token)
        {
            statusmsg nas = new statusmsg { statusCode = 419 };
            return Json(nas);
        }
        */
        [HttpPost]
        [AllowAnonymous]
        public JsonResult Register(RegUser rgu, string token)
        {
            //var response = Request["g-recaptcha-response"];
            //const string secretKey = "6LfeKqYUAAAAAGxavxkX63DBojCAjDhNfSUubGV6";
            var client = Session["Token"];
            statusmsg nas = new statusmsg { statusCode = 419 };
            string FullName = rgu.customer_last_name + " " + rgu.customer_last_name;

            string query = $"SELECT person_id FROM persons WHERE person_code ='{rgu.customer_id}';";
            var usr = Provider.RunScalar(query);
            if (usr > 1)
            {
                nas.statusMessage = "iin code already exists";
                return Json(nas);
            }

            query = $"SELECT org_id FROM organizations WHERE org_code ='{rgu.company_id}';";
            var frm = Provider.RunScalar(query);
            if (frm < 0)
            {
                string bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"), dd = DateTime.Now.ToString("yyyy.MM.dd");
                if (rgu.company_regdate != null)
                    bb = rgu.company_regdate?.ToString("yyyy.MM.dd");
                if (rgu.company_reregdate != null)
                    cc = rgu.company_reregdate?.ToString("yyyy.MM.dd");
                if (rgu.company_ceo_date != null)
                    dd = rgu.company_ceo_date?.ToString("yyyy.MM.dd");
                //if (String.IsNullOrEmpty(rgu.company_residency))
                //{
                //    rgu.company_residency = "KZ";
                //}
                query = $"INSERT INTO organizations (org_code, org_name, company_address, company_contacts, company_status, org_reg_date, org_reregdate, org_oked,secondary_oked, company_region, " +
                    $"company_main_sphere, company_additional_sphere, company_filials, company_ceo, company_ceo_date, company_founder, company_number_of_founders, " +
                    $"company_social_networks, company_website, org_residency) " +
                    $"VALUES ('{rgu.company_id}', '{rgu.company_title}', '{rgu.company_address}', '{rgu.company_contacts}', '{rgu.company_status}', '{bb}', '{cc}'," +
                    $" '{rgu.company_oked}','{rgu.secondary_oked}', '{rgu.company_region}', '{rgu.company_main_sphere}', '{rgu.company_additional_sphere}', '{rgu.company_filials}', '{rgu.company_ceo}', '{dd}'," +
                    $" '{rgu.company_founder}', '{rgu.company_number_of_founders}', '{rgu.company_social_networks}', '{rgu.company_website}', '{rgu.org_residency}') RETURNING org_id;";
                frm = Provider.RunScalar(query);
            }

            var user = new ApplicationUser { UserName = rgu.customer_email, Email = rgu.customer_email, PhoneNumber = rgu.customer_phone };
            var result = UserManager.Create(user, rgu.customer_password);

            if (result.Succeeded)
            {
                var guid = Guid.NewGuid().ToString("N");
                string gen = "0";
                if (rgu.customer_gender == "true") gen = "1";

                var results = Provider.RunScalarStoredProcedure("add_user", rgu.customer_id, rgu.customer_last_name, rgu.customer_first_name, rgu.customer_middlename,
                    gen, rgu.customer_birthdate, 0, "KZ", user.Id, FullName, guid, /*namekz*/ rgu.customer_first_name, /*srnamekz*/ rgu.customer_last_name, /*mdkz*/ rgu.customer_middlename);
                //var code = UserManager.GenerateEmailConfirmationToken(user.Id);
                if (!string.IsNullOrEmpty(Provider.lastError))
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogAccount.Register}', '{LogAccount.Register}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    nas.statusMessage = Provider.lastError;
                    return Json(nas);
                }
                //var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code },protocol: Request.Url.Scheme);
                //var body = "</head><body leftmargin=\"0\" marginwidth=\"0\" topmargin=\"0\" marginheight=\"0\" offset=\"0\"><center><table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" id=\"bodyTable\"><tr><td align=\"center\" valign=\"top\" id=\"bodyCell\" stile = \"margin:0; padding:0; border:0; height:auto; line-height:100%; outline:none; text-decoration:none; border-collapse:collapse !important; height:100% !important; margin:0; padding:0; width:100% !important; padding:20px; width:600px; background-color:#DEE0E2; border-top:4px solid #BBBBBB; border:1px solid #BBBBBB;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"templateContainer\"><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templatePreheader\"><tr></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateHeader\"><tr><td valign=\"top\" class=\"headerContent\" style = \"color: #505050; font-family: Helvetica; font-size: 20px; font-weight: bold; line-height: 100%; padding-top: 0; padding-right: 0; padding-bottom: 0; padding-left: 0; text-align: left; vertical-align: middle;\"></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateBody\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><tr><td valign=\"top\" class=\"bodyContent\" mc:edit=\"body_content\"><h1 style = \"color: #202020 !important; display: block; font-family: Helvetica; font-size: 26px; font-style: normal; font-weight: bold; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Уважаемый(ая) " + rgu.customer_first_name + " " + rgu.customer_last_name + "!</h1><h3 style = \"color: #606060 !important; display: block; font-family: Helvetica; font-size: 16px; font-style: italic; font-weight: normal; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Добро пожаловать на портал Attis !</h3><div style = \"color: #505050; font-family: Helvetica; font-size: 14px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\">Все Ваши данные, предоставленные для портала, хранятся в надежных руках: самые современные технологии кодирования и многоступенчатые системы сетевой защиты гарантируют максимальный уровень сохранности.<br /><br />Перед тем как пользоваться услугами нашего портала, необходимо активировать свой аккаунт. Для этого кликните, пожалуйста, по <a href=\"" + callbackUrl + "\">ссылке</a>.  <br> " + " Ссылка будет доступна в течение 48 часов. После этого срока неактивированный аккаунт будет удален. <br /><br />Если у Вас возникнут вопросы, на них с удовольствием ответит наша служба поддержки. E-mail:<a href=\"mailto:support@finplatform.kz\" target=\"_blank\">support@attis.com</a></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateFooter\"></tr><tr style = \"color: #808080; font-family: Helvetica; font-size: 10px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\"><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0;\" mc:edit=\"footer_content01\"><em>Copyright &copy; ТОО \"Attis\", All rights reserved.</em></tr><tr><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0; padding-bottom:40px;\" mc:edit=\"footer_content02\">&nbsp;</td></tr></table></td></tr></table></td></tr></table></center></body></html>";
                var body = "</head><body leftmargin=\"0\" marginwidth=\"0\" topmargin=\"0\" marginheight=\"0\" offset=\"0\"><center><table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" id=\"bodyTable\"><tr><td align=\"center\" valign=\"top\" id=\"bodyCell\" stile = \"margin:0; padding:0; border:0; height:auto; line-height:100%; outline:none; text-decoration:none; border-collapse:collapse !important; height:100% !important; margin:0; padding:0; width:100% !important; padding:20px; width:600px; background-color:#DEE0E2; border-top:4px solid #BBBBBB; border:1px solid #BBBBBB;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"templateContainer\"><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templatePreheader\"><tr></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateHeader\"><tr><td valign=\"top\" class=\"headerContent\" style = \"color: #505050; font-family: Helvetica; font-size: 20px; font-weight: bold; line-height: 100%; padding-top: 0; padding-right: 0; padding-bottom: 0; padding-left: 0; text-align: left; vertical-align: middle;\"></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateBody\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><tr><td valign=\"top\" class=\"bodyContent\" mc:edit=\"body_content\"><h1 style = \"color: #202020 !important; display: block; font-family: Helvetica; font-size: 26px; font-style: normal; font-weight: bold; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Уважаемый(ая) " + rgu.customer_first_name + " " + rgu.customer_last_name + "!</h1><h3 style = \"color: #606060 !important; display: block; font-family: Helvetica; font-size: 16px; font-style: italic; font-weight: normal; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Ваша Заявка на регистрацию будет рассмотрена в ближайшее время.</h3></br>Если у Вас возникнут вопросы, на них с удовольствием ответит наша служба поддержки. E-mail:<a href=\"mailto:support@attis.com\" target=\"_blank\">support@attis.com</a></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateFooter\"></tr><tr style = \"color: #808080; font-family: Helvetica; font-size: 10px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\"><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0;\" mc:edit=\"footer_content01\"><em>Copyright &copy; ТОО \"Attis\", All rights reserved.</em></tr><tr><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0; padding-bottom:40px;\" mc:edit=\"footer_content02\">&nbsp;</td></tr></table></td></tr></table></td></tr></table></center></body></html>";
                int mail = 1;
                UserManager.AddClaim(user.Id, new Claim("user_role", "4"));

                var host = System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"];
                var port = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]);
                var sender = System.Configuration.ConfigurationManager.AppSettings["EmailSender"];
                var password = System.Configuration.ConfigurationManager.AppSettings["EmailSenderPass"];
                var mlclient = new System.Net.Mail.SmtpClient(host, port);
                mlclient.EnableSsl = false;
                mlclient.UseDefaultCredentials = false;
                mlclient.Credentials = new System.Net.NetworkCredential(sender, password);
                try
                {
                    System.Net.Mail.MailMessage message1 = new System.Net.Mail.MailMessage();
                    // Add receiver
                    message1.To.Add(rgu.customer_email);
                    message1.From = new System.Net.Mail.MailAddress(sender);
                    message1.Subject = "Welcome to Attis portal / Добро пожаловать на портал Attis";
                    message1.Body = body;
                    message1.IsBodyHtml = true;
                    mlclient.Send(message1);
                }
                catch (Exception ex) { nas.statusMessage = ex.Message; mail = 0; }

                query = $"UPDATE persons SET org_id = '{frm}', post_address = '{rgu.customer_address}', middle_name='{rgu.customer_middlename}', gender='{rgu.customer_gender}', position='{rgu.customer_position}', country='{rgu.org_residency}' WHERE user_id = '{user.Id}' RETURNING person_id;";
                var personId = Provider.RunScalar(query);
                query = $"INSERT INTO persons_phones (person_id, person_phone_number, person_phone_type) VALUES ('{personId}', '{rgu.customer_phone}', 1)";
                Provider.RunNonQuery(query);
                query = $"UPDATE subjects SET org_code = '{rgu.company_id}' WHERE user_id = '{user.Id}';";
                Provider.RunNonQuery(query);
                if (mail == 0) return Json(nas);
                else {
                    nas.statusCode = 200;
                    nas.statusMessage = "registration successful";
                    nas.user = new loginuser();
                    nas.user.firstName = rgu.customer_email;
                    nas.user.lastName = rgu.customer_last_name;
                    nas.user.id = user.Id;
                    //sends email notification to admin
                    var cp = new ContractController();
                    var eml = new ContractController.eml();
                    eml.email = "admin@attistrade.kz,vr@crossborderxp.com";
                    var adm_msg = System.Configuration.ConfigurationManager.AppSettings["AdminMessage"];
                    //eml.subject = "new Attis user"; //prod
                    eml.subject = adm_msg;
                    eml.message = "user registered with email  " + rgu.customer_email;
                    cp.SendEmail(eml);
                    notify(user.Id, rgu.customer_email); //notify admins
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.Register}', '{LogAccount.Register}', '{LogSection.Account}', '{user.Id}');";
                    log.Info("register " + user);
                    Provider.RunNonQuery(query);
                    return Json(nas);
                }
            }

            nas.statusMessage = string.Join(",", result.Errors.ToArray());
            return Json(nas);
        }

        [AllowAnonymous]
        private void notify(string user, string email)
        {
            var query = "SELECT \"Id\" FROM \"AspNetUsers\" WHERE \"UserName\" = 'admin@attistrade.kz';";
            var adm = Provider.RunQueryStr(query);
            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.NewUser,
                CreatorId = user,
                RecipientId = adm,
                CreationDate = DateTime.Now,
                ObjectId = 0,
                Comment = email
            });

            query = "SELECT \"Id\" FROM \"AspNetUsers\" WHERE \"UserName\" = 'vr@crossborderxp.com';";
            adm = Provider.RunQueryStr(query);
            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.NewUser,
                CreatorId = user,
                RecipientId = adm,
                CreationDate = DateTime.Now,
                ObjectId = 0,
                Comment = email
            });
        }

        public class certs
        {
            public int? cert_exists { get; set; }
            public DateTime? start_date { get; set; }
            public DateTime? end_date { get; set; }
            public string cert { get; set; }
            public string cert_name { get; set; }
            public string cert_bin { get; set; }
        }

        [HttpPost]
        public string setSignature(certs crt)
        {
            string user = User.Identity.GetUserId();
            if (user == "null")
                return "{\"status\":\"error: login first\"}";
            string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd");
            if (crt.start_date != null)
                aa = crt.start_date?.ToString("yyyy.MM.dd");
            if (crt.end_date != null)
                bb = crt.end_date?.ToString("yyyy.MM.dd");

            var query = $"INSERT INTO signatures (user_id, cert, start_date, end_date, cert_bin, cert_name) " +
                $"VALUES('{user}', '{crt.cert}', '{aa}', '{bb}', '{crt.cert_bin}', '{crt.cert_name}') " +
                $"ON CONFLICT(user_id) DO UPDATE SET cert = '{crt.cert}', start_date = '{aa}', end_date = '{bb}', cert_bin='{crt.cert_bin}', cert_name='{crt.cert_name}'";
            Provider.RunNonQuery(query);
            if (Provider.lastError != "")
            {
                var query1 = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogAccount.SetSignature}', '{LogAccount.SetSignature}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query1, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            else
            {
                log.Info("set signature " + user + JsonConvert.SerializeObject(crt));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                        $"VALUES('NOW()', '{(int)LogAccount.SetSignature}', '{LogAccount.SetSignature}', '{LogSection.Account}', '{user}', '', '', '{JsonConvert.SerializeObject(crt)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }

        }

        public string loadSignatureDetails()
        {
            string user = User.Identity.GetUserId();
            var result = new certs();
            result.cert_exists = 0;
            string query = $"SELECT * FROM signatures WHERE user_id='{user}'";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    result.cert = reader["cert"].ToString();
                    if (string.IsNullOrEmpty(result.cert))
                        result.cert_exists = 0;
                    else {
                        result.cert_exists = 1;
                        result.end_date = GetDateTimeFromString(reader["end_date"].ToString());
                        result.start_date = GetDateTimeFromString(reader["start_date"].ToString());
                        result.cert_bin = reader["cert_bin"].ToString();
                        result.cert_name = reader["cert_name"].ToString();
                    }

                }
                reader.Close();
                return JsonConvert.SerializeObject(result);
            }
            else {
                result.cert_exists = 0;
                return JsonConvert.SerializeObject(result);
            }



        }

        [HttpPost]
        public string ActivateUser(string user_id, string name, string last_name, string token)
        {
            var usr = UserManager.FindById(user_id);
            var code = UserManager.GenerateEmailConfirmationToken(user_id);
            var host = System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"];
            var port = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]);
            var sender = System.Configuration.ConfigurationManager.AppSettings["EmailSender"];
            var password = System.Configuration.ConfigurationManager.AppSettings["EmailSenderPass"];
            var mlclient = new System.Net.Mail.SmtpClient(host, port);
            var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user_id, code },
                    protocol: Request.Url.Scheme);
            var body = "</head><body leftmargin=\"0\" marginwidth=\"0\" topmargin=\"0\" marginheight=\"0\" offset=\"0\"><center><table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" id=\"bodyTable\"><tr><td align=\"center\" valign=\"top\" id=\"bodyCell\" stile = \"margin:0; padding:0; border:0; height:auto; line-height:100%; outline:none; text-decoration:none; border-collapse:collapse !important; height:100% !important; margin:0; padding:0; width:100% !important; padding:20px; width:600px; background-color:#DEE0E2; border-top:4px solid #BBBBBB; border:1px solid #BBBBBB;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"templateContainer\"><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templatePreheader\"><tr></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateHeader\"><tr><td valign=\"top\" class=\"headerContent\" style = \"color: #505050; font-family: Helvetica; font-size: 20px; font-weight: bold; line-height: 100%; padding-top: 0; padding-right: 0; padding-bottom: 0; padding-left: 0; text-align: left; vertical-align: middle;\"></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateBody\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><tr><td valign=\"top\" class=\"bodyContent\" mc:edit=\"body_content\"><h1 style = \"color: #202020 !important; display: block; font-family: Helvetica; font-size: 26px; font-style: normal; font-weight: bold; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Уважаемый(ая) " + name + " " + last_name + "!</h1><h3 style = \"color: #606060 !important; display: block; font-family: Helvetica; font-size: 16px; font-style: italic; font-weight: normal; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Добро пожаловать на портал Attis !</h3><div style = \"color: #505050; font-family: Helvetica; font-size: 14px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\">Все Ваши данные, предоставленные для портала, хранятся в надежных руках: самые современные технологии кодирования и многоступенчатые системы сетевой защиты гарантируют максимальный уровень сохранности.<br /><br />Перед тем как пользоваться услугами нашего портала, необходимо активировать свой аккаунт. Для этого кликните, пожалуйста, по <a href=\"" + callbackUrl + "\">ссылке</a>.  <br> " + " Ссылка будет доступна в течение 48 часов. После этого срока неактивированный аккаунт будет удален. <br /><br />Если у Вас возникнут вопросы, на них с удовольствием ответит наша служба поддержки. E-mail:<a href=\"mailto:support@attistrade.kz\" target=\"_blank\">support@attistrade.kz</a></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateFooter\"></tr><tr style = \"color: #808080; font-family: Helvetica; font-size: 10px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\"><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0;\" mc:edit=\"footer_content01\"><em>Copyright &copy; ТОО \"Attis\", All rights reserved.</em></tr><tr><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0; padding-bottom:40px;\" mc:edit=\"footer_content02\">&nbsp;</td></tr></table></td></tr></table></td></tr></table></center></body></html>";
            mlclient.EnableSsl = false;
            mlclient.UseDefaultCredentials = false;
            mlclient.Credentials = new System.Net.NetworkCredential(sender, password);
            user_id = user_id.Trim();
            try
            {
                System.Net.Mail.MailMessage message1 = new System.Net.Mail.MailMessage();
                // Add receiver
                message1.To.Add(usr.Email);
                message1.From = new System.Net.Mail.MailAddress(sender);
                message1.Subject = "Подтверждение электронной почты";
                message1.Body = body;
                message1.IsBodyHtml = true;
                mlclient.Send(message1);

                string query = $"UPDATE persons SET accepted = 1 WHERE user_id = '{user_id}';";
                Provider.RunNonQuery(query);
            }
            catch (Exception ex) { return ex.Message; }
            return "ok";
        }


        public class statusmsg
        {
            public int statusCode;
            public string statusMessage;
            public loginuser user;
            //"statusCode": 419,
            //"": "wrong security token"
        }

        public class Organization
        {
            public string company_id;
            public string company_title;
            public string company_regdate;
            public string company_status;
            public string company_reregdate;
            public string company_oked;
            public string company_contacts;
            public string company_region;
            public string company_main_sphere;
            public string company_additional_sphere;
            public string company_filials;
            public string company_ceo;
            public string company_ceo_date;
            public string company_founder;
            public string company_number_of_founders;
            public string company_social_networks;
            public string company_website;
            public string company_address;
        }
        [HttpGet]
        [AllowAnonymous]
        public JsonResult getOrgList(int company_id)
        {
            var query = $"SELECT * from organizations WHERE org_code ~ '{company_id}'";
            var reader = Provider.RunQuery(query);
            var organizations = new List<Organization>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new Organization
                    {
                        company_id = reader["org_code"].ToString(),
                    };
                    rep.company_title = reader["org_name"].ToString();
                    rep.company_address = reader["company_address"].ToString();
                    rep.company_contacts = reader["company_contacts"].ToString();
                    rep.company_status = reader["company_status"].ToString();
                    rep.company_regdate = reader["org_reg_date"].ToString();
                    rep.company_reregdate = reader["org_reregdate"].ToString();
                    rep.company_oked = reader["org_oked"].ToString();
                    rep.company_region = reader["company_region"].ToString();
                    rep.company_main_sphere = reader["company_main_sphere"].ToString();
                    rep.company_additional_sphere = reader["company_additional_sphere"].ToString();
                    rep.company_filials = reader["company_filials"].ToString();
                    rep.company_ceo = reader["company_ceo"].ToString();
                    rep.company_ceo_date = reader["company_ceo_date"].ToString();
                    rep.company_founder = reader["company_founder"].ToString();
                    rep.company_number_of_founders = reader["company_number_of_founders"].ToString();
                    rep.company_social_networks = reader["company_social_networks"].ToString();
                    rep.company_website = reader["company_website"].ToString();
                    organizations.Add(rep);
                }
                reader.Close();
                return Json(organizations, JsonRequestBehavior.AllowGet);
            }
            else return null;
        }

        //Требуется полный рефактор, с добавлением UserStore и переопределением всех функций работы с пользователями 
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Register0(RegisterViewModel model)
        {
            var response = Request["g-recaptcha-response"];
            const string secretKey = "6LfeKqYUAAAAAGxavxkX63DBojCAjDhNfSUubGV6";
            var client = new WebClient();
            var result1 = client.DownloadString(
                $"https://www.google.com/recaptcha/api/siteverify?secret={secretKey}&response={response}");
            var obj = JObject.Parse(result1);
            var status = (bool)obj.SelectToken("success");
            model.FullName = model.Surname + " " + model.GivenName;

            if (!status || !model.Agree || model.Password == null)
            {
                return View(model);
            }
            string query = $"SELECT org_id FROM organizations WHERE org_code ='{model.Bin}';";
            var frm = Provider.RunScalar(query);
            if (frm < 0)
            {
                query = $"INSERT INTO organizations (org_code, org_name, org_address, org_phone, org_type) VALUES ('{model.Bin}', '{model.FirmName}', '{model.Address}', '{model.FirmPhone}', '{model.Role}') RETURNING org_id;";
                frm = Provider.RunScalar(query);
            }

            var user = new ApplicationUser { UserName = model.Email, Email = model.Email/*, PhoneNumber = model.Phone*/ };
            var result = await UserManager.CreateAsync(user, model.Password);

            if (result.Succeeded)
            {
                var guid = Guid.NewGuid().ToString("N");
                model.Birthday = DateTime.Now;
                var results = Provider.RunScalarStoredProcedure("add_user", model.PersonCode, model.Surname, model.GivenName, model.MiddleName, model.Role, model.Birthday, model.Residency, model.Country, user.Id, model.FullName, guid, model.GivenNameKz, model.SurnameKz, model.MiddleNameKz);
                var code = await UserManager.GenerateEmailConfirmationTokenAsync(user.Id);

                var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code },
                    protocol: Request.Url.Scheme);
                var body = "</head><body leftmargin=\"0\" marginwidth=\"0\" topmargin=\"0\" marginheight=\"0\" offset=\"0\"><center><table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" id=\"bodyTable\"><tr><td align=\"center\" valign=\"top\" id=\"bodyCell\" stile = \"margin:0; padding:0; border:0; height:auto; line-height:100%; outline:none; text-decoration:none; border-collapse:collapse !important; height:100% !important; margin:0; padding:0; width:100% !important; padding:20px; width:600px; background-color:#DEE0E2; border-top:4px solid #BBBBBB; border:1px solid #BBBBBB;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"templateContainer\"><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templatePreheader\"><tr></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateHeader\"><tr><td valign=\"top\" class=\"headerContent\" style = \"color: #505050; font-family: Helvetica; font-size: 20px; font-weight: bold; line-height: 100%; padding-top: 0; padding-right: 0; padding-bottom: 0; padding-left: 0; text-align: left; vertical-align: middle;\"></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateBody\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><tr><td valign=\"top\" class=\"bodyContent\" mc:edit=\"body_content\"><h1 style = \"color: #202020 !important; display: block; font-family: Helvetica; font-size: 26px; font-style: normal; font-weight: bold; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Уважаемый(ая) " + model.GivenName + " " + model.Surname + "!</h1><h3 style = \"color: #606060 !important; display: block; font-family: Helvetica; font-size: 16px; font-style: italic; font-weight: normal; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Добро пожаловать на портал торговой площадки FIP !</h3><div style = \"color: #505050; font-family: Helvetica; font-size: 14px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\">Все Ваши данные, предоставленные для портала, хранятся в надежных руках: самые современные технологии кодирования и многоступенчатые системы сетевой защиты гарантируют максимальный уровень сохранности.<br /><br />Перед тем как пользоваться услугами нашего портала, необходимо активировать свой аккаунт. Для этого кликните, пожалуйста, по <a href=\"" + callbackUrl + "\">ссылке</a>.  <br> " + " Ссылка будет доступна в течение 48 часов. После этого срока неактивированный аккаунт будет удален. <br /><br />Если у Вас возникнут вопросы, на них с удовольствием ответит наша служба поддержки. E-mail:<a href=\"mailto:support@finplatform.kz\" target=\"_blank\">support@finplatform.kz</a></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateFooter\"></tr><tr style = \"color: #808080; font-family: Helvetica; font-size: 10px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\"><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0;\" mc:edit=\"footer_content01\"><em>Copyright &copy; ТОО \"FIP\", All rights reserved.</em></tr><tr><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0; padding-bottom:40px;\" mc:edit=\"footer_content02\">&nbsp;</td></tr></table></td></tr></table></td></tr></table></center></body></html>";

                if (model.UserType != null) await UserManager.AddClaimAsync(user.Id, new Claim("user_role", "-4"));

                //заглушка
                //model.Address = "Astana";
                model.Geocode = "51.152347, 71.430286";
                //

                if (results < 0)
                {
                    return View(model);
                }

                await UserManager.SendEmailAsync(user.Id, "Подтверждение электронной почты", body);
                query = $"UPDATE persons SET org_id = '{frm}', middle_name='{model.MiddleName}', phone='{model.Phone}' WHERE user_id = '{user.Id}';";
                Provider.RunNonQuery(query);

                //notify admin
                await UserManager.SendEmailAsync("support@finplatform.kz", "Уведомление о регистрации нового пользователя", "Уважаемый администратор ситемы. Пользователь " + user.Id + " ожидает валидации");
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.NewValid,
                    CreatorId = "6134b6a0-f830-46c1-92b0-23f02b934585",
                    RecipientId = "6134b6a0-f830-46c1-92b0-23f02b934585",
                    CreationDate = DateTime.Now,
                    ObjectId = 0,
                    Comment = user.Id
                });
                return RedirectToAction("EmailNeedConfirmation", "Account");
            }

            AddErrors(result);

            return View(model);
        }

        public int GetCount()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT COUNT(*) FROM notifications WHERE notification_archived='false' AND notification_recipient ='" + user + "';";
            var reader = Provider.RunScalar(query);

            return reader;
        }
        /*
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> RegisterLawyer(RegisterViewModel model)
        {
            var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

            if (claim == "63") // Admin
            {
                model.FullName = model.Surname + " " + model.GivenName;
                var user = new ApplicationUser { UserName = model.Email, Email = model.Email//, PhoneNumber = model.Phone };
                var result = await UserManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    var guid = Guid.NewGuid().ToString("N");
                    var results = Provider.RunScalarStoredProcedure("add_user", model.PersonCode, model.Surname, model.GivenName, model.MiddleName, model.Gender, model.Birthday, model.Residency, model.Country, user.Id, model.FullName, guid, model.GivenNameKz, model.SurnameKz, model.MiddleNameKz);
                    var code = await UserManager.GenerateEmailConfirmationTokenAsync(user.Id);

                    var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code },
                               protocol: Request.Url.Scheme);
                    var body = "</head><body leftmargin=\"0\" marginwidth=\"0\" topmargin=\"0\" marginheight=\"0\" offset=\"0\"><center><table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" id=\"bodyTable\"><tr><td align=\"center\" valign=\"top\" id=\"bodyCell\" stile = \"margin:0; padding:0; border:0; height:auto; line-height:100%; outline:none; text-decoration:none; border-collapse:collapse !important; height:100% !important; margin:0; padding:0; width:100% !important; padding:20px; width:600px; background-color:#DEE0E2; border-top:4px solid #BBBBBB; border:1px solid #BBBBBB;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"templateContainer\"><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templatePreheader\"><tr></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateHeader\"><tr><td valign=\"top\" class=\"headerContent\" style = \"color: #505050; font-family: Helvetica; font-size: 20px; font-weight: bold; line-height: 100%; padding-top: 0; padding-right: 0; padding-bottom: 0; padding-left: 0; text-align: left; vertical-align: middle;\"></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateBody\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><tr><td valign=\"top\" class=\"bodyContent\" mc:edit=\"body_content\"><h1 style = \"color: #202020 !important; display: block; font-family: Helvetica; font-size: 26px; font-style: normal; font-weight: bold; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Уважаемый(ая) " + model.GivenName + " " + model.Surname + "!</h1><h3 style = \"color: #606060 !important; display: block; font-family: Helvetica; font-size: 16px; font-style: italic; font-weight: normal; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Добро пожаловать на портал Республиканской коллегии адвокатов Казахстана!</h3><div style = \"color: #505050; font-family: Helvetica; font-size: 14px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\">Все Ваши данные, предоставленные для портала, хранятся в надежных руках: самые современные технологии кодирования и многоступенчатые системы сетевой защиты гарантируют максимальный уровень сохранности.<br /><br />Ваш пароль для аккаунта: \"" + model.Password + "\" . Перед тем как пользоваться услугами нашего портала, необходимо активировать свой аккаунт. Для этого кликните, пожалуйста, по <a href=\"" + callbackUrl + "\">ссылке</a>.  <br> " + " Ссылка будет доступна в течение 48 часов. После этого срока неактивированный аккаунт будет удален. <br /><br />Если у Вас возникнут вопросы, на них с удовольствием ответит наша служба поддержки. E-mail:<a href=\"http://10.10.7.228:7777/\" target=\"_blank\">support@fip.kz</a></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateFooter\"></tr><tr style = \"color: #808080; font-family: Helvetica; font-size: 10px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\"><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0;\" mc:edit=\"footer_content01\"><em>Copyright &copy; ТОО \"FIP\", All rights reserved.</em></tr><tr><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0; padding-bottom:40px;\" mc:edit=\"footer_content02\">&nbsp;</td></tr></table></td></tr></table></td></tr></table></center></body></html>";

                    switch (model.UserType)
                    {
                        case "-2": // Клиент
                            await UserManager.AddClaimAsync(user.Id, new Claim("user_role", model.UserType)); // -2 - Клиент со старым паролем
                            results = Provider.RunScalarStoredProcedure("add_lawyer_status_request_TKA", user.Id, model.LawCollegiumId, 10); // чтобы не отображался в заявке до того, как запонит свои данные
                            break;
                        case "2": // секретарь ТКА
                            await UserManager.AddClaimAsync(user.Id, new Claim("user_role", "-4")); // -4 - секретарь со старым паролем
                            results = Provider.RunScalarStoredProcedure("add_lawyer_status_request_TKA", user.Id, model.LawCollegiumId, 2);
                            break;
                        case "3": // бухгалтер
                            await UserManager.AddClaimAsync(user.Id, new Claim("user_role", "42"));
                            results = Provider.RunScalarStoredProcedure("add_lawyer_status_request_TKA", user.Id, model.LawCollegiumId, 3);
                            break;
                        case "4": // председатель
                            await UserManager.AddClaimAsync(user.Id, new Claim("user_role", "43"));
                            results = Provider.RunScalarStoredProcedure("add_lawyer_status_request_TKA", user.Id, model.LawCollegiumId, 4);
                            break;
                    }


                    if (results >= 0)
                    {
                        await UserManager.SendEmailAsync(user.Id, "Подтверждение электронной почты", body);
                        TempData["Message"] = "Пользователь был добавлен!";
                        return RedirectToAction("RegisterLawyer", "Account");
                    }
                    else
                    {
                        ViewBag.Message = "Возникла ошибка при регистрации";
                        return View("Error");
                    }
                }
                else
                {
                    // Get Collegiums list from DB
                    var query = @"SELECT * FROM public.law_collegiums;";
                    var reader = Provider.RunQuery(query);
                    var selListCollegiums = new List<SelectListItem>();
                    selListCollegiums.Add(new SelectListItem { Text = "", Value = "" });

                    while (reader.Read())
                    {
                        selListCollegiums.Add(new SelectListItem { Text = reader["law_collegium_name_ru"].ToString(), Value = reader["law_collegium_id"].ToString() });
                    }
                    reader.Close();

                    model.Collegiums = selListCollegiums;

                    AddErrors(result);
                    return View(model);
                }
            }
            ViewBag.Message = "У Вас не хватает прав.";
            return View("Error");
        }
        */
        [AllowAnonymous]
        public async Task<ActionResult> ConfirmEmail(string userId, string code)
        {
            if (userId == null || code == null)
            {
                return View("Error");
            }
            var result = await UserManager.ConfirmEmailAsync(userId, code);
            return View(result.Succeeded ? "ConfirmEmail" : "Error");
        }

        [AllowAnonymous]
        public ActionResult EmailNeedConfirmation()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public string ForgotPassword(string email)
        {
            try
            {
                var user = UserManager.FindByName(email);
                if (user == null || !(UserManager.IsEmailConfirmed(user.Id)))
                {
                    // Don't reveal that the user does not exist or is not confirmed
                    return "error: user is not found/verified";
                }

                // Send an email with this link
                var code = UserManager.GeneratePasswordResetToken(user.Id);
                code = Convert.ToBase64String(GetBytes(code));
                //var callbackUrl = Url.Action("Reset", "#", new { email = user.Email, code }, protocol: Request.Url.Scheme);
                var path = Request.Url.Authority + "/ru#/reset/" + code;
                UserManager.SendEmail(user.Id, "Восстановление пароля", "Для восстановления пароля, пройдите по <a href=\"http://" + path + "\">ссылке</a>");
                return "ok";
            }
            catch (Exception ex) { return ex.Message; }
        }


        [HttpPost]
        [AllowAnonymous]
        public string ResetPassword(string email, string code, string password)
        {
            var user = UserManager.FindByName(email);
            if (user == null)
            {
                // Don't reveal that the user does not exist
                return "user error";
            }
            var cod = Encoding.Default.GetString(Convert.FromBase64String(code));
            var result = UserManager.ResetPassword(user.Id, cod, password);
            if (result.Succeeded)
            {
                return "ok";
            }
            return "error, token invalid";
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLogin(string provider, string returnUrl)
        {
            // Request a redirect to the external login provider
            return new ChallengeResult(provider, Url.Action("ExternalLoginCallback", "Account", new { ReturnUrl = returnUrl }));
        }

        [AllowAnonymous]
        public async Task<ActionResult> SendCode(string returnUrl, bool rememberMe)
        {
            var userId = await SignInManager.GetVerifiedUserIdAsync();
            if (userId == null)
            {
                return View("Error");
            }
            var userFactors = await UserManager.GetValidTwoFactorProvidersAsync(userId);
            var factorOptions = userFactors.Select(purpose => new SelectListItem { Text = purpose, Value = purpose }).ToList();
            return View(new SendCodeViewModel { Providers = factorOptions, ReturnUrl = returnUrl, RememberMe = rememberMe });
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SendCode(SendCodeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            // Generate the token and send it
            if (!await SignInManager.SendTwoFactorCodeAsync(model.SelectedProvider))
            {
                return View("Error");
            }
            return RedirectToAction("VerifyCode", new { Provider = model.SelectedProvider, model.ReturnUrl, model.RememberMe });
        }

        [AllowAnonymous]
        public async Task<ActionResult> ExternalLoginCallback(string returnUrl)
        {
            var loginInfo = await AuthenticationManager.GetExternalLoginInfoAsync();

            if (loginInfo == null)
            {
                return RedirectToAction("Login");
            }

            // Sign in the user with this external login provider if the user already has a login
            var result = await SignInManager.ExternalSignInAsync(loginInfo, isPersistent: false);

            switch (result)
            {
                case SignInStatus.Success:
                    return RedirectToLocal(returnUrl);
                case SignInStatus.LockedOut:
                    return View("Lockout");
                case SignInStatus.RequiresVerification:
                    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = false });
                case SignInStatus.Failure:
                    ViewBag.ReturnUrl = returnUrl;
                    ViewBag.LoginProvider = loginInfo.Login.LoginProvider;
                    return View("ExternalLoginConfirmation", new ExternalLoginConfirmationViewModel { Email = loginInfo.Email });
                default:
                    // If the user does not have an account, then prompt the user to create an account
                    ViewBag.ReturnUrl = returnUrl;
                    ViewBag.LoginProvider = loginInfo.Login.LoginProvider;
                    return View("ExternalLoginConfirmation", new ExternalLoginConfirmationViewModel { Email = loginInfo.Email });
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ExternalLoginConfirmation(ExternalLoginConfirmationViewModel model, string returnUrl)
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Manage");
            }

            if (ModelState.IsValid)
            {
                // Get the information about the user from the external login provider
                var info = await AuthenticationManager.GetExternalLoginInfoAsync();
                if (info == null)
                {
                    return View("ExternalLoginFailure");
                }
                var user = new ApplicationUser { UserName = model.Email, Email = model.Email };
                var result = await UserManager.CreateAsync(user);
                if (result.Succeeded)
                {
                    result = await UserManager.AddLoginAsync(user.Id, info.Login);
                    if (result.Succeeded)
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                        return RedirectToLocal(returnUrl);
                    }
                }
                AddErrors(result);
            }

            ViewBag.ReturnUrl = returnUrl;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            logOut();
            return RedirectToAction("Index", "Home");
        }
        /*
        public ActionResult LogOut()
        {
            logOut();

            return RedirectToAction("Index", "Home");
        }
        */
        public string logOut()
        {
            string user = User.Identity.GetUserId();
            AuthenticationManager.SignOut();
            HttpContext.Session.Remove("Templates");
            HttpContext.Session.Remove("DataSets");
            HttpContext.Session.Remove("Validators");
            HttpContext.Session.Remove("Reports");
            HttpContext.Session.Remove("Token");
            string query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id) " +
            $"VALUES('NOW()', '{(int)LogAccount.Logout}', '{LogAccount.Logout}', '{LogSection.Account}', '{user}', '0');";
            return "{\"status\":\"ok\"}";
        }

        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }
        /*
        public async Task<ActionResult> PersonalInfo()
        {
            //var claimfromDb = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

            var query = @"SELECT t1.""ClaimValue""
                                FROM ""AspNetUserClaims"" t1
                                WHERE t1.""UserId"" = '" + User.Identity.GetUserId() + "' and t1.\"ClaimType\" = 'user_role';";

            var reader = Provider.RunQuery(query);

            var claimfromDb = "1";

            while (reader.Read())
            {
                claimfromDb = reader["ClaimValue"].ToString();
            }

            reader.Close();

            //var claimFromStorage = ((ClaimsIdentity)this.User.Identity).Claims.First(c => c.Type == "user_role").Value;
            if (claimfromDb == "-100")
            {
                return RedirectToAction("LogOut", "Account");
            }

            var model = new PersonalViewModel();

            query = @"SELECT t1.*, t2.*, t3.doc_guid, t4.doc_widget_id, t4.doc_img_scan, t5.*,
                                t6.law_collegium_name_ru,  t6.law_collegium_name_kz,
                                t7.legal_advise_type_name_ru, t7.legal_advise_type_name_kz

                                FROM public.persons t1

                                left join public.""AspNetUsers"" t2 on t2.""Id"" = t1.user_id
                                left join public.subjects t3 on t1.subj_id = t3.subj_id
                                left join public.docimages t4 on t4.doc_guid = t3.doc_guid
                                left join public.subjects_law_suppliers t5 on t5.person_id = t3.user_id
                                left join public.law_collegiums t6 on t6.law_collegium_id = t5.law_collegium_id
                                left join public.legal_advise_types t7 on t7.legal_advise_type_id = t5.law_supp_org_type
                                

                                WHERE t1.user_id ='" + User.Identity.GetUserId() + "';";


            var readerDt = Provider.RunQueryDataTable(query);

            for (var j = 0; j < readerDt.Rows.Count; j++)
            {
                model.Name = readerDt.Rows[j].Field<string>("given_name");
                model.Surname = readerDt.Rows[j].Field<string>("last_name");
                model.Middlename = readerDt.Rows[j].Field<string>("middle_name");
                model.Name_KZ = readerDt.Rows[j].Field<string>("given_name_kz");
                model.Surname_KZ = readerDt.Rows[j].Field<string>("last_name_kz");
                model.Middlename_KZ = readerDt.Rows[j].Field<string>("middle_name_kz");
                model.Country = readerDt.Rows[j].Field<string>("country");
                model.Address = readerDt.Rows[j].Field<string>("post_address");
                model.Geocode = readerDt.Rows[j].Field<string>("post_address_geo");
                model.Phone = readerDt.Rows[j].Field<string>("PhoneNumber");
                model.Email = readerDt.Rows[j].Field<string>("Email");
                model.PersonalCode = readerDt.Rows[j].Field<string>("person_code");
                model.Birthday = readerDt.Rows[j].Field<DateTime>("date_of_birth");
                model.DocGuid = readerDt.Rows[j].Field<string>("doc_guid");
                model.Gender = readerDt.Rows[j].Field<string>("gender");
                model.UserID = readerDt.Rows[j].Field<string>("user_id");

                var x = readerDt.Rows[j].Field<short>("subj_law_supplier_status");

                var lawyer = new LawyerStatusRequestViewModel
                {
                    RequestStatus = x
                };

                if (lawyer.RequestStatus == 1 || lawyer.RequestStatus == 2 || lawyer.RequestStatus == 3 || lawyer.RequestStatus == 0 || lawyer.RequestStatus == 10 || lawyer.RequestStatus == 5)
                {
                    lawyer.RequestId = readerDt.Rows[j].Field<int>("subj_law_supplier_id");
                    lawyer.FIO = readerDt.Rows[j].Field<string>("subj_law_supplier_name");
                    lawyer.Address = readerDt.Rows[j].Field<string>("subj_law_supplier_address");
                    lawyer.Geocode = readerDt.Rows[j].Field<string>("subj_law_supplier_address_geo");
                    lawyer.LicenseNumber = readerDt.Rows[j].Field<string>("subj_law_supplier_lic_num");
                    lawyer.LicenseDate = readerDt.Rows[j].Field<DateTime?>("subj_law_supplier_lic_date");
                    lawyer.Fax = readerDt.Rows[j].Field<string>("subj_law_supplier_fax");
                    lawyer.Email = readerDt.Rows[j].Field<string>("subj_law_supplier_email");
                    lawyer.WorkingDays = readerDt.Rows[j].Field<string>("subj_law_supplier_work_days");
                    lawyer.WorkTime = readerDt.Rows[j].Field<string>("subj_law_supplier_work_time");
                    lawyer.CellPhoneNumber = readerDt.Rows[j].Field<string>("subj_law_supplier_mobile");
                    lawyer.PhoneNumber = readerDt.Rows[j].Field<string>("subj_law_supplier_phone");
                    lawyer.Collegia = readerDt.Rows[j].Field<int>("law_collegium_id");
                    lawyer.OrgForma = readerDt.Rows[j].Field<int?>("law_supp_org_type");
                    lawyer.CollegiaName = readerDt.Rows[j].Field<string>("law_collegium_name_ru");
                    lawyer.OrgFormaName = readerDt.Rows[j].Field<string>("legal_advise_type_name_ru");
                    lawyer.isGGUP = readerDt.Rows[j].Field<int?>("law_state_aids");
                    lawyer.GGUPDocNumber = readerDt.Rows[j].Field<string>("law_state_aid_docnum");
                    lawyer.GGUPDocDate = readerDt.Rows[j].Field<DateTime?>("law_state_aid_docdate");
                    lawyer.Bin = readerDt.Rows[j].Field<string>("subj_law_bin");
                    lawyer.Website = readerDt.Rows[j].Field<string>("subj_law_website");
                    lawyer.ConsultationId = readerDt.Rows[j].Field<int?>("subj_law_consult_id");
                    lawyer.ShouldPay = readerDt.Rows[j].Field<int?>("subj_law_fee_free");
                    lawyer.DownPaymentIndebtness = readerDt.Rows[j].Field<string>("subj_law_down_fee");
                    lawyer.MonthlyPaymentIndebtness = readerDt.Rows[j].Field<string>("subj_law_monthly_fee");
                    lawyer.GGUPNextYear = readerDt.Rows[j].Field<int?>("law_state_aid_application").ToString();
                    lawyer.IsRural = readerDt.Rows[j].Field<int?>("subj_law_supp_is_rural");
                    lawyer.Comment = readerDt.Rows[j].Field<string>("comment");
                    lawyer.ContractOffer = readerDt.Rows[j].Field<string>("subj_law_contract_offer");
                    lawyer.PersonId = readerDt.Rows[j].Field<string>("user_id");

                    var dateToConvert = readerDt.Rows[j].Field<DateTime?>("subj_law_contract_date");
                    lawyer.ContractOfferDate = dateToConvert.HasValue ? dateToConvert.Value.ToString("dd/MM/yyyy") : "00/00/0000";
                }

                var subjId = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "subj_id").Value);

                //get Phones
                query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 1;";
                var dt = Provider.RunQueryDataTable(query);
                var phones = new List<SubjectPhone>();

                for (var i = 0; i < dt.Rows.Count; i++)
                {
                    var phone = new SubjectPhone
                    {
                        Id = dt.Rows[i].Field<int>("person_phone_id"),
                        SubjectId = dt.Rows[i].Field<int>("subj_id"),
                        Number = dt.Rows[i].Field<string>("subj_phone_number")
                    };
                    //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                    //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());

                    phones.Add(phone);
                }

                model.PhoneNumbers = phones;

                //get Cell Phones
                query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 2;";
                dt = Provider.RunQueryDataTable(query);

                var cellPhones = new List<SubjectPhone>();

                for (var i = 0; i < dt.Rows.Count; i++)
                {
                    var phone = new SubjectPhone
                    {
                        Id = dt.Rows[i].Field<int>("person_phone_id"),
                        SubjectId = dt.Rows[i].Field<int>("subj_id"),
                        Number = dt.Rows[i].Field<string>("subj_phone_number")
                    };
                    //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                    //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());

                    cellPhones.Add(phone);
                }

                model.CellPhoneNumbers = cellPhones;

                //get Emails
                query = @"SELECT * FROM subj_emails where subj_id = '" + subjId + "';";
                dt = Provider.RunQueryDataTable(query);
                var emails = new List<SubjectEmail>();

                for (var i = 0; i < dt.Rows.Count; i++)
                {
                    var email = new SubjectEmail
                    {
                        Id = dt.Rows[i].Field<int>("subj_email_id"),
                        Email = dt.Rows[i].Field<string>("subj_email")
                    };
                    emails.Add(email);
                }

                model.Emails = emails;

                //get Addresses
                query = @"SELECT * FROM subj_post_addresses where subj_id = '" + subjId + "';";
                dt = Provider.RunQueryDataTable(query);
                var addresses = new List<SubjectAddress>();

                for (var i = 0; i < dt.Rows.Count; i++)
                {
                    var address = new SubjectAddress
                    {
                        Id = dt.Rows[i].Field<int>("post_addr_id"),
                        Address = dt.Rows[i].Field<string>("post_addr_name"),
                        Geocode = dt.Rows[i].Field<string>("post_addr_name_geo")
                    };

                    addresses.Add(address);
                }

                model.Addresses = addresses;
                model.lawyer = lawyer;
            }


            // Get OrgForms list from DB
            query = @"SELECT * FROM public.legal_advise_types;";
            reader = Provider.RunQuery(query);
            var selListOrgForms = new List<SelectListItem> { new SelectListItem { Text = "", Value = "" } };

            while (reader.Read())
            {
                selListOrgForms.Add(new SelectListItem { Text = reader["legal_advise_type_name_ru"].ToString(), Value = reader["legal_advise_type_id"].ToString() });
            }

            reader.Close();
            model.lawyer.OrgForms = selListOrgForms;

            // Get Collegiums list from DB
            query = @"SELECT * FROM public.law_collegiums;";
            reader = Provider.RunQuery(query);
            var selListCollegiums = new List<SelectListItem> { new SelectListItem { Text = "", Value = "" } };

            while (reader.Read())
            {
                selListCollegiums.Add(new SelectListItem { Text = reader["law_collegium_name_ru"].ToString(), Value = reader["law_collegium_id"].ToString() });
            }

            reader.Close();
            model.lawyer.Collegiums = selListCollegiums;

            // Get Bureaues list from DB
            query = @"SELECT * FROM public.legal_aid_bureaues where law_collegium_id = " + model.lawyer.Collegia + " or legal_aid_bureau_code = '0';"; ;
            reader = Provider.RunQuery(query);
            var selListBureaues = new List<SelectListItem> { new SelectListItem { Text = "", Value = "" } };

            while (reader.Read())
            {
                selListBureaues.Add(new SelectListItem { Text = reader["legal_aid_bureau_name_ru"].ToString(), Value = reader["legal_aid_bureau_id"].ToString() });
            }

            reader.Close();
            model.lawyer.Bureaues = selListBureaues;

            try
            {
                ViewBag.Message = TempData["Message"] != null ? TempData["Message"].ToString() : null;
            }
            catch (NullReferenceException)
            {
                ViewBag.Message = null;
            }

            model.PhoneNumber = await UserManager.GetPhoneNumberAsync(User.Identity.GetUserId());
            model.TwoFactor = await UserManager.GetTwoFactorEnabledAsync(User.Identity.GetUserId());

            //get coordinates with ',' symbol
            //var client = new HttpClient();
            //var responseString = await client.GetStringAsync("https://geocode-maps.yandex.ru/1.x/?format=json&geocode=" + model.Address + "&results=1");
            //var json = JObject.Parse(responseString);
            //string str;

            //try
            //{
            //    str = json["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]["Point"]["pos"].ToString();
            //    str = str.Replace(" ", " , ");
            //    var str1 = str.Substring(0, 9);
            //    var str2 = str.Substring(11, 9);
            //    str = str2 + ", " + str1;
            //}
            //catch (ArgumentOutOfRangeException)
            //{
            //    //str = "51.1554792,71.4925812,15";
            //    str = string.Empty;
            //}

            //ViewBag.Map = str;
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> PersonalInfo(PersonalViewModel model)
        {
            var query = @"SELECT t1.""ClaimValue""
                                FROM ""AspNetUserClaims"" t1
                                WHERE t1.""UserId"" = '" + User.Identity.GetUserId() + "' and t1.\"ClaimType\" = 'user_role';";

            var reader = Provider.RunQuery(query);

            var claimfromDb = "1";
            while (reader.Read())
            {
                claimfromDb = reader["ClaimValue"].ToString();
            }
            reader.Close();
            //var claimFromStorage = ((ClaimsIdentity)this.User.Identity).Claims.First(c => c.Type == "user_role").Value;
            //if ((claimfromDB != "2") || (claimFromStorage == "1" && claimfromDB == "2")) return RedirectToAction("LogOut", "Account");
            if (claimfromDb == "-100") return RedirectToAction("LogOut", "Account");


            var modelToCompare = new PersonalViewModel();
            var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

            query = "SELECT t1.*, t2.* FROM subjects_law_suppliers t1 JOIN persons t2 on t1.person_id = t2.user_id WHERE subj_law_supplier_id = " + model.lawyer.RequestId + ";";
            reader = Provider.RunQuery(query);
            while (reader.Read())
            {
                modelToCompare.Name = GetStringForComparing(reader["given_name"].ToString());
                modelToCompare.Surname = GetStringForComparing(reader["last_name"].ToString());
                modelToCompare.Middlename = GetStringForComparing(reader["middle_name"].ToString());
                modelToCompare.Gender = GetStringForComparing(reader["gender"].ToString());
                modelToCompare.Birthday = GetDateTimeFromString(reader["date_of_birth"].ToString());
                modelToCompare.Address = GetStringForComparing(reader["post_address"].ToString());
                modelToCompare.PersonalCode = GetStringForComparing(reader["person_code"].ToString());

                var lawyer = new LawyerStatusRequestViewModel
                {
                    FIO = GetStringForComparing(reader["subj_law_supplier_name"].ToString()),
                    LicenseNumber = GetStringForComparing(reader["subj_law_supplier_lic_num"].ToString()),
                    LicenseDate = GetDateTimeFromString(reader["subj_law_supplier_lic_date"].ToString()),
                    WorkingDays = GetStringForComparing(reader["subj_law_supplier_work_days"].ToString()),
                    WorkTime = GetStringForComparing(reader["subj_law_supplier_work_time"].ToString()),
                    OrgForma = GetIntFromString(reader["law_supp_org_type"].ToString()),
                    Bin = GetStringForComparing(reader["subj_law_bin"].ToString()),
                    Collegia = GetIntFromString(reader["law_collegium_id"].ToString()),
                    PhoneNumber = GetStringForComparing(reader["subj_law_supplier_phone"].ToString()),
                    CellPhoneNumber = GetStringForComparing(reader["subj_law_supplier_mobile"].ToString()),
                    ConsultationId = GetIntFromString(reader["subj_law_consult_id"].ToString()),
                    Address = GetStringForComparing(reader["subj_law_supplier_address"].ToString())
                };

                modelToCompare.lawyer = lawyer;
            }
            reader.Close();

            var isChanged = false;
            var changedData = new Dictionary<string, string>();

            #region Переписать автоматическим добавлением полей в коллекцию (проблема с соответствием 

            if (GetStringForComparing(model.Name) != modelToCompare.Name)
            {
                changedData.Add("Name", GetStringForComparing(model.Name));
                isChanged = true;
            }
            if (GetStringForComparing(model.Surname) != modelToCompare.Surname)
            {
                changedData.Add("Surname", GetStringForComparing(model.Surname));
                isChanged = true;
            }
            if (model.Address != modelToCompare.Address)
            {
                changedData.Add("Address", GetStringForComparing(model.Address));
                changedData.Add("Geocode", GetStringForComparing(model.Geocode));
                isChanged = true;
            }
            if (GetStringForComparing(model.Gender) != modelToCompare.Gender)
            {
                changedData.Add("Gender", GetStringForComparing(model.Gender));
                isChanged = true;
            }
            if (model.Birthday != modelToCompare.Birthday)
            {
                changedData.Add("Birthday", model.Birthday.ToString());
                isChanged = true;
            }
            if (model.PersonalCode != modelToCompare.PersonalCode)
            {
                changedData.Add("PersonalCode", model.PersonalCode);
                isChanged = true;
            }
            if (GetStringForComparing(model.lawyer.FIO) != modelToCompare.lawyer.FIO)
            {
                changedData.Add("lawyer.FIO", GetStringForComparing(model.lawyer.FIO));
                isChanged = true;
            }
            if (GetStringForComparing(model.lawyer.LicenseNumber) != modelToCompare.lawyer.LicenseNumber)
            {
                changedData.Add("lawyer.LicenseNumber", GetStringForComparing(model.lawyer.LicenseNumber));
                isChanged = true;
            }
            if (model.lawyer.LicenseDate != modelToCompare.lawyer.LicenseDate)
            {
                changedData.Add("lawyer.LicenseDate", model.lawyer.LicenseDate.HasValue ? model.lawyer.LicenseDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                isChanged = true;
            }
            if (model.lawyer.WorkingDays != modelToCompare.lawyer.WorkingDays)
            {
                changedData.Add("lawyer.WorkingDays", GetStringForComparing(model.lawyer.WorkingDays));
                isChanged = true;
            }
            if (model.lawyer.WorkTime != modelToCompare.lawyer.WorkTime)
            {
                changedData.Add("lawyer.WorkTime", GetStringForComparing(model.lawyer.WorkTime));
                isChanged = true;
            }
            if ((model.lawyer.OrgForma ?? 0) != (modelToCompare.lawyer.OrgForma ?? 0))
            {
                changedData.Add("lawyer.OrgForma", model.lawyer.OrgForma.ToString());
                isChanged = true;
            }
            if (GetStringForComparing(model.lawyer.Bin) != modelToCompare.lawyer.Bin)
            {
                changedData.Add("lawyer.Bin", GetStringForComparing(model.lawyer.Bin));
                isChanged = true;
            }
            if (GetStringForComparing(model.lawyer.PhoneNumber) != modelToCompare.lawyer.PhoneNumber)
            {
                changedData.Add("lawyer.PhoneNumber", GetStringForComparing(model.lawyer.PhoneNumber));
                isChanged = true;
            }
            if (GetStringForComparing(model.lawyer.Address) != modelToCompare.lawyer.Address)
            {
                changedData.Add("lawyer.Address", GetStringForComparing(model.lawyer.Address));
                isChanged = true;
            }
            if (GetStringForComparing(model.lawyer.CellPhoneNumber) != modelToCompare.lawyer.CellPhoneNumber)
            {
                changedData.Add("lawyer.CellPhoneNumber", GetStringForComparing(model.lawyer.CellPhoneNumber));
                isChanged = true;
            }
            if ((model.lawyer.ConsultationId ?? 203) != (modelToCompare.lawyer.ConsultationId ?? 203))
            {
                changedData.Add("lawyer.ConsultationId", model.lawyer.ConsultationId.ToString());
                isChanged = true;
            }

            if (claimfromDb == "4" || claimfromDb == "31" || claimfromDb == "-1")
            {
                isChanged = false;
            }
            #endregion


            if (!isChanged)
            {
                // Сохранение данных
                var results = Provider.RunScalarStoredProcedure("updateuser",
                    model.PersonalCode,
                    model.Surname,
                    model.Name,
                    model.Middlename,
                    model.Gender,
                    model.Birthday,
                    model.Residency,
                    model.Country,
                    User.Identity.GetUserId(),
                    model.Name_KZ,
                    model.Surname_KZ,
                    model.Middlename_KZ,
                    model.Address,
                    model.Geocode);
                if (results >= 0)
                    try
                    {
                        results = Provider.RunScalarStoredProcedure("update_lawyer_info",
                            model.lawyer.FIO,
                            model.lawyer.Address,
                            User.Identity.GetUserId(),
                            model.lawyer.LicenseNumber,
                            model.lawyer.LicenseDate ?? DateTime.MinValue,
                            model.lawyer.PhoneNumber,
                            model.lawyer.CellPhoneNumber,
                            model.lawyer.Fax,
                            model.lawyer.Email,
                            model.lawyer.WorkingDays,
                            model.lawyer.WorkTime,
                            model.lawyer.OrgForma ?? 0,
                            model.lawyer.RequestId,
                            model.lawyer.Website,
                            model.lawyer.Bin,
                            model.lawyer.ShouldPay ?? 0,
                            model.lawyer.IsRural ?? 0,
                            string.IsNullOrEmpty(model.lawyer.GGUPNextYear) ? 0 : Convert.ToInt32(model.lawyer.GGUPNextYear),
                            Convert.ToInt32(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "subj_id").Value),
                            model.lawyer.ConsultationId ?? 203,
                            model.lawyer.Geocode);
                    }
                    catch (NullReferenceException)
                    {
                        results = -10;
                    }

                if (model.lawyer == null)
                {
                    return RedirectToAction("PersonalInfo", "Account");
                }

                // Исправление статуса при первом изменении адвокатом
                query = "SELECT subj_law_supplier_status FROM subjects_law_suppliers WHERE subj_law_supplier_id = " + model.lawyer.RequestId + ";";
                reader = Provider.RunQuery(query);

                var status = "";
                while (reader.Read())
                {
                    status = reader["subj_law_supplier_status"].ToString();
                }
                reader.Close();

                if (claimfromDb == "31")
                {
                    query = $@"UPDATE ""AspNetUserClaims"" SET ""ClaimValue"" = 4  WHERE ""UserId"" = '{User.Identity.GetUserId()}' AND ""ClaimType"" = 'user_role';";
                    Provider.RunNonQuery(query);
                    TempData["logout_message"] = "Спасибо за заполнение профиля. Требуется повторная авторизация";
                    return RedirectToAction("LogOut", "Account");
                 }

                if (status == "10" || status == "5")
                {
                    query =
                        "UPDATE public.subjects_law_suppliers SET subj_law_supplier_status = 0, subj_law_contract_offer = '" +
                        model.PersonalCode +
                        "/" +
                        DateTime.Now.Date.ToString("dd/MM/yyyy") +
                        "', subj_law_contract_date = '" +
                        DateTime.Now.Date.ToString("dd/MM/yyyy") +
                        "' WHERE subj_law_supplier_id =" +
                        model.lawyer.RequestId +
                        ";";
                    Provider.RunNonQuery(query);

                    // Уведомление секретарям коллегии
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.RequestApprovalProfile,
                        CreatorId = User.Identity.GetUserId(),
                        CreationDate = DateTime.Now,
                        ObjectId = model.lawyer.RequestId
                    });

                    // Отправка секретарям коллегии
                    var collegiumId = string.Empty;
                    query = @"SELECT law_collegium_id
                                 FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";

                    reader = Provider.RunQuery(query);

                    while (reader.Read())
                    {
                        collegiumId = reader["law_collegium_id"].ToString();
                    }
                    reader.Close();

                    query = "SELECT t2.\"Id\" from subjects_law_suppliers t1 LEFT JOIN \"AspNetUsers\" t2 on t1.person_id = t2.\"Id\" WHERE t1.law_collegium_id = " + collegiumId + " and t1.subj_law_supplier_status = 2";
                    reader = Provider.RunQuery(query);
                    var users = new List<string>();

                    while (reader.Read())
                    {
                        users.Add(reader["Id"].ToString());
                    }
                    reader.Close();

                    if (model.lawyer.LicenseDate == null)
                    {
                        return RedirectToAction("PersonalInfo", "Account");
                    }

                    var body =
                        $"Были изменены данные у клиента из вашей коллегии. <br /> Наименование: {model.lawyer.FIO} <br /> Номер лицензии:  {model.lawyer.LicenseNumber}";
                    foreach (var user in users)
                    {
                        await UserManager.SendEmailAsync(user, "Изменение личных данных у клиента.", body);
                    }
                }
            }
            else
            {
                foreach (var field in changedData)
                {
                    query =
                        $"INSERT INTO change_history(model_type, model_field, change_date, status, new_value, id_value) VALUES(1, '{field.Key}', now(), 1, '{field.Value}', '{User.Identity.GetUserId()}');";
                    Provider.RunNonQuery(query);
                }

                var results = Provider.RunScalarStoredProcedure("add_lawyer_request_to_change_data", model.Name,
                model.Surname, model.Middlename, model.PersonalCode, model.Gender, model.Birthday,
                model.PostIndex, model.lawyer.FIO, model.lawyer.LicenseNumber, model.lawyer.LicenseDate,
                model.lawyer.WorkingDays, model.lawyer.WorkTime,
                model.lawyer.OrgForma, model.lawyer.Bin, model.lawyer.ConsultationId, User.Identity.GetUserId(),
                model.lawyer.CellPhoneNumber, model.lawyer.PhoneNumber, model.lawyer.Address, model.PostIndex);

                query = "UPDATE subjects_law_suppliers SET subj_law_supplier_status = 0, subj_law_supplier_fax = '" +
                        model.lawyer.Fax +
                        "', subj_law_website = '" +
                        model.lawyer.Website +
                        "', subj_law_supplier_address = '" +
                        model.lawyer.Address +
                        "', subj_law_supplier_address_geo = '" +
                        model.lawyer.Geocode +
                        "' WHERE person_id = '" +
                        User.Identity.GetUserId() +
                        "';";
                Provider.RunNonQuery(query);
                //query = "UPDATE persons SET post_address = '" +
                //        model.Address +
                //        "', post_address_geo='" +
                //        model.Geocode +
                //        "' WHERE user_id = '" +
                //        User.Identity.GetUserId() +
                //        "';";
                //Provider.RunNonQuery(query);

                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.RequestEditProfile,
                    CreationDate = DateTime.Now,
                    CreatorId = User.Identity.GetUserId(),
                    ObjectId = results
                });
            }

            //if (results >= 0)
            //    TempData["Message"] = "Информация была изменена";
            //else
            //TempData["Message"] = "Возникла ошибка";

            return RedirectToAction("PersonalInfo", "Account");
        }

        [HttpPost]
        public ActionResult UpdateUserBySecretary(PersonalViewModel model)
        {
            var results = Provider.RunScalarStoredProcedure("update_lawyer_by_secretary",
                model.lawyer.GGUPDocNumber,
                model.lawyer.GGUPDocDate ?? DateTime.MinValue,
                model.lawyer.ConsultationId ?? 203,
                model.lawyer.RequestId,
                model.lawyer.ShouldPay ?? 0,
                model.lawyer.DownPaymentIndebtness,
                model.lawyer.MonthlyPaymentIndebtness,
                model.lawyer.isGGUP ?? 0);


            if (results >= 0)
                TempData["Message"] = "Информация была изменена";
            else
                TempData["Message"] = "Возникла ошибка";

            return RedirectPermanent("/Account/Lawyer/" + model.lawyer.RequestId);
        }

        [HttpPost]
        public ActionResult DeleteEvent()
        {
            var userId = User.Identity.GetUserId();

            var query = @"DELETE FROM public.processes
                            WHERE process_id = " + Request["eventId"] + " and user_id ='" + userId + "';";
            Provider.RunNonQuery(query);

            return null;
        }

        public async Task<ActionResult> LawyerStatusRequest()
        {
            var model = new LawyerStatusRequestViewModel();
            var subjId = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "subj_id").Value);


            //если был редирект на эту страницу с TempData
            try { ViewBag.Message = TempData["Message"] != null ? TempData["Message"].ToString() : null; }
            catch (NullReferenceException) { ViewBag.Message = null; }

            // Check is existing request
            var count = -1;
            var query = @"SELECT COUNT(*) FROM subjects_law_suppliers where person_id = '" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);
            while (reader.Read())
            {
                count = int.Parse(reader["count"].ToString());
            }
            reader.Close();

            //если запроса нет
            if (count == 0)
            {
                // Get OrgForms list from DB
                query = @"SELECT * FROM public.legal_advise_types;";
                reader = Provider.RunQuery(query);
                var selListOrgForms = new List<SelectListItem>();
                selListOrgForms.Add(new SelectListItem { Text = "", Value = "" });
                while (reader.Read())
                {
                    selListOrgForms.Add(new SelectListItem { Text = reader["legal_advise_type_name_ru"].ToString(), Value = reader["legal_advise_type_id"].ToString() });
                }
                reader.Close();

                // Get Collegiums list from DB
                query = @"SELECT * FROM public.law_collegiums;";
                reader = Provider.RunQuery(query);
                var selListCollegiums = new List<SelectListItem>();
                selListCollegiums.Add(new SelectListItem { Text = "", Value = "" });

                while (reader.Read())
                {
                    selListCollegiums.Add(new SelectListItem { Text = reader["law_collegium_name_ru"].ToString(), Value = reader["law_collegium_id"].ToString() });
                }
                reader.Close();

                model.Email = await UserManager.GetEmailAsync(User.Identity.GetUserId());
                model.OrgForms = selListOrgForms;
                model.Collegiums = selListCollegiums;
                model.SubjectId = subjId;

                //get Phones
                query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 1;";
                reader = Provider.RunQuery(query);
                var phones = new List<SubjectPhone>();

                while (reader.Read())
                {
                    var phone = new SubjectPhone();
                    phone.Id = int.Parse(reader["person_phone_id"].ToString());
                    phone.SubjectId = int.Parse(reader["subj_id"].ToString());
                    //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                    //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());
                    phone.Number = reader["subj_phone_number"].ToString();

                    phones.Add(phone);
                }
                reader.Close();
                model.PhoneNumbers = phones;

                //get Cell Phones
                query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 2;";
                reader = Provider.RunQuery(query);
                var CellPhones = new List<SubjectPhone>();

                while (reader.Read())
                {
                    var phone = new SubjectPhone();
                    phone.Id = int.Parse(reader["person_phone_id"].ToString());
                    phone.SubjectId = int.Parse(reader["subj_id"].ToString());
                    //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                    //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());
                    phone.Number = reader["subj_phone_number"].ToString();

                    CellPhones.Add(phone);
                }
                reader.Close();
                model.CellPhoneNumbers = CellPhones;

                //get Emails
                query = @"SELECT * FROM subj_emails where subj_id = '" + subjId + "';";
                reader = Provider.RunQuery(query);
                var Emails = new List<SubjectEmail>();

                while (reader.Read())
                {
                    var email = new SubjectEmail();
                    email.Id = int.Parse(reader["subj_email_id"].ToString());
                    email.Email = reader["subj_email"].ToString();
                    Emails.Add(email);
                }
                reader.Close();
                model.Emails = Emails;

                //get Addresses
                query = @"SELECT * FROM subj_post_addresses where subj_id = '" + subjId + "';";
                reader = Provider.RunQuery(query);
                var Addresses = new List<SubjectAddress>();
                while (reader.Read())
                {
                    var address = new SubjectAddress();
                    address.Id = int.Parse(reader["post_addr_id"].ToString());
                    address.Address = reader["post_addr_name"].ToString();
                    Addresses.Add(address);
                }
                reader.Close();
                model.Addresses = Addresses;

                return View(model);
            }
            if (count >= 1) // если запрос уже отправлен
            {
                // Get OrgForms list from DB
                query = @"SELECT * FROM public.legal_advise_types;";
                reader = Provider.RunQuery(query);
                var selListOrgForms = new List<SelectListItem>();
                selListOrgForms.Add(new SelectListItem { Text = "", Value = "" });
                while (reader.Read())
                {
                    selListOrgForms.Add(new SelectListItem { Text = reader["legal_advise_type_name_ru"].ToString(), Value = reader["legal_advise_type_id"].ToString() });
                }
                reader.Close();

                // Get Collegiums list from DB
                query = @"SELECT * FROM public.law_collegiums;";
                reader = Provider.RunQuery(query);
                var selListCollegiums = new List<SelectListItem>();
                selListCollegiums.Add(new SelectListItem { Text = "", Value = "" });
                while (reader.Read())
                {
                    selListCollegiums.Add(new SelectListItem { Text = reader["law_collegium_name_ru"].ToString(), Value = reader["law_collegium_id"].ToString() });
                }
                reader.Close();

                // Get Bureaues list from DB
                query = @"SELECT * FROM public.legal_aid_bureaues;";
                reader = Provider.RunQuery(query);
                var selListBureaues = new List<SelectListItem>();
                selListBureaues.Add(new SelectListItem { Text = "", Value = "" });
                while (reader.Read())
                {
                    selListBureaues.Add(new SelectListItem { Text = reader["legal_aid_bureau_name_ru"].ToString(), Value = reader["legal_aid_bureau_id"].ToString() });
                }
                reader.Close();

                model.Email = await UserManager.GetEmailAsync(User.Identity.GetUserId());
                model.OrgForms = selListOrgForms;
                model.Collegiums = selListCollegiums;
                model.SubjectId = subjId;
                model.Bureaues = selListBureaues;

                query = @"SELECT * FROM subjects_law_suppliers where person_id = '" + User.Identity.GetUserId() + "';";
                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    int tempInt;
                    DateTime tempDt;
                    model.RequestId = int.Parse(reader["subj_law_supplier_id"].ToString());
                    model.RequestStatus = int.Parse(reader["subj_law_supplier_status"].ToString());
                    model.FIO = reader["subj_law_supplier_name"].ToString();
                    model.Address = reader["subj_law_supplier_address"].ToString();
                    model.LicenseNumber = reader["subj_law_supplier_lic_num"].ToString();
                    model.LicenseDate = DateTime.Parse(reader["subj_law_supplier_lic_date"].ToString());
                    model.PhoneNumber = reader["subj_law_supplier_phone"].ToString();
                    model.Fax = reader["subj_law_supplier_fax"].ToString();
                    model.Email = reader["subj_law_supplier_email"].ToString();
                    model.WorkingDays = reader["subj_law_supplier_work_days"].ToString();
                    model.Collegia = int.Parse(reader["law_collegium_id"].ToString());
                    model.WorkTime = reader["subj_law_supplier_work_time"].ToString();
                    model.CellPhoneNumber = reader["subj_law_supplier_mobile"].ToString();
                    int orgForma; int.TryParse(reader["law_supp_org_type"].ToString(), out orgForma);
                    model.OrgForma = orgForma;
                    model.Comment = reader["comment"].ToString();
                    model.Bin = reader["subj_law_bin"].ToString();
                    model.Website = reader["subj_law_website"].ToString();
                    tempInt = 1000; int.TryParse(reader["subj_law_consult_id"].ToString(), out tempInt);
                    model.ConsultationId = tempInt;
                    tempInt = 1000; int.TryParse(reader["subj_law_fee_free"].ToString(), out tempInt);
                    model.ShouldPay = tempInt;
                    model.DownPaymentIndebtness = reader["subj_law_down_fee"].ToString();
                    model.MonthlyPaymentIndebtness = reader["subj_law_monthly_fee"].ToString();
                    tempInt = 0; int.TryParse(reader["law_state_aids"].ToString(), out tempInt);
                    model.isGGUP = tempInt;
                    model.GGUPDocNumber = reader["law_state_aid_docnum"].ToString();
                    tempDt = default(DateTime); DateTime.TryParse(reader["law_state_aid_docdate"].ToString(), out tempDt);
                    model.GGUPDocDate = tempDt;
                    tempInt = 0; int.TryParse(reader["subj_law_supp_is_rural"].ToString(), out tempInt);
                    model.IsRural = tempInt;
                }
                reader.Close();

                //get Phones
                query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 1;";
                reader = Provider.RunQuery(query);
                var phones = new List<SubjectPhone>();
                while (reader.Read())
                {
                    var phone = new SubjectPhone();
                    phone.Id = int.Parse(reader["person_phone_id"].ToString());
                    phone.SubjectId = int.Parse(reader["subj_id"].ToString());
                    //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                    //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());
                    phone.Number = reader["subj_phone_number"].ToString();

                    phones.Add(phone);
                }
                reader.Close();
                model.PhoneNumbers = phones;

                //get Cell Phones
                query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 2;";
                reader = Provider.RunQuery(query);
                var CellPhones = new List<SubjectPhone>();
                while (reader.Read())
                {
                    var phone = new SubjectPhone();
                    phone.Id = int.Parse(reader["person_phone_id"].ToString());
                    phone.SubjectId = int.Parse(reader["subj_id"].ToString());
                    //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                    //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());
                    phone.Number = reader["subj_phone_number"].ToString();

                    CellPhones.Add(phone);
                }
                reader.Close();
                model.CellPhoneNumbers = CellPhones;

                //get Emails
                query = @"SELECT * FROM subj_emails where subj_id = '" + subjId + "';";
                reader = Provider.RunQuery(query);
                var Emails = new List<SubjectEmail>();
                while (reader.Read())
                {
                    var email = new SubjectEmail();
                    email.Id = int.Parse(reader["subj_email_id"].ToString());
                    email.Email = reader["subj_email"].ToString();
                    Emails.Add(email);
                }
                reader.Close();
                model.Emails = Emails;

                //get Addresses
                query = @"SELECT * FROM subj_post_addresses where subj_id = '" + subjId + "';";
                reader = Provider.RunQuery(query);
                var Addresses = new List<SubjectAddress>();
                while (reader.Read())
                {
                    var address = new SubjectAddress();
                    address.Id = int.Parse(reader["post_addr_id"].ToString());
                    address.Address = reader["post_addr_name"].ToString();
                    Addresses.Add(address);
                }
                reader.Close();
                model.Addresses = Addresses;

                return View(model);
            }
            return View("Error");
        }

        public async Task<ActionResult> Lawyer(string id)
        {
            var model = new PersonalViewModel();

            var user_role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);

            if (user_role == 4)
            {
                var query = @"SELECT person_id, subj_id from subjects_law_suppliers where subj_law_supplier_id = " + id + ";";
                var reader = Provider.RunQuery(query);
                var userId = string.Empty;
                var subjId = string.Empty;
                var collId = string.Empty;
                while (reader.Read())
                {
                    userId = reader["person_id"].ToString();
                    subjId = reader["subj_id"].ToString();
                }
                reader.Close();

                query = @"SELECT law_collegium_id from subjects_law_suppliers where person_id = '" + User.Identity.GetUserId() + "';";
                reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    collId = reader["law_collegium_id"].ToString();
                }
                reader.Close();

                query = @"SELECT t1.*, t2.*, t3.doc_guid, t4.doc_widget_id, t4.doc_img_scan, t5.*,
                                t6.law_collegium_name_ru,  t6.law_collegium_name_kz,
                                t7.legal_advise_type_name_ru, t7.legal_advise_type_name_kz,
                                t8.legal_aid_bureau_code

                                FROM public.persons t1

                                left join public.""AspNetUsers"" t2 on t2.""Id"" = t1.user_id
                                left join public.subjects t3 on t1.subj_id = t3.subj_id
                                left join public.docimages t4 on t4.doc_guid = t3.doc_guid
                                left join public.subjects_law_suppliers t5 on t5.person_id = t3.user_id
                                left join public.law_collegiums t6 on t6.law_collegium_id = t5.law_collegium_id
                                left join public.legal_advise_types t7 on t7.legal_advise_type_id = t5.law_supp_org_type
                                left join public.legal_aid_bureaues t8 on t8.legal_aid_bureau_id = t5.subj_law_consult_id
                                

                                WHERE t1.user_id ='" + userId + "' and t5.law_collegium_id = " + collId + ";";


                var dtMain = Provider.RunQueryDataTable(query);

                DataTable dt;

                for (var j = 0; j < dtMain.Rows.Count; j++)
                {
                    model.Name = dtMain.Rows[j].Field<string>("given_name");
                    model.Surname = dtMain.Rows[j].Field<string>("last_name");
                    model.Middlename = dtMain.Rows[j].Field<string>("middle_name");
                    model.Name_KZ = dtMain.Rows[j].Field<string>("given_name_kz");
                    model.Surname_KZ = dtMain.Rows[j].Field<string>("last_name_kz");
                    model.Middlename_KZ = dtMain.Rows[j].Field<string>("middle_name_kz");
                    model.Country = dtMain.Rows[j].Field<string>("country");
                    model.Address = dtMain.Rows[j].Field<string>("post_address");
                    model.Phone = dtMain.Rows[j].Field<string>("PhoneNumber");
                    model.Email = dtMain.Rows[j].Field<string>("Email");
                    model.PersonalCode = dtMain.Rows[j].Field<string>("person_code");
                    model.Birthday = dtMain.Rows[j].Field<DateTime?>("date_of_birth");
                    model.DocGuid = dtMain.Rows[j].Field<string>("doc_guid");
                    model.Gender = dtMain.Rows[j].Field<string>("gender");
                    model.Residency = dtMain.Rows[j].Field<short?>("residency") ?? 0;
                    model.UserID = dtMain.Rows[j].Field<string>("user_id");

                    var lawyer = new LawyerStatusRequestViewModel();
                    lawyer.RequestStatus = dtMain.Rows[j].Field<short?>("subj_law_supplier_status") ?? 0;
                    if (lawyer.RequestStatus == 1 || lawyer.RequestStatus == 0 || lawyer.RequestStatus == 5)
                    {
                        lawyer.RequestId = dtMain.Rows[j].Field<int>("subj_law_supplier_id");
                        lawyer.FIO = dtMain.Rows[j].Field<string>("subj_law_supplier_name");
                        lawyer.Address = dtMain.Rows[j].Field<string>("subj_law_supplier_address");
                        lawyer.LicenseNumber = dtMain.Rows[j].Field<string>("subj_law_supplier_lic_num");
                        lawyer.LicenseDate = dtMain.Rows[j].Field<DateTime?>("subj_law_supplier_lic_date");
                        lawyer.PhoneNumber = dtMain.Rows[j].Field<string>("subj_law_supplier_phone");
                        lawyer.Fax = dtMain.Rows[j].Field<string>("subj_law_supplier_fax");
                        lawyer.Email = dtMain.Rows[j].Field<string>("subj_law_supplier_email");
                        lawyer.WorkingDays = dtMain.Rows[j].Field<string>("subj_law_supplier_work_days");
                        lawyer.WorkTime = dtMain.Rows[j].Field<string>("subj_law_supplier_work_time");
                        lawyer.CellPhoneNumber = dtMain.Rows[j].Field<string>("subj_law_supplier_mobile");
                        lawyer.PhoneNumber = dtMain.Rows[j].Field<string>("subj_law_supplier_phone");
                        lawyer.Collegia = dtMain.Rows[j].Field<int?>("law_collegium_id") ?? 0;
                        lawyer.OrgForma = dtMain.Rows[j].Field<int?>("law_supp_org_type") ?? 0;
                        lawyer.CollegiaName = dtMain.Rows[j].Field<string>("law_collegium_name_ru");
                        lawyer.OrgFormaName = dtMain.Rows[j].Field<string>("legal_advise_type_name_ru");
                        lawyer.isGGUP = dtMain.Rows[j].Field<int?>("law_state_aids") ?? 1000;
                        lawyer.GGUPDocNumber = dtMain.Rows[j].Field<string>("law_state_aid_docnum");
                        lawyer.GGUPDocDate = dtMain.Rows[j].Field<DateTime?>("law_state_aid_docdate");
                        lawyer.GGUPDocDate = dtMain.Rows[j].Field<DateTime?>("law_state_aid_docdate");
                        lawyer.Bin = dtMain.Rows[j].Field<string>("subj_law_bin");
                        lawyer.Website = dtMain.Rows[j].Field<string>("subj_law_website");
                        lawyer.ConsultationId = dtMain.Rows[j].Field<int?>("subj_law_consult_id") ?? 203;
                        lawyer.ShouldPay = dtMain.Rows[j].Field<int?>("subj_law_fee_free") ?? 1000;
                        lawyer.DownPaymentIndebtness = dtMain.Rows[j].Field<string>("subj_law_down_fee");
                        lawyer.MonthlyPaymentIndebtness = dtMain.Rows[j].Field<string>("subj_law_monthly_fee");
                        lawyer.IsRural = dtMain.Rows[j].Field<int?>("subj_law_supp_is_rural");
                        lawyer.GGUPNextYear = dtMain.Rows[j].Field<int?>("law_state_aid_application").HasValue
                            ? dtMain.Rows[j].Field<int?>("law_state_aid_application").Value.ToString()
                            : "0";
                        lawyer.ContractOffer = dtMain.Rows[j].Field<string>("subj_law_contract_offer");
                        lawyer.ContractOfferDate = dtMain.Rows[j]
                            .Field<DateTime?>("subj_law_contract_date")
                            .HasValue
                            ? dtMain.Rows[j]
                                .Field<DateTime?>("subj_law_contract_date")
                                .Value.ToString("dd/MM/yyyy")
                            : "00.00.0000";

                        ViewBag.Bureau = dtMain.Rows[j].Field<string>("legal_aid_bureau_code");
                    }

                    //get Phones
                    query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 1;";
                    dt = Provider.RunQueryDataTable(query);
                    var phones = new List<SubjectPhone>();
                    for (var i = 0; i < dt.Rows.Count; i++)
                    {
                        var phone = new SubjectPhone();
                        phone.Id = dt.Rows[i].Field<int>("person_phone_id");
                        phone.SubjectId = dt.Rows[i].Field<int>("subj_id");
                        //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                        //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());
                        phone.Number = dt.Rows[i].Field<string>("subj_phone_number");

                        phones.Add(phone);
                    }
                    model.PhoneNumbers = phones;

                    //get Cell Phones
                    query = @"SELECT * FROM subj_phones where subj_id = '" + subjId + "' and subj_phone_type = 2;";
                    dt = Provider.RunQueryDataTable(query);
                    var CellPhones = new List<SubjectPhone>();
                    for (var i = 0; i < dt.Rows.Count; i++)
                    {
                        var phone = new SubjectPhone();
                        phone.Id = dt.Rows[i].Field<int>("person_phone_id");
                        phone.SubjectId = dt.Rows[i].Field<int>("subj_id");
                        //phone.Status = Int32.Parse(reader["subj_phone_status"].ToString());
                        //phone.Type = Int32.Parse(reader["subj_phone_type"].ToString());
                        phone.Number = dt.Rows[i].Field<string>("subj_phone_number");

                        CellPhones.Add(phone);
                    }
                    model.CellPhoneNumbers = CellPhones;

                    //get Emails
                    query = @"SELECT * FROM subj_emails where subj_id = '" + subjId + "';";
                    dt = Provider.RunQueryDataTable(query);
                    var Emails = new List<SubjectEmail>();
                    for (var i = 0; i < dt.Rows.Count; i++)
                    {
                        var email = new SubjectEmail();
                        email.Id = dt.Rows[i].Field<int>("subj_email_id");
                        email.Email = dt.Rows[i].Field<string>("subj_email");
                        Emails.Add(email);
                    }
                    model.Emails = Emails;

                    //get Addresses
                    query = @"SELECT * FROM subj_post_addresses where subj_id = '" + subjId + "';";
                    dt = Provider.RunQueryDataTable(query);
                    var Addresses = new List<SubjectAddress>();
                    var cl = new HttpClient();
                    var resStr = string.Empty;
                    JObject jsn;
                    var strv = string.Empty;
                    for (var i = 0; i < dt.Rows.Count; i++)
                    {
                        var address = new SubjectAddress();
                        address.Id = dt.Rows[i].Field<int>("post_addr_id");
                        address.Address = dt.Rows[i].Field<string>("post_addr_name");
                        //get coordinates with ',' symbol
                        resStr = await cl.GetStringAsync("https://geocode-maps.yandex.ru/1.x/?format=json&geocode=" + dt.Rows[i].Field<string>("post_addr_name") + "&results=1");
                        jsn = JObject.Parse(resStr);

                        try
                        {
                            strv = jsn["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]["Point"]["pos"].ToString();
                            strv = strv.Replace(" ", " , ");
                            var str1 = strv.Substring(0, 9);
                            var str2 = strv.Substring(11, 9);
                            strv = str2 + ", " + str1;
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                            strv = string.Empty;
                        }
                        address.Geocode = strv;
                        Addresses.Add(address);
                    }
                    model.Addresses = Addresses;

                    model.lawyer = lawyer;
                }
                reader.Close();

                // Get OrgForms list from DB
                query = @"SELECT * FROM public.legal_advise_types;";
                reader = Provider.RunQuery(query);
                var selListOrgForms = new List<SelectListItem>();
                selListOrgForms.Add(new SelectListItem { Text = "", Value = "" });
                while (reader.Read())
                {
                    selListOrgForms.Add(new SelectListItem { Text = reader["legal_advise_type_name_ru"].ToString(), Value = reader["legal_advise_type_id"].ToString() });
                }
                reader.Close();

                // Get Collegiums list from DB
                query = @"SELECT * FROM public.law_collegiums;";
                reader = Provider.RunQuery(query);
                var selListCollegiums = new List<SelectListItem>();
                selListCollegiums.Add(new SelectListItem { Text = "", Value = "" });
                while (reader.Read())
                {
                    selListCollegiums.Add(new SelectListItem { Text = reader["law_collegium_name_ru"].ToString(), Value = reader["law_collegium_id"].ToString() });
                }
                reader.Close();

                // Get Bureaues list from DB
                query = @"SELECT * FROM public.legal_aid_bureaues where law_collegium_id = " + collId + " or legal_aid_bureau_code = '0';";
                reader = Provider.RunQuery(query);
                var selListBureaues = new List<SelectListItem>();
                selListBureaues.Add(new SelectListItem { Text = "", Value = "" });
                while (reader.Read())
                {
                    selListBureaues.Add(new SelectListItem { Text = reader["legal_aid_bureau_name_ru"].ToString(), Value = reader["legal_aid_bureau_id"].ToString() });
                }
                reader.Close();

                model.lawyer.Collegiums = selListCollegiums;
                model.lawyer.OrgForms = selListOrgForms;
                model.lawyer.Bureaues = selListBureaues;

                try { ViewBag.Message = TempData["Message"] != null ? TempData["Message"].ToString() : null; }
                catch (NullReferenceException) { ViewBag.Message = null; }

                model.PhoneNumber = await UserManager.GetPhoneNumberAsync(User.Identity.GetUserId());
                model.TwoFactor = await UserManager.GetTwoFactorEnabledAsync(User.Identity.GetUserId());

                //get coordinates with ',' symbol
                var client = new HttpClient();
                var responseString = await client.GetStringAsync("https://geocode-maps.yandex.ru/1.x/?format=json&geocode=" + model.Address + "&results=1");
                var json = JObject.Parse(responseString);
                var str = string.Empty;
                try
                {
                    str = json["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]["Point"]["pos"].ToString();
                    str = str.Replace(" ", " , ");
                    var str1 = str.Substring(0, 9);
                    var str2 = str.Substring(11, 9);
                    str = str2 + ", " + str1;
                }
                catch (ArgumentOutOfRangeException)
                {
                    //str = "51.1554792,71.4925812,15";
                    str = string.Empty;
                }


                ViewBag.Map = str;


                return View(model);
            }

            ViewBag.Message = "Недостаточно прав!";
            return View("Error");
        }

        public ActionResult LawyerRequest(string id)
        {
            var model = new PersonalViewModel();

            var user_role = int.Parse(((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value);

            if (user_role == 4)
            {
                ViewBag.RequestId = id;
                var query = @"SELECT t1.*, t2.subj_id from lawyer_requests t1 JOIN subjects t2 on t1.user_id = t2.user_id  where request_id = " + id + ";";
                var reader = Provider.RunQuery(query);
                var userId = string.Empty;
                var subjId = string.Empty;
                var collId = string.Empty;

                while (reader.Read())
                {
                    userId = reader["user_id"].ToString();
                    subjId = reader["subj_id"].ToString();
                    model.RequestStatus = reader.GetFieldValueOrDefault<int>("request_status");
                }
                reader.Close();

                query = @"SELECT law_collegium_id from subjects_law_suppliers where person_id = '" + User.Identity.GetUserId() + "';";
                reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    collId = reader["law_collegium_id"].ToString();

                }
                reader.Close();

                query = @"SELECT t1.*, t2.*
                                FROM public.subjects_law_suppliers t1
                                JOIN persons t2 ON t1.person_id = t2.user_id
                                WHERE t1.person_id ='" + userId + "';";

                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    model.Name = reader["given_name"].ToString();
                    model.Surname = reader["last_name"].ToString();
                    model.Middlename = reader["middle_name"].ToString();
                    model.PersonalCode = reader["person_code"].ToString();
                    model.Birthday = GetDateTimeFromString(reader["date_of_birth"].ToString());
                    model.Gender = reader["gender"].ToString();
                    model.UserID = reader["user_id"].ToString();
                    model.Address = reader["post_address"].ToString();

                    var lawyer = new LawyerStatusRequestViewModel
                    {
                        FIO = reader["subj_law_supplier_name"].ToString(),
                        LicenseNumber = reader["subj_law_supplier_lic_num"].ToString(),
                        LicenseDate = GetDateTimeFromString(reader["subj_law_supplier_lic_date"].ToString()),
                        WorkingDays = reader["subj_law_supplier_work_days"].ToString(),
                        WorkTime = reader["subj_law_supplier_work_time"].ToString(),
                        OrgForma = GetIntFromString(reader["law_supp_org_type"].ToString()),
                        Bin = reader["subj_law_bin"].ToString(),
                        ConsultationId = GetIntFromString(reader["subj_law_consult_id"].ToString()),
                        Address = reader["subj_law_supplier_address"].ToString(),
                        CellPhoneNumber = reader["subj_law_supplier_mobile"].ToString(),
                        isGGUP = reader.GetFieldValueOrDefault<int>("law_state_aids"),
                        ShouldPay = reader.GetFieldValueOrDefault<int>("subj_law_fee_free"),
                        PhoneNumber = reader["subj_law_supplier_phone"].ToString()
                    };

                    model.lawyer = lawyer;
                }
                reader.Close();

                // Get OrgForms list from DB
                query = @"SELECT * FROM public.legal_advise_types;";
                reader = Provider.RunQuery(query);

                var selListOrgForms = new List<SelectListItem> { new SelectListItem { Text = "", Value = "" } };

                while (reader.Read())
                {
                    selListOrgForms.Add(new SelectListItem { Text = reader["legal_advise_type_name_ru"].ToString(), Value = reader["legal_advise_type_id"].ToString() });
                }

                reader.Close();

                // Get Collegiums list from DB
                query = @"SELECT * FROM public.law_collegiums;";
                reader = Provider.RunQuery(query);

                var selListCollegiums = new List<SelectListItem> { new SelectListItem { Text = "", Value = "" } };

                while (reader.Read())
                {
                    selListCollegiums.Add(new SelectListItem { Text = reader["law_collegium_name_ru"].ToString(), Value = reader["law_collegium_id"].ToString() });
                }

                reader.Close();

                // Get Bureaues list from DB
                query = @"SELECT * FROM public.legal_aid_bureaues where law_collegium_id = " + collId + " or legal_aid_bureau_code = '0';";
                reader = Provider.RunQuery(query);

                var selListBureaues = new List<SelectListItem> { new SelectListItem { Text = "", Value = "" } };

                while (reader.Read())
                {
                    selListBureaues.Add(new SelectListItem { Text = reader["legal_aid_bureau_name_ru"].ToString(), Value = reader["legal_aid_bureau_id"].ToString() });
                }

                reader.Close();

                model.lawyer.Collegiums = selListCollegiums;
                model.lawyer.OrgForms = selListOrgForms;
                model.lawyer.Bureaues = selListBureaues;

                ViewBag.Message = TempData["Message"]?.ToString();
                
                var modelType = (int)ModelType.PersonalViewModel;
                query = @"SELECT * FROM public.change_history WHERE id_value = '" + userId + "' AND model_type = " + modelType + " AND status = 1;";
                reader = Provider.RunQuery(query);
                var newValue = new List<SelectListItem>();
                while (reader.Read())
                {
                    newValue.Add(new SelectListItem { Text = reader["model_field"].ToString(), Value = reader["new_value"].ToString() });
                }
                reader.Close();
                var jValue = JsonConvert.SerializeObject(newValue, Formatting.None);
                ViewBag.NewValue = jValue;

                return View(model);
            }

            ViewBag.Message = "Недостаточно прав!";
            return View("Error");
        }

        public ActionResult LawyerAllRequests(LawyerAllRequestsViewModel model)
        {
            var role = GetRoleFromDb();

            if (role != "4")
            {
                ViewBag.Message = "Недостаточно прав!";
                return View("Error");
            }
            var query = $@"SELECT
	t1.*,
	t2.subj_law_supplier_name as check_request,
    p.given_name,
    p.last_name,
    p.middle_name,
    n.*,
    n1.notification_creation_date as request_creation_date
FROM subjects_law_suppliers t1
INNER JOIN persons p ON t1.person_id = p.user_id 
LEFT JOIN lawyer_requests t2 ON t1.person_id = t2.user_id 
LEFT OUTER JOIN notifications n ON n.notification_type = {(int)NotificationType.RequestApprovalProfileRejected} and n.notification_object_id = t1.subj_law_supplier_id 
LEFT OUTER JOIN notifications n1 ON n1.notification_type = {(int)NotificationType.RequestApprovalProfileRejected} and n1.notification_object_id = t1.subj_law_supplier_id AND n.notification_Id < n1.notification_Id
WHERE n1.notification_Id is null and t2.subj_law_supplier_name IS NULL
    and t1.subj_law_supplier_status in (0,1,5)
	and law_collegium_id = 
	(SELECT law_collegium_id
	FROM subjects_law_suppliers
	WHERE person_id = '{User.Identity.GetUserId()}')
ORDER BY subj_law_supplier_status;";

            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                int.TryParse(reader["law_supp_org_type"].ToString(), out var orgForma);

                var request = new LawyerStatusRequestViewModel
                {
                    RequestId = int.Parse(reader["subj_law_supplier_id"].ToString()),
                    RequestStatus = int.Parse(reader["subj_law_supplier_status"].ToString()),
                    FIO = reader["subj_law_supplier_name"].ToString(),
                    Address = reader["subj_law_supplier_address"].ToString(),
                    LicenseNumber = reader["subj_law_supplier_lic_num"].ToString(),
                    PhoneNumber = reader["subj_law_supplier_phone"].ToString(),
                    Fax = reader["subj_law_supplier_fax"].ToString(),
                    Email = reader["subj_law_supplier_email"].ToString(),
                    WorkingDays = reader["subj_law_supplier_work_days"].ToString(),
                    WorkTime = reader["subj_law_supplier_work_time"].ToString(),
                    CellPhoneNumber = reader["subj_law_supplier_mobile"].ToString(),
                    OrgForma = orgForma,
                    PersonId = reader["person_id"].ToString(),
                    LicenseDate = reader.GetFieldValueOrDefault<DateTime>("subj_law_supplier_lic_date"),
                                        GivenName = reader["given_name"].ToString(),
                    LastName = reader["last_name"].ToString(),
                    MiddleName = reader["middle_name"].ToString(),
                    RequestAnswer = string.Empty
                };

                if (request.RequestStatus == 5)
                {
                    request.RequestAnswer = reader["notification_comment"].ToString();
                    request.RequestAnswerDate = GetDateTimeFromString(reader["notification_creation_date"].ToString());
                }

                model.Requests.Add(request);
            }

            reader.Close();
            ViewBag.Message = TempData["Message"]?.ToString();
            
            return View(model);
        }

        public ActionResult AllCollegialLawyers(LawyerAllRequestsViewModel model)
        {
            lock (Provider.Locker)
            {
                var role = GetRoleFromDb();

                if (role != "4")
                {
                    ViewBag.Message = "Недостаточно прав!";
                    return View("Error");
                }
                
                //get current Collegium ID
                var collegiumId = string.Empty;
                var query = @"SELECT law_collegium_id
                                  FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";
                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    collegiumId = reader["law_collegium_id"].ToString();
                }

                reader.Close();

                query = @"SELECT t1.*, r.given_name, r.last_name, r.middle_name, n.*, lat.legal_advise_type_name_ru
                    FROM subjects_law_suppliers t1 
                    left join public.legal_advise_types lat on lat.legal_advise_type_id = t1.law_supp_org_type
                    INNER JOIN persons r ON t1.person_id = r.user_id 
                    LEFT JOIN ""AspNetUserClaims"" t2 ON t1.person_id = t2.""UserId""
                    LEFT OUTER JOIN notifications n ON n.notification_type = " +
                        (int) NotificationType.AccountLockedTka +
                        @" and n.notification_object_id = t1.subj_law_supplier_id 
                    LEFT OUTER JOIN notifications n1 ON n1.notification_type = " +
                        (int) NotificationType.AccountLockedTka +
                        @" and n1.notification_object_id = t1.subj_law_supplier_id 
                        AND n.notification_Id < n1.notification_Id
                    WHERE n1.notification_Id is null and law_collegium_id = " + collegiumId + " " +
                        @" AND t2.""ClaimType"" = 'user_role' 
                    AND (subj_law_supplier_status = 1 OR (subj_law_supplier_status = 5 AND t2.""ClaimValue"" = '-100') OR (subj_law_supplier_status = 0 AND t2.""ClaimValue"" = '2'));";

                reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    var request =
                        new LawyerStatusRequestViewModel
                        {
                            RequestId = int.Parse(reader["subj_law_supplier_id"].ToString()),
                            LawyerStatus = int.Parse(reader["subj_law_supplier_status"].ToString()),
                            FIO = reader["subj_law_supplier_name"].ToString(),
                            Address = reader["subj_law_supplier_address"].ToString(),
                            LicenseNumber = reader["subj_law_supplier_lic_num"].ToString(),
                            LicenseDate = GetDateTimeFromString(reader["subj_law_supplier_lic_date"].ToString()),
                            PhoneNumber = reader["subj_law_supplier_phone"].ToString(),
                            Fax = reader["subj_law_supplier_fax"].ToString(),
                            Email = reader["subj_law_supplier_email"].ToString(),
                            WorkingDays = reader["subj_law_supplier_work_days"].ToString(),
                            WorkTime = reader["subj_law_supplier_work_time"].ToString(),
                            CellPhoneNumber = reader["subj_law_supplier_mobile"].ToString(),
                            isGGUP = GetIntFromString(reader["law_state_aids"].ToString()),
                            OrgForma = GetIntFromString(reader["law_supp_org_type"].ToString()),
                            OrgFormaName = reader["legal_advise_type_name_ru"].ToString(),
                            PersonId = reader["person_id"].ToString(),
                            GivenName = reader["given_name"].ToString(),
                            LastName = reader["last_name"].ToString(),
                            MiddleName = reader["middle_name"].ToString(),
                            RequestAnswer = string.Empty,
                            RegistrationDate = reader.GetFieldValueOrDefault<DateTime>("subj_law_reg_date")
                        };

                    if (request.LawyerStatus == 5)
                    {
                        request.RequestAnswer = reader["notification_comment"].ToString();
                        request.RequestAnswerDate =
                            GetDateTimeFromString(reader["notification_creation_date"].ToString());
                    }

                    model.Requests.Add(request);
                }

                reader.Close();

                ViewBag.Message = TempData["Message"]?.ToString();
                
                return View(model);
            }
        }

        public ActionResult AllGGUPLawyers(LawyerAllRequestsViewModel model)
        {
            var role = GetRoleFromDb();

            if (role != "4")
            {
                ViewBag.Message = "Недостаточно прав!";
                return View("Error");
            }
            //get current Collegium ID
            var collegiumId = string.Empty;
            var query = @"SELECT law_collegium_id
                                  FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);
            while (reader.Read())
            {
                collegiumId = reader["law_collegium_id"].ToString();
            }
            reader.Close();

            query = $@"SELECT 
	t1.*,
	t2.legal_advise_type_name_ru,
	r.given_name, r.last_name, r.middle_name,
	lab.legal_aid_bureau_name_ru,
	coalesce(subj_law_supplier_address, '') || coalesce(', ' || addr.addr_name, '') as address,
	coalesce(subj_law_supplier_phone,'') || coalesce(', ' || subj_law_supplier_mobile) || coalesce(', ' || ph.phone_name, '')  as phone
FROM subjects_law_suppliers t1 
INNER JOIN persons r ON t1.person_id = r.user_id
left join public.legal_advise_types t2 on t2.legal_advise_type_id = t1.law_supp_org_type
join legal_aid_bureaues lab on t1.subj_law_consult_id = lab.legal_aid_bureau_id
left outer join (select subj_id, string_agg(post_addr_name, ', ') as addr_name from subj_post_addresses group by subj_id) addr on addr.subj_id = t1.subj_id
left outer join (select subj_id, string_agg(subj_phone_number, ', ') as phone_name from subj_phones group by subj_id) ph on ph.subj_id = t1.subj_id
WHERE t1.law_collegium_id = {collegiumId} and (subj_law_supplier_status = 1 or subj_law_supplier_status = 5) and law_state_aids = 1;";
            reader = Provider.RunQuery(query);
            while (reader.Read())
            {
                var request =
                    new LawyerStatusRequestViewModel
                    {
                        RequestId = int.Parse(reader["subj_law_supplier_id"].ToString()),
                        RequestStatus = int.Parse(reader["subj_law_supplier_status"].ToString()),
                        FIO = reader["subj_law_supplier_name"].ToString(),
                        Address = reader["address"].ToString(),
                        LicenseNumber = reader["subj_law_supplier_lic_num"].ToString(),
                        LicenseDate = GetDateTimeFromString(reader["subj_law_supplier_lic_date"].ToString()),
                        PhoneNumber = reader["phone"].ToString(),
                        Fax = reader["subj_law_supplier_fax"].ToString(),
                        Email = reader["subj_law_supplier_email"].ToString(),
                        OrgFormaName = reader["legal_advise_type_name_ru"].ToString(),
                        WorkingDays = reader["subj_law_supplier_work_days"].ToString(),
                        WorkTime = reader["subj_law_supplier_work_time"].ToString(),
                        CellPhoneNumber = reader["subj_law_supplier_mobile"].ToString(),
                        isGGUP = GetIntFromString(reader["law_state_aids"].ToString()),
                        OrgForma = GetIntFromString(reader["law_supp_org_type"].ToString()),
                        GGUPDocNumber = reader["law_state_aid_docnum"].ToString(),
                        GGUPDocDate = GetDateTimeFromString(reader["law_state_aid_docdate"].ToString()),
                        PersonId = reader["person_id"].ToString(),
                        GivenName = reader["given_name"].ToString(),
                        LastName = reader["last_name"].ToString(),
                        MiddleName = reader["middle_name"].ToString(),
                        CollegiaName = reader["legal_aid_bureau_name_ru"].ToString()
                    };
                model.Requests.Add(request);
            }
            reader.Close();

            ViewBag.Message = TempData["Message"]?.ToString();

            return View(model);
        }

        public ActionResult AllGGUPNextYearLawyers(LawyerAllRequestsViewModel model)
        {
            var role = GetRoleFromDb();

            if (role != "4")
            {
                ViewBag.Message = "Недостаточно прав!";
                return View("Error");
            }
            //get current Collegium ID
            var collegiumId = string.Empty;
            var query = @"SELECT law_collegium_id
                                  FROM subjects_law_suppliers
                                 WHERE person_id = '" + User.Identity.GetUserId() + "';";
            var reader = Provider.RunQuery(query);
            while (reader.Read())
            {
                collegiumId = reader["law_collegium_id"].ToString();
            }
            reader.Close();

            query = $@"SELECT 
	t1.*,
	t2.legal_advise_type_name_ru,
	r.given_name, r.last_name, r.middle_name,
	lab.legal_aid_bureau_name_ru,
	coalesce(subj_law_supplier_address, '') || coalesce(', ' || addr.addr_name, '') as address,
	coalesce(subj_law_supplier_phone,'') || coalesce(', ' || subj_law_supplier_mobile) || coalesce(', ' || ph.phone_name, '')  as phone
FROM subjects_law_suppliers t1 
INNER JOIN persons r ON t1.person_id = r.user_id
left join public.legal_advise_types t2 on t2.legal_advise_type_id = t1.law_supp_org_type
join legal_aid_bureaues lab on t1.subj_law_consult_id = lab.legal_aid_bureau_id
left outer join (select subj_id, string_agg(post_addr_name, ', ') as addr_name from subj_post_addresses group by subj_id) addr on addr.subj_id = t1.subj_id
left outer join (select subj_id, string_agg(subj_phone_number, ', ') as phone_name from subj_phones group by subj_id) ph on ph.subj_id = t1.subj_id
WHERE t1.law_collegium_id = {collegiumId} and (subj_law_supplier_status = 1 or subj_law_supplier_status = 5) and law_state_aid_application = 1;";

            reader = Provider.RunQuery(query);
            while (reader.Read())
            {
                var request =
                    new LawyerStatusRequestViewModel
                    {
                        RequestId = int.Parse(reader["subj_law_supplier_id"].ToString()),
                        RequestStatus = int.Parse(reader["subj_law_supplier_status"].ToString()),
                        FIO = reader["subj_law_supplier_name"].ToString(),
                        Address = reader["address"].ToString(),
                        LicenseNumber = reader["subj_law_supplier_lic_num"].ToString(),
                        LicenseDate = GetDateTimeFromString(reader["subj_law_supplier_lic_date"].ToString()),
                        PhoneNumber = reader["phone"].ToString(),
                        Fax = reader["subj_law_supplier_fax"].ToString(),
                        Email = reader["subj_law_supplier_email"].ToString(),
                        OrgFormaName = reader["legal_advise_type_name_ru"].ToString(),
                        WorkingDays = reader["subj_law_supplier_work_days"].ToString(),
                        WorkTime = reader["subj_law_supplier_work_time"].ToString(),
                        CellPhoneNumber = reader["subj_law_supplier_mobile"].ToString(),
                        isGGUP = GetIntFromString(reader["law_state_aids"].ToString()),
                        OrgForma = GetIntFromString(reader["law_supp_org_type"].ToString()),
                        GGUPDocNumber = reader["law_state_aid_docnum"].ToString(),
                        GGUPDocDate = GetDateTimeFromString(reader["law_state_aid_docdate"].ToString()),
                        PersonId = reader["person_id"].ToString(),
                        GivenName = reader["given_name"].ToString(),
                        LastName = reader["last_name"].ToString(),
                        MiddleName = reader["middle_name"].ToString(),
                        CollegiaName = reader["legal_aid_bureau_name_ru"].ToString()
                    };
                model.Requests.Add(request);
            }
            reader.Close();

            try { ViewBag.Message = TempData["Message"] != null ? TempData["Message"].ToString() : null; }
            catch (NullReferenceException) { ViewBag.Message = null; }

            return View(model);
        }

        private int AddLawyerStatusRequestDb(LawyerStatusRequestViewModel model)
        {
            return Provider.RunScalarStoredProcedure("add_lawyer_status_request",
                model.FIO,
                model.Address,
                User.Identity.GetUserId(),
                model.LicenseNumber,
                model.LicenseDate,
                model.PhoneNumber,
                model.CellPhoneNumber,
                model.Fax,
                model.Email,
                model.WorkingDays,
                model.WorkTime,
                model.OrgForma,
                model.Collegia,
                model.isGGUP ?? 0,
                model.GGUPDocNumber,
                model.GGUPDocDate ?? DateTime.MinValue,
                model.SubjectId,
                model.Website,
                model.Bin,
                model.ConsultationId ?? 203,
                model.ShouldPay ?? 0,
                string.IsNullOrEmpty(model.DownPaymentIndebtness) ? 0 : Convert.ToInt32(model.DownPaymentIndebtness),
                string.IsNullOrEmpty(model.MonthlyPaymentIndebtness) ? 0 : Convert.ToInt32(model.MonthlyPaymentIndebtness));
        }

        [HttpPost]
        public ActionResult AddLawyerStatusRequest(LawyerStatusRequestViewModel model)
        {
            var results = AddLawyerStatusRequestDb(model);

            if (results >= 0)
            {
                TempData["Message"] = "Информация была изменена";
                var logText = "Отправлена заявка на получение статуса клиента пользователем с user_id = " + User.Identity.GetUserId();
                results = Provider.RunScalarStoredProcedure("add_to_log", logText, "Статус клиента - заявка");
            }
            else
                TempData["Message"] = "Возникла ошибка";

            return RedirectToAction("LawyerStatusRequest", "Account");
        }

        [HttpPost]
        public ActionResult UpdateLawyerStatusRequest(LawyerStatusRequestViewModel model)
        {
            var subjId = ((ClaimsIdentity)User.Identity).Claims.Where(c => c.Type == "subj_id").First().Value;
            var results = Provider.RunScalarStoredProcedure("update_lawyer_status_request", model.FIO, User.Identity.GetUserId(), model.LicenseNumber, model.LicenseDate, model.Fax,
                model.WorkingDays, model.WorkTime, model.OrgForma, model.Collegia, model.isGGUP, model.RequestId, model.GGUPDocNumber, model.GGUPDocDate, subjId, model.Website, model.Bin,
                model.ConsultationId, model.ShouldPay, model.DownPaymentIndebtness, model.MonthlyPaymentIndebtness);

            if (results >= 0)
            {
                TempData["Message"] = "Информация была изменена";
                var logText = "Отправлена заявка на получение статуса клиента пользователем с user_id = " + User.Identity.GetUserId();
                results = Provider.RunScalarStoredProcedure("add_to_log", logText, "Статус клиента - заявка");
            }
            else
                TempData["Message"] = "Возникла ошибка";

            return RedirectToAction("LawyerStatusRequest", "Account");
        }

        [HttpPost]
        public ActionResult ApproveLawyerRequest(int id)
        {
            lock (Provider.Locker)
            {
                //Get person Id from Request
                var personId = string.Empty;
                var query = @"SELECT person_id
                           from subjects_law_suppliers
                         WHERE subj_law_supplier_id = " + id + ";";

                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    personId = reader["person_id"].ToString();
                }
                reader.Close();

                //Set status in subjects_law_suppliers
                query = @"UPDATE public.subjects_law_suppliers
                           SET subj_law_supplier_status=1, subj_law_reg_date = current_timestamp
                         WHERE subj_law_supplier_id = " + id + ";";

                Provider.RunNonQuery(query);

                //Add claims for person_id
                query = "UPDATE \"AspNetUserClaims\" SET \"ClaimValue\"=2 WHERE \"UserId\" = '" + personId + "' AND \"ClaimType\" = 'user_role';";
                Provider.RunNonQuery(query);

                query = "INSERT INTO public.\"AspNetUserClaims\"(\"ClaimType\", \"ClaimValue\", \"UserId\") VALUES('subject_law_supplier_id', '" + id + "', '" + personId + "'); ";
                Provider.RunNonQuery(query);

                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.RequestApprovalProfileAccepted,
                    CreationDate = DateTime.Now,
                    CreatorId = User.Identity.GetUserId(),
                    RecipientId = personId
                });

                var logText = "Заявка с id = " + id + " была подтверждена user_id =" + User.Identity.GetUserId();
                var results = Provider.RunScalarStoredProcedure("add_to_log", logText, "Статус клиента - подтверждено");

                return RedirectToAction("LawyerAllRequests", "Account");
            }
        }

        [HttpPost]
        public ActionResult RefuseLawyerRequest(int id)
        {
            var query = @"UPDATE public.subjects_law_suppliers SET subj_law_supplier_status=5, subj_law_contract_offer = null, subj_law_contract_date = null, comment = '" + Request["comment"] + "' WHERE subj_law_supplier_id = " + id + ";";
            Provider.RunNonQuery(query);

            var logText = "Заявка с id = " + id + " была отклонена user_id =" + User.Identity.GetUserId();
            Provider.RunScalarStoredProcedure("add_to_log", logText, "Статус клиента - отказано");

            return null;
        }

        [HttpPost]
        public ActionResult BlockLawyer(int id)
        {
            lock (Provider.Locker)
            {
                var query = @"UPDATE public.subjects_law_suppliers
                           SET subj_law_supplier_status = 5 WHERE subj_law_supplier_id = " + id + ";";

                Provider.RunNonQuery(query);

                var logText = "Клиент с id = " + id + " был заблокирован user_id =" + User.Identity.GetUserId();
                var results = Provider.RunScalarStoredProcedure("add_to_log", logText, "Статус клиента - заблокирован");

                //get Person ID
                var userId = string.Empty;

                query = @"SELECT person_id
                           from subjects_law_suppliers
                         WHERE subj_law_supplier_id = " + id + ";";
                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    userId = reader["person_id"].ToString();
                }
                reader.Close();

                //Remove Claims from Person Id
                query = "UPDATE \"AspNetUserClaims\" SET \"ClaimValue\"='-100' WHERE \"UserId\" = '" + userId + "' AND \"ClaimType\" = 'user_role';";
                Provider.RunNonQuery(query);
            }

            return Json(new { result = "Ok" });
        }

        [HttpPost]
        public ActionResult UnblockLawyer(int id)
        {
            lock (Provider.Locker)
            {
                var query = @"UPDATE public.subjects_law_suppliers
                           SET subj_law_supplier_status=1 WHERE subj_law_supplier_id = " + id + ";";
                Provider.RunNonQuery(query);

                var logText = "Клиент с id = " + id + " был раззаблокирован user_id =" + User.Identity.GetUserId();
                var results = Provider.RunScalarStoredProcedure("add_to_log", logText, "Статус клиента - разблокирован");

                //get Person ID
                var personId = string.Empty;
                query = @"SELECT person_id
                           from subjects_law_suppliers
                         WHERE subj_law_supplier_id = " + id + ";";

                var reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    personId = reader["person_id"].ToString();
                }
                reader.Close();

                //Remove Claims from Person Id
                query = "UPDATE \"AspNetUserClaims\" SET \"ClaimValue\"=2 WHERE \"UserId\" = '" + personId + "' AND \"ClaimType\" = 'user_role';";
                Provider.RunNonQuery(query);


                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.AccountUnlockedTka,
                    CreationDate = DateTime.Now,
                    CreatorId = User.Identity.GetUserId(),
                    RecipientId = personId
                });
            }

            return Json(new { result = "Ok" });
        }

        public string GetFirmName()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunQueryStr(query);
            return result;
        }

        public ActionResult Cabinet(PersonalViewModel model, string usr)
        {
            var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;
            ViewBag.namec = User.Identity.GetUserName();
            ViewBag.Firm = GetFirmName();
            ViewBag.Count = GetCount();
            var query = "";
            if (usr == "" || usr == null)
            {
                usr = User.Identity.GetUserId();
                query = @"SELECT t1.*, t2.org_name, t2.org_type, t3.""Email""
                                FROM public.persons t1 LEFT JOIN organizations 
                                t2 on t1.org_id=t2.org_id 
                                LEFT JOIN ""AspNetUsers"" t3 on t1.user_id=t3.""Id"" WHERE user_id = '" + usr + "';";
            }
            else {
                query = @"SELECT t1.*, t2.org_name, t2.org_type, t3.""Email""
                                FROM public.persons t1 LEFT JOIN organizations 
                                t2 on t1.org_id=t2.org_id 
                                LEFT JOIN ""AspNetUsers"" t3 on t1.user_id=t3.""Id"" WHERE person_id = '" + usr + "';";
            }
            if (claim != "63")
            {
                var reader = Provider.RunQuery(query);
                while (reader.Read())
                {
                    model.Name = reader["given_name"].ToString();
                    model.Surname = reader["last_name"].ToString();
                    model.Middlename = reader["middle_name"].ToString();
                    model.Name_KZ = reader["given_name_kz"].ToString();
                    model.Surname_KZ = reader["last_name_kz"].ToString();
                    model.Middlename_KZ = reader["middle_name_kz"].ToString();
                    model.Country = reader["country"].ToString();
                    model.Address = reader["post_address"].ToString();
                    model.Phone = reader["phone"].ToString();
                    model.Faceb = reader["faceb"].ToString();
                    model.Instag = reader["instag"].ToString();
                    model.Skype = reader["skype"].ToString();
                    model.Region = reader["org_name"].ToString();                    
                    model.PersonalCode = reader["person_code"].ToString();
                    //model.Birthday = GetDateTimeFromString(reader["date_of_birth"].ToString());
                    //model.DocGuid = reader["doc_guid"].ToString();
                    model.Gender = reader["org_type"].ToString();
                    model.Email = reader["Email"].ToString();
                    model.UserID = reader["user_id"].ToString();
                }
                reader.Close();
                query = "SELECT id FROM docimages WHERE doc_guid='logo' and doc_widget_id ='" + model.Email + "' ORDER BY id DESC LIMIT 1;";
                ViewBag.logo = Provider.RunScalar(query);
            }
            else model.Name = "Admin";
            return View(model);
        }

            public ActionResult Personal1(PersonalViewModel model)
        {
            lock (Provider.Locker)
            {
                var claim = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;

                if (claim == "-2" || claim == "-4") // -2 Клиент со старым паролем, -4 - секретарь со старым паролем
                {
                    return RedirectToAction("ChangePasswordRequired", "Manage");
                }
                if (claim == "-1")
                {
                    return RedirectToAction("PersonalInfo", "Account");
                }

                var query = @"SELECT t1.*, t2.*, t3.doc_guid, t4.doc_widget_id, t4.doc_img_scan, t5.*,
                                t6.law_collegium_name_ru,  t6.law_collegium_name_kz,
                                t7.legal_advise_type_name_ru, t7.legal_advise_type_name_kz

                                FROM public.persons t1

                                left join public.""AspNetUsers"" t2 on t2.""Id"" = t1.user_id
                                left join public.subjects t3 on t1.subj_id = t3.subj_id
                                left join public.docimages t4 on t4.doc_guid = t3.doc_guid
                                left join public.subjects_law_suppliers t5 on t5.person_id = t3.user_id
                                left join public.law_collegiums t6 on t6.law_collegium_id = t5.law_collegium_id
                                left join public.legal_advise_types t7 on t7.legal_advise_type_id = t5.law_supp_org_type
                                

                                WHERE t1.user_id ='" + User.Identity.GetUserId() + "';";


                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    model.Name = reader["given_name"].ToString();
                    model.Surname = reader["last_name"].ToString();
                    model.Middlename = reader["middle_name"].ToString();
                    model.Name_KZ = reader["given_name_kz"].ToString();
                    model.Surname_KZ = reader["last_name_kz"].ToString();
                    model.Middlename_KZ = reader["middle_name_kz"].ToString();
                    model.Country = reader["country"].ToString();
                    model.Address = reader["post_address"].ToString();
                    model.Phone = reader["PhoneNumber"].ToString();
                    model.Email = reader["Email"].ToString();
                    model.PersonalCode = reader["person_code"].ToString();
                    model.Birthday = GetDateTimeFromString(reader["date_of_birth"].ToString());
                    model.DocGuid = reader["doc_guid"].ToString();
                    model.Gender = reader["gender"].ToString();
                    model.Residency = GetIntFromString(reader["residency"].ToString());
                    model.UserID = reader["user_id"].ToString();
                    var lawyer = new LawyerStatusRequestViewModel();
                    lawyer.RequestStatus = GetIntFromString(reader["subj_law_supplier_status"].ToString());
                    if (lawyer.RequestStatus == 1)
                    {
                        lawyer.RequestId = int.Parse(reader["subj_law_supplier_id"].ToString());
                        lawyer.FIO = reader["subj_law_supplier_name"].ToString();
                        lawyer.Address = reader["subj_law_supplier_address"].ToString();
                        lawyer.LicenseNumber = reader["subj_law_supplier_lic_num"].ToString();
                        lawyer.LicenseDate = GetDateTimeFromString(reader["subj_law_supplier_lic_date"].ToString());
                        lawyer.PhoneNumber = reader["subj_law_supplier_phone"].ToString();
                        lawyer.Fax = reader["subj_law_supplier_fax"].ToString();
                        lawyer.Email = reader["subj_law_supplier_email"].ToString();
                        lawyer.WorkingDays = reader["subj_law_supplier_work_days"].ToString();
                        lawyer.WorkTime = reader["subj_law_supplier_work_time"].ToString();
                        lawyer.CellPhoneNumber = reader["subj_law_supplier_mobile"].ToString();
                        lawyer.CollegiaName = reader["law_collegium_name_ru"].ToString();
                        lawyer.OrgFormaName = reader["legal_advise_type_name_ru"].ToString();
                    }
                    model.lawyer = lawyer;
                }
                reader.Close();

                query = @"SELECT process_id, process_name,  process_start_date,  process_complete_date, user_id, process_body, process_creator_id
                                FROM public.processes
                                WHERE  user_id = '" + User.Identity.GetUserId() + "' and process_start_date >= current_date order by process_start_date;";
                reader = Provider.RunQuery(query);

                var events = new List<CalendarEventModel>();

                while (reader.Read())
                {
                    var ev = new CalendarEventModel();
                    ev.eventId = reader["process_id"].ToString();
                    ev.eventName = reader["process_name"].ToString();
                    ev.eventEndDate = GetDateTimeFromString(reader["process_complete_date"].ToString());
                    ev.eventStartDate = GetDateTimeFromString(reader["process_start_date"].ToString());
                    ev.eventMessage = reader["process_body"].ToString();
                    ev.userId = reader["user_id"].ToString();

                    events.Add(ev);
                }
                reader.Close();

                model.Events = events;

                
                query = @"SELECT given_name, last_name, middle_name,  user_id, given_name_kz, last_name_kz, middle_name_kz
                                FROM public.persons order by last_name";

                reader = Provider.RunQuery(query);

                var users = new List<ProcessModel>();

                while (reader.Read())
                {
                    var eventUser = new ProcessModel();
                    eventUser.firstName = reader["given_name"].ToString();
                    eventUser.lastName = reader["last_name"].ToString();
                    eventUser.middleName = reader["middle_name"].ToString();
                    eventUser.firstNameKz = reader["given_name_kz"].ToString();
                    eventUser.lastNameKz = reader["last_name_kz"].ToString();
                    eventUser.middleNameKz = reader["middle_name_kz"].ToString();
                    eventUser.userId = reader["user_id"].ToString();
                    users.Add(eventUser);
                }
                reader.Close();

                var selList = new List<SelectListItem>();
                selList.Add(new SelectListItem { Text = "", Value = "" });
                foreach (var user in users)
                {
                    selList.Add(new SelectListItem { Text = user.lastName + " " + user.firstName, Value = user.userId });
                }
                model.users = selList;
                

                try
                {
                    ViewBag.Message = TempData["Message"] != null ? TempData["Message"].ToString() : null;
                }
                catch (NullReferenceException)
                {
                    ViewBag.Message = null;
                }

                ViewBag.Role = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "user_role").Value;
                return View(model);
            }
        }

        [HttpPost]
        public async Task<ActionResult> AddingEvent(PersonalViewModel model)
        {
            var userId = User.Identity.GetUserId();

            if (model.userId1 == null) { model.userId1 = userId; }
            //var a = model.processStartDate.Add(model.processStartTime.TimeOfDay);
            var results = Provider.RunScalarStoredProcedure("addevent", model.processName, model.processBody, model.processStartTime, model.processStartTime.AddYears(1), model.userId1, userId);

            if (results >= 0)
            {
                //var sendTo = await UserManager.GetEmailAsync(model.userId1);
                var title = "Вам добавлено новое событие в календаре: " + model.processName;
                var body = "</head><body leftmargin=\"0\" marginwidth=\"0\" topmargin=\"0\" marginheight=\"0\" offset=\"0\"><center><table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\" id=\"bodyTable\"><tr><td align=\"center\" valign=\"top\" id=\"bodyCell\" stile = \"margin:0; padding:0; border:0; height:auto; line-height:100%; outline:none; text-decoration:none; border-collapse:collapse !important; height:100% !important; margin:0; padding:0; width:100% !important; padding:20px; width:600px; background-color:#DEE0E2; border-top:4px solid #BBBBBB; border:1px solid #BBBBBB;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"templateContainer\"><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templatePreheader\"><tr></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateHeader\"><tr><td valign=\"top\" class=\"headerContent\" style = \"color: #505050; font-family: Helvetica; font-size: 20px; font-weight: bold; line-height: 100%; padding-top: 0; padding-right: 0; padding-bottom: 0; padding-left: 0; text-align: left; vertical-align: middle;\"></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateBody\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><tr><td valign=\"top\" class=\"bodyContent\" mc:edit=\"body_content\"><h1 style = \"color: #202020 !important; display: block; font-family: Helvetica; font-size: 26px; font-style: normal; font-weight: bold; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Уважаемый(ая) пользователь!</h1><h3 style = \"color: #606060 !important; display: block; font-family: Helvetica; font-size: 16px; font-style: italic; font-weight: normal; line-height: 100%; letter-spacing: normal; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: center;\">Вам было добавлено новое событие в календаре на " + model.processStartDate + ".</h3><div style = \"color: #505050; font-family: Helvetica; font-size: 14px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\">" + model.processName + "<br /> + " + model.processBody + "<br /><br />Если у Вас возникнут вопросы, на них с удовольствием ответит наша служба поддержки. E-mail:<a href=\"http://10.10.7.228:7777/\" target=\"_blank\">support@alsy.by</a></td></tr></table></td></tr><tr><td align=\"center\" valign=\"top\" stile = \"color: #505050;  font-family: Helvetica;  font-size: 14px;  line-height: 150%;  padding-top: 20px;  padding-right: 20px;  padding-bottom: 20px;  padding-left: 20px;  text-align: left;\"><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"templateFooter\"></tr><tr style = \"color: #808080; font-family: Helvetica; font-size: 10px; line-height: 150%; padding-top: 20px; padding-right: 20px; padding-bottom: 20px; padding-left: 20px; text-align: left;\"><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0;\" mc:edit=\"footer_content01\"><em>Copyright &copy; ЗАО \"Алгоритмы И Системы\", All rights reserved.</em></tr><tr><td valign=\"top\" class=\"footerContent\" style=\"padding-top:0; padding-bottom:40px;\" mc:edit=\"footer_content02\">&nbsp;</td></tr></table></td></tr></table></td></tr></table></center></body></html>";
                await UserManager.SendEmailAsync(model.userId1, title, body);
                TempData["Message"] = "Событие было добавлено";
            }
            else
            {
                TempData["Message"] = "Возникла ошибка";
            }

            return RedirectToAction("Personal", "Account");
        }

        [AllowAnonymous]
        public ActionResult EcpLogin(string returnUrl)
        {
            var isAuth = (System.Web.HttpContext.Current.User != null) && System.Web.HttpContext.Current.User.Identity.IsAuthenticated;
            if (!isAuth)
            {
                ViewBag.ReturnUrl = returnUrl;
                ViewBag.Guid =
                    $"<?xml version =\"1.0\" encoding = \"utf-8\" ?> <root><guid>{Guid.NewGuid()}</guid></root>";
                return View();
            }
            else
            {
                return RedirectToAction("Error");
            }
        }
        */
        [HttpPost]
        [AllowAnonymous]
        [ValidateInput(false)]
        public ActionResult EcpLogin()
        {
            //var KalkanCOM = new KalkanCryptCOMLib.KalkanCryptCOM();
            //KalkanCOM.Init();

            var guid = Request.Unvalidated["guid"];
            var data = Request.Unvalidated["data"];
            var serIndex = guid.IndexOf("SERIALNUMBER");
            var iino = guid.Substring(serIndex + 16, 12);
            //var outVerifyInfo = " ";
            //uint err;
            //var errStr = " ";
            if (data == "")
            {
                ViewBag.Message = "Возникла ошибка";
                return View("Error");
            }
            else
            {
                //KalkanCOM.VerifyXML(" ", 0, data, out outVerifyInfo);
                //KalkanCOM.GetLastErrorString(out errStr, out err);
                if (true)
                {
                    //var serNumberIndex = outVerifyInfo.IndexOf("serialNumber");
                    //var iin = outVerifyInfo.Substring(serNumberIndex + 16, 12);

                    var query = @"SELECT t1.""Id""

                                FROM public.""AspNetUsers"" t1

                                left join public.persons t2 on t1.""Id"" = t2.user_id
                                WHERE t2.person_code ='" + iino + "';";
                    var reader = Provider.RunQuery(query);

                    var userId = string.Empty;
                    while (reader.Read())
                    {
                        userId = reader["Id"].ToString();
                    }
                    reader.Close();
                    statusmsg nas = new statusmsg { statusCode = 419 };
                    var user = UserManager.FindById(userId);
                    if (user != null)
                    {
                        nas.user = new loginuser();
                        SignInManager.SignIn(user, true, true);
                        Session["Token"] = "1";
                        nas.statusCode = 200;
                        nas.statusMessage = "OK";
                        nas.user.id = user.Id;
                        nas.user.firstName = user.UserName;
                        nas.user.lastName = user.UserName;
                        nas.user.Roles = user.Roles.ToString();
                        return Json(nas);
                    }
                    else return Json(nas);
                }

            }
        }
        [HttpPost]
        public string create_insurance_request(insurance_request req)
        {
            string user = User.Identity.GetUserId();
            //user = "08b1cf8c-f5bf-42a4-b7fd-99e560c18d2e"; test
            string query = $"INSERT INTO insurance_request (user_id, contract_id, org_name, ceo_name, status, insurance_type, document_id, amount, date_time)" +
                    $" VALUES ('{user}','{req.contract_id}', '{req.org_name}', '{req.ceo_name}', '{req.status}', '{req.insurance_type}', '{req.document_id}', {req.amount.GetValueOrDefault()}, now()) RETURNING id;";

            int res = Provider.RunScalar(query);

            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.InsuranceRequest}', '{LogAccount.InsuranceRequest}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = res.ToString(),
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "insurance request"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);
            }

            query = "SELECT user_id FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id where org_is_insurer = 1;";
            var reader = Provider.RunQuery(query);
            var usrs = new List<string>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    string usr = reader["user_id"].ToString();
                    usrs.Add(usr);
                }
                reader.Close();
            }
            foreach (var usr in usrs)
            {
                if (usr != "-10")
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.insuranceRequest,
                        CreatorId = user,
                        RecipientId = usr,
                        CreationDate = DateTime.Now,
                        ObjectId = res,
                        Comment = req.contract_id.ToString()
                    });
            }
            return "{\"status\":\"ok\"}";

        }

        [HttpPost]
        public string update_insurance_request(insurance_request req, int id)
        {
            string user = User.Identity.GetUserId();
            //user = "08b1cf8c-f5bf-42a4-b7fd-99e560c18d2e"; test
            string query = $"UPDATE insurance_request SET (contract_id, org_name, ceo_name, status, insurance_type, document_id, amount)" +
                    $" = ('{req.contract_id}', '{req.org_name}', '{req.ceo_name}', '{req.status}', '{req.insurance_type}', '{req.document_id}', '{req.amount}' ) WHERE id='{id}';";

            Provider.RunNonQuery(query);

            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.InsuranceRequest}', '{LogAccount.InsuranceRequest}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = id.ToString(),
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "insurance request"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

            }
            query = "SELECT user_id FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id where org_is_insurer = 1;";
            var reader = Provider.RunQuery(query);
            var usrs = new List<string>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    string usr = reader["user_id"].ToString();
                    usrs.Add(usr);
                }
                reader.Close();
            }
            foreach (var usr in usrs)
            {
                if (usr != "-10")
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.insuranceRequest,
                        CreatorId = user,
                        RecipientId = usr,
                        CreationDate = DateTime.Now,
                        ObjectId = id,
                        Comment = req.contract_id.ToString()
                    });
            }
            return "{\"status\":\"ok\"}";

        }
        [HttpPost]
        public string select_insurance_offer(List<string> insurer_id, int request_id)
        {
            string user = User.Identity.GetUserId();
            string qr = $"SELECT contract_id FROM insurance_request WHERE id={request_id};";
            var contract_id = Provider.RunQueryStr(qr);
            if (insurer_id != null)
                foreach (var ins in insurer_id)
                {
                    string query = $"UPDATE insurer_response SET select_status=1 WHERE request_id={request_id} AND insurer_id='{ins}';";
                    Provider.RunNonQuery(query);
                    if (Provider.lastError != "")
                    {
                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogAccount.insuranceApproved}', '{LogAccount.insuranceApproved}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                        Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                    else
                    {
                        NotificationHelper.AddNotification(new Notification()
                        {
                            Type = NotificationType.insuranceApproved,
                            CreatorId = user,
                            RecipientId = ins,
                            CreationDate = DateTime.Now,
                            ObjectId = request_id,
                            Comment = contract_id
                        });
                    }
                }
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string request_docs_for_insurance_request(int request_id, string message)
        {
            string user = User.Identity.GetUserId();
            string oname ="", uname="";
            string query = $"SELECT contract_id FROM insurance_request WHERE id={request_id};";
            var cid = Provider.RunQueryStr(query);
            query = $"UPDATE insurance_request SET insurer_message ='{message}', status='returned' WHERE id={request_id} RETURNING user_id;";
            var res = Provider.RunQueryStr(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.InsuranceRequest}', '{LogAccount.InsuranceRequest}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            else
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.insuranceDocRequest,
                    CreatorId = user,
                    RecipientId = res,
                    CreationDate = DateTime.Now,
                    ObjectId = request_id,
                    Comment = cid
                });
                query = $"SELECT t2.org_name, t1.given_name, t1.last_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}';";
                var reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        oname = reader["org_name"].ToString();
                        uname = reader["given_name"].ToString() +" "+ reader["last_name"].ToString();
                    }
                    reader.Close();
                }
                query = $"INSERT INTO insurer_response (request_id, insurer_id, insurer_name, insurer_orgname, insurer_message, status)" +
                    $" VALUES ('{request_id}', '{user}', '{uname}', '{oname}', '{message}', 'returned')";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\"}";
            }
        }

        [HttpPost]
        public string approve_insurance_request(int request_id, string message)
        {
            var query = $"SELECT contract_id FROM insurance_request WHERE id={request_id};";
            var cid = Provider.RunQueryStr(query);
            string user = User.Identity.GetUserId(), uname="", oname="";
            query = $"SELECT user_id FROM insurance_request WHERE id='{request_id}'";
            var kn = Provider.RunQueryStr(query);
            var r = new List<ImageFile>();
            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.insuranceApproved,
                CreatorId = user,
                RecipientId = kn,
                CreationDate = DateTime.Now,
                ObjectId = request_id,
                Comment = cid
            });
            //certificate – file)
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = cid,
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "insurance"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);
                r.Add(imgFile);
            }
            var cert = "/picture/getfile/";
            try {
                cert = cert + r[0].ID;
            }
            catch (Exception) { }
            query = $"UPDATE insurance_request SET status='approved', certificate = '{cert}' WHERE id={request_id};";
            Provider.RunNonQuery(query);
            query = "SELECT person_id FROM persons WHERE user_id ='" + kn + "';";
            int oid = Provider.RunScalar(query);
            query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id =@p0;";
            var document_issued_by = Provider.RunNoStr(query, user);

            query = $"SELECT insurance_type FROM insurance_request WHERE id={request_id};";
            int document_type = Provider.RunScalar(query);
            query = $"INSERT INTO pa_docs (pa_doc_type_code, pa_doc_number, pa_doc_series, pa_doc_create_org, person_id, pa_doc_active)" +
                        $" VALUES ('{document_type}', '{request_id}', '{request_id}', '{document_issued_by}', '{oid}', '1' ) RETURNING pa_doc_id";
            int docid = Provider.RunScalar(query);

            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = docid.ToString(),
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "pa_doc"
                };

                hpf.InputStream.CopyTo(imgFile.Image);
                Provider.SaveFile(imgFile);
            }
            query = $"SELECT t2.org_name, t1.given_name, t1.last_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    oname = reader["org_name"].ToString();
                    uname = reader["given_name"].ToString() + " " + reader["last_name"].ToString();
                }
                reader.Close();
            }
            query = $"INSERT INTO insurer_response (request_id, insurer_id, insurer_name, insurer_orgname, insurer_message, status)" +
                $" VALUES ('{request_id}', '{user}', '{uname}', '{oname}', '{message}', 'approved')";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string attach_contract_to_insurance_offer(int request_id, float? price, float? franchise)
        {
            //var user = User.Identity.GetUserId();
            var user = "b860b070-3d8b-48ed-a6f1-9011dbfe3d09";
            string query = $"UPDATE insurer_response SET(price, franchise, offer_sent)" +
                    $" = ({price.GetValueOrDefault()}, {franchise.GetValueOrDefault()}, 1) WHERE request_id={request_id} AND insurer_id='{user}'";
            Provider.RunNonQuery(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogAccount.AttachInsurance}', '{LogAccount.AttachInsurance}', '{LogSection.Account}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            } else
            return "{\"status\":\"ok\"}";
        }
        public string load_all_insurance_requests()
        {
            var user = User.Identity.GetUserId();
            var lst = new List<insurance_request>();
            
            var query = "SELECT * FROM insurance_request ORDER BY id DESC";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var list = new insurance_request();
                    list.id = reader.GetFieldValueOrDefault<int>("id");
                    list.contract_id = reader.GetFieldValueOrDefault<int>("contract_id");
                    list.org_name = reader["org_name"].ToString();
                    list.ceo_name = reader["ceo_name"].ToString();
                    list.user_id = reader["user_id"].ToString();
                    list.status = reader["status"].ToString();
                    list.insurance_type = reader.GetFieldValueOrDefault<int>("insurance_type");
                    list.insurer_message = reader["insurer_message"].ToString();
                    list.document_id = reader["document_id"].ToString();
                    list.certificate = reader["certificate"].ToString();
                    list.amount = reader.GetFieldValueOrDefault<float>("amount");
                    list.date_time = reader["date_time"].ToString();
                    lst.Add(list);
                }
                reader.Close();
            }
            foreach (var ls in lst)
            {
                query = $"SELECT select_status FROM insurer_response WHERE request_id={ls.id} AND insurer_id='{user}';";
                int ss = Provider.RunScalar(query);
                if (ss == 1)
                    ls.select_status = 1;
                else ls.select_status = 0;
                query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{ls.id}' and doc_widget_id ='insurance request' ORDER BY id";
                reader = Provider.RunQuery(query);
                //var files = new List<Kfiles>();
                int cnt = 0;
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        rep.name = reader["img_file_name"].ToString();
                        //files.Add(rep);
                        switch(cnt)
                        {
                            case 0: 
                            ls.statute = "/picture/getfile/" + rep.id;
                            break;
                            case 1:
                                ls.registration_certificate = "/picture/getfile/" + rep.id;
                                break;
                            case 2:
                                ls.signature_right_certificate = "/picture/getfile/" + rep.id;
                                break;
                            case 3:
                                ls.ceo_passport = "/picture/getfile/" + rep.id;
                                break;
                            default: break;
                        }
                        cnt++;    
                    }
                    reader.Close();
                }
            }
            var settings = new JsonSerializerSettings
            {
                DateFormatString = "yyyy-MM-dd",
                DateTimeZoneHandling = DateTimeZoneHandling.Utc
            };
            return JsonConvert.SerializeObject(lst,settings);
        }

        public string load_my_insurance_requests()
        {
            string user = User.Identity.GetUserId();
            var lst = new List<insurance_request>();
            
            var query = $"SELECT * FROM insurance_request WHERE user_id='{user}' ORDER BY id DESC";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var list = new insurance_request();
                    list.id = (int)reader["id"];
                    list.contract_id = (int)reader["contract_id"];
                    list.org_name = reader["org_name"].ToString();
                    list.ceo_name = reader["ceo_name"].ToString();
                    list.user_id = reader["user_id"].ToString();
                    list.status = reader["status"].ToString();
                    list.insurer_message = reader["insurer_message"].ToString();
                    list.insurance_type = reader.GetFieldValueOrDefault<int>("insurance_type");
                    list.document_id = reader["document_id"].ToString();
                    list.certificate = reader["certificate"].ToString();
                    list.amount = reader.GetFieldValueOrDefault<float>("amount");
                    list.date_time = reader["date_time"].ToString();
                    list.is_signed = reader.GetFieldValueOrDefault<int>("is_signed");
                    list.sign_date = reader["sign_date"].ToString();
                    lst.Add(list);
                }
                reader.Close();
            }
            foreach (var ls in lst)
            {
                query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{ls.id}' and doc_widget_id ='insurance request' ORDER BY id";
                reader = Provider.RunQuery(query);
                //var files = new List<Kfiles>();
                int cnt = 0;
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        rep.name = reader["img_file_name"].ToString();
                        //files.Add(rep);
                        switch (cnt)
                        {
                            case 0:
                                ls.statute = "/picture/getfile/" + rep.id;
                                break;
                            case 1:
                                ls.registration_certificate = "/picture/getfile/" + rep.id;
                                break;
                            case 2:
                                ls.signature_right_certificate = "/picture/getfile/" + rep.id;
                                break;
                            case 3:
                                ls.ceo_passport = "/picture/getfile/" + rep.id;
                                break;
                            default: break;
                        }
                        cnt++;
                    }
                    reader.Close();
                }
                
                query = $"SELECT * FROM insurer_response WHERE request_id={ls.id};";
                reader = Provider.RunQuery(query);
                var ins = new List<Insurer>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Insurer
                        {
                            id = reader.GetFieldValueOrDefault<int>("id"),
                        };
                        rep.insurer_request_id = reader.GetFieldValueOrDefault<int>("request_id");
                        rep.insurer_id = reader["insurer_id"].ToString();
                        rep.insurer_name = reader["insurer_name"].ToString();
                        rep.insurer_orgname = reader["insurer_orgname"].ToString();
                        rep.status = reader["status"].ToString();
                        rep.select_status = reader.GetFieldValueOrDefault<int>("select_status");
                        rep.price = reader.GetFieldValueOrDefault<float>("price");
                        rep.franchise = reader.GetFieldValueOrDefault<float>("franchise");
                        rep.offer_sent = reader.GetFieldValueOrDefault<int>("offer_sent");
                        rep.is_signed = reader.GetFieldValueOrDefault<int>("is_signed");
                        rep.sign_date = reader["sign_date"].ToString();
                        ins.Add(rep);
                    }
                    reader.Close();
                }
                ls.insurers = new List<Insurer>(ins);
            }
            var settings = new JsonSerializerSettings
            {
                DateFormatString = "yyyy-MM-dd HH:mm",
                DateTimeZoneHandling = DateTimeZoneHandling.Utc
            };
            return JsonConvert.SerializeObject(lst, settings);
        }


        public string get_insurance_contract_xml(int id)
        {
            string user = User.Identity.GetUserId();
            var list = new insurance_request();

            var query = $"SELECT * FROM insurance_request WHERE id={id};";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {                   
                    list.id = (int)reader["id"];
                    list.contract_id = (int)reader["contract_id"];
                    list.org_name = reader["org_name"].ToString();
                    list.ceo_name = reader["ceo_name"].ToString();
                    list.user_id = reader["user_id"].ToString();
                    list.status = reader["status"].ToString();
                    list.insurer_message = reader["insurer_message"].ToString();
                    list.insurance_type = reader.GetFieldValueOrDefault<int>("insurance_type");
                    list.document_id = reader["document_id"].ToString();
                    list.certificate = reader["certificate"].ToString();
                    list.amount = reader.GetFieldValueOrDefault<float>("amount");
                    list.date_time = reader["date_time"].ToString();
                }
                reader.Close();
            }
                query = $"SELECT * FROM insurer_response WHERE request_id={list.id} AND select_status=1";
                reader = Provider.RunQuery(query);
                var ins = new List<Insurer>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Insurer
                        {
                            id = reader.GetFieldValueOrDefault<int>("id"),
                        };
                        rep.insurer_request_id = reader.GetFieldValueOrDefault<int>("request_id");
                        rep.insurer_id = reader["insurer_id"].ToString();
                        rep.insurer_name = reader["insurer_name"].ToString();
                        rep.insurer_orgname = reader["insurer_orgname"].ToString();
                        rep.status = reader["status"].ToString();
                        rep.select_status = reader.GetFieldValueOrDefault<int>("select_status");
                        rep.price = reader.GetFieldValueOrDefault<float>("price");
                        rep.franchise = reader.GetFieldValueOrDefault<float>("franchise");
                        rep.offer_sent = reader.GetFieldValueOrDefault<int>("offer_sent");
                        ins.Add(rep);
                    }
                    reader.Close();
                }
                list.insurers = new List<Insurer>(ins);
            XmlSerializer xsSubmit = new XmlSerializer(typeof(insurance_request));
            var xml = "";

            using (var sww = new StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sww))
                {
                    xsSubmit.Serialize(writer, list);
                    xml = sww.ToString(); // Your XML
                }
            }
            return xml;
        }
        [HttpPost]
        public string sign_insurance_offer(int id, int request_id, string signature, string sign_name)
        {
            if (string.IsNullOrEmpty(sign_name) )
                sign_name = "abc";
            string user = User.Identity.GetUserId();
            var query = $"SELECT user_id FROM insurance_request WHERE id={request_id};";
            var client = Provider.RunQueryStr(query);
            query = $"SELECT contract_id FROM insurance_request WHERE id={request_id};";
            var cid = Provider.RunQueryStr(query);
            //if (user == client)
            {
                query = $"UPDATE insurance_request SET signature = '{signature}', is_signed=1, sign_date='now()' WHERE id={request_id};";
                Provider.RunNonQuery(query);
                query = $"UPDATE insurer_response SET signature = '{signature}', sign_name='{sign_name}', is_signed=1, sign_date='now()' WHERE id={id};";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\"}";
                query = $"SELECT insurer_id FROM insurer_response WHERE request_id={request_id} AND select_status=1;";
                var reader = Provider.RunQuery(query);
                var usrs = new List<string>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        string usr = reader["insurer_id"].ToString();
                        usrs.Add(usr);
                    }
                    reader.Close();
                }
                foreach (var usr in usrs)
                {
                    if (usr != "-10")
                        NotificationHelper.AddNotification(new Notification()
                        {
                            Type = NotificationType.insuranceSigned,
                            CreatorId = user,
                            RecipientId = usr,
                            CreationDate = DateTime.Now,
                            ObjectId = request_id,
                            Comment = cid
                        });
                }

            }
            //else
             {
                query = $"UPDATE insurer_response SET signature = '{signature}', is_signed=1, sign_date='now()' WHERE id={id};";
                Provider.RunNonQuery(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.insuranceSigned,
                    CreatorId = user,
                    RecipientId = client,
                    CreationDate = DateTime.Now,
                    ObjectId = request_id,
                    Comment = cid
                });
            }
            return "{\"status\":\"ok\"}";
        }
        [HttpPost]
        //[AllowAnonymous]
        public int CheckEmail(string email)
        {
            var query = $"select count(*) from public.\"AspNetUsers\" where \"UserName\" = '{email}';";
            int result = Provider.RunScalar(query);
            return result;
        }
        [HttpPost]
        public string check_certificate(string cert)
        {
            string outInfo = "";

            int validType = (int)KalkanCryptCOMLib.KALKANCRYPTCOM_VALIDTYPE.KC_USE_OCSP;//1028; type of validation adress
            string validPath = "http://ocsp.pki.gov.kz/";
            uint err;
            string errStr;
            DateTime tmpD = new DateTime();
            //string query = $"SELECT cert FROM signatures WHERE id=1"; //db testing
            //string crt = Provider.RunQueryStr(query);
            var kalkanCryptCom = new KalkanCryptCOMLib.KalkanCryptCOM();
            kalkanCryptCom.Init();
            try
            {
                kalkanCryptCom.X509ValidateCertificate(cert, validType, validPath, tmpD, out outInfo);
                //KalkanCOMTest.X509ValidateCertificate(inCert, validType, validPath, tmpD, out outInfo);

                kalkanCryptCom.GetLastErrorString(out errStr, out err);
                if (err > 0) //if error found
                {
                    return err.ToString("X8") + errStr;
                }
                return "ok";
            }
            catch (Exception ex) { return ex.Message; }

        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult CheckUnique(CheckUniqueModel model)
        {
            var arr = model.FieldName.Split('.');

            var query = string.Empty;

            switch (model.FieldName)
            {
                case "AspNetUsers.UserName":
                    query = $"select count(*) from \"{arr[0]}\" where \"{arr[1]}\" = '{model.FieldValue}'";
                    break;
                case "persons.person_code":
                    query = $"select count(*) from \"{arr[0]}\" where \"{arr[1]}\" = '{model.FieldValue}'";
                     break;
                case "subjects_law_suppliers.subj_law_supplier_lic_num":
                    query = $"select count(*) from \"{arr[0]}\" where \"{arr[1]}\" = '{model.FieldValue}'";
                    break;
            }

            var result = Provider.RunScalar(query) == 0;

            return Json(new { Result = result });
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        /// <summary>
        /// The XSRF key
        /// </summary>
        private const string XsrfKey = "XsrfId";

        /// <summary>
        /// Gets the authentication manager.
        /// </summary>
        /// <value>The authentication manager.</value>
        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        /// <summary>
        /// Adds the errors.
        /// </summary>
        /// <param name="result">The result.</param>
        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        /// <summary>
        /// Redirects to local.
        /// </summary>
        /// <param name="returnUrl">The return URL.</param>
        /// <returns>ActionResult.</returns>
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// Documentses this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Documents()
        {
            return View("Personal");
        }

        /// <summary>
        /// Class ChallengeResult.
        /// </summary>
        internal class ChallengeResult : HttpUnauthorizedResult
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="ChallengeResult"/> class.
            /// </summary>
            /// <param name="provider">The provider.</param>
            /// <param name="redirectUri">The redirect URI.</param>
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ChallengeResult"/> class.
            /// </summary>
            /// <param name="provider">The provider.</param>
            /// <param name="redirectUri">The redirect URI.</param>
            /// <param name="userId">The user identifier.</param>
            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            /// <summary>
            /// Gets or sets the login provider.
            /// </summary>
            /// <value>The login provider.</value>
            public string LoginProvider { get; set; }
            /// <summary>
            /// Gets or sets the redirect URI.
            /// </summary>
            /// <value>The redirect URI.</value>
            public string RedirectUri { get; set; }
            /// <summary>
            /// Gets or sets the user identifier.
            /// </summary>
            /// <value>The user identifier.</value>
            public string UserId { get; set; }

            /// <summary>
            /// Enables processing of the result of an action method by a custom type that inherits from the <see cref="T:System.Web.Mvc.ActionResult" /> class.
            /// </summary>
            /// <param name="context">The context in which the result is executed. The context information includes the controller, HTTP content, request context, and route data.</param>
            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult UpdateSubject(IEnumerable<Data> values)
        {
            var query = string.Empty;
            var subjId = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "subj_id").Value;

            if (values == null)
            {
                return Json(new { result = "OK" });
            }

            foreach (var item in values)
            {
                switch (item.Action)
                {
                    case "add":
                        switch (item.Type)
                        {
                            case "email":
                                query =
                                    $"INSERT INTO public.subj_emails(subj_id, subj_email) VALUES({subjId}, '{item.Value}');";
                                break;
                            case "phone":
                                query =
                                    $"INSERT INTO public.subj_phones(subj_id, subj_phone_type, subj_phone_number) VALUES({subjId}, 1, '{item.Value}');";
                                break;
                            case "cellphone":
                                query =
                                    $"INSERT INTO public.subj_phones(subj_id, subj_phone_type, subj_phone_number) VALUES({subjId}, 2, '{item.Value}');";
                                break;
                            case "address":
                                query =
                                    $"INSERT INTO public.subj_post_addresses(subj_id, post_addr_name, post_addr_name_geo) VALUES({subjId},'{item.Value}','{item.Geocode}');";
                                break;
                            default:
                                break;
                        }

                        break;
                    case "delete":
                        switch (item.Type)
                        {
                            case "email":
                                query =
                                    $"DELETE FROM public.subj_emails WHERE subj_email_id = {item.Id} and subj_id = {subjId};";
                                break;
                            case "phone":
                            case "cellphone":
                                query =
                                    $"DELETE FROM public.subj_phones WHERE person_phone_id = {item.Id} and subj_id = {subjId};";
                                break;
                            case "address":
                                query =
                                    $"DELETE FROM public.subj_post_addresses WHERE post_addr_id = {item.Id} and subj_id = {subjId};";
                                break;
                            default:
                                break;
                        }

                        break;
                    case "update":
                        switch (item.Type)
                        {
                            case "email":
                                query =
                                    $"UPDATE public.subj_emails SET subj_email = '{item.Value}' WHERE subj_email_id = {item.Id} and subj_id = {subjId};";
                                break;
                            case "phone":
                            case "cellphone":
                                query =
                                    $"UPDATE public.subj_phones SET subj_phone_number = '{item.Value}' WHERE person_phone_id = {item.Id} and subj_id = {subjId};";
                                break;
                            case "address":
                                query =
                                    $"UPDATE public.subj_post_addresses SET post_addr_name = '{item.Value}', post_addr_name_geo = '{item.Geocode}' WHERE post_addr_id = {item.Id} and subj_id = {subjId};";
                                break;
                            default:
                                break;
                        }

                        break;
                    default:
                        break;
                }
                var reader = Provider.RunNonQuery(query);
            }

            return Json(new { result = "OK" });
        }

        [HttpPost]
        public string UpdateSubjectA(List<Data> values, int a)
        {
            var query = string.Empty;
            var subjId = ((ClaimsIdentity)User.Identity).Claims.First(c => c.Type == "subj_id").Value;

            if (values == null)
            {
                return null;
            }

            foreach (var item in values)
            {
                if (item.Action == "add")
                    query =
                        $"INSERT INTO subject_change_data_requests(data_type, data_value, action_type,subject_id) VALUES('{item.Type}', '{item.Value}', '{item.Action}', {subjId});";
                else
                    query =
                        $"INSERT INTO subject_change_data_requests(data_type, data_value, action_type, entity_id, subject_id) VALUES('{item.Type}', '{item.Value}', '{item.Action}', {item.Id}, {subjId});";

                Provider.RunNonQuery(query);
            }

            return null;
        }

        [HttpPost]
        public string GetRequestSequenceValue()
        {
            var query = "SELECT nextval('account_types_account_type_id_seq');";
            var seqVal = string.Empty;
            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                seqVal = reader["nextval"].ToString();
            }

            reader.Close();

            return seqVal;
        }

        public class Data
        {
            public string Action { get; set; }
            public string Type { get; set; }
            public string Table { get; set; }
            public string InsertType { get; set; }
            public string Value { get; set; }
            public string Id { get; set; }
            public string Geocode { get; set; }
        }

        private string GetRoleFromDb()
        {
            var query = @"SELECT t1.""ClaimValue""
                                FROM ""AspNetUserClaims"" t1
                                WHERE t1.""UserId"" = '" + User.Identity.GetUserId() + "' and t1.\"ClaimType\" = 'user_role';";

            var reader = Provider.RunQuery(query);

            var claimfromDb = "1";

            while (reader.Read())
            {
                claimfromDb = reader["ClaimValue"].ToString();
            }

            reader.Close();

            return claimfromDb;
        }

        public static DateTime GetDateTimeFromString(string inputDate)
        {
            var success = DateTime.TryParse(inputDate, out var tempDt);
            return success ? tempDt.Date : default;
        }

        public int GetIntFromString(string inputDate)
        {
            int tempInt;
            var success = int.TryParse(inputDate, out tempInt);

            return success ? tempInt : default(int);
        }

        public DateTime? GetNullableDateTimeFromString(string inputDate)
        {
            DateTime tempDt;
            var success = DateTime.TryParse(inputDate, out tempDt);

            if (success)
            {
                return tempDt;
            }

            return null;
        }

        public string GetStringForComparing(string inputDate)
        {
            return inputDate ?? string.Empty;
        }

        #endregion
    }
}