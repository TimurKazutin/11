﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 02-20-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 02-20-2015
// ***********************************************************************
// <copyright file="FieldFilter.cs" company="SP Alexey Shumeyko">
//     Copyright (c) SP Alexey Shumeyko. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Xml.Serialization;
    using Lawyers.Common.Enums;

    /// <summary>
    /// Class FieldFilter.
    /// </summary>
    [XmlType]
    public class FieldFilter
    {
        [XmlAttribute(AttributeName = "apply")]
        public string _apply;

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        [XmlAttribute(AttributeName = "Value")]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets the type of the operation.
        /// </summary>
        /// <value>The type of the operation.</value>
        [XmlAttribute(AttributeName = "operation")]
        public ConditionOperationType OperationType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="FieldFilter"/> is apply.
        /// </summary>
        /// <value><c>true</c> if apply; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool Apply
        {
            get { return this._apply == "1"; }
            set { this._apply = value ? "1" : "0"; }
        }
    }
}
