﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.SessionState;
using System.Web.Mvc;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using Models;

    [SessionState(SessionStateBehavior.Disabled)]
    public class NewsController : Controller
    {
        private IDataProvider Provider1
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }
        // GET: News
        public JsonResult Index(string lang)
        {
            //var selListMsg = new List<NewsModel> { new NewsModel { NewsID = new int(), Title = "", Content = "", Date = new System.DateTime() } };
            lock (Provider1.Locker)
            {
                string query = "SELECT * FROM public.\"site_news\" WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = Provider1.RunQuery(query);

                var news = new List<NewsModel1>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var dt = reader["date"].ToString().Split(' ');
                        news.Add(new NewsModel1 { id = (int)reader["id"], title = reader["title"].ToString(), text = reader["text"].ToString(), date = dt[0] });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    return Json(news, JsonRequestBehavior.AllowGet);
                }
                else return Json(news, JsonRequestBehavior.AllowGet);
            }
        }
    }
}