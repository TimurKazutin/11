﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Lawyers.Web.App.Helpers
{
    public class GlobalisationRouteHandler : MvcRouteHandler
    {
        private String CultureValue
        {
            get
            {
                return (String)RouteDataValues[GlobalisedRoute.CultureKey];
            }
        }

        private RouteValueDictionary RouteDataValues { get; set; }

        protected override IHttpHandler GetHttpHandler(RequestContext requestContext)
        {
            RouteDataValues = requestContext.RouteData.Values;
            CultureManager.SetCulture(CultureValue);

            return base.GetHttpHandler(requestContext);
        }

        public GlobalisationRouteHandler() : base()
        {

        }

        public GlobalisationRouteHandler(IControllerFactory controllerFactory) : base(controllerFactory)
        {

        }
    }
}