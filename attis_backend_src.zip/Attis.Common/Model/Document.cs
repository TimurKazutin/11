﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-17-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-28-2014
// ***********************************************************************
// <copyright file="Document.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class Document.
    /// </summary>
    public class Document : Widget
    {
        /// <summary>
        /// Gets or sets the checks.
        /// </summary>
        /// <value>The checks.</value>
        [XmlArray("checks")]
        [XmlArrayItem(Type = typeof(Check), ElementName = "check")]
        public List<Check> Checks { get; set; }
    }
}
