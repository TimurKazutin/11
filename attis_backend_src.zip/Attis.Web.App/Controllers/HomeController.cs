﻿using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;
    using System.Web;
    using System.Web.Mvc;
    using Common;
    using Common.Interfaces;
    using log4net;
    using Microsoft.AspNet.Identity;
    using Models;
    using Newtonsoft.Json;

    /// <summary>
    /// Class HomeController.
    /// </summary>
    public class HomeController : Controller
    {
        public static int news_id = 1;
        public int SliderId = news_id * 10 +16;
        public int MsnId = news_id * 10 + 1;
        public int MngId = news_id * 10 + 2;
        public int KonsId = news_id * 10 + 3;
        public int RegId = news_id * 10 + 4;
        public int PartId = news_id * 10 + 5;
        public int aPartId = news_id * 10 + 6;
        public int ProgId = news_id * 10 + 7;
        public int ProofId = news_id * 10 + 8;
        public int DescId = news_id * 10 + 9;
        public int ResultId = news_id * 10 + 10;
        public int EventId = news_id * 10+11;
        //public int OtherId = news_id * 10;
        public int FaqId = news_id * 10 + 12;
        public int CallId = news_id * 10 + 13;
        //public int MisnId = news_id * 10 + 14;
        public int GenId = news_id * 10 + 20;
        public int ComId = news_id * 10 + 21;
        public int FinId = news_id * 10 + 22;

        public string cult = System.Threading.Thread.CurrentThread.CurrentCulture.DisplayName;
        private readonly ILog _logger = LogManager.GetLogger(typeof(HomeController));
        private IDataProvider provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Index()
        {/*
            lock (provider.Locker)
            {
                var query = "SELECT t1.*, t2.*, t3.*" +
                               " FROM  public.subjects t1" +
                               " LEFT JOIN  public.subjects_law_suppliers t2 on t1.user_id = t2.person_id" +
                               " LEFT JOIN  public.docimages t3 on t1.doc_guid = t3.doc_guid" +
                               " WHERE t3.doc_widget_id = 'logo' and t2.subj_law_supplier_status = 1";

                System.Data.IDataReader reader = provider.RunQuery(query);

                List<HomeLawyer> lawyers = new List<HomeLawyer>();
                HomeViewModel model = new HomeViewModel();

                while (reader.Read())
                {
                    HomeLawyer law = new HomeLawyer
                    {
                        LawyerName = reader["subj_name"].ToString(),
                        LawyerPhoto = (byte[]) reader["doc_img_scan"]
                    };

                    lawyers.Add(law);
                }
                reader.Close();

                model.HomeLawyers = lawyers;*/
            //ViewBag.allNews = Display(SliderId);
            //ViewBag.allFiles = DisplayFiles(SliderId);
            ViewBag.CurrentView = "Index";
            //ViewBag.Count = GetCount();
            return View();
            //}
        }
        public ActionResult OfferPdf()
        {/*
            
            return new FileContentResult(byteArray, "application/pdf");*/
            var query = "SELECT file_id FROM licenses WHERE status=1;";
            int fl = provider.RunScalar(query);
            var file = provider.GetFileByID(fl);
            if (file != null)
            {
                Response.AppendHeader("content-disposition", "inline; filename=" + file.Name);
                Response.AppendHeader("Content-Length", file.Image.Length.ToString());
                return new FileStreamResult(file.Image, file.ContentType);
            }
            return null;
        }
        public ActionResult _News()
        {
            //var query = $"SELECT t2.org_type FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{User.Identity.GetUserId()}';";
            //ViewBag.Role = provider.RunScalar(query);
            //ViewBag.GenNews = Display(GenId);
            //ViewBag.ComNews = Display(ComId);
            //ViewBag.FinNews = Display(FinId);
            return PartialView();
        }

        /// <summary>
        /// About this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult About()
        {
            return Index();
        }

        /// <summary>
        /// About this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Error()
        {
            return View();
        }

        /// <summary>
        /// About this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Assistance()
        {
            return View();
        }

        /// <summary>
        /// About this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult JudicialPractice()
        {
            return View();
        }

        /// <summary>
        /// About this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Legislation()
        {
            return View();
        }

        /// <summary>
        /// About this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult FormsDocuments()
        {
            return View();
        }

        /// <summary>
        /// About this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult LawyerCorps()
        {
            return View();
        }

        public ActionResult TerritorialCollegia()
        {
            return View();
        }

        public ActionResult CodeProfessionalEthics()
        {
            return View();
        }

        public ActionResult RepublicanCollegium()
        {
            return View();
        }

        /// <summary>
        /// Contacts this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        public ActionResult Contact()
        {
            return View(new ContactViewModel());
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> Contact(ContactViewModel model)
        //{
        //    //// Code for validating the CAPTCHA and inputs
        //    //if (this.IsCaptchaValid(GlobalStrings.CaptchaError))
        //    //{
        //    //    if (ModelState.IsValid)
        //    //    {
        //    //        var emailSender = new EmailService();
        //    //        emailSender.fromAddress = model.Email;
        //    //        //try
        //    //        //{
        //    //            await emailSender.SendAsync(new IdentityMessage()
        //    //            {
        //    //                Body = string.Format("Email From: {0} ({1}),\n {2}", model.Name, model.Email, model.Text),
        //    //                Destination = "tto@alsy.by",
        //    //                Subject = "Question from the user of IP Management Service",
        //    //            });
        //    //        /*}
        //    //        catch (Exception ex)
        //    //        {
        //    //            ViewBag.ErrMessage = GlobalStrings.SendEmailError;
        //    //        }*/
        //    //        ModelState.Clear();
        //    //        return RedirectToAction("Sent");
        //    //    }
        //    //}
        //    //else
        //    //{
        //    //    ViewBag.ErrMessage = GlobalStrings.Shared_Error + ": " + GlobalStrings.CaptchaError;
        //    //}

        //    return View(model);
        //}
        /*
        public ActionResult Test()
        {
            //var cl = new HttpClient();
            //var resStr = string.Empty;
            //JObject jsn;
            var msg = new
            {
                client_message_id = "236234857",
                sender = "SMSGW",
                recipient = "77010000000",
                message_text = "тест"
            };
            var jValue = JsonConvert.SerializeObject(msg);
            var httpContent = new StringContent(jValue, Encoding.UTF8, "application/json");
            var client = new HttpClient();
            client.BaseAddress = new Uri("https://api.kcell.kz/app/smsgw/rest/v2/messages");
            var buffer = Encoding.ASCII.GetBytes("john:secret");
            //var authHeader = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(buffer));
            var authHeader = new AuthenticationHeaderValue("Basic", "pxT3bdk4dGYXNzd29db4"); 
            client.DefaultRequestHeaders.Authorization = authHeader;
            //var response = client.GetAsync("/api/authenticate").Result;
            var httpResponse = client.PostAsync("https://api.kcell.kz/app/smsgw/rest/v2/messages", httpContent);
            // If the response contains content we want to read it!
            if (httpResponse.Result.Content != null)
            {
                var responseContent = httpResponse.Result.Content.ReadAsStringAsync();

                // From here on you could deserialize the ResponseContent back again to a concrete C# type using Json.Net
            }
            return View();
        }
        */
        /// <summary>
        /// News this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        /*
        [HttpPost]
        [Authorize(Users = "astan@law.kk, asta_tka@law.kz, admin@alsy.by")]
        public ActionResult Edit(NewsModel model)
        {
            int ids = 0;
            if (cult.Contains("English"))
            {/*
                switch (model.Purpos)
                {
                    case "News":
                        ids = ColEn;
                        break;
                    case "Priv": //
                        ids = PrivEn;
                        break;
                    case "List":
                        ids = ListEn;
                        break;
                    case "Help":
                        ids = HelpEn;
                        break;
                    case "Prv":
                        ids = PrvEn;
                        break;
                    case "Desc":
                        ids = DescEn;
                        break;
                    default:
                        break;
                }
            }
            else if (cult.Contains("Russian") || cult.Contains("Рус"))
                switch (model.Purpos)
                {
                    case "Slider":
                        ids = SliderId;
                        break;
                    case "Kons":
                        ids = KonsId;
                        break;
                    case "Priv":
                        ids = MsnId;
                        break;
                    case "List":
                        ids = MngId;
                        break;
                    case "Help":
                        ids = FaqId;
                        break;
                    case "Result":
                        ids = ResultId;
                        break;
                    case "Desc":
                        ids = DescId;
                        break;
                    case "Call":
                        ids = CallId;
                        break;
                    case "Reg":
                        ids = RegId;
                        break;
                    case "Part":
                        ids = PartId;
                        break;
                    case "aPart":
                        ids = aPartId;
                        break;
                    case "Prog":
                        ids = ProgId;
                        break;
                    case "Proof":
                        ids = ProofId;
                        break;
                    case "Gen":
                        ids = GenId;
                        break;
                    case "Com":
                        ids = ComId;
                        break;
                    case "Fin":
                        ids = FinId;
                        break;
                    default:
                        break;
                }
            else
                switch (model.Purpos)
                {/*
                    case "News":
                        ids = ColKk;
                        break;
                    case "Priv": //
                        ids = PrivKk;
                        break;
                    case "List":
                        ids = ListKk;
                        break;
                    case "Help":
                        ids = HelpKk;
                        break;
                    case "Prv":
                        ids = PrvKk;
                        break;
                    case "Desc":
                        ids = DescKk;
                        break;                    
                    default:
                        break;
                }
            string query = "";
            int id = SelPage(model.Purpos);
            if (model.NewsID > 0)
            {
                query = $"UPDATE public.site_news SET title='{model.Title}', created_on='NOW()', content='{model.Content}' WHERE id='{model.NewsID}';";
                provider.RunNonQuery(query);
                //string log = User.Identity.Name + " edit page " + model.Purpos + " " + model.NewsID;
                //_logger.Info(log);
                return RedirectToAction("page", new { page = id });
            }
            else
            {
                //var tt = model.Content;            
                query = $"INSERT INTO public.\"site_news\"(page_id, title, content, created_on) VALUES('{ids}', '{model.Title}', '{model.Content}', 'NOW()');";
                //string query = $"INSERT INTO subject_change_data_requests(chat_id, chat_name, chat_text, created_on) VALUES('{value.Id}', '{value.Name}', '{value.Message}', 'NOW()');";
                provider.RunNonQuery(query);
                //string log = User.Identity.Name + " new page " + model.Purpos;
                //_logger.Info(log);
                //ViewBag.allNews = Display(col_id);
                return RedirectToAction("page", new { page = id });
            }
        }

        [Authorize]
        public ActionResult Edit(int? id, string page)
        { //dd
            ViewBag.Page = page;
            //ViewBag.Count = GetCount();
            if (id != null)
            {
                string query = "SELECT * FROM public.\"site_news\" WHERE id =" + id + ";";
                IDataReader reader = provider.RunQuery(query);

                var model = new NewsModel { NewsID = new int(), Title = "", Content = "", Date = new System.DateTime() };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        model.NewsID = (int)reader["id"];
                        model.Title = reader["title"].ToString();
                        model.Content = reader["content"].ToString();
                        model.Date = System.DateTime.Parse(reader["created_on"].ToString());
                    }
                    reader.Close();
                    model.Purpos = page;
                }
                return View(model);
            }//decimalo
            else return View();
        }

        [HttpPost]
        [Authorize(Users = "admin@alsy.by, admin_test@nitec.kz")]
        public ActionResult Delete(NewsModel model, string value, string area)
        {
            var view = area;
            string cid = Request.Params["delete"];
            string query = "DELETE FROM public.\"site_news\" WHERE id =" + cid + ";";
            provider.RunNonQuery(query);
            int id = SelPage(area);
            return RedirectToAction("page", new { page = id });
        }

        public ActionResult Page(int? page, string date)
        {
            if (cult.Contains("English"))
            {   /*
                switch (page)
                {
                    case 1: //Privet
                        {
                            ViewBag.allNews = Display(PrivEn);
                            ViewBag.allFiles = DisplayFiles(PrivId);
                            ViewBag.CurrentView = "Priv";
                            ViewBag.Title = GlobalStrings.tka_priv;
                            ViewBag.EditView = "EditPriv";
                            break;
                        }
                    case 2: //List
                        {
                            ViewBag.allNews = Display(ListEn);
                            ViewBag.allFiles = DisplayFiles(ListId);
                            ViewBag.CurrentView = "List";
                            ViewBag.Title = GlobalStrings.Col_zk;
                            ViewBag.EditView = "EditList";
                            break;
                        }
                    case 3: //news
                        {
                            ViewBag.allNews = Display(ColEn);
                            ViewBag.allFiles = DisplayFiles(ColEn);
                            ViewBag.CurrentView = "News";
                            ViewBag.Title = GlobalStrings.News;
                            ViewBag.EditView = "Edit";
                            break;
                        }
                    case 4: //help
                        {
                            ViewBag.allNews = Display(HelpEn);
                            ViewBag.allFiles = DisplayFiles(HelpId);
                            ViewBag.Title = @GlobalStrings.Help_law;
                            ViewBag.CurrentView = "Help";
                            ViewBag.EditView = "EditHelp";
                            break;
                        }
                    case 5: //PRV
                        {
                            ViewBag.allNews = Display(PrvEn);
                            ViewBag.allFiles = DisplayFiles(PrvId);
                            ViewBag.Title = "Service section";
                            ViewBag.CurrentView = "Prv";
                            ViewBag.EditView = "EditPrv";
                            break;
                        }
                    case 6:
                        ViewBag.allNews = Display(DescEn);
                        ViewBag.allFiles = DisplayFiles(DescId);
                        ViewBag.Title = @GlobalStrings.desc_coll;
                        ViewBag.CurrentView = "Desc";
                        ViewBag.EditView = "EditDesc";
                        break;
                    case 7:
                        ViewBag.allNews = Display(ProofEn);
                        ViewBag.allFiles = DisplayFiles(ProofId);
                        ViewBag.Title = @GlobalStrings.prof_coll;
                        ViewBag.CurrentView = "Proof";
                        ViewBag.EditView = "EditProof";
                        break;
                    case 8:
                        ViewBag.allNews = Display(ResultEn);
                        ViewBag.allFiles = DisplayFiles(ResultId);
                        ViewBag.Title = @GlobalStrings.Granted_help;
                        ViewBag.CurrentView = "Result";
                        ViewBag.EditView = "EditResult";
                        break;
                    //
            }
            else if (cult.Contains("Russian") || cult.Contains("Рус"))
            {
                switch (page)
                {
                    case 26: //Slider
                        {
                            ViewBag.allNews = Display(SliderId);
                            ViewBag.allFiles = DisplayFiles(SliderId);
                            ViewBag.CurrentView = "Slider";
                            ViewBag.Title = "Слаидер";
                            break;
                        }
                    case 1: //Mission
                        {
                            ViewBag.allNews = Display(MsnId);
                            ViewBag.allFiles = DisplayFiles(MsnId);
                            ViewBag.CurrentView = "Priv";
                            ViewBag.Title = "Миссия";
                            break;
                        }
                    case 2: //List
                        {
                            ViewBag.allNews = Display(MngId);
                            ViewBag.allFiles = DisplayFiles(MngId);
                            ViewBag.CurrentView = "List";
                            ViewBag.Title = "Менеджмент";
                            break;
                        }
                    case 3: //news
                        {
                            ViewBag.allNews = Display(KonsId);
                            ViewBag.allFiles = DisplayFiles(KonsId);
                            ViewBag.Title = "Консалтинг";
                            ViewBag.CurrentView = "Kons";
                            break;
                        }
                    case 4: //faq
                        {
                            ViewBag.allNews = Display(FaqId);
                            ViewBag.allFiles = DisplayFiles(FaqId);
                            ViewBag.Title = "Полезная информация"; //@GlobalStrings.Help_law;
                            ViewBag.CurrentView = "Help";
                            break;
                        }
                    case 5: //cont
                        {
                            ViewBag.allNews = Display(CallId);
                            ViewBag.allFiles = DisplayFiles(CallId);
                            ViewBag.Title = "Контакты";
                            ViewBag.CurrentView = "Call";
                            break;
                        }
                    case 6:
                        ViewBag.allNews = Display(DescId);
                        ViewBag.allFiles = DisplayFiles(DescId);
                        ViewBag.Title = "Программные решения";
                        ViewBag.CurrentView = "Desc";
                        break;
                    case 7:
                        ViewBag.allNews = Display(ProofId);
                        ViewBag.allFiles = DisplayFiles(ProofId);
                        ViewBag.Title = "Транзакционный сервис";
                        ViewBag.CurrentView = "Proof";
                        break;
                    case 8:
                        ViewBag.allNews = Display(ResultId);
                        ViewBag.allFiles = DisplayFiles(ResultId);
                        ViewBag.Title = "Общая информация";
                        ViewBag.CurrentView = "Result";
                        break;
                    case 9:
                        ViewBag.allNews = Display(RegId);
                        ViewBag.allFiles = DisplayFiles(RegId);
                        ViewBag.Title = "Зарегистрироваться";
                        ViewBag.CurrentView = "Reg";
                        break;
                    case 10:
                        ViewBag.allNews = Display(PartId);
                        ViewBag.allFiles = DisplayFiles(PartId);
                        ViewBag.Title = "Участникам";
                        ViewBag.CurrentView = "Part";
                        break; 
                    case 11:
                        ViewBag.allNews = Display(aPartId);
                        ViewBag.allFiles = DisplayFiles(aPartId);
                        ViewBag.Title = "О партнёрах";
                        ViewBag.CurrentView = "aPart";
                        break;
                    case 12:
                        ViewBag.allNews = Display(ProgId);
                        ViewBag.allFiles = DisplayFiles(ProgId);
                        ViewBag.Title = "Партнёрская программа";
                        ViewBag.CurrentView = "Prog";
                        break;

                    case 30:
                        ViewBag.allNews = Display(GenId);
                        ViewBag.allFiles = DisplayFiles(GenId);
                        ViewBag.Title = "Общие новости";
                        ViewBag.CurrentView = "Gen";
                        break;

                    case 31:
                        ViewBag.allNews = Display(ComId);
                        ViewBag.allFiles = DisplayFiles(ComId);
                        ViewBag.Title = "События компании";
                        ViewBag.CurrentView = "Com";
                        break;
                    case 32:
                        ViewBag.allNews = Display(FinId);
                        ViewBag.allFiles = DisplayFiles(FinId);
                        ViewBag.Title = "Информация о торгах";
                        ViewBag.CurrentView = "Fin";
                        break;
                    case 33:
                        ViewBag.allNews = AllNews();
                        ViewBag.allFiles = DisplayFiles(FinId);
                        ViewBag.Title = "Все новости";
                        ViewBag.CurrentView = "AllNews";
                        break;
                }
                //ViewBag.FirstNews = Display(col_id);
                //ViewBag.Events = Display(EventId);
                //ViewBag.Foto = DisplayFiles(AAId);
                //ViewBag.Name = Display(AAId);
            }
            else
            { /*
                switch (page)
                {
                    case 1: //Privet
                        {
                            ViewBag.allNews = Display(PrivKk);
                            ViewBag.allFiles = DisplayFiles(PrivId);
                            ViewBag.CurrentView = "Priv";
                            ViewBag.Title = GlobalStrings.tka_priv;
                            ViewBag.EditView = "EditPriv";
                            break;
                        }
                    case 2: //List
                        {
                            ViewBag.allNews = Display(ListKk);
                            ViewBag.allFiles = DisplayFiles(ListId);
                            ViewBag.CurrentView = "List";
                            ViewBag.Title = GlobalStrings.Col_zk;
                            ViewBag.EditView = "EditList";
                            break;
                        }
                    case 3: //news
                        {
                            ViewBag.allNews = Display(ColKk);
                            ViewBag.allFiles = DisplayFiles(ColEn);
                            ViewBag.Title = GlobalStrings.News;
                            ViewBag.CurrentView = "News";
                            ViewBag.EditView = "Edit";
                            break;
                        }
                    case 4: //help
                        {
                            ViewBag.allNews = Display(HelpKk);
                            ViewBag.allFiles = DisplayFiles(HelpId);
                            ViewBag.Title = @GlobalStrings.Help_law;
                            ViewBag.CurrentView = "Help";
                            ViewBag.EditView = "EditHelp";
                            break;
                        }
                    case 5: //call
                        {
                            ViewBag.allNews = Display(PrvKk);
                            ViewBag.allFiles = DisplayFiles(PrvId);
                            ViewBag.Title = "Служебный раздел";
                            ViewBag.CurrentView = "Prv";
                            ViewBag.EditView = "EditPrv";
                            break;
                        }
                    case 6:
                        ViewBag.allNews = Display(DescKk);
                        ViewBag.allFiles = DisplayFiles(DescId);
                        ViewBag.Title = @GlobalStrings.desc_coll;
                        ViewBag.CurrentView = "Desc";
                        ViewBag.EditView = "EditDesc";
                        break;
                    case 7:
                        ViewBag.allNews = Display(ProofKk);
                        ViewBag.allFiles = DisplayFiles(ProofId);
                        ViewBag.Title = @GlobalStrings.prof_coll;
                        ViewBag.CurrentView = "Proof";
                        ViewBag.EditView = "EditProof";
                        break;
                    case 8:
                        ViewBag.allNews = Display(ResultKk);
                        ViewBag.allFiles = DisplayFiles(ResultId);
                        ViewBag.Title = @GlobalStrings.Granted_help;
                        ViewBag.CurrentView = "Result";
                        ViewBag.EditView = "EditResult";
                        break;
                    case 9:
                        ViewBag.allNews = Display(ConsKk);
                        ViewBag.allFiles = DisplayFiles(ConsId);
                        ViewBag.Title = @GlobalStrings.tka_cons;
                        ViewBag.CurrentView = "Cons";
                        ViewBag.EditView = "EditCons";
                        break;                    
                    default:
                        {
                            ViewBag.allNews = Display(ColKk);
                            ViewBag.allFiles = DisplayFiles(ColEn);
                            ViewBag.Title = GlobalStrings.News;
                            ViewBag.CurrentView = "News";
                            ViewBag.EditView = "Edit";
                            break;
                        }

                }
                ViewBag.FirstNews = Display(ColKk);
                ViewBag.Events = Display(EventKk);
                ViewBag.Foto = DisplayFiles(AAId);
                ViewBag.Name = Display(AAKk);//
            }
            ViewBag.Page = page;
            //ViewBag.Count = GetCount();
            //ViewBag.AllCl = DisplayEv("");
            //ViewBag.Color = Display(Cld);
            return View();
        }

        public List<NewsModel> Display(int cid)
        {
            lock (provider.Locker)
            {
                string query = "SELECT * FROM public.\"site_news\" WHERE page_id =" + cid + " ORDER BY created_on DESC;";
                IDataReader reader = provider.RunQuery(query);

                var selListMsg = new List<NewsModel> { new NewsModel { NewsID = new int(), Title = "", Content = "", Date = new System.DateTime() } };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        selListMsg.Add(new NewsModel { NewsID = (int)reader["id"], Title = reader["title"].ToString(), Content = reader["content"].ToString(), Date = System.DateTime.Parse(reader["created_on"].ToString()) });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    return selListMsg;
                }
                else return null;
            }

        }

        public List<NewsModel> AllNews()
        {
            lock (provider.Locker)
            {
                string query = $"SELECT * FROM public.\"site_news\" WHERE page_id BETWEEN '{GenId}' AND '{FinId}' ORDER BY created_on DESC;";
                IDataReader reader = provider.RunQuery(query);

                var selListMsg = new List<NewsModel> { new NewsModel { NewsID = new int(), Title = "", Content = "", Date = new System.DateTime() } };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        selListMsg.Add(new NewsModel { NewsID = (int)reader["id"], Title = reader["title"].ToString(), Content = reader["content"].ToString(), Date = System.DateTime.Parse(reader["created_on"].ToString()) });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    return selListMsg;
                }
                else return null;
            }

        }

        public List<NewsModel> Display(int cid, string search)
        {
            lock (provider.Locker)
            {
                string query = "SELECT * FROM public.\"collnews\" WHERE coll_id =" + cid + " ORDER BY created_on DESC;";
                if (search != "" && search != null)
                {
                    query = "SELECT * FROM public.\"collnews\" WHERE coll_id =" + cid + " AND (LOWER(title) LIKE LOWER('%" + search + "%') OR LOWER(contnt) LIKE LOWER('%" + search + "%')) ORDER BY created_on DESC;";
                }
                IDataReader reader = provider.RunQuery(query);
                var selListMsg = new List<NewsModel> { new NewsModel { NewsID = new int(), Title = "", Content = "", Priv = "", Date = new System.DateTime() } };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        selListMsg.Add(new NewsModel { NewsID = (int)reader["id"], Title = reader["title"].ToString(), Priv = reader["priv"].ToString(), Content = reader["contnt"].ToString(), Date = System.DateTime.Parse(reader["created_on"].ToString()) });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    return selListMsg;
                }
                else return null;
            }

        }

        public List<NewsModel> DisplayFiles(int cid)
        {
            lock (provider.Locker)
            {
                string query = "SELECT * FROM public.\"site_docs\" WHERE page_id =" + cid + " ORDER BY created_on DESC;";
                IDataReader reader = provider.RunQuery(query);

                var selListMsg = new List<NewsModel> { new NewsModel { NewsID = new int(), Title = "", Date = new System.DateTime() } };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        selListMsg.Add(new NewsModel { NewsID = (int)reader["id"], Title = reader["title"].ToString(), Date = System.DateTime.Parse(reader["created_on"].ToString()) });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;
                    return selListMsg;
                }
                else return null;
            }

        }

        public JsonResult GetFirmsList(string Areas, string term = "")
        {
            var FirmNames = new List<string> { };
            var query = "";
            if (term == "")
            {
                query = @"SELECT * FROM public.organizations ORDER BY LOWER(org_name) ASC;";
            }
            else
            {
                query = @"SELECT * FROM public.organizations WHERE LOWER(org_code) 
            LIKE LOWER('%" + term + "%') ORDER BY LOWER(org_name) ASC;";
            }
            var reader = provider.RunQuery(query);
            if (reader != null)
            while (reader.Read())
            {
                var bin = reader["org_code"].ToString();
                var name = reader["org_name"].ToString();
                var phone = reader["org_phone"].ToString();
                var address = reader["org_address"].ToString();

                FirmNames.Add(bin + "; " + name + "; "+ phone + "; " + address);
            }
            reader.Close();
            return Json(FirmNames, JsonRequestBehavior.AllowGet);
        }

        //public ActionResult Documents()
        //{
        //    return View();
        //}

        public ActionResult FAQ()
        {
            return View();
        }

        public ActionResult Rules()
        {
            return View();
        }

        public ActionResult ConfirmRegistration()
        {
            return View();
        }

        public ActionResult Search()
        {
            return View();
        }

        [Authorize]
        public ActionResult EditSlider()
        {
            int id = 0;
            if (cult.Contains("English"))
            {
                //id = SliderEn;
            }
            else if (cult.Contains("Russian") || cult.Contains("Рус")) id = news_id;
            //else id = SliderKk;
            if (id != 0)
            {
                string query = "SELECT * FROM public.\"site_news\" WHERE page_id =" + id + ";";
                IDataReader reader = provider.RunQuery(query);

                var model = new NewsModel { NewsID = new int(), Title = "", Content = "", Date = new System.DateTime() };
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        model.NewsID = (int)reader["id"];
                        model.Title = reader["title"].ToString();
                        model.Content = reader["content"].ToString();
                        model.Date = System.DateTime.Parse(reader["created_on"].ToString());
                    }
                    reader.Close();

                }
                return PartialView(model);
            }
            else return PartialView();
        }
        [HttpPost]
        public ActionResult TinyMceUpload(HttpPostedFileBase file)
        {
            //Response.AppendHeader("Access-Control-Allow-Origin", "*");

            var location = SaveFile(Server.MapPath("~/uploads/"), file);

            return Json(new { location }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Saves the contents of an uploaded image file.
        /// </summary>
        /// <param name="targetFolder">Location where to save the image file.</param>
        /// <param name="file">The uploaded image file.</param>
        /// <exception cref="InvalidOperationException">Invalid MIME content type.</exception>
        /// <exception cref="InvalidOperationException">Invalid file extension.</exception>
        /// <exception cref="InvalidOperationException">File size limit exceeded.</exception>
        /// <returns>The relative path where the file is stored.</returns>
        private static string SaveFile(string targetFolder, HttpPostedFileBase file)
        {
            const int megabyte = 1024 * 1024;

            if (!file.ContentType.StartsWith("image/"))
            {
                throw new InvalidOperationException("Invalid MIME content type.");
            }

            var extension = Path.GetExtension(file.FileName.ToLowerInvariant());
            string[] extensions = { ".gif", ".jpg", ".png", ".svg", ".webp" };
            if (!extensions.Contains(extension))
            {
                throw new InvalidOperationException("Invalid file extension.");
            }

            if (file.ContentLength > (8 * megabyte))
            {
                throw new InvalidOperationException("File size limit exceeded.");
            }

            var fileName = Guid.NewGuid() + extension;
            var path = Path.Combine(targetFolder, fileName);
            file.SaveAs(path);

            return Path.Combine("/uploads", fileName).Replace('\\', '/');
        }

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file, string area)
        {
            int ids = selArea(area);

            if (file != null && file.ContentLength > 0)
                try
                {
                    string path = Path.Combine(Server.MapPath("~/Uploads"),
                                               Path.GetFileName(file.FileName));
                    file.SaveAs(path);
                    //ViewBag.Message = "File uploaded successfully";
                    string query = $"INSERT INTO public.\"site_docs\"(page_id, title, created_on) VALUES('{ids}', '{file.FileName}', 'NOW()');";
                    //string query = $"INSERT INTO subject_change_data_requests(chat_id, chat_name, chat_text, created_on) VALUES('{value.Id}', '{value.Name}', '{value.Message}', 'NOW()');";
                    provider.RunNonQuery(query);
                }
                catch (Exception ex)
                {
                    ViewBag.Message = "Ошибка:" + ex.Message.ToString();
                }
            else
            {
                ViewBag.Message = "Bам нужно выбрать файл.";
            }
            int id = SelPage(area);
            if (area == "Index" || area == "EditFoto" || area == "AddNew")
                return RedirectToAction(area);
            else return RedirectToAction("page", new { page = id });
        }

        int SelPage(string area)
        {
            switch (area)
            {
                case "Slider":
                    return 26;
                case "Kons":
                    return 3;
                case "List":
                    return 2;
                case "Npa":
                    return 44;
                case "aPart":
                    return 11;
                case "Prog":
                    return 12;
                case "Proof":
                    return 7;
                case "Desc":
                    return 6;
                case "Result":
                    return 8;
                case "Help":
                    return 4;
                case "Call":
                    return 5;
                case "Contacts":
                    return 17;
                case "Cons":
                    return 9;
                case "Part":
                    return 10;
                case "Priv":
                    return 1;
                case "Reg":
                    return 9;
                case "Gen":
                    return 30;
                case "Com":
                    return 31;
                case "Fin":
                    return 32;
                default: return 3;
            }
        }

        int selArea(string area)
        {
            int ids = 1;

            switch (area)
            {
                case "Slider":
                    ids = SliderId;
                    break;
                case "Index":
                    ids = news_id;
                    break;
                case "List":
                    ids = MngId;
                    break;
                case "Kons":
                    ids = KonsId;
                    break;
                case "Part":
                    ids = PartId;
                    break;
                case "aPart":
                    ids = aPartId;
                    break;
                case "Prog":
                    ids = ProgId;
                    break;
                case "Proof":
                    ids = ProofId;
                    break;
                case "Desc":
                    ids = DescId;
                    break;
                case "Result":
                    ids = ResultId;
                    break;
                case "Event":
                    ids = EventId;
                    break;
                case "Help":
                    ids = FaqId;
                    break;
                case "Call":
                    ids = CallId;
                    break;
                case "Priv":
                    ids = MsnId;
                    break; 
                case "Cons":
                    ids = RegId;
                    break;
                case "Gen":
                    ids = GenId;
                    break;
                case "Com":
                    ids = ComId;
                    break;
                case "Fin":
                    ids = FinId;
                    break;
                default:
                    break;
            }
            return ids;
        }

        [HttpPost]
        [Authorize(Users = "astan@law.kk, asta_tka@law.kz, admin@alsy.by, admin_test@nitec.kz")]
        public ActionResult DelFile(NewsModel model, string value, string area)
        {
            var view = area;
            string cid = Request.Params["delete"];
            string query = "DELETE FROM public.\"site_docs\" WHERE id =" + cid + ";";
            provider.RunNonQuery(query);
            int id = SelPage(area);
            if (area == "Index")
                return RedirectToAction(area);
            else return RedirectToAction("page", new { page = id });
        }
        /*
        public int GetCount()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT COUNT(*) FROM notifications WHERE notification_archived='false' AND notification_recipient ='" + user + "';";
            var reader = provider.RunScalar(query);
            return reader;
        }
        
        public string UpdateQuantityUser()
        {
            lock (provider.Locker)
            {
                string query = "SELECT COUNT(*) FROM public.\"AspNetUsers\"";
                System.Data.IDataReader reader = provider.RunQuery(query);

                var count = string.Empty;

                while (reader.Read())
                {
                    count = reader["count"].ToString();
                }
                reader.Close();
                return count;
            }
        }*/
    }
}