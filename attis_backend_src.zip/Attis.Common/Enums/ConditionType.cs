﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-18-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-18-2014
// ***********************************************************************
// <copyright file="ConditionType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    using System.Xml.Serialization;

    /// <summary>
    /// Enum ConditionType
    /// </summary>
    public enum ConditionType
    {
        /// <summary>
        /// The root
        /// </summary>
        [XmlEnum(Name = "root")]
        Root,
        /// <summary>
        /// The brackets
        /// </summary>
        [XmlEnum(Name = "brackets")]
        Brackets,
        /// <summary>
        /// The condition
        /// </summary>
        [XmlEnum(Name = "condition")]
        Condition,
        /// <summary>
        /// The condition_sp
        /// </summary>
        [XmlEnum(Name = "condition_sp")]
        Condition_sp,
        /// <summary>
        /// The condition_widget
        /// </summary>
        [XmlEnum(Name = "condition_widget")]
        Condition_widget,
        /// <summary>
        /// The condition_array count
        /// </summary>
        [XmlEnum(Name = "condition_arrayCount")]
        Condition_arrayCount,
        /// <summary>
        /// The condition compare
        /// </summary>
        [XmlEnum(Name = "condition_compare")]
        ConditionCompare
    }
}
