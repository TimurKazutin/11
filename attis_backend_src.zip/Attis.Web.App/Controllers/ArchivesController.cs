﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using Microsoft.AspNet.Identity;
    using Newtonsoft.Json;
    using Lawyers.Web.App.Helpers;
    using System.Web.WebPages;
    using Lawyers.Web.App.Models;
    using Lawyers.Web.App.Models.Enums;
    using Lawyers.Common.Classes;
    using System.IO;
    using System.Text;

    public class ArchivesController : Controller
    {
        private IDataProvider Provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

        public class Product
        {
            public string attis_cg_good_name { get; set; }
            public string attis_cg_TNVED { get; set; }
            public string attis_cg_quantity { get; set; }
            public string attis_cg_measures { get; set; }
            public string attis_cg_price { get; set; }
        }

        public class Kfiles
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class Prod
        {
            public string attis_cg_good_name { get; set; }
            public string attis_cg_TNVED { get; set; }
            public int attis_cg_quantity { get; set; }
            public string attis_cg_measures { get; set; }
            public float attis_cg_price { get; set; }
        }

        public class Sellers
        {
            public int attis_contract_id { get; set; }
            public string attis_contract_owner { get; set; }
            public string attis_contract_status { get; set; }
            public string attis_contract_kpveds { get; set; }
            public bool attis_contract_type { get; set; }
            public bool attis_contract_case { get; set; }
            public string attis_contract_subject { get; set; }
            public string attis_contract_desc { get; set; }
            public string attis_contract_currency { get; set; }
            public string conditions { get; set; }
            public string attis_contract_delivery_term { get; set; }
            public string attis_contract_delivery_place { get; set; }
            public DateTime? attis_contract_date { get; set; }
            public string attis_contract_payment_type { get; set; }
            public string attis_contract_contragent { get; set; }
            public DateTime? attis_contract_deadline { get; set; }
            public DateTime attis_contract_create_date { get; set; }
            public List<Product> product { get; set; }
            public List<Kfiles> files { get; set; }
            public string language { get; set; }
            public string attis_contract_is_public { get; set; }
        }

        public class Contr
        {
            public int id { get; set; }
            public string attis_contract_currency { get; set; }
            public string attis_contract_status { get; set; }
            public string attis_contract_subject { get; set; }
            public string attis_contract_desc { get; set; }
            public string attis_contract_number { get; set; }
            public string attis_contract_date { get; set; }
            public string attis_contract_owner { get; set; }
            public string owner_org { get; set; }
            public string owner_org_name { get; set; }
            public string attis_contract_contragent { get; set; }
            public string attis_contract_contragent_name { get; set; }
            public float attis_contract_amount { get; set; }
        }

        public class Orders
        {
            public string title { get; set; }
            public List<Contr> contracts { get; set; }
        }


        // GET: deals
        public string Index(string customer_id, string language, string filter)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);
            string kpv = string.Empty;
            if (!String.IsNullOrEmpty(filter))
            {
                //query = $"SELECT kpved_subkind FROM kpved WHERE kpved_id='{filter}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                //kpv = Provider.RunQueryStr(query);
                kpv = "attis_contract_kpveds~'" + filter + "' AND ";
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} attis_contract_is_public = TRUE AND attis_contract_status ='-1' ORDER BY attis_contract_id DESC;";
            }
            else
                //if (customer_id != user) return "user id incorrect";
                //if (string.IsNullOrWhiteSpace(customer_id))
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE attis_contract_status ='-1' AND (attis_contract_contragent='{org_code}' OR attis_contract_owner = '{user}') ORDER BY attis_contract_id DESC;";
            //else query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} attis_contract_owner = '{user}' AND (attis_contract_status ='0' OR attis_contract_status ='1' OR attis_contract_status ='2') OR (attis_contract_status ='1' AND attis_contract_contragent='{org_code}') ORDER BY attis_contract_id DESC;";
            //var query = $"SELECT attis_contract_id, attis_contract_create_date, attis_contract_desc, attis_contract_subject, attis_contract_date FROM attis_contracts WHERE attis_contract_owner = '{user}' OR ;";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";SELECT* FROM currencies WHERE LOWER(currency_name_ru) ~'{query}'
            var reader = Provider.RunQuery(query);
            var sellers = new List<Contr>();
            var mine = new List<Contr>();
            var contag = new List<Contr>();
            var list = new List<Orders>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new Contr
                    {
                        id = (int)reader["attis_contract_id"],
                    };
                    rep.attis_contract_status = reader["attis_contract_status"].ToString();
                    rep.attis_contract_currency = reader["currency_name_ru"].ToString();
                    rep.attis_contract_desc = reader["attis_contract_desc"].ToString();
                    rep.attis_contract_subject = reader["attis_contract_subject"].ToString();
                    rep.attis_contract_owner = reader["attis_contract_owner"].ToString();
                    rep.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                    rep.attis_contract_date = reader["attis_contract_date"].ToString().Split(' ')[0];
                    rep.attis_contract_number = rep.id.ToString();// + "/2020" + rep.attis_contract_date?.ToString("yyyy");

                    sellers.Add(rep);
                }
                reader.Close();
                foreach (var ln in sellers)
                {
                    query = $"SELECT SUM(attis_cg_price*attis_cg_quantity) FROM attis_contract_goods WHERE attis_cg_contract_id = '{ln.id}';";
                    ln.attis_contract_amount = Provider.RunScalar(query);
                    if (!String.IsNullOrEmpty(ln.attis_contract_contragent))
                    {
                        query = $"SELECT org_name FROM organizations WHERE org_code= '{ln.attis_contract_contragent}'";
                        ln.attis_contract_contragent_name = Provider.RunQueryStr(query);
                    }
                    else ln.attis_contract_contragent_name = "";
                    query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                    ln.owner_org = Provider.RunQueryStr(query);
                    query = $"SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                    ln.owner_org_name = Provider.RunQueryStr(query);
                    if (ln.attis_contract_amount < 0) ln.attis_contract_amount = 0;
                    if (ln.attis_contract_owner == user) mine.Add(ln);
                    if (ln.attis_contract_contragent == org_code) contag.Add(ln);
                }
                var new1 = new Orders
                {
                    title = "Новые",
                };
                new1.contracts = new List<Contr>(sellers);
                var new2 = new Orders
                {
                    title = "Мои",
                };
                new2.contracts = new List<Contr>(mine);
                var new3 = new Orders
                {
                    title = "Участвую",
                };
                new3.contracts = new List<Contr>(contag);
                list.Add(new1); list.Add(new2); list.Add(new3);
                //return Json(list, JsonRequestBehavior.AllowGet);
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }
        //end
    }
}