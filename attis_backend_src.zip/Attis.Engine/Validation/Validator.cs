﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 11-12-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 18-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Validation namespace.
/// </summary>
namespace Lawyers.Engine.Validation
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using Lawyers.Common.Classes;
    using Lawyers.Common.Enums;
    using Common.Model;
    using Lawyers.Engine.Data;
    using System.Threading;

    /// <summary>
    /// Class Validator.
    /// </summary>
    public class Validator
    {
        /// <summary>
        /// The document
        /// </summary>
        private Document document;
        /// <summary>
        /// The dataset
        /// </summary>
        private DataSet dataset;
        /// <summary>
        /// Default culture
        /// </summary>
        private CultureInfo defaultCulture;

        /// <summary>
        /// Initializes a new instance of the <see cref="Validator"/> class.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="dataset">The dataset.</param>
        public Validator(Document document, DataSet dataset, CultureInfo defaultCulture)
        {
            this.dataset = dataset;
            this.document = document;
            this.defaultCulture = defaultCulture;
        }

        /// <summary>
        /// Checks the specified widget.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="record">The record.</param>
        /// <param name="value">The value.</param>
        /// <param name="errors">The errors.</param>
        /// <param name="actions">The actions.</param>
        public void Check(Widget widget, SortedDictionary<string, int> FieldIndexes, Record record, object value, out List<string> errors, out List<Common.Model.Action> actions, Func<string, string, string> ExternalTemplateCall)
        {
            errors = new List<string>();
            actions = new List<Common.Model.Action>();

            this.GetErrors(widget, value, ref errors);
            if (widget.LocalChecks != null) this.GetActions(widget, FieldIndexes, record, value, ref errors, ref actions, ExternalTemplateCall);
        }

        /// <summary>
        /// Checks rules of the specified widget.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="record">The record.</param>
        /// <param name="value">The value.</param>
        /// <param name="errors">The errors.</param>
        public void CheckRules(Widget widget, SortedDictionary<string, int> FieldIndexes, Record record, object value, out List<string> errors)
        {
            errors = new List<string>();
            this.GetErrors(widget, value, ref errors);
        }

        /// <summary>
        /// Checks the specified widget.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="record">The record.</param>
        /// <param name="value">The value.</param>
        /// <param name="errors">The errors.</param>
        /// <param name="actions">The actions.</param>
        public void ApplyActions(Widget widget, SortedDictionary<string, int> FieldIndexes, Record record, object value, out List<string> errors, out List<Common.Model.Action> actions, Func<string, string, string> ExternalTemplateCall)
        {
            errors = new List<string>();
            actions = new List<Common.Model.Action>();

            if (widget.LocalChecks != null)
                this.GetActions(widget, FieldIndexes, record, value, ref errors, ref actions, ExternalTemplateCall);
        }

        /// <summary>
        /// Gets the errors.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="value">The value.</param>
        /// <param name="errors">The errors.</param>
        private void GetErrors(Widget widget, object value, ref List<string> errors)
        {
            var currentCulturePostfix = Common.Cultures.GetLanguage();
            //todo translate into supported languages
            // Required
            if (widget.Mandatory && (value == null || value.ToString() == ""))
            {
                if (currentCulturePostfix == Lawyers.Common.Cultures.RussianCultureName)
                    errors.Add("Это поле обязательно к заполнению");
                else if (currentCulturePostfix == Lawyers.Common.Cultures.KazakhCultureName)
                    errors.Add("Бұл өріс міндетті");
                else
                    errors.Add("This field is required!");
            }

            // Data validation
            if (value != null && value.ToString().Length > 0)
            {
                switch (widget.DataType)
                {
                    case DataType.Int2:
                    case DataType.Int4:
                    case DataType.Integer:
                        try
                        {
                            var number = Convert.ToInt32(value);
                        }
                        catch
                        {
                            if (currentCulturePostfix == Lawyers.Common.Cultures.RussianCultureName)
                                errors.Add("Значение нельзя преобразовать в число");
                            else if (currentCulturePostfix == Lawyers.Common.Cultures.KazakhCultureName)
                                errors.Add("Мәнді санға түрлендіру мүмкін емес");
                            else
                                errors.Add("Could not convert to number!");
                        }
                        break;
                    case DataType.Decimal:
                    case DataType.Numeric:
                        try
                        {
                            var number = Convert.ToDecimal(value, this.defaultCulture);
                        }
                        catch
                        {
                            if (currentCulturePostfix == Lawyers.Common.Cultures.RussianCultureName)
                                errors.Add("Значение нельзя преобразовать в число");
                            else if (currentCulturePostfix == Lawyers.Common.Cultures.KazakhCultureName)
                                errors.Add("Мәнді санға түрлендіру мүмкін емес");
                            else
                                errors.Add("Could not convert to number!");
                        }
                        break;
                    case DataType.Date_:
                    case DataType.Date:
                        try
                        {
                            var date = DateTime.ParseExact(value.ToString(), "dd.MM.yyyy", CultureInfo.InvariantCulture);
                            //var date = DateTime.ParseExact(value.ToString(), "yyyy.MM.dd", CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            if (currentCulturePostfix == Lawyers.Common.Cultures.RussianCultureName)
                                errors.Add("Неправильный формат даты");
                            else if (currentCulturePostfix == Lawyers.Common.Cultures.KazakhCultureName)
                                errors.Add("Жарамсыз күн пішімі");
                            else
                                errors.Add("Date is not formatted correctly!");
                        }
                        break;
                    default:
                        break;
                }
            }

            // Length
            if (widget.Length > 0 && value != null && value.ToString().Length > widget.Length)
            {
                if (currentCulturePostfix == Lawyers.Common.Cultures.RussianCultureName)
                    errors.Add("Число символов не должно превосходить " + widget.Length.ToString());
                else if (currentCulturePostfix == Lawyers.Common.Cultures.KazakhCultureName)
                    errors.Add("Таңбалардың саны аспауы керек " + widget.Length.ToString());
                else
                    errors.Add("Number of symbols should not exceed " + widget.Length.ToString());
            }

            /*/ mask
			if (widget.Mask != null && widget.Mask.Length > 0 && value != null && value.ToString().Length > 0)
			{
				if (Regex.IsMatch(value.ToString(), widget.Mask))
				    result.Add("Неверный формат данных");
			}*/
        }

        /// <summary>
        /// Gets the actions.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="record">The record.</param>
        /// <param name="value">The value.</param>
        /// <param name="errors">The errors.</param>  //TODO errors actually are not used in Actions
        /// <param name="actions">The actions.</param>
        private void GetActions(Widget widget, SortedDictionary<string, int> FieldIndexes, Record record, object value, ref List<string> errors, ref List<Common.Model.Action> actions, Func<string, string, string> ExternalTemplateCall)
        {
            foreach (Check check in widget.LocalChecks)
            {
                bool isApply = check.Condition.Check(this.document, this.dataset.Identity, FieldIndexes, widget, record == null ? null : record.Values.Select(c => c.Value).ToArray(), value);

                foreach (Common.Model.Action action in check.Actions)
                {
                    actions.AddRange(this.SetAction(null, action, isApply, record, ExternalTemplateCall));
                }
            }
        }

        /// <summary>
        /// Sets the action.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="action">The action.</param>
        /// <param name="apply">if set to <c>true</c> [apply].</param>
        /// <param name="record">The record.</param>
        /// <returns>List&lt;Model.Action&gt;.</returns>
        private List<Common.Model.Action> SetAction(Widget widget, Common.Model.Action action, bool apply, Record record, Func<string, string, string> ExternalTemplateCall)
        {
            List<Common.Model.Action> result = new List<Common.Model.Action>();

            Common.Model.Action act = new Common.Model.Action()
            {
                Apply = apply,
                DefaultValue = action.DefaultValue,
                DestMvcName = action.DestMvcName,
                FieldFilterName = action.FieldFilterName,
                Mask = action.Mask,
                Message = action.Message,
                MvcName = action.MvcName,
                StoredProcedureName = action.StoredProcedureName,
                Type = action.Type,
                TypeString = action.TypeString,
                WidgetDestination = action.WidgetDestination,
                WidgetName = action.WidgetName,
                WidgetSource = action.WidgetSource
            };

            if (widget == null)
            {
                act.WidgetName = string.IsNullOrEmpty(action.WidgetName) ? act.WidgetSource : act.WidgetName;
                widget = this.document.FindChildByName(act.WidgetName);
                if (widget != null) act.MvcName = widget.WidgetName;
            }
            else
            {
                act.MvcName = widget.WidgetName;
            }

            switch (action.Type)
            {
                case ActionType.Mandatory:
                    widget.Mandatory = apply;

                    break;
                case ActionType.ReadOnly:
                    widget.ReadOnly = apply;
                    break;
                case ActionType.Visible:
                    widget.Visible = apply;
                    break;
                case ActionType.Link:
                    Widget dest = this.document.FindChildByName(act.WidgetDestination);
                    if (dest != null)
                    {
                        act.DestMvcName = dest.MvcType + "_" + dest.Name;
                    }
                    break;
                case ActionType.Value:
                    string value = !action.DefaultValue.Contains("function:") ? action.DefaultValue : this.FunctionCalculate(action.DefaultValue, widget.TableName, record, ExternalTemplateCall);
                    act.DefaultValue = value;
                    break;
                case ActionType.Filter:
                    Widget wgtDest = this.document.FindChildByName(act.WidgetDestination);
                    if (wgtDest != null && wgtDest.Parent != null && wgtDest.Parent.Type == WidgetType.DBComboBox && apply)
                    {
                        wgtDest.Filters.First(f => f.Name == act.FieldFilterName).Apply = true;
                        act.DestMvcName = wgtDest.Parent.MvcType + "_" + wgtDest.Parent.Name;
                        Table table = this.dataset.Tables[wgtDest.TableName];
                        act.Data = (wgtDest.Filters.Count == 0 ? table.Records : table.ApplyFilters(wgtDest, record, this.dataset))
                        .Select(r =>
                            new KeyValueData(
                                r[table.GetFieldIndex(wgtDest.Field)].ToString(),
                                r[table.GetFieldIndex(wgtDest.FieldView)].ToString(),
                                wgtDest.Children.Where(w => w.Visible).ToDictionary(ws => ws.MvcType + "_" + ws.Name, ws => r[table.GetFieldIndex(ws.Field)].ToString()))
                            ).OrderBy(k => k.Key).ToList();
                        wgtDest.Filters.First(f => f.Name == act.FieldFilterName).Apply = false;
                    }
                    break;
                default:
                    break;
            }

            result.Add(act);

            if (widget != null && !widget.Simple && (action.Type == ActionType.Mandatory || action.Type == ActionType.ReadOnly || action.Type == ActionType.Visible))
            {
                foreach (Widget child in widget.Children) result.AddRange(this.SetAction(child, action, apply, record, ExternalTemplateCall));
            }

            return result;
        }

        /// <summary>
        /// Checks all.
        /// </summary>
        public void CheckAll(Func<string, string, string> ExternalTemplateCall)
        {
            List<string> errors;
            List<Common.Model.Action> actions;

            this.CheckWidget(this.document, out errors, out actions, ExternalTemplateCall);

            foreach (Common.Model.Action action in actions.Where(a => a.Apply))
            {
                switch (action.Type)
                {
                    case ActionType.Value:
                        Widget widget = this.document.FindChildByName(action.WidgetName);
                        string value = !action.DefaultValue.Contains("function:") ? action.DefaultValue : this.FunctionCalculate(action.DefaultValue, null, null, ExternalTemplateCall);
                        widget.Value = value;
                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// Functions the calculate.
        /// </summary>
        /// <param name="formula">The formula.</param>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="record">The record.</param>
        /// <returns>System.String.</returns>
        private string FunctionCalculate(string formula, string tableName, Record record, Func<string, string, string> ExternalTemplateCall)
        {
            formula = formula.Remove(0, 9);
            formula = WebUtility.HtmlDecode(formula);

            while (formula.Contains("sum(") ||
                formula.Contains("count(") ||
                formula.Contains("count_filter(") ||
                formula.Contains("sum_filter(") ||
                formula.Contains("auth()") ||
                formula.Contains("subj_id()") ||
                formula.Contains("law_id()") ||
                formula.Contains("auth_role()") ||
                formula.Contains("auth_company()") ||
                formula.Contains("template(") || formula.Contains('['))
            {
                bool isBracket = true;

                string tableField = string.Empty;

                if (formula.Contains("sum("))
                {
                    string subSum = formula.Substring(formula.IndexOf("sum("), formula.IndexOf(")", formula.IndexOf("sum(")) - formula.IndexOf("sum(") + 1);
                    tableField = subSum.Substring(subSum.IndexOf('[') + 1, subSum.IndexOf(']') - subSum.IndexOf('[') - 1);
                    string sum = SumTableField(tableField, this.dataset).ToString().Replace(',', '.');

                    formula = formula.Replace(subSum, sum);
                    isBracket = false;
                }

                if (formula.Contains("count("))
                {
                    string subSum = formula.Substring(formula.IndexOf("count("), formula.IndexOf(")", formula.IndexOf("count(")) - formula.IndexOf("count(") + 1);
                    tableField = subSum.Substring(subSum.IndexOf('[') + 1, subSum.IndexOf(']') - subSum.IndexOf('[') - 1);
                    string sum = CountTableField(tableField, this.dataset).ToString().Replace(',', '.');

                    formula = formula.Replace(subSum, sum);
                    isBracket = false;
                }

                if (formula.Contains("count_filter("))
                {
                    string funcParameters = formula.Substring(formula.IndexOf("count_filter("), formula.IndexOf(")", formula.IndexOf("count_filter(")) - formula.IndexOf("count_filter(") + 1);
                    string[] funcParams = funcParameters.Substring(funcParameters.IndexOf('(') + 1, funcParameters.IndexOf(')') - funcParameters.IndexOf('(') - 1).Split(',');
                    string funcWidget = funcParams[0].Substring(2);
                    tableField = funcParams[1].Substring(funcParams[1].IndexOf('[') + 1, funcParams[1].IndexOf(']') - funcParams[1].IndexOf('[') - 1);
                    string sum = CountFilter(funcWidget, tableField, this.dataset, record).ToString().Replace(',', '.');

                    formula = formula.Replace(funcParameters, sum);
                    isBracket = false;
                }

                if (formula.Contains("sum_filter("))
                {
                    string funcParameters = formula.Substring(formula.IndexOf("sum_filter("), formula.IndexOf(")", formula.IndexOf("sum_filter(")) - formula.IndexOf("sum_filter(") + 1);
                    string[] funcParams = funcParameters.Substring(funcParameters.IndexOf('(') + 1, funcParameters.IndexOf(')') - funcParameters.IndexOf('(') - 1).Split(',');
                    string funcWidget = funcParams[0].Substring(2);
                    tableField = funcParams[1].Substring(funcParams[1].IndexOf('[') + 1, funcParams[1].IndexOf(']') - funcParams[1].IndexOf('[') - 1);
                    string sum = SumFilterTableField(funcWidget, tableField, this.dataset, record).ToString().Replace(',', '.');

                    formula = formula.Replace(funcParameters, sum);
                    isBracket = false;
                }

                if (formula.Contains("auth()"))
                {
                    var userID = this.dataset.Identity.Claims.Where(c => c.Type == System.Security.Claims.ClaimTypes.NameIdentifier).First().Value;
                    formula = formula.Replace("auth()", userID);
                    //isBracket = false; //TODO check new version of userID (now it is guid)
                    return formula;
                }

                if (formula.Contains("subj_id()"))
                {
                    string res = String.Empty;
                    var claim = this.dataset.Identity.Claims.Where(c => c.Type == "subj_id").FirstOrDefault();
                    if (claim != null)
                        res = claim.Value;
                    formula = formula.Replace("subj_id()", res);
                    return formula;
                }

                if (formula.Contains("law_id()"))
                {
                    string res = String.Empty;
                    var claim = this.dataset.Identity.Claims.Where(c => c.Type == "subject_law_supplier_id").FirstOrDefault();
                    if (claim != null)
                        res = claim.Value;
                    //try
                    //{
                    //    res = this.dataset.Identity.Claims.Where(c => c.Type == "subject_law_supplier_id").First().Value;
                    //}
                    //catch (InvalidOperationException)
                    //{
                    //    res = "";
                    //}

                    formula = formula.Replace("law_id()", res);
                    return formula;
                }

                if (formula.Contains("auth_role()"))
                {
                    var userID = this.dataset.Identity.Claims.Where(c => c.Type == System.Security.Claims.ClaimTypes.GroupSid).First().Value;
                    formula = formula.Replace("auth_role()", userID);
                    //isBracket = false;
                    return formula;
                }

                if (formula.Contains("auth_company()"))
                {
                    string userID = String.Empty;
                    var claim = this.dataset.Identity.Claims.Where(c => c.Type == System.Security.Claims.ClaimTypes.PrimarySid).FirstOrDefault();
                    if (claim != null)
                        userID = claim.Value;
                    formula = formula.Replace("auth_company()", userID);
                    return formula;
                }

                if (formula.Contains("template("))
                {
                    string funcParameters = formula.Substring(formula.IndexOf("template("), formula.IndexOf(")", formula.IndexOf("template(")) - formula.IndexOf("template(") + 1);
                    string[] funcParams = funcParameters.Substring(funcParameters.IndexOf('(') + 1, funcParameters.IndexOf(')') - funcParameters.IndexOf('(') - 1).Split(',');
                    string res = ExternalTemplateResult(funcParams, ExternalTemplateCall);

                    formula = formula.Replace(funcParameters, res);
                    isBracket = false;
                }

                if (isBracket)
                {
                    string subField = formula.Substring(formula.IndexOf("["), formula.IndexOf("]") - formula.IndexOf("[") + 1);
                    tableField = subField.Substring(subField.IndexOf('[') + 1, subField.IndexOf(']') - subField.IndexOf('[') - 1);
                    string value = tableField.StartsWith("w:") ?
                        this.GetWidgetValue(tableField.Substring(2)) :
                        GetTableField(tableField, this.dataset, tableName, record).Replace(',', '.');
                    if (value == "") value = "0";

                    formula = formula.Replace(subField, value);
                }
            }

            CodeBuilder cb = new CodeBuilder();
            string result = cb.Calculate(formula);
            return result;
        }

        private string ExternalTemplateResult(string[] funcParams, Func<string, string, string> ExternalTemplateCall)
        {
            string guid = funcParams[0].Trim();
            string pars = string.Empty;

            for (int i = 1; i < funcParams.Length; i++)
            {
                pars += "/";
                if (funcParams[i].StartsWith("w:"))
                {
                    Widget widget = this.document.FindChildByName(funcParams[i].Substring(2));
                    if ((widget.Value ?? widget.DefaultValue) == null)
                    {
                        return "0";
                    }
                    pars += (widget.Value ?? widget.DefaultValue).ToString().Replace(" ", string.Empty);
                }
                else
                {
                    pars += funcParams[i];
                }
            }

            pars = pars.Substring(1);
            string result = ExternalTemplateCall(guid, pars);
            return result;
        }

        /// <summary>
        /// Counts the filter.
        /// </summary>
        /// <param name="funcWidget">The function widget.</param>
        /// <param name="tableField">The table field.</param>
        /// <param name="ds">The ds.</param>
        /// <param name="record">The record.</param>
        /// <returns>System.Object.</returns>
        private object CountFilter(string funcWidget, string tableField, DataSet ds, Record record)
        {
            string[] split = tableField.Split('.');
            string tableName = split[0];
            string fieldName = split[1];

            Table table = ds.Tables[tableName];

            Widget wgt = this.document.FindChildByName(funcWidget);

            List<Record> records = table.ApplyFilters(wgt, record, ds);

            return records.Count;
        }

        /// <summary>
        /// Sums the filter table field.
        /// </summary>
        /// <param name="funcWidget">The function widget.</param>
        /// <param name="tableField">The table field.</param>
        /// <param name="ds">The ds.</param>
        /// <param name="record">The record.</param>
        /// <returns>System.Decimal.</returns>
        private decimal SumFilterTableField(string funcWidget, string tableField, DataSet ds, Record record)
        {
            string[] split = tableField.Split('.');
            string tableName = split[0];
            string fieldName = split[1];

            decimal result = 0;
            Table table = ds.Tables[tableName];

            Widget wgt = this.document.FindChildByName(funcWidget);

            List<Record> records = table.ApplyFilters(wgt, record, ds);

            foreach (Record rcd in records)
            {
                result += (decimal)rcd[table.GetFieldIndex(fieldName)].Value;
            }

            return result;
        }

        /// <summary>
        /// Sums the table field.
        /// </summary>
        /// <param name="tableField">The table field.</param>
        /// <param name="ds">The ds.</param>
        /// <returns>System.Decimal.</returns>
        private decimal SumTableField(string tableField, DataSet ds/*, string tblName, Record record*/)
        {
            string[] split = tableField.Split('.');
            string tableName = split[0];
            string fieldName = split[1];

            decimal result = 0;
            Table table = ds.Tables[tableName];

            List<Record> records = table.Records;

            Widget tableWidget = this.document.FindChildByTable(tableName);

            if (tableWidget != null && tableWidget.Filters.Count > 0)
            {
                records = table.ApplyFilters(tableWidget, null, ds);
            }

            foreach (Record record in records)
            {
                result += (decimal)record[table.GetFieldIndex(fieldName)].Value;
            }

            return result;
        }

        /// <summary>
        /// Counts the table field.
        /// </summary>
        /// <param name="tableField">The table field.</param>
        /// <param name="ds">The ds.</param>
        /// <returns>System.Decimal.</returns>
        private int CountTableField(string tableField, DataSet ds/*, string tblName, Record record*/)
        {
            string[] split = tableField.Split('.');
            string tableName = split[0];
            string fieldName = split[1];

            int result = 0;
            Table table = ds.Tables[tableName];

            result = table.Records.Count;

            return result;
        }

        /// <summary>
        /// Gets the table field.
        /// </summary>
        /// <param name="tableField">The table field.</param>
        /// <param name="ds">The ds.</param>
        /// <param name="tblName">Name of the table.</param>
        /// <param name="record">The record.</param>
        /// <returns>System.String.</returns>
        private string GetTableField(string tableField, DataSet ds, string tblName, Record record)
        {
            string[] split = tableField.Split('.');
            string tableName = split[0];
            string fieldName = split[1];

            string result = string.Empty;
            Table table = ds.Tables[tableName];

            if (record != null && record.Parent.Name != table.Name)
            {
                record = null;
            }

            if (record != null && tableName == tblName)
            {
                if (record[table.GetFieldIndex(fieldName)].Value == null)
                {
                    result += null;
                }
                else
                {
                    result += record[table.GetFieldIndex(fieldName)].Value.ToString();
                }
            }
            else
            {
                if (table.Records.Count > 0 && table.Records[0][table.GetFieldIndex(fieldName)].Value != null)
                {
                    result += table.Records[0][table.GetFieldIndex(fieldName)].Value.ToString();
                }
            }

            return result;
        }

        /// <summary>
        /// Gets the widget value.
        /// </summary>
        /// <param name="p">The p.</param>
        /// <returns>System.String.</returns>
        private string GetWidgetValue(string p)
        {
            Widget widget = this.document.FindChildByName(p);
            object res = widget.Value ?? widget.DefaultValue;
            return res == null ? string.Empty : res.ToString().Replace(',', '.');
        }

        /// <summary>
        /// Checks the widget.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="errors">The errors.</param>
        /// <param name="actions">The actions.</param>
        public void CheckWidget(Widget widget, out List<string> errors, out List<Common.Model.Action> actions, Func<string, string, string> ExternalTemplateCall)
        {
            errors = new List<string>();
            actions = new List<Common.Model.Action>();

            List<string> _errors;
            List<Common.Model.Action> _actions;

            foreach (Check check in widget.LocalChecks)
            {
                Record record = string.IsNullOrEmpty(widget.TableName) ? null : dataset.Tables[widget.TableName].Records.FirstOrDefault();
                SortedDictionary<string, int> FieldIndexes = string.IsNullOrEmpty(widget.TableName) ? null : dataset.Tables[widget.TableName].GetFieldIndexes();

                /// TODO: Add widgets from conditions

                this.Check(widget, FieldIndexes, record, null, out _errors, out _actions, ExternalTemplateCall);
                errors.AddRange(_errors);
                actions.AddRange(_actions);
            }

            foreach (Widget child in widget.Children)
            {
                CheckWidget(child, out _errors, out _actions, ExternalTemplateCall);
                errors.AddRange(_errors);
                actions.AddRange(_actions);
            }
        }
    }
}
