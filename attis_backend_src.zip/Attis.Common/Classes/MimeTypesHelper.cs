﻿namespace Lawyers.Common.Classes
{
    using System.Collections.Generic;

    /// <summary>
    /// Helps with Mime Types
    /// </summary>
    public static class MimeTypesHelper
    {
        /// <summary>
        /// Returns the content type based on the given file extension
        /// </summary>
        public static string GetContentType(string fileExtension)
        {
            var mimeTypes = new Dictionary<string, string>
            {
                {".bmp",  "image/bmp"},
                {".gif",  "image/gif"},
                {".jpeg", "image/jpeg"},
                {".jpg",  "image/jpeg"},
                {".png",  "image/png"},
                {".tif",  "image/tiff"},
                {".tiff", "image/tiff"},
                {".doc",  "application/msword"},
                {".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
                {".pdf",  "application/pdf"},
                {".ppt",  "application/vnd.ms-powerpoint"},
                {".pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"},
                {".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
                {".xls",  "application/vnd.ms-excel"},
                {".csv",  "text/csv"},
                {".xml",  "text/xml"},
                {".txt",  "text/plain"},
                {".zip",  "application/zip"},
                {".ogg",  "application/ogg"},
                {".mp3",  "audio/mpeg"},
                {".wma",  "audio/x-ms-wma"},
                {".wav",  "audio/x-wav"},
                {".wmv",  "audio/x-ms-wmv"},
                {".swf",  "application/x-shockwave-flash"},
                {".avi",  "video/avi"},
                {".mp4",  "video/mp4"},
                {".mpeg", "video/mpeg"},
                {".mpg",  "video/mpeg"},
                {".qt",   "video/quicktime"}
            };

            // if the file type is not recognized, return "application/octet-stream" so the browser will simply download it
            return mimeTypes.ContainsKey(fileExtension) ? mimeTypes[fileExtension] : "application/octet-stream";
        }

        public static string GetIconPath(string fileExtension)
        {
            var mimeTypes = new Dictionary<string, string>
            {
                {".bmp",  "/Content/images/apps/file-bmp.png"},
                {".gif",  "/Content/images/apps/file-gif.png"},
                {".jpeg", "/Content/images/apps/file-jpg.png"},
                {".jpg",  "/Content/images/apps/file-jpg.png"},
                {".png",  "/Content/images/apps/file-png.png"},
                {".tif",  "/Content/images/apps/common.png"},
                {".tiff", "/Content/images/apps/common.png"},
                {".doc",  "/Content/images/apps/file-doc.png"},
                {".docx", "/Content/images/apps/file-doc.png"},
                {".pdf",  "/Content/images/apps/pdf-icon.png"},
                {".ppt",  "/Content/images/apps/file-ppt.png"},
                {".pptx", "/Content/images/apps/file-ppt.png"},
                {".xlsx", "/Content/images/apps/file-xls.png"},
                {".xls",  "/Content/images/apps/file-xls.png"},
                {".csv",  "/Content/images/apps/common.png"},
                {".xml",  "/Content/images/apps/common.png"},
                {".txt",  "/Content/images/apps/common.png"},
                {".zip",  "/Content/images/apps/common.png"},
                {".ogg",  "/Content/images/apps/common.png"},
                {".mp3",  "/Content/images/apps/file-mp3.png"},
                {".wma",  "/Content/images/apps/common.png"},
                {".wav",  "/Content/images/apps/common.png"},
                {".wmv",  "/Content/images/apps/common.png"},
                {".swf",  "/Content/images/apps/common.png"},
                {".avi",  "/Content/images/apps/file-avi.png"},
                {".mp4",  "/Content/images/apps/file-mp4.png"},
                {".mpeg", "/Content/images/apps/common.png"},
                {".mpg",  "/Content/images/apps/common.png"},
                {".qt",   "/Content/images/apps/common.png"}
            };

            // if the file type is not recognized, return "application/octet-stream" so the browser will simply download it
            return mimeTypes.ContainsKey(fileExtension) ? mimeTypes[fileExtension] : "/Content/images/apps/common.png";
        }

        public static bool IsPicture(string fileExtension)
        {
            var mimeTypes = new List<string>
            {
                ".bmp",
                ".gif",
                ".jpeg",
                ".jpg",
                ".png",
                ".tif",
                ".tiff"
            };

            return mimeTypes.Contains(fileExtension);
        }
    }
}
