﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lawyers.Web.App.Models
{

    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0", IsNullable = false)]
    public partial class ESADout_CU
    {

        private string documentIDField;

        private ushort customsOfficeField;

        private ulong aWLocationDocumentNumberField;

        private string customsProcedureField;

        private byte customsModeCodeField;

        private string languageCUESADField;

        private string recipientCountryCodeField;

        private System.DateTime executionDateField;

        private string securityLabelCodeField;

        private byte wTORatesField;

        private ESADout_CUESADout_CUGoodsShipment eSADout_CUGoodsShipmentField;

        private ESADout_CUFilledPerson filledPersonField;

        private ESADout_CUCUESADCustomsRepresentative cUESADCustomsRepresentativeField;

        private ESADout_CUDTSout_CU dTSout_CUField;

        private string documentModeIDField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string DocumentID
        {
            get
            {
                return this.documentIDField;
            }
            set
            {
                this.documentIDField = value;
            }
        }

        /// <remarks/>
        public ushort CustomsOffice
        {
            get
            {
                return this.customsOfficeField;
            }
            set
            {
                this.customsOfficeField = value;
            }
        }

        /// <remarks/>
        public ulong AWLocationDocumentNumber
        {
            get
            {
                return this.aWLocationDocumentNumberField;
            }
            set
            {
                this.aWLocationDocumentNumberField = value;
            }
        }

        /// <remarks/>
        public string CustomsProcedure
        {
            get
            {
                return this.customsProcedureField;
            }
            set
            {
                this.customsProcedureField = value;
            }
        }

        /// <remarks/>
        public byte CustomsModeCode
        {
            get
            {
                return this.customsModeCodeField;
            }
            set
            {
                this.customsModeCodeField = value;
            }
        }

        /// <remarks/>
        public string LanguageCUESAD
        {
            get
            {
                return this.languageCUESADField;
            }
            set
            {
                this.languageCUESADField = value;
            }
        }

        /// <remarks/>
        public string RecipientCountryCode
        {
            get
            {
                return this.recipientCountryCodeField;
            }
            set
            {
                this.recipientCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime ExecutionDate
        {
            get
            {
                return this.executionDateField;
            }
            set
            {
                this.executionDateField = value;
            }
        }

        /// <remarks/>
        public string SecurityLabelCode
        {
            get
            {
                return this.securityLabelCodeField;
            }
            set
            {
                this.securityLabelCodeField = value;
            }
        }

        /// <remarks/>
        public byte WTORates
        {
            get
            {
                return this.wTORatesField;
            }
            set
            {
                this.wTORatesField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipment ESADout_CUGoodsShipment
        {
            get
            {
                return this.eSADout_CUGoodsShipmentField;
            }
            set
            {
                this.eSADout_CUGoodsShipmentField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUFilledPerson FilledPerson
        {
            get
            {
                return this.filledPersonField;
            }
            set
            {
                this.filledPersonField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUCUESADCustomsRepresentative CUESADCustomsRepresentative
        {
            get
            {
                return this.cUESADCustomsRepresentativeField;
            }
            set
            {
                this.cUESADCustomsRepresentativeField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUDTSout_CU DTSout_CU
        {
            get
            {
                return this.dTSout_CUField;
            }
            set
            {
                this.dTSout_CUField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string DocumentModeID
        {
            get
            {
                return this.documentModeIDField;
            }
            set
            {
                this.documentModeIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipment
    {

        private string originCountryNameField;

        private byte totalGoodsNumberField;

        private byte totalPackageNumberField;

        private byte totalSheetNumberField;

        private decimal totalCustCostField;

        private string custCostCurrencyCodeField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUConsignor eSADout_CUConsignorField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUConsignee eSADout_CUConsigneeField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUFinancialAdjustingResponsiblePerson eSADout_CUFinancialAdjustingResponsiblePersonField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUDeclarant eSADout_CUDeclarantField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsLocation eSADout_CUGoodsLocationField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigment eSADout_CUConsigmentField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUMainContractTerms eSADout_CUMainContractTermsField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoods[] eSADout_CUGoodsField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPayment[] eSADout_CUPaymentsField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string OriginCountryName
        {
            get
            {
                return this.originCountryNameField;
            }
            set
            {
                this.originCountryNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte TotalGoodsNumber
        {
            get
            {
                return this.totalGoodsNumberField;
            }
            set
            {
                this.totalGoodsNumberField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte TotalPackageNumber
        {
            get
            {
                return this.totalPackageNumberField;
            }
            set
            {
                this.totalPackageNumberField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte TotalSheetNumber
        {
            get
            {
                return this.totalSheetNumberField;
            }
            set
            {
                this.totalSheetNumberField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal TotalCustCost
        {
            get
            {
                return this.totalCustCostField;
            }
            set
            {
                this.totalCustCostField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string CustCostCurrencyCode
        {
            get
            {
                return this.custCostCurrencyCodeField;
            }
            set
            {
                this.custCostCurrencyCodeField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUConsignor ESADout_CUConsignor
        {
            get
            {
                return this.eSADout_CUConsignorField;
            }
            set
            {
                this.eSADout_CUConsignorField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUConsignee ESADout_CUConsignee
        {
            get
            {
                return this.eSADout_CUConsigneeField;
            }
            set
            {
                this.eSADout_CUConsigneeField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUFinancialAdjustingResponsiblePerson ESADout_CUFinancialAdjustingResponsiblePerson
        {
            get
            {
                return this.eSADout_CUFinancialAdjustingResponsiblePersonField;
            }
            set
            {
                this.eSADout_CUFinancialAdjustingResponsiblePersonField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUDeclarant ESADout_CUDeclarant
        {
            get
            {
                return this.eSADout_CUDeclarantField;
            }
            set
            {
                this.eSADout_CUDeclarantField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsLocation ESADout_CUGoodsLocation
        {
            get
            {
                return this.eSADout_CUGoodsLocationField;
            }
            set
            {
                this.eSADout_CUGoodsLocationField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigment ESADout_CUConsigment
        {
            get
            {
                return this.eSADout_CUConsigmentField;
            }
            set
            {
                this.eSADout_CUConsigmentField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUMainContractTerms ESADout_CUMainContractTerms
        {
            get
            {
                return this.eSADout_CUMainContractTermsField;
            }
            set
            {
                this.eSADout_CUMainContractTermsField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoods[] ESADout_CUGoods
        {
            get
            {
                return this.eSADout_CUGoodsField;
            }
            set
            {
                this.eSADout_CUGoodsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("ESADout_CUCustomsPayment", IsNullable = false)]
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPayment[] ESADout_CUPayments
        {
            get
            {
                return this.eSADout_CUPaymentsField;
            }
            set
            {
                this.eSADout_CUPaymentsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUConsignor
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private Address addressField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public Address Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", IsNullable = false)]
    public partial class Address
    {

        private string countryCodeField;

        private string counryNameField;

        private string cityField;

        private string streetHouseField;

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string CounryName
        {
            get
            {
                return this.counryNameField;
            }
            set
            {
                this.counryNameField = value;
            }
        }

        /// <remarks/>
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <remarks/>
        public string StreetHouse
        {
            get
            {
                return this.streetHouseField;
            }
            set
            {
                this.streetHouseField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUConsignee
    {

        private byte declarantEqualFlagField;

        /// <remarks/>
        public byte DeclarantEqualFlag
        {
            get
            {
                return this.declarantEqualFlagField;
            }
            set
            {
                this.declarantEqualFlagField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUFinancialAdjustingResponsiblePerson
    {

        private byte declarantEqualFlagField;

        /// <remarks/>
        public byte DeclarantEqualFlag
        {
            get
            {
                return this.declarantEqualFlagField;
            }
            set
            {
                this.declarantEqualFlagField = value;
            }
        }
    }


    public class RKOrganizationFeatures
    { 
        public string BIN { get; set; }
        public string ITN { get; set; }
    }
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUDeclarant
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RKOrganizationFeatures rKOrganizationFeaturesField;

        private Address addressField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RKOrganizationFeatures RKOrganizationFeatures
        {
            get
            {
                return this.rKOrganizationFeaturesField;
            }
            set
            {
                this.rKOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public Address Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }
    }
    /*
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", IsNullable = false)]
    public partial class RKOrganizationFeatures
    {

        private ulong bINField;

        private RKOrganizationFeaturesITN iTNField;

        /// <remarks/>
        public ulong BIN
        {
            get
            {
                return this.bINField;
            }
            set
            {
                this.bINField = value;
            }
        }

        /// <remarks/>
        public RKOrganizationFeaturesITN ITN
        {
            get
            {
                return this.iTNField;
            }
            set
            {
                this.iTNField = value;
            }
        }
    }
    */
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
    public partial class RKOrganizationFeaturesITN
    {

        private byte categoryCodeField;

        private byte kATOCodeField;

        private ulong rNNField;

        /// <remarks/>
        public byte CategoryCode
        {
            get
            {
                return this.categoryCodeField;
            }
            set
            {
                this.categoryCodeField = value;
            }
        }

        /// <remarks/>
        public byte KATOCode
        {
            get
            {
                return this.kATOCodeField;
            }
            set
            {
                this.kATOCodeField = value;
            }
        }

        /// <remarks/>
        public ulong RNN
        {
            get
            {
                return this.rNNField;
            }
            set
            {
                this.rNNField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsLocation
    {

        private byte informationTypeCodeField;

        private ushort customsOfficeField;

        private string customsCountryCodeField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsLocationGoodsLocationWarehouse goodsLocationWarehouseField;

        /// <remarks/>
        public byte InformationTypeCode
        {
            get
            {
                return this.informationTypeCodeField;
            }
            set
            {
                this.informationTypeCodeField = value;
            }
        }

        /// <remarks/>
        public ushort CustomsOffice
        {
            get
            {
                return this.customsOfficeField;
            }
            set
            {
                this.customsOfficeField = value;
            }
        }

        /// <remarks/>
        public string CustomsCountryCode
        {
            get
            {
                return this.customsCountryCodeField;
            }
            set
            {
                this.customsCountryCodeField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsLocationGoodsLocationWarehouse GoodsLocationWarehouse
        {
            get
            {
                return this.goodsLocationWarehouseField;
            }
            set
            {
                this.goodsLocationWarehouseField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsLocationGoodsLocationWarehouse
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigment
    {

        private byte containerIndicatorField;

        private string dispatchCountryCodeField;

        private string dispatchCountryNameField;

        private string destinationCountryCodeField;

        private string destinationCountryNameField;

        private BorderCustomsOffice borderCustomsOfficeField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransport eSADout_CUDepartureArrivalTransportField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransport eSADout_CUBorderTransportField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte ContainerIndicator
        {
            get
            {
                return this.containerIndicatorField;
            }
            set
            {
                this.containerIndicatorField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string DispatchCountryCode
        {
            get
            {
                return this.dispatchCountryCodeField;
            }
            set
            {
                this.dispatchCountryCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string DispatchCountryName
        {
            get
            {
                return this.dispatchCountryNameField;
            }
            set
            {
                this.dispatchCountryNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string DestinationCountryCode
        {
            get
            {
                return this.destinationCountryCodeField;
            }
            set
            {
                this.destinationCountryCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string DestinationCountryName
        {
            get
            {
                return this.destinationCountryNameField;
            }
            set
            {
                this.destinationCountryNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public BorderCustomsOffice BorderCustomsOffice
        {
            get
            {
                return this.borderCustomsOfficeField;
            }
            set
            {
                this.borderCustomsOfficeField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransport ESADout_CUDepartureArrivalTransport
        {
            get
            {
                return this.eSADout_CUDepartureArrivalTransportField;
            }
            set
            {
                this.eSADout_CUDepartureArrivalTransportField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransport ESADout_CUBorderTransport
        {
            get
            {
                return this.eSADout_CUBorderTransportField;
            }
            set
            {
                this.eSADout_CUBorderTransportField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class BorderCustomsOffice
    {

        private ushort codeField;

        private string officeNameField;

        private ushort customsCountryCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ushort Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OfficeName
        {
            get
            {
                return this.officeNameField;
            }
            set
            {
                this.officeNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ushort CustomsCountryCode
        {
            get
            {
                return this.customsCountryCodeField;
            }
            set
            {
                this.customsCountryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransport
    {

        private byte transportModeCodeField;

        private string transportNationalityCodeField;

        private byte transportMeansQuantityField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransportTransportMeans transportMeansField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public byte TransportModeCode
        {
            get
            {
                return this.transportModeCodeField;
            }
            set
            {
                this.transportModeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string TransportNationalityCode
        {
            get
            {
                return this.transportNationalityCodeField;
            }
            set
            {
                this.transportNationalityCodeField = value;
            }
        }

        /// <remarks/>
        public byte TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransportTransportMeans TransportMeans
        {
            get
            {
                return this.transportMeansField;
            }
            set
            {
                this.transportMeansField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransportTransportMeans
    {

        private string transportIdentifierField;

        private string transportMeansNationalityCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string TransportIdentifier
        {
            get
            {
                return this.transportIdentifierField;
            }
            set
            {
                this.transportIdentifierField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string TransportMeansNationalityCode
        {
            get
            {
                return this.transportMeansNationalityCodeField;
            }
            set
            {
                this.transportMeansNationalityCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransport
    {

        private byte transportModeCodeField;

        private string transportNationalityCodeField;

        private byte transportMeansQuantityField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransportTransportMeans transportMeansField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public byte TransportModeCode
        {
            get
            {
                return this.transportModeCodeField;
            }
            set
            {
                this.transportModeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string TransportNationalityCode
        {
            get
            {
                return this.transportNationalityCodeField;
            }
            set
            {
                this.transportNationalityCodeField = value;
            }
        }

        /// <remarks/>
        public byte TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransportTransportMeans TransportMeans
        {
            get
            {
                return this.transportMeansField;
            }
            set
            {
                this.transportMeansField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransportTransportMeans
    {

        private string transportIdentifierField;

        private string transportMeansNationalityCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string TransportIdentifier
        {
            get
            {
                return this.transportIdentifierField;
            }
            set
            {
                this.transportIdentifierField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string TransportMeansNationalityCode
        {
            get
            {
                return this.transportMeansNationalityCodeField;
            }
            set
            {
                this.transportMeansNationalityCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUMainContractTerms
    {

        private string contractCurrencyCodeField;

        private decimal contractCurrencyRateField;

        private decimal totalInvoiceAmountField;

        private string tradeCountryCodeField;

        private byte dealFeatureCodeField;

        private byte dealNatureCodeField;

        private CUESADDeliveryTerms cUESADDeliveryTermsField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string ContractCurrencyCode
        {
            get
            {
                return this.contractCurrencyCodeField;
            }
            set
            {
                this.contractCurrencyCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal ContractCurrencyRate
        {
            get
            {
                return this.contractCurrencyRateField;
            }
            set
            {
                this.contractCurrencyRateField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal TotalInvoiceAmount
        {
            get
            {
                return this.totalInvoiceAmountField;
            }
            set
            {
                this.totalInvoiceAmountField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string TradeCountryCode
        {
            get
            {
                return this.tradeCountryCodeField;
            }
            set
            {
                this.tradeCountryCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte DealFeatureCode
        {
            get
            {
                return this.dealFeatureCodeField;
            }
            set
            {
                this.dealFeatureCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte DealNatureCode
        {
            get
            {
                return this.dealNatureCodeField;
            }
            set
            {
                this.dealNatureCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public CUESADDeliveryTerms CUESADDeliveryTerms
        {
            get
            {
                return this.cUESADDeliveryTermsField;
            }
            set
            {
                this.cUESADDeliveryTermsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class CUESADDeliveryTerms
    {

        private string deliveryPlaceField;

        private string deliveryTermsStringCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string DeliveryPlace
        {
            get
            {
                return this.deliveryPlaceField;
            }
            set
            {
                this.deliveryPlaceField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string DeliveryTermsStringCode
        {
            get
            {
                return this.deliveryTermsStringCodeField;
            }
            set
            {
                this.deliveryTermsStringCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoods
    {

        private byte goodsNumericField;

        private string goodsDescriptionField;

        private ushort grossWeightQuantityField;

        private ushort netWeightQuantityField;

        private decimal invoicedCostField;

        private decimal customsCostField;

        private decimal statisticalCostField;

        private ulong goodsTNVEDCodeField;

        private string originCountryCodeField;

        private string originCountryNameField;

        private byte customsCostCorrectMethodField;

        private byte additionalSheetCountField;

        private GoodsGroupDescription goodsGroupDescriptionField;

        private Preferencii preferenciiField;

        private string[] nTMCodesField;

        private string currencyCodeField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUPresentedDocument[] eSADout_CUPresentedDocumentField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUCustomsPaymentCalculation[] eSADout_CUCustomsPaymentCalculationField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsSupplementaryGoodsQuantity supplementaryGoodsQuantityField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADGoodsPackaging eSADGoodsPackagingField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADCustomsProcedure eSADCustomsProcedureField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte GoodsNumeric
        {
            get
            {
                return this.goodsNumericField;
            }
            set
            {
                this.goodsNumericField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string GoodsDescription
        {
            get
            {
                return this.goodsDescriptionField;
            }
            set
            {
                this.goodsDescriptionField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort GrossWeightQuantity
        {
            get
            {
                return this.grossWeightQuantityField;
            }
            set
            {
                this.grossWeightQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort NetWeightQuantity
        {
            get
            {
                return this.netWeightQuantityField;
            }
            set
            {
                this.netWeightQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal InvoicedCost
        {
            get
            {
                return this.invoicedCostField;
            }
            set
            {
                this.invoicedCostField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal CustomsCost
        {
            get
            {
                return this.customsCostField;
            }
            set
            {
                this.customsCostField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal StatisticalCost
        {
            get
            {
                return this.statisticalCostField;
            }
            set
            {
                this.statisticalCostField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ulong GoodsTNVEDCode
        {
            get
            {
                return this.goodsTNVEDCodeField;
            }
            set
            {
                this.goodsTNVEDCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string OriginCountryCode
        {
            get
            {
                return this.originCountryCodeField;
            }
            set
            {
                this.originCountryCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string OriginCountryName
        {
            get
            {
                return this.originCountryNameField;
            }
            set
            {
                this.originCountryNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte CustomsCostCorrectMethod
        {
            get
            {
                return this.customsCostCorrectMethodField;
            }
            set
            {
                this.customsCostCorrectMethodField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte AdditionalSheetCount
        {
            get
            {
                return this.additionalSheetCountField;
            }
            set
            {
                this.additionalSheetCountField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public GoodsGroupDescription GoodsGroupDescription
        {
            get
            {
                return this.goodsGroupDescriptionField;
            }
            set
            {
                this.goodsGroupDescriptionField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public Preferencii Preferencii
        {
            get
            {
                return this.preferenciiField;
            }
            set
            {
                this.preferenciiField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("NTMCodes", Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string[] NTMCodes
        {
            get
            {
                return this.nTMCodesField;
            }
            set
            {
                this.nTMCodesField = value;
            }
        }

        /// <remarks/>
        public string CurrencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("ESADout_CUPresentedDocument")]
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUPresentedDocument[] ESADout_CUPresentedDocument
        {
            get
            {
                return this.eSADout_CUPresentedDocumentField;
            }
            set
            {
                this.eSADout_CUPresentedDocumentField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("ESADout_CUCustomsPaymentCalculation")]
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUCustomsPaymentCalculation[] ESADout_CUCustomsPaymentCalculation
        {
            get
            {
                return this.eSADout_CUCustomsPaymentCalculationField;
            }
            set
            {
                this.eSADout_CUCustomsPaymentCalculationField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsSupplementaryGoodsQuantity SupplementaryGoodsQuantity
        {
            get
            {
                return this.supplementaryGoodsQuantityField;
            }
            set
            {
                this.supplementaryGoodsQuantityField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADGoodsPackaging ESADGoodsPackaging
        {
            get
            {
                return this.eSADGoodsPackagingField;
            }
            set
            {
                this.eSADGoodsPackagingField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADCustomsProcedure ESADCustomsProcedure
        {
            get
            {
                return this.eSADCustomsProcedureField;
            }
            set
            {
                this.eSADCustomsProcedureField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class GoodsGroupDescription
    {

        private string goodsDescriptionField;

        private GoodsGroupDescriptionGoodsGroupInformation goodsGroupInformationField;

        /// <remarks/>
        public string GoodsDescription
        {
            get
            {
                return this.goodsDescriptionField;
            }
            set
            {
                this.goodsDescriptionField = value;
            }
        }

        /// <remarks/>
        public GoodsGroupDescriptionGoodsGroupInformation GoodsGroupInformation
        {
            get
            {
                return this.goodsGroupInformationField;
            }
            set
            {
                this.goodsGroupInformationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    public partial class GoodsGroupDescriptionGoodsGroupInformation
    {

        private string manufacturerField;

        private string tradeMarkField;

        private string goodsMarkField;

        private string goodsModelField;

        private string goodsMarkingField;

        private GoodsGroupDescriptionGoodsGroupInformationGoodsGroupQuantity goodsGroupQuantityField;

        /// <remarks/>
        public string Manufacturer
        {
            get
            {
                return this.manufacturerField;
            }
            set
            {
                this.manufacturerField = value;
            }
        }

        /// <remarks/>
        public string TradeMark
        {
            get
            {
                return this.tradeMarkField;
            }
            set
            {
                this.tradeMarkField = value;
            }
        }

        /// <remarks/>
        public string GoodsMark
        {
            get
            {
                return this.goodsMarkField;
            }
            set
            {
                this.goodsMarkField = value;
            }
        }

        /// <remarks/>
        public string GoodsModel
        {
            get
            {
                return this.goodsModelField;
            }
            set
            {
                this.goodsModelField = value;
            }
        }

        /// <remarks/>
        public string GoodsMarking
        {
            get
            {
                return this.goodsMarkingField;
            }
            set
            {
                this.goodsMarkingField = value;
            }
        }

        /// <remarks/>
        public GoodsGroupDescriptionGoodsGroupInformationGoodsGroupQuantity GoodsGroupQuantity
        {
            get
            {
                return this.goodsGroupQuantityField;
            }
            set
            {
                this.goodsGroupQuantityField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    public partial class GoodsGroupDescriptionGoodsGroupInformationGoodsGroupQuantity
    {

        private ushort goodsQuantityField;

        private string measureUnitQualifierNameField;

        private ushort measureUnitQualifierCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ushort GoodsQuantity
        {
            get
            {
                return this.goodsQuantityField;
            }
            set
            {
                this.goodsQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ushort MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class Preferencii
    {

        private string customsTaxField;

        private string customsDutyField;

        private string exciseField;

        private string rateField;

        /// <remarks/>
        public string CustomsTax
        {
            get
            {
                return this.customsTaxField;
            }
            set
            {
                this.customsTaxField = value;
            }
        }

        /// <remarks/>
        public string CustomsDuty
        {
            get
            {
                return this.customsDutyField;
            }
            set
            {
                this.customsDutyField = value;
            }
        }

        /// <remarks/>
        public string Excise
        {
            get
            {
                return this.exciseField;
            }
            set
            {
                this.exciseField = value;
            }
        }

        /// <remarks/>
        public string Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUPresentedDocument
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private System.DateTime prDocumentDateField;

        private bool prDocumentDateFieldSpecified;

        private ushort presentedDocumentModeCodeField;

        private System.DateTime documentEndActionsDateField;

        private bool documentEndActionsDateFieldSpecified;

        private System.DateTime presentingLackingDateField;

        private bool presentingLackingDateFieldSpecified;

        private byte providingIndicationMarkField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool PrDocumentDateSpecified
        {
            get
            {
                return this.prDocumentDateFieldSpecified;
            }
            set
            {
                this.prDocumentDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort PresentedDocumentModeCode
        {
            get
            {
                return this.presentedDocumentModeCodeField;
            }
            set
            {
                this.presentedDocumentModeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", DataType = "date")]
        public System.DateTime DocumentEndActionsDate
        {
            get
            {
                return this.documentEndActionsDateField;
            }
            set
            {
                this.documentEndActionsDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool DocumentEndActionsDateSpecified
        {
            get
            {
                return this.documentEndActionsDateFieldSpecified;
            }
            set
            {
                this.documentEndActionsDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", DataType = "date")]
        public System.DateTime PresentingLackingDate
        {
            get
            {
                return this.presentingLackingDateField;
            }
            set
            {
                this.presentingLackingDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool PresentingLackingDateSpecified
        {
            get
            {
                return this.presentingLackingDateFieldSpecified;
            }
            set
            {
                this.presentingLackingDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte ProvidingIndicationMark
        {
            get
            {
                return this.providingIndicationMarkField;
            }
            set
            {
                this.providingIndicationMarkField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUCustomsPaymentCalculation
    {

        private ushort paymentModeCodeField;

        private decimal paymentAmountField;

        private ushort paymentCurrencyCodeField;

        private decimal taxBaseField;

        private bool taxBaseFieldSpecified;

        private ushort taxBaseCurrencyCodeField;

        private bool taxBaseCurrencyCodeFieldSpecified;

        private ushort rateField;

        private string rateTypeCodeField;

        private System.DateTime rateUseDateField;

        private string paymentCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort PaymentModeCode
        {
            get
            {
                return this.paymentModeCodeField;
            }
            set
            {
                this.paymentModeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal PaymentAmount
        {
            get
            {
                return this.paymentAmountField;
            }
            set
            {
                this.paymentAmountField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort PaymentCurrencyCode
        {
            get
            {
                return this.paymentCurrencyCodeField;
            }
            set
            {
                this.paymentCurrencyCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal TaxBase
        {
            get
            {
                return this.taxBaseField;
            }
            set
            {
                this.taxBaseField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool TaxBaseSpecified
        {
            get
            {
                return this.taxBaseFieldSpecified;
            }
            set
            {
                this.taxBaseFieldSpecified = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort TaxBaseCurrencyCode
        {
            get
            {
                return this.taxBaseCurrencyCodeField;
            }
            set
            {
                this.taxBaseCurrencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool TaxBaseCurrencyCodeSpecified
        {
            get
            {
                return this.taxBaseCurrencyCodeFieldSpecified;
            }
            set
            {
                this.taxBaseCurrencyCodeFieldSpecified = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string RateTypeCode
        {
            get
            {
                return this.rateTypeCodeField;
            }
            set
            {
                this.rateTypeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", DataType = "date")]
        public System.DateTime RateUseDate
        {
            get
            {
                return this.rateUseDateField;
            }
            set
            {
                this.rateUseDateField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public string PaymentCode
        {
            get
            {
                return this.paymentCodeField;
            }
            set
            {
                this.paymentCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsSupplementaryGoodsQuantity
    {

        private ushort goodsQuantityField;

        private string measureUnitQualifierNameField;

        private ushort measureUnitQualifierCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ushort GoodsQuantity
        {
            get
            {
                return this.goodsQuantityField;
            }
            set
            {
                this.goodsQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ushort MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADGoodsPackaging
    {

        private byte pakageQuantityField;

        private byte pakageTypeCodeField;

        private PackingInformation packingInformationField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte PakageQuantity
        {
            get
            {
                return this.pakageQuantityField;
            }
            set
            {
                this.pakageQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte PakageTypeCode
        {
            get
            {
                return this.pakageTypeCodeField;
            }
            set
            {
                this.pakageTypeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public PackingInformation PackingInformation
        {
            get
            {
                return this.packingInformationField;
            }
            set
            {
                this.packingInformationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class PackingInformation
    {

        private string packingCodeField;

        private byte pakingQuantityField;

        /// <remarks/>
        public string PackingCode
        {
            get
            {
                return this.packingCodeField;
            }
            set
            {
                this.packingCodeField = value;
            }
        }

        /// <remarks/>
        public byte PakingQuantity
        {
            get
            {
                return this.pakingQuantityField;
            }
            set
            {
                this.pakingQuantityField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADCustomsProcedure
    {

        private byte mainCustomsModeCodeField;

        private byte precedingCustomsModeCodeField;

        private byte goodsTransferFeatureField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte MainCustomsModeCode
        {
            get
            {
                return this.mainCustomsModeCodeField;
            }
            set
            {
                this.mainCustomsModeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte PrecedingCustomsModeCode
        {
            get
            {
                return this.precedingCustomsModeCodeField;
            }
            set
            {
                this.precedingCustomsModeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte GoodsTransferFeature
        {
            get
            {
                return this.goodsTransferFeatureField;
            }
            set
            {
                this.goodsTransferFeatureField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
   // [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPayment
    {

        private ushort paymentModeCodeField;

        private decimal paymentAmountField;

        private ushort paymentCurrencyCodeField;

        private byte currencyRateField;

        private string paymentWayCodeField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPaymentPaymentDocument paymentDocumentField;

        private ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPaymentRKOrganizationFeatures rKOrganizationFeaturesField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort PaymentModeCode
        {
            get
            {
                return this.paymentModeCodeField;
            }
            set
            {
                this.paymentModeCodeField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public decimal PaymentAmount
        {
            get
            {
                return this.paymentAmountField;
            }
            set
            {
                this.paymentAmountField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ushort PaymentCurrencyCode
        {
            get
            {
                return this.paymentCurrencyCodeField;
            }
            set
            {
                this.paymentCurrencyCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public byte CurrencyRate
        {
            get
            {
                return this.currencyRateField;
            }
            set
            {
                this.currencyRateField = value;
            }
        }

        /// <remarks/>
        public string PaymentWayCode
        {
            get
            {
                return this.paymentWayCodeField;
            }
            set
            {
                this.paymentWayCodeField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPaymentPaymentDocument PaymentDocument
        {
            get
            {
                return this.paymentDocumentField;
            }
            set
            {
                this.paymentDocumentField = value;
            }
        }

        /// <remarks/>
        public ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPaymentRKOrganizationFeatures RKOrganizationFeatures
        {
            get
            {
                return this.rKOrganizationFeaturesField;
            }
            set
            {
                this.rKOrganizationFeaturesField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPaymentPaymentDocument
    {

        private System.DateTime prDocumentDateField;

        private System.DateTime paymentDateField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime PaymentDate
        {
            get
            {
                return this.paymentDateField;
            }
            set
            {
                this.paymentDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUESADout_CUGoodsShipmentESADout_CUCustomsPaymentRKOrganizationFeatures
    {

        private ulong bINField;

        private ITN iTNField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ulong BIN
        {
            get
            {
                return this.bINField;
            }
            set
            {
                this.bINField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ITN ITN
        {
            get
            {
                return this.iTNField;
            }
            set
            {
                this.iTNField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", IsNullable = false)]
    public partial class ITN
    {

        private byte categoryCodeField;

        private byte kATOCodeField;

        private ulong rNNField;

        /// <remarks/>
        public byte CategoryCode
        {
            get
            {
                return this.categoryCodeField;
            }
            set
            {
                this.categoryCodeField = value;
            }
        }

        /// <remarks/>
        public byte KATOCode
        {
            get
            {
                return this.kATOCodeField;
            }
            set
            {
                this.kATOCodeField = value;
            }
        }

        /// <remarks/>
        public ulong RNN
        {
            get
            {
                return this.rNNField;
            }
            set
            {
                this.rNNField = value;
            }
        }
    }
    public class IdentityCard
    {
        
    }
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUFilledPerson
    {

        private string personSurnameField;

        private string personNameField;

        private string personMiddleNameField;

        private AuthoritesDocument authoritesDocumentField;

        private IdentityCard identityCardField;

        private Contact contactField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonSurname
        {
            get
            {
                return this.personSurnameField;
            }
            set
            {
                this.personSurnameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonMiddleName
        {
            get
            {
                return this.personMiddleNameField;
            }
            set
            {
                this.personMiddleNameField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public AuthoritesDocument AuthoritesDocument
        {
            get
            {
                return this.authoritesDocumentField;
            }
            set
            {
                this.authoritesDocumentField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public Contact Contact
        {
            get
            {
                return this.contactField;
            }
            set
            {
                this.contactField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class AuthoritesDocument
    {

        private string prDocumentNumberField;

        private System.DateTime prDocumentDateField;

        private System.DateTime complationAuthorityDateField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime ComplationAuthorityDate
        {
            get
            {
                return this.complationAuthorityDateField;
            }
            set
            {
                this.complationAuthorityDateField = value;
            }
        }
    }
    /*
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class IdentityCard
    {

        private string identityCardNameField;

        private uint identityCardNumberField;

        private System.DateTime identityCardDateField;

        private string organizationNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string IdentityCardName
        {
            get
            {
                return this.identityCardNameField;
            }
            set
            {
                this.identityCardNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public uint IdentityCardNumber
        {
            get
            {
                return this.identityCardNumberField;
            }
            set
            {
                this.identityCardNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime IdentityCardDate
        {
            get
            {
                return this.identityCardDateField;
            }
            set
            {
                this.identityCardDateField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }
    }
*/
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
   // [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
   // [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class Contact
    {

        private long phoneField;

        private string e_mailField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public long Phone
        {
            get
            {
                return this.phoneField;
            }
            set
            {
                this.phoneField = value;
            }
        }

        /// <remarks/>
      //  [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string E_mail
        {
            get
            {
                return this.e_mailField;
            }
            set
            {
                this.e_mailField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUCUESADCustomsRepresentative
    {

        private ContractRepresDecl contractRepresDeclField;

        private CustomsRepresCertificate customsRepresCertificateField;

        private RKOrganizationFeatures1 rKOrganizationFeaturesField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public ContractRepresDecl ContractRepresDecl
        {
            get
            {
                return this.contractRepresDeclField;
            }
            set
            {
                this.contractRepresDeclField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public CustomsRepresCertificate CustomsRepresCertificate
        {
            get
            {
                return this.customsRepresCertificateField;
            }
            set
            {
                this.customsRepresCertificateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
        public RKOrganizationFeatures1 RKOrganizationFeatures
        {
            get
            {
                return this.rKOrganizationFeaturesField;
            }
            set
            {
                this.rKOrganizationFeaturesField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
   // [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class ContractRepresDecl
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private System.DateTime prDocumentDateField;

        /// <remarks/>
      //  [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
      //  [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
   // [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
   // [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class CustomsRepresCertificate
    {

        private string prDocumentNumberField;

        private System.DateTime prDocumentDateField;

        /// <remarks/>
      //  [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
   // [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0")]
   // [System.Xml.Serialization.XmlRootAttribute("RKOrganizationFeatures", Namespace = "urn:customs.ru:CUESADCommonAggregateTypesCust:5.12.0", IsNullable = false)]
    public partial class RKOrganizationFeatures1
    {

        private ulong bINField;

        private ITN iTNField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ulong BIN
        {
            get
            {
                return this.bINField;
            }
            set
            {
                this.bINField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public ITN ITN
        {
            get
            {
                return this.iTNField;
            }
            set
            {
                this.iTNField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
   // [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:ESADout_CU:5.12.0")]
    public partial class ESADout_CUDTSout_CU
    {

        private string documentIDField;

        private string refDocumentIDField;

        private DTSBuyerSellerDependence dTSBuyerSellerDependenceField;

        private DTSSellingLimitation dTSSellingLimitationField;

        private DTSAdditionalPayments dTSAdditionalPaymentsField;

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string DocumentID
        {
            get
            {
                return this.documentIDField;
            }
            set
            {
                this.documentIDField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string RefDocumentID
        {
            get
            {
                return this.refDocumentIDField;
            }
            set
            {
                this.refDocumentIDField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0")]
        public DTSBuyerSellerDependence DTSBuyerSellerDependence
        {
            get
            {
                return this.dTSBuyerSellerDependenceField;
            }
            set
            {
                this.dTSBuyerSellerDependenceField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0")]
        public DTSSellingLimitation DTSSellingLimitation
        {
            get
            {
                return this.dTSSellingLimitationField;
            }
            set
            {
                this.dTSSellingLimitationField = value;
            }
        }

        /// <remarks/>
       // [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0")]
        public DTSAdditionalPayments DTSAdditionalPayments
        {
            get
            {
                return this.dTSAdditionalPaymentsField;
            }
            set
            {
                this.dTSAdditionalPaymentsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0", IsNullable = false)]
    public partial class DTSBuyerSellerDependence
    {

        private byte column7AField;

        private byte column7BField;

        private byte column7CField;

        /// <remarks/>
        public byte Column7A
        {
            get
            {
                return this.column7AField;
            }
            set
            {
                this.column7AField = value;
            }
        }

        /// <remarks/>
        public byte Column7B
        {
            get
            {
                return this.column7BField;
            }
            set
            {
                this.column7BField = value;
            }
        }

        /// <remarks/>
        public byte Column7C
        {
            get
            {
                return this.column7CField;
            }
            set
            {
                this.column7CField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0", IsNullable = false)]
    public partial class DTSSellingLimitation
    {

        private byte column8AField;

        private byte column8BField;

        /// <remarks/>
        public byte Column8A
        {
            get
            {
                return this.column8AField;
            }
            set
            {
                this.column8AField = value;
            }
        }

        /// <remarks/>
        public byte Column8B
        {
            get
            {
                return this.column8BField;
            }
            set
            {
                this.column8BField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CUESADDTSCommonAggregateTypes:5.12.0", IsNullable = false)]
    public partial class DTSAdditionalPayments
    {

        private byte column9AField;

        private byte column9BField;

        /// <remarks/>
        public byte Column9A
        {
            get
            {
                return this.column9AField;
            }
            set
            {
                this.column9AField = value;
            }
        }

        /// <remarks/>
        public byte Column9B
        {
            get
            {
                return this.column9BField;
            }
            set
            {
                this.column9BField = value;
            }
        }
    }


}