﻿using System.Threading;

namespace Lawyers.Common
{
    public static class Cultures
    {
        public const string EnglishCultureName = "en";
        public const string KazakhCultureName = "kk";
        public const string RussianCultureName = "ru";
        public const string FullEnglishCultureName = "en-GB";
        public const string FullRussianCultureName = "ru-RU";

        public const string DefaultCulture = EnglishCultureName;

        private static string ConvertToShortForm(string code)
        {
            return code.Substring(0, 2);
        }

        public static bool CultureIsSupported(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                return false;
            }

            code = ConvertToShortForm(code).ToLowerInvariant();
            return (code == Cultures.EnglishCultureName || code == Cultures.KazakhCultureName || code == Cultures.RussianCultureName);
        }

        public static string GetLanguage()
        {
            var code = Thread.CurrentThread.CurrentCulture.TwoLetterISOLanguageName;

            if (!CultureIsSupported(code))
            {
                return ConvertToShortForm(Cultures.DefaultCulture);
            }

            return ConvertToShortForm(code).ToLowerInvariant();
        }

        public static string GetFullLanguage(string lang)
        {
            if (lang == Cultures.RussianCultureName)
                return Cultures.FullRussianCultureName;
            else if (lang == Cultures.KazakhCultureName)
                return lang;
            else if (lang == Cultures.EnglishCultureName)
                return Cultures.FullEnglishCultureName;

            return Cultures.FullRussianCultureName;
        }

    }
}
