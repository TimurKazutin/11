﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 11-04-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 18-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Interfaces namespace.
/// </summary>

using System;

namespace Lawyers.Common.Interfaces
{
	using System.Data;
	using System.Xml.Linq;
	using Model;
	using Classes;
	using System.Collections.Generic;
	using Metadata;

	/// <summary>
	/// Interface IDataProvider
	/// </summary>
	public interface IDataProvider
    {
        /// <summary>
        /// Saves the data.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <param name="dataset">The dataset.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        //bool SaveData(Table table, Lawyers.Engine.Data.DataSet dataset);

        /// <summary>
        /// Deletes the data.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <param name="id">The identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        //bool DeleteData(Engine.Data.Table table, object id);

        /// <summary>
        /// Gets the templates.
        /// </summary>
        /// <returns>TemplateDictionary.</returns>
        //TemplateDictionary GetTemplates();

        /// <summary>
        /// Runs the query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns>IDataReader.</returns>
        IDataReader RunQuery(string query, params object[] parameters);

        DataTable RunQueryDataTable(string query, params object[] parameters);

        /// <summary>
        /// Runs the non query.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns>System.Int32.</returns>
        int RunNonQuery(string query, params object[] parameters);

		int RunNonQuery(string query, object[] values, int[] paramIndexes, int[] pkIndexes, Field[] fields, out object paramOut);

		int RunNonQuery(string query, object[] values, int[] paramIndexes, int[] pkIndexes, Field[] fields);

        /// <summary>
        /// Runs the scalar stored procedure.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns>int.</returns>
        int RunScalarStoredProcedure(string name, params object[] parameters);

        int RunScalar(string query);
        string RunQueryStr(string query);

        string RunNoStr(string query, params object[] parameters);

        /// <summary>
        /// Gets the database metadata.
        /// </summary>
        /// <returns>XDocument.</returns>
        List<MetaTable> GetDatabaseMetadata();

		bool IsDeveloper { get; }

        string lastError { get; }
        void clearError();

		void SaveFile(ImageFile imgFile);

        string AddNewReport(string subjLawSupplId, string userId, string collegiumId, string beginDate, string endDate, string reportNumber);

        void UploadBlockDoc(ImageFile imgFile);

        List<ImageFile> GetFiles(System.Guid guid);

        List<ImageFile> GetFiles(string id, string widgetId);

        ImageFile GetFileByID(int id);

        void DeleteFile(int id);

        object Locker { get; }

        ImageFile GetFileByGuid(Guid id);
    }
}
