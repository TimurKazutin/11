﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-23-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 12-10-2014
// ***********************************************************************
// <copyright file="Record.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Data namespace.
/// </summary>
namespace Lawyers.Engine.Data
{
	using System;
	using System.Globalization;
	using Lawyers.Common.Enums;
	using Lawyers.Common.Model;

	/// <summary>
	/// Class Record.
	/// </summary>
	public class Record
    {
        /// <summary>
        /// The parent
        /// </summary>
        private Table parent;

        /// <summary>
        /// The values
        /// </summary>
        private Cell[] values;

        /// <summary>
        /// Gets the unique identifier of record.
        /// </summary>
        /// <value>The unique identifier.</value>
        public Guid Guid { get; private set; }

        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        /// <value>The state.</value>
        public RecordState State { get; set; }

        /// <summary>
        /// Gets or sets the <see cref="Cell" /> at the specified index.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>Cell.</returns>
        public Cell this[int index]
        {
            get { return this.values[index]; }
            set { this.values[index] = value; }
        }

        /// <summary>
        /// Gets the values.
        /// </summary>
        /// <value>The values.</value>
        public Cell[] Values { get { return this.values; } }

        /// <summary>
        /// Initializes a new instance of the <see cref="Record"/> class.
        /// </summary>
        /// <param name="parent">The parent.</param>
        public Record(Table parent) : this(parent, RecordState.None) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="Record"/> class.
        /// </summary>
        /// <param name="parent">The parent.</param>
        /// <param name="state">The state.</param>
        public Record(Table parent, RecordState state)
        {
            this.parent = parent;
            this.State = state;
            this.values = new Cell[this.parent.FieldsCount];

            for (int i = 0; i < this.parent.FieldsCount; i++)
            {
                switch (this.parent[i].DataType)
                {
                    case DataType.Integer:
                    case DataType.Int2:
                    case DataType.Int4:
                        this.values[i] = new Cell(typeof(int), this);
                        this.values[i].Value = string.IsNullOrEmpty(this.parent[i].DefaultValue) ? null : (object)Convert.ToInt32(this.parent[i].DefaultValue);
                        break;
                    case DataType.Decimal:
                    case DataType.Numeric:
                        this.values[i] = new Cell(typeof(decimal), this);
                        this.values[i].Value = string.IsNullOrEmpty(this.parent[i].DefaultValue) ? null : (object)Convert.ToDecimal(this.parent[i].DefaultValue, Culture);
                        break;
                    case DataType.Date_:
                    case DataType.Date:
                    case DataType.DateTime:
                        this.values[i] = new Cell(typeof(DateTime), this);
                        if(string.IsNullOrEmpty(this.parent[i].DefaultValue))
                            this.values[i].Value = null;
                        else
                            this.values[i].Value = (object)(String.Equals(this.parent[i].DefaultValue, "sysdate", StringComparison.OrdinalIgnoreCase) ? DateTime.Now : Convert.ToDateTime(this.parent[i].DefaultValue));
                        break;
                    default:
                        this.values[i] = new Cell(typeof(string), this);
                        this.values[i].Value = parent[i].Name.ToUpper() == "DOC_GUID" ? Guid.NewGuid().ToString("N") : this.parent[i].DefaultValue;
                        break;
                }
            }

            this.Guid = Guid.NewGuid();
        }

        /// <summary>
        /// Gets the culture.
        /// </summary>
        /// <value>The culture.</value>
        public CultureInfo Culture { get { return parent.Culture; } }

        /// <summary>
        /// Gets a value indicating whether this <see cref="Record"/> is new.
        /// </summary>
        /// <value><c>true</c> if new; otherwise, <c>false</c>.</value>
        public bool New
        {
            get
            {
                bool flag = false;

                foreach (FieldPrimaryKey pk in this.parent.PrimaryKeys.Values)
                {
                    if (Values[this.parent.GetFieldIndex(pk.Name)].Value == null)
                    {
                        flag = true;
                        break;
                    }
                }

                return flag;
            }
        }

		/// <summary>
		/// Gets the parent table.
		/// </summary>
		/// <value>The parent table.</value>
		public Table Parent { get { return this.parent; } }
    }
}
