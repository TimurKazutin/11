﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 02-02-2015
// ***********************************************************************
// <copyright file="BundleConfig.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace Lawyers.Web.App
{
    using System.Web.Optimization;

    /// <summary>
    /// Class BundleConfig.
    /// </summary>
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        /// <summary>
        /// Registers the bundles.
        /// </summary>
        /// <param name="bundles">The bundles.</param>
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/Scripts/popper.min.js",      
                "~/Scripts/bootstrap.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/mainJS").Include(
                      "~/Scripts/main.js"));

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-3.3.1.min.js",
                        "~/Scripts/jquery-ui-1.12.1.min.js",
                        "~/Scripts/jquery.unobtrusive-ajax.min.js",
                        "~/Scripts/jquery.validate.min.js",
                        "~/Scripts/jquery.validate.unobtrusive.min.js",
                        "~/Scripts/jtable/jquery.jtable.js",
                        "~/Scripts/chosen.jquery.js",
                        "~/Scripts/jQuery.FileUpload/jquery.fileupload.js",
                        "~/Scripts/jQuery.FileUpload/jquery.fileupload-process.js",
                        "~/Scripts/jQuery.FileUpload/jquery.fileupload-validate.js",
                        "~/Scripts/autoNumeric-min.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/crypto").Include(
                        "~/Scripts/Crypto/crypto_object.js",
                        "~/Scripts/Crypto/jquery.blockUI.js",
                        "~/Scripts/Crypto/jquery.serializejson.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/datatables").Include(
                        "~/Scripts/datatables/datatables.min.js",
                        "~/Scripts/datatables/pdfmake.min.js",
                        "~/Scripts/datatables/vfs_fonts.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/Content/jTableCss").Include(
                        "~/Scripts/jtable/themes/metro/lawyers/jtable.css"));
            /*
            bundles.Add(new StyleBundle("~/Content/css")
                        .Include(
                        "~/Content/style.css",
                        "~/Content/font-face.css",
                        "~/Content/Site.css",
                        "~/Content/datatables/datatables.min.css",
                        "~/Content/bootstrap/bootstrap*",
                        "~/Content/mPOS/font-awesome.css",
                        "~/Content/themes/ui-lightness/jquery-ui.min.css",
                        "~/Content/themes/ui-lightness/jquery-ui.structure.min.css",
                        "~/Content/themes/ui-lightness/jquery-ui.theme.min.css",
                        "~/Content/datatables/datatables.min.css",
                        "~/Content/jQuery.FileUpload/css/jquery.fileupload.css"));
            */

            // Set EnableOptimizations to false for debugging. For more information,
            // visit http://go.microsoft.com/fwlink/?LinkId=301862
            BundleTable.EnableOptimizations = false;
        }
    }
}
