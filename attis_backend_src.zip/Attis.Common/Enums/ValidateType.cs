﻿using System.ComponentModel;

namespace Lawyers.Common.Enums
{
    public enum ValidateSection
    {
        Account,
        Contract, 
        Document,
        Offer,
        [Description("ЛК")]
        PersonalAccount,
        CompanyAccount

    }

    public enum SubSection
    {
        [Description("ЮЛ адреса")]
        CompanyAdress,
        [Description("ЮЛ общие данные")]
        Company,
        [Description("ФЛ общие данные")]
        Personal,
        [Description("ЮЛ учредители")]
        Founders,
        [Description("Счета")]
        Bank,
        Contract,
        Invoice,
        PackingList,
        Epi,
        CMR

    }

    public enum ControlNo
    {
        PA1_Addr_001,
        PA1_Addr_002,
        PA1_Addr_003,
        PA1_Addr_004,
        PA1_Addr_005,
        PA1_Addr_006,
        PA1_Addr_007,
        PA1_Addr_008,
        PA1_Addr_009,
    }
    public enum Level
    {
        Warrning,
        Error,

    }
}
