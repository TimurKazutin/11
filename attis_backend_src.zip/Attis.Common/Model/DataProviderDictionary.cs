﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-15-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-15-2015
// ***********************************************************************
// <copyright file="DataProviderDictionary.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
	using System.Collections.Generic;
	using Lawyers.Common.Interfaces;

	/// <summary>
	/// Class DataProviderDictionary.
	/// </summary>
	public class DataProviderDictionary : SortedDictionary<string, IDataProvider>
	{
	}
}
