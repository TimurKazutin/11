﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-23-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 18-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace Lawyers.Engine.Data
{
	using log4net;
	using System;
	using System.Collections.Generic;
	using System.Globalization;
	using System.Linq;
	using Lawyers.Common.Enums;
	using Common.Model;

	/// <summary>
	/// Class Table.
	/// </summary>
	public class Table
    {
        /// <summary>
        /// The logger
        /// </summary>
        ILog logger = log4net.LogManager.GetLogger(typeof(Table));

        /// <summary>
        /// The field indexes
        /// </summary>
        private SortedDictionary<string, int> FieldIndexes;

        /// <summary>
        /// Gets or sets the fields.
        /// </summary>
        /// <value>The fields.</value>
        private SortedDictionary<int, Field> Fields { get; set; }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; private set; }

        /// <summary>
        /// Gets the primary keys.
        /// </summary>
        /// <value>The primary keys.</value>
        public SortedDictionary<string, FieldPrimaryKey> PrimaryKeys { get; private set; }

        /// <summary>
        /// Gets the foreign keys.
        /// </summary>
        /// <value>The foreign keys.</value>
        public SortedDictionary<string, FieldForeignKey> ForeignKeys { get; private set; }

        /// <summary>
        /// The master selection ID (to show just one record).
        /// </summary>
        /// <value>The master selection ID.</value>
        public int? SelectID { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        public TableType Type { get; set; }

        /// <summary>
        /// Gets the records.
        /// </summary>
        /// <value>The records.</value>
        public List<Record> Records { get; private set; }

        /// <summary>
        /// Gets the records.
        /// </summary>
        /// <value>The records.</value>
        //public Dictionary<int, string> Errors { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Table" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public Table(string name)
        {
            this.Name = name;
            this.PrimaryKeys = new SortedDictionary<string, FieldPrimaryKey>();
            this.ForeignKeys = new SortedDictionary<string, FieldForeignKey>();
            this.Fields = new SortedDictionary<int, Field>();
            this.FieldIndexes = new SortedDictionary<string, int>();
            //this.Errors = new Dictionary<int, string>();
            this.Records = new List<Record>();
            this.Type = TableType.Detail;
            this.Culture = CultureInfo.CreateSpecificCulture(Common.Cultures.GetFullLanguage(Common.Cultures.DefaultCulture));
        }

        /// <summary>
        /// Adds the field.
        /// </summary>
        /// <param name="field">The field.</param>
        public void AddField(Field field)
        {
            int index = Fields.Count;
            this.Fields.Add(index, field);
            this.FieldIndexes.Add(field.Name, index);
        }

        /// <summary>
        /// Gets the <see cref="Field"/> with the specified i.
        /// </summary>
        /// <param name="i">The i.</param>
        /// <returns>Field.</returns>
        public Field this[int i]
        {
            get { return this.Fields[i]; }
        }

        /// <summary>
        /// Gets the index of the field.
        /// </summary>
        /// <param name="fieldName">Name of the field.</param>
        /// <returns>System.Int32.</returns>
        public int GetFieldIndex(string fieldName)
        {
            return this.FieldIndexes[fieldName];
        }

        /// <summary>
        /// Determines whether the specified field name contains field.
        /// </summary>
        /// <param name="fieldName">Name of the field.</param>
        /// <returns><c>true</c> if the specified field name contains field; otherwise, <c>false</c>.</returns>
        public bool ContainsField(string fieldName)
        {
            return this.FieldIndexes.ContainsKey(fieldName);
        }

        /// <summary>
        /// Gets the field list.
        /// </summary>
        /// <value>The field list.</value>
        public List<Field> FieldList { get { return this.Fields.Values.ToList(); } }

        /// <summary>
        /// Gets the fields count.
        /// </summary>
        /// <value>The fields count.</value>
        public int FieldsCount { get { return this.Fields.Count; } }

        /// <summary>
        /// Gets the culture.
        /// </summary>
        /// <value>The culture ru.</value>
        public CultureInfo Culture { get; private set; }

        /// <summary>
        /// Fields the string.
        /// </summary>
        /// <param name="queryType">Type of the query.</param>
        /// <returns>System.String.</returns>
        private string FieldsString(SqlQueryType queryType)
        {
            string result = string.Empty;

            switch (queryType)
            {
                case SqlQueryType.Select:
                    result = string.Join(",", this.Fields.Select(f => f.Value.Name).ToArray());
                    break;
                case SqlQueryType.Insert:
                    result = string.Join(",", this.Fields.Where(f => f.Value.Editable/*f.Value.Type != FieldType.PrimaryKey*/).Select(f => f.Value.Name).ToArray());
                    break;
                case SqlQueryType.Update:
                    result = string.Join(",", this.Fields.Where(f => f.Value.Editable/*f.Value.Type != FieldType.PrimaryKey*/).Select(f => string.Format("{0}=:p{1}", f.Value.Name, f.Key)).ToArray());
                    break;
                default:
                    break;
            }

            return result;
        }

        /// <summary>
        /// SQLs the query.
        /// </summary>
        /// <param name="queryType">Type of the query.</param>
        /// <returns>System.String.</returns>
        public string SqlQuery(SqlQueryType queryType)
        {
            string result = string.Empty;

            switch (queryType)
            {
                case SqlQueryType.Select:
                    result = string.Format("select {0} from {1}", this.FieldsString(queryType), this.Name);
                    break;
                case SqlQueryType.Insert:
                    result = string.Format("insert into {0}({1}) values ({2}) returning {3}", this.Name, this.FieldsString(queryType),
                        string.Join(",", this.Fields.Where(f => f.Value.Editable/*f.Value.Type != FieldType.PrimaryKey*/).Select(f => ":p" + f.Key.ToString()).ToArray()),
                        this.PrimaryKeys.First().Key);
                    break;
                case SqlQueryType.Update:
                    result = string.Format("update {0} set {1} where {2}", this.Name, this.FieldsString(queryType),
                        string.Join(" and ", this.Fields.Where(f => f.Value.Type == FieldType.PrimaryKey).Select(f => string.Format("{0}=:pk{1}", f.Value.Name, f.Key)).ToArray()));
                    break;
                case SqlQueryType.Delete:
                    result = string.Format("delete from {0} where {1}=", this.Name, this.PrimaryKeys.First().Key);
                    break;
            }

            return result;
        }

        /// <summary>
        /// Parameters the indexes.
        /// </summary>
        /// <param name="queryType">Type of the query.</param>
        /// <returns>System.Int32[].</returns>
        public int[] ParameterIndexes(SqlQueryType queryType)
        {
            int[] result = null;
            switch (queryType)
            {
                case SqlQueryType.Insert:
                case SqlQueryType.Update:
                    result = this.Fields.Where(f => f.Value.Editable/*f.Value.Type != FieldType.PrimaryKey*/).Select(f => f.Key).ToArray();
                    break;
                default:
                    break;
            }

            return result;
        }

        /// <summary>
        /// Gets the primary key indexes.
        /// </summary>
        /// <value>The primary key indexes.</value>
        public int[] PrimaryKeyIndexes
        {
            get { return this.Fields.Where(f => f.Value.Type == FieldType.PrimaryKey).Select(f => f.Key).ToArray(); }
        }

        /// <summary>
        /// Gets the name of the parent table.
        /// </summary>
        /// <value>The name of the parent table.</value>
        public string ParentTableName
        {
            get
            {
                string table = null;

                if (this.Type == TableType.Detail)
                {
                    table = this.ForeignKeys.First().Value.TableName;
                }

                return table;
            }
        }

        /// <summary>
        /// Applies the filters.
        /// </summary>
        /// <param name="widget">The widget.</param>
        /// <param name="record">The record.</param>
        /// <param name="ds">The ds.</param>
        /// <returns>List&lt;Record&gt;.</returns>
        public List<Record> ApplyFilters(Widget widget, Record record, DataSet ds)
        {
            List<Record> result = new List<Record>(this.Records);

            for (int i = 0; i < widget.Filters.Count; i++)
                if (widget.Filters[i].Apply)
                {
                    string val = widget.GetFilterValue(widget.Filters[i].Value, record == null ? null : record.Values.Select(c=>c.Value).ToArray(), record == null ? this.FieldIndexes : record.Parent.FieldIndexes, ds.Identity); /// TODO: widget value
                    
                    switch (widget.Filters[i].OperationType)
                    {
                        case ConditionOperationType.Equal:
                            result = result.Where(r => r[this.GetFieldIndex(widget.Filters[i].Name)].Value != null && r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString() == val).ToList();
                            break;
                        case ConditionOperationType.NotEqual:
                            result = result.Where(r => r[this.GetFieldIndex(widget.Filters[i].Name)].Value != null && r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString() != val).ToList();
                            break;
                        case ConditionOperationType.LessOrEqual:
                            result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture) <= DateTime.ParseExact(val.Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture)).ToList();
                            //result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture) <= DateTime.ParseExact(val.Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture)).ToList();
                            break;
                        case ConditionOperationType.Less:
                            result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture) < DateTime.ParseExact(val.Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture)).ToList();
                            //result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture) < DateTime.ParseExact(val.Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture)).ToList();
                            break;
						case ConditionOperationType.GreaterOrEqual:
							result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture) >= DateTime.ParseExact(val.Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture)).ToList();
                            //result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture) >= DateTime.ParseExact(val.Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture)).ToList();
							break;
						case ConditionOperationType.Greater:
							result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture) > DateTime.ParseExact(val.Substring(0, 10), "dd.MM.yyyy", CultureInfo.InvariantCulture)).ToList();
                            //result = result.Where(r => DateTime.ParseExact(r[this.GetFieldIndex(widget.Filters[i].Name)].Value.ToString().Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture) > DateTime.ParseExact(val.Substring(0, 10), "yyyy.MM.dd", CultureInfo.InvariantCulture)).ToList();
							break;
						default:
                            break;
                    }
                }

            return result;
        }

        /// <summary>
        /// Sets the records.
        /// </summary>
        /// <param name="records">The records.</param>
        internal void SetRecords(List<Record> records)
        {
            this.Records = records;
        }

		public SortedDictionary<string, int> GetFieldIndexes()
		{
			return this.FieldIndexes;
		}
    }
}
