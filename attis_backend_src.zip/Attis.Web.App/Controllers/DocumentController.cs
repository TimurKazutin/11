﻿using System;
using System.IO;
using System.IO.Packaging;
using System.Collections.Generic;
using System.Linq;
using System.Web.SessionState;
using System.Web.Mvc;
//using EasyDox;
using System.Diagnostics;
using System.Threading;
//using TemplateEngine.Docx;
//using DocumentFormat.OpenXml;
using System.Xml;
using System.Xml.Linq;
using Lawyers.Engine.Configuration;
using Lawyers.Web.App.Helpers;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using Lawyers.Common.Classes;
    using Lawyers.Common.Enums;
    using Lawyers.Web.App.Models;
    using log4net;
    using Microsoft.Ajax.Utilities;
    using Microsoft.AspNet.Identity;
    using Newtonsoft.Json;
    using OfficeOpenXml;
    using System.Data;
    using System.Data.SqlTypes;
    using System.Net;
    using System.Net.Http;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Web.Security;
    using System.Xml.Serialization;
    using static Lawyers.Web.App.Controllers.ContractController;

    [SessionState(SessionStateBehavior.Disabled)]
    public class DocumentController : Controller
    {
        private readonly ILog log = LogManager.GetLogger("Document"); //log to file
        private static IDataProvider Provider => GlobalContainer.Instance.Get<Configuration>().DataProvider;
        public static DateTime GetDateTimeFromString(string inputDate)
        {
            var success = DateTime.TryParse(inputDate, out var tempDt);
            return success ? tempDt.Date : default;
        }
        public string Index(string attis_contract_id, string category, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{attis_contract_id}'";
            /* check if owner 
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            //query = $"SELECT t1.doc_guid, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" WHERE t1.attis_contract_doc_contract = '{attis_contract_id}';";
            if (category.IsNullOrWhiteSpace())
                query = $"SELECT t1.*, t2.attis_doc_type_name_ru, t2.attis_doc_type_name_en, t2.attis_doc_type_code FROM attis_contract_docs t1 LEFT JOIN  attis_doc_types t2 ON t1.attis_contract_doc_type = t2.attis_doc_type_code WHERE attis_contract_doc_contract = '{attis_contract_id}';";
            else query = $"SELECT t1.*, t2.attis_doc_type_name_ru, t2.attis_doc_type_name_en, t2.attis_doc_type_code FROM attis_contract_docs t1 LEFT JOIN  attis_doc_types t2 ON t1.attis_contract_doc_type = t2.attis_doc_type_code WHERE attis_contract_doc_contract = '{attis_contract_id}' AND t1.category='{category}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            var docs = new List<DocModel>();
            string ln = "attis_doc_type_name_ru";
            if (language != null)
            if (language.Equals("en")) ln = "attis_doc_type_name_en";
            if (reader != null)
            {
                while (reader.Read())
                {
                    var list = new DocModel
                    {
                        DocumentID = reader["attis_contract_doc_id"].ToString(),
                    };
                    //list.DocumentID = reader["DocumentID"].ToString();
                    list.DocGuid = reader["doc_guid"].ToString();
                    list.DocumentNumber = reader["attis_contract_doc_number"].ToString();
                    list.DocumentDate = GetDateTimeFromString(reader["attis_contract_doc_date"].ToString());
                    list.DocType = reader["attis_doc_type_name_ru"].ToString();
                    list.DocTypeTitle = reader[ln].ToString();
                    list.FileType = reader["file_type"].ToString();

                    docs.Add(list);
                }
                reader.Close();

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(docs, settings);
            }
            return "[]";

        }



        public comp invfirm(string bin)
        {
            var list = new comp();
            string query = $"SELECT * FROM organizations WHERE org_code= '{bin}'";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.org_name = reader["org_name"].ToString();
                    list.org_code = reader["org_code"].ToString();
                    list.org_type = reader["company_address"].ToString();
                    list.company_address = reader["company_address"].ToString();
                    list.org_post_infex = reader["org_post_infex"].ToString();
                    list.org_custom_code = reader["org_custom_code"].ToString();
                    list.org_reg_date = GetDateTimeFromString(reader["org_reg_date"].ToString()).ToString("yyyy.MM.dd");
                    list.company_region = reader["company_region"].ToString();
                    list.org_oked = reader["org_oked"].ToString();
                    list.company_contacts = reader["company_contacts"].ToString();
                    list.company_main_sphere = reader["company_main_sphere"].ToString();
                    list.company_additional_sphere = reader["company_additional_sphere"].ToString();
                    list.company_ceo = reader["company_ceo"].ToString();
                    list.company_founder = reader["company_founder"].ToString();
                    list.company_website = reader["company_website"].ToString();
                    list.company_email = reader["company_email"].ToString();
                    list.org_residency = reader["org_residency"].ToString();
                }
                reader.Close();
            }
            return list;
        }

        public ActionResult XmlAstana1(string id, string language)
        {
            //string sqlQuery = @"SELECT attis_contract_id FROM attis_contracts WHERE attis_contract_id=@p0";
            //System.Data.IDataReader read = this.Provider.RunQuery(sqlQuery, 155);
            //string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{id}'";

            query = $"SELECT t1.doc_guid, t1.attis_contract_doc_contract, t1.attis_contract_doc_date, t2.*, t3.*, t4.*, t5.*, " +
                $"t6.ap_memb_organization_name as ap_memb_organization_name_1, t6.ap_memb_short_name as ap_memb_short_name_1, t6.ap_memb_bin as ap_memb_bin_1, t6.ap_memb_itn as ap_memb_itn_1,t6.ap_member_postal_code as ap_member_postal_code_1, t6.ap_member_country_name as ap_member_country_name_1, t6.ap_member_region as ap_member_region_1, t6.ap_member_city as ap_member_city_1, t6.ap_member_street_house as ap_member_street_house_1, " +
                $"t7.ap_memb_organization_name as ap_memb_organization_name_2, t7.ap_memb_short_name as ap_memb_short_name_2, t7.ap_memb_bin as ap_memb_bin_2, t7.ap_memb_itn as ap_memb_itn_2, t7.ap_member_postal_code as ap_member_postal_code_2, t7.ap_member_country_name as ap_member_country_name_2, t7.ap_member_region as ap_member_region_2, t7.ap_member_city as ap_member_city_2, t7.ap_member_street_house as ap_member_street_house_2, " +
                $"t8.ap_memb_organization_name as ap_memb_organization_name_3, t8.ap_memb_short_name as ap_memb_short_name_3, t8.ap_memb_bin as ap_memb_bin_3, t8.ap_memb_itn as ap_memb_itn_3, t8.ap_member_postal_code as ap_member_postal_code_3, t8.ap_member_country_name as ap_member_country_name_3, t8.ap_member_region as ap_member_region_3, t8.ap_member_city as ap_member_city_3, t8.ap_member_street_house as ap_member_street_house_3, " +
                $"t11.ap_memb_organization_name as ap_memb_organization_name_4, t11.ap_memb_short_name as ap_memb_short_name_4, t11.ap_memb_bin as ap_memb_bin_4, t11.ap_memb_itn as ap_memb_itn_4, t11.ap_member_postal_code as ap_member_postal_code_4, t11.ap_member_country_name as ap_member_country_name_4, t11.ap_member_region as ap_member_region_4, t11.ap_member_city as ap_member_city_4, t11.ap_member_street_house as ap_member_street_house_4, " +
                $"t9.*, t10.*, t12.ap_person_reg_country_code as ap_person_reg_country_code_2, t12.ap_person_person_surname as ap_person_person_surname_2, t12.ap_person_person_post as ap_person_person_post_2, " +
                $"t12.ap_person_person_name as ap_person_person_name_2, t12.ap_person_person_middle_name as ap_person_person_middle_name_2 FROM attis_contract_docs t1 " +
                $"LEFT JOIN ap_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                $"LEFT JOIN ap_goods t3 ON t2.ap_main_id = t3.ap_good_main_id " +
                $"LEFT JOIN ap_send_rec t4 ON t2.ap_main_id = t4.ap_main_id " +
                $"LEFT JOIN ap_members t5 ON t4.sender_id = t5.ap_memb_id " +
                $"LEFT JOIN ap_members t6 ON t4.recipient_id = t6.ap_memb_id " +
                $"LEFT JOIN ap_members t7 ON t4.fin_reg_id = t7.ap_memb_id " +
                $"LEFT JOIN ap_members t8 ON t4.declarant_id = t8.ap_memb_id " +
                $"LEFT JOIN ap_members t11 ON t4.driver_id = t11.ap_memb_id " +
                $"LEFT JOIN ap_transportations t9 ON t2.ap_main_id = t9.ap_main_id " +
                $"LEFT JOIN ap_persons t10 ON t4.decl_officer_id = t10.ap_person_id " +
                $"LEFT JOIN ap_persons t12 ON t4.person1_id = t12.ap_person_id WHERE t1.attis_contract_doc_id = {id};";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);

            var nls = new Envelope();
            nls.Body = new EnvelopeBody();
            nls.Body.registerAutoPreliminaryInformation = new registerAutoPreliminaryInformation();
            nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation = new AutoPreliminaryInformation();

            var apd = ""; 
            string curr = "";
            int ctr = 0;
            if (reader != null)
            {
                while (reader.Read())
                {

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.EDocCode = reader["attis_contract_doc_contract"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.EDocId = reader["doc_guid"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.EDocDateTime = reader["attis_contract_doc_date"].ToString();

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails = new PIDeclarantDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectName = reader["ap_memb_organization_name_3"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectBriefName = reader["ap_memb_short_name_3"].ToString();
                    
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.EqualIndicator = reader["ap_memb_bin_3"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.TaxpayerId = reader["ap_memb_itn_3"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectAddressDetails = new SubjectAddressDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectAddressDetails.UnifiedCountryCode = new UnifiedCountryCode { Value = reader["ap_member_country_name"].ToString()};
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectAddressDetails.RegionName= reader["ap_member_region"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectAddressDetails.CityName = reader["ap_member_city"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectAddressDetails.StreetName = reader["ap_member_street_house"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIDeclarantDetails.SubjectAddressDetails.PostCode = reader["ap_member_postal_code"].ToString();

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails = new PIATBorderTransportDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.TransportTypeCode = new TransportTypeCode { Value = reader["ap_transp_information_type_code"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.ContainerIndicator = reader["ap_transp_container_indicator"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.TransportMeansRegId = new TransportMeansRegId();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.TransportMeansRegId.countryCode = reader["ap_transp_transport_nationality_code"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.TransportMeansRegId.Value = reader["ap_transp_vin"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.PIATItineraryPointDetails = new PIATBorderTransportDetailsPIATItineraryPointDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.PIATItineraryPointDetails.UnifiedCountryCode = new UnifiedCountryCode();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.PIATItineraryPointDetails.UnifiedCountryCode.Value = reader["ap_transp_customs_country_code"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATBorderTransportDetails.PIATItineraryPointDetails.PlaceName = reader["ap_transp_customs_office"].ToString();

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails = new PIATCarrierDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectName = reader["ap_memb_organization_name_4"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectBriefName = reader["ap_memb_short_name_4"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.TaxpayerId = reader["ap_memb_itn_4"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectAddressDetails = new SubjectAddressDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectAddressDetails.UnifiedCountryCode = new UnifiedCountryCode { Value = reader["ap_member_country_name_4"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectAddressDetails.CityName = reader["ap_member_city_4"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectAddressDetails.RegionName = reader["ap_member_region_4"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectAddressDetails.StreetName = reader["ap_member_street_house_4"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATCarrierDetails.SubjectAddressDetails.PostCode = reader["ap_member_postal_code_4"].ToString();

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails = new PIATMainConsignmentDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.TIRCarnetIndicator = reader["ap_main_carnet"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.GoodsQuantity = reader["ap_good_total_goods_number"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.CargoQuantity = reader["ap_good_total_package_number"].ToString().TrimEnd();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PITransitTransportMeansDetails = new PIATMainConsignmentDetailsPITransitTransportMeansDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PITransitTransportMeansDetails.TransportMeansRegistrationIdDetails = new PIATMainConsignmentDetailsPITransitTransportMeansDetailsTransportMeansRegistrationIdDetails { VehicleId = reader["ap_transp_information_type_code"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PITransitTransportMeansDetails.TransportMeansRegistrationIdDetails.TransportMeansRegId = new TransportMeansRegId();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PITransitTransportMeansDetails.TransportMeansRegistrationIdDetails.TransportMeansRegId.countryCode = reader["ap_transp_transport_nationality_code"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PITransitTransportMeansDetails.TransportMeansRegistrationIdDetails.TransportMeansRegId.Value = reader["ap_transp_vin"].ToString();

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.TransitTerminationDetails = new PIATMainConsignmentDetailsTransitTerminationDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.TransitTerminationDetails.CustomsOfficeDetails = new CustomsOfficeDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.TransitTerminationDetails.CustomsOfficeDetails.CustomsOfficeCode = reader["ap_transp_customs_office_inout"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.TransitTerminationDetails.CustomsOfficeDetails.UnifiedCountryCode = new UnifiedCountryCode { Value = reader["ap_transp_customs_country_code_io"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.DeclarationKindCode = reader["ap_main_trans_kind_code"].ToString().Trim();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.LoadingListsQuantity = reader["ap_good_specification_number"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.LoadingListsPageQuantity = reader["ap_good_specification_list_number"].ToString().Trim();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.GoodsQuantity = reader["ap_good_total_goods_number"].ToString().Trim();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.CargoQuantity = reader["ap_good_total_package_number"].ToString().Trim();


                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.SealDetails = new PIATMainConsignmentDetailsSealDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.SealDetails.SealQuantity = reader["ap_main_seal_quantity"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.SealDetails.SealId = reader["ap_main_seal_number"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails = new PIATMainConsignmentDetailsPIATConsignmentDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.CargoQuantity = reader["ap_good_total_package_number"].ToString().Trim();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.DepartureCountryDetails = new PIATMainConsignmentDetailsPIATConsignmentDetailsDepartureCountryDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.DepartureCountryDetails.CACountryCode = new CACountryCode { Value = reader["ap_transp_dispatch_country_code"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.DepartureCountryDetails.ShortCountryName = country(reader["ap_transp_dispatch_country_code"].ToString(), "ru").display_text;  //todo
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.DestinationCountryDetails = new PIATMainConsignmentDetailsPIATConsignmentDetailsDestinationCountryDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.DestinationCountryDetails.CACountryCode = new CACountryCode { Value = reader["ap_transp_dispatch_country_code"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.DestinationCountryDetails.ShortCountryName = country(reader["ap_transp_dispatch_country_code"].ToString(), "ru").display_text;  //todo

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.CAInvoiceValueAmount = new CAInvoiceValueAmount();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.CAInvoiceValueAmount.Value = reader["ap_good_total_cust_cost"].ToString().Trim();
                    curr = reader["ap_good_cust_cost_currency_code"].ToString().Trim();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.CAInvoiceValueAmount.currencyCode = curr;
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails = new PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignorDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectName = reader["ap_memb_organization_name"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectBriefName = reader["ap_memb_short_name"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.TaxpayerId = reader["ap_memb_itn"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.EqualIndicator = reader["ap_memb_bin"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectAddressDetails = new SubjectAddressDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectAddressDetails.UnifiedCountryCode =new UnifiedCountryCode { Value = reader["ap_member_country_name"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectAddressDetails.PostCode = reader["ap_member_postal_code"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectAddressDetails.RegionName = reader["ap_member_region"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectAddressDetails.CityName = reader["ap_member_city"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignorDetails.SubjectAddressDetails.StreetName = reader["ap_member_street_house"].ToString();

                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails = new PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsigneeDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectName = reader["ap_memb_organization_name_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectBriefName = reader["ap_memb_short_name_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.TaxpayerId = reader["ap_memb_itn_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.EqualIndicator = reader["ap_memb_bin_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectAddressDetails = new SubjectAddressDetails();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectAddressDetails.UnifiedCountryCode = new UnifiedCountryCode { Value = reader["ap_member_country_name"].ToString() };
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectAddressDetails.PostCode = reader["ap_member_postal_code_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectAddressDetails.RegionName = reader["ap_member_region_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectAddressDetails.CityName = reader["ap_member_city_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsigneeDetails.SubjectAddressDetails.StreetName = reader["ap_member_street_house_1"].ToString();
                    nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails = new PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetails[10];
                    //nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[0].PIPrecedingDocDetails = 
                }
                reader.Close();
                query = $"SELECT t1.*, t2.attis_doc_type_name_ru FROM attis_contract_docs t1 LEFT JOIN  attis_doc_types t2 ON t1.attis_contract_doc_type = t2.attis_doc_type_code WHERE attis_contract_doc_contract = '{ctr}'";
                reader = Provider.RunQuery(query);
                int cnt = 0;
                var prdl = new PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIPrecedingDocDetails();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        int tp = (int)reader["attis_contract_doc_type"];
                        if (tp < 5)
                        {
                            prdl.DocName = reader["attis_doc_type_name_ru"].ToString();
                            prdl.DocId = reader["attis_contract_doc_number"].ToString();
                            prdl.DocCreationDate = reader["attis_contract_doc_date"].ToString(); //ap_prev_doc_preceding_document_date
                            cnt++;
                        }
                    }
                    reader.Close();
                }
                
                //prdl = prdl.Where(s => s != null).ToArray();
                //list.ESADout_CUGoodsShipment.ESADout_CUGoods.ESADout_CUPresentedDocument = new ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUPresentedDocument[prdl.Count()];
                //list.ESADout_CUGoodsShipment.ESADout_CUGoods.ESADout_CUPresentedDocument = prdl;
                //qery = $"SELECT country_name_ru FROM countries WHERE country_2a_code='{list.MainConsignmentDetails.ConsignmentDetails[0].ConsigneeDetails.SubjectAddressDetails[0].CounryName}'";

                var query1 = $"SELECT * FROM ap_good_data WHERE ap_main_id = '{apd}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<EpGoods>();
                //var curr = list.MainConsignmentDetails.ConsignmentDetails[0].CAInvoiceValueAmount.CurrencyCode;
                cnt = 0;
                //query = $"SELECT COUNT(t2.*) FROM  public.subjects WHERE t3.doc_widget_id = "{ }";
                //int lnt = prdl.Count(s => s != null);
                //list.MainConsignmentDetails.ConsignmentDetails[0].GoodsItem = new AutoPreliminaryMainConsignmentDetailsConsignmentDetailsGoodsItem[10];
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt] = new PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetails();
                        //string nr = reader1["ap_good_data_list_numeric"].ToString();
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].GoodsDescriptionText = reader1["ap_good_data_goods_description"].ToString();
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].CAValueAmount = new CAValueAmount { Value = reader1["ap_good_data_invoiced_cost"].ToString(), currencyCode = curr };
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].AddGoodsMeasureDetails = new PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsAddGoodsMeasureDetails();
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].AddGoodsMeasureDetails.GoodsMeasure = new GoodsMeasure { Value = reader1["ap_good_data_list_numeric"].ToString() };
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].UnifiedGrossMassMeasure = new UnifiedGrossMassMeasure { Value = reader1["ap_good_data_gross_weight_quantity"].ToString() };
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].UnifiedNetMassMeasure = new UnifiedNetMassMeasure { Value = reader1["ap_good_data_net_weight_quantity"].ToString() };
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].ProductionPlaceName = reader1["ap_good_data_origin_country_code"].ToString();
                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].GoodsLabelDescriptionText = reader1["ap_good_data_goods_tnved_code"].ToString();

                        nls.Body.registerAutoPreliminaryInformation.AutoPreliminaryInformation.PIATMainConsignmentDetails.PIATConsignmentDetails.PIATConsignmentItemDetails[cnt].PIPrecedingDocDetails = prdl;
                        cnt++;
                    }
                    reader.Close();
                }

                XmlSerializer xsSubmit = new XmlSerializer(typeof(Envelope));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, nls);
                        xml = sww.ToString(); // Your XML
                    }
                }/*
                xml = xml.Replace("xmlns=\"dsp\"", "");
                xml = xml.Replace("xmlns=\"ddc\"", "");
                xml = xml.Replace("xmlns=\"cav\"", "");
                xml = xml.Replace("xmlns=\"urnx\"", "");
                */
                //return xml;
                //var file = Provider.GetFileByID(id);
                var contentType = "text/xml";
                var bytes = Encoding.UTF8.GetBytes(xml);
                var result = new FileContentResult(bytes, contentType);
                string fn = DateTime.Now.ToString();
                result.FileDownloadName = fn + ".xml";
                return result;
            }
            return null;
        }
        public ActionResult Xmlinv(string id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{id}'";

            query = $"SELECT t1.doc_guid, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" WHERE t1.attis_contract_doc_id = '{id}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            var list = new DocModel();
            var lst = new Invoice();
            if (reader != null)
            {
                while (reader.Read())
                {
                    lst.HeaderExchangedDocument = new InvoiceHeaderExchangedDocument();
                    lst.HeaderExchangedDocument.ID = reader["DocumentNumber"].ToString();

                    lst.SpecifiedLogisticsConsignment = new InvoiceSpecifiedLogisticsConsignment();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment = new IncludedSupplyChainConsignment();

                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransaction();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.LineItemQuantity = 1;
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlement();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement.BillingSpecifiedPeriod = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementBillingSpecifiedPeriod();
                    list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                    lst.HeaderExchangedDocument.IssueDateTime = DateTime.Now;
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement.BillingSpecifiedPeriod.StartDateTime = list.DocumentDate;
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement.BillingSpecifiedPeriod.EndDateTime = list.DocumentDate;
                    list.CurrencyCode = reader["CurrencyCode"].ToString().Trim();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement.InvoiceApplicableTradeCurrencyExchange = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementInvoiceApplicableTradeCurrencyExchange();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement.InvoiceApplicableTradeCurrencyExchange.SourceCurrencyCode = list.CurrencyCode; //cur
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreement();

                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItem();

                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradeParty();
                    list.InvoiceSeller = reader["InvoiceSeller"].ToString().Trim();

                    list.InvoiceByer = reader["InvoiceByer"].ToString().Trim();
                    list.DocumentID = reader["DocumentID"].ToString().Trim();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItem();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeSettlement = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlement();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation.LineTotalAmount = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationLineTotalAmount();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation.LineTotalAmount.currencyCode = "usd";

                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation.LineTotalAmount.Value = Decimal.Round(reader.GetFieldValueOrDefault<decimal>("GCost"), 2);
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeDelivery = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDelivery();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeDelivery.BilledQuantity = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliveryBilledQuantity();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeDelivery.BilledQuantity.Value = reader.GetFieldValueOrDefault<byte>("PlacesQuantity");
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation();
                    lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation.GrandTotal = reader.GetFieldValueOrDefault<string>("GCost");

                    //lst.MessageHeaderDocument = new InvoiceMessageHeaderDocument();
                    //lst.MessageHeaderDocument.IssueDateTime = "";
                    //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.tr
                    /*
                    
                    list.DocGuid = reader["doc_guid"].ToString();
                    
                    
                    
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.PlacesDescription = reader["PlacesDescription"].ToString();
                    list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                    list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                    list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                    list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                    list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                    list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                    list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                    */

                }
                reader.Close();


                var sellr = invfirm(list.InvoiceSeller);
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.GlobalID = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyGlobalID();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.GlobalID.Value = list.InvoiceSeller;
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.Name = sellr.org_name; //orgname
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.PostalTradeAddress = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddress();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.PostalTradeAddress.CityName = sellr.company_region;
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.PostalTradeAddress.StreetName = sellr.org_type;
                //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.PostalTradeAddress.PostcodeCode = "";
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.PostalTradeAddress.CountryIdentificationTradeCountry = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddressCountryIdentificationTradeCountry();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.PostalTradeAddress.CountryIdentificationTradeCountry.Name = sellr.org_residency; //ES
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.DefinedTradeContact = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContact();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.DefinedTradeContact.DirectTelephoneUniversalCommunication = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.SellerTradeParty.DefinedTradeContact.DirectTelephoneUniversalCommunication.CompleteNumber = sellr.company_contacts;
                var buyr = invfirm(list.InvoiceByer);
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradeParty();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.GlobalID = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyGlobalID();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.GlobalID.Value = list.InvoiceByer;
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.Name = buyr.org_name; //orgname
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.PostalTradeAddress = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddress();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.PostalTradeAddress.CityName = buyr.company_region;
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.PostalTradeAddress.StreetName = buyr.org_type;
                //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.PostalTradeAddress.PostcodeCode = "";
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.PostalTradeAddress.CountryIdentificationTradeCountry = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddressCountryIdentificationTradeCountry();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.PostalTradeAddress.CountryIdentificationTradeCountry.Name = buyr.org_residency; //ES
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.DefinedTradeContact = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContact();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.DefinedTradeContact.DirectTelephoneUniversalCommunication = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.ApplicableSupplyChainTradeAgreement.BuyerTradeParty.DefinedTradeContact.DirectTelephoneUniversalCommunication.CompleteNumber = buyr.company_contacts;

                var product = new List<GoodsModel>();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackage[10];
                int cnt = 0;
                query = $"SELECT currency_a3_code FROM currencies WHERE currency_code='{list.CurrencyCode}'";
                string curr = Provider.RunQueryStr(query);
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation.LineTotalAmount.currencyCode = curr;
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreement();
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePrice[10];
                var query1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                var reader1 = Provider.RunQuery(query1);
                if (reader1 != null)
                {

                    while (reader1.Read())
                    {
                        var rep1 = new GoodsModel
                        {
                            GoodsCode = reader1["GoodsCode"].ToString(),
                        };

                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage[cnt] = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackage();
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage[cnt].Description = reader1["GoodsDescription"].ToString();
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage[cnt].ItemQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity");

                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage[cnt].NetWeightMeasure = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageNetWeightMeasure();
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage[cnt].NetWeightMeasure.Value = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity");
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage[cnt].GrossWeightMeasure = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageGrossWeightMeasure();
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.SpecifiedLogisticsPackage[cnt].GrossWeightMeasure.Value = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity");

                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt] = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePrice();
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].ChargeAmount = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceChargeAmount();
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].ChargeAmount.Value = reader1.GetFieldValueOrDefault<float>("Price");
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].ChargeAmount.currencyCode = curr;
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].BasisQuantity = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceBasisQuantity();
                        lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].BasisQuantity.Value = reader1.GetFieldValueOrDefault<float>("GoodsQuantity");

                        cnt++;
                        /*
                        rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                        rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                        rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                        rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                        rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                        rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                        rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                        rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                        rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                        product.Add(rep1);*/
                    }
                    reader.Close();
                }
                //list.product = new List<GoodsModel>(product);
                lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice = lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice.Where(s => s != null).ToArray();
                XmlSerializer xsSubmit = new XmlSerializer(typeof(Invoice));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, lst);
                        xml = sww.ToString(); // Your XML
                    }
                }
                //return xml;
                //var file = Provider.GetFileByID(id);
                var contentType = "text/xml";
                var bytes = Encoding.UTF8.GetBytes(xml);
                var result = new FileContentResult(bytes, contentType);
                var fn = DateTime.Now.ToString();
                result.FileDownloadName = "invoice" + fn + ".xml";
                return result;
            }
            return null;

            //upl.invoiceUpload(sa);


        }

        public string InvoicExport(string id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{id}'";

            query = $"SELECT t1.doc_guid, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" WHERE t1.attis_contract_doc_id = '{id}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            var list = new DocModel();

            var upl = new Lawyers.Web.App.invoice_service.InvoiceWebServiceClient();

            var sa = new Lawyers.Web.App.invoice_service.invoiceUpload();


            if (reader != null)
            {
                while (reader.Read())
                {
                    sa.invoiceUploadRequest = new invoice_service.InvoiceUploadRequest();
                    sa.invoiceUploadRequest.invoiceList = new invoice_service.InvoiceType[1];
                    sa.invoiceUploadRequest.invoiceList[0] = new invoice_service.InvoiceType();
                    sa.invoiceUploadRequest.invoiceList[0].HeaderExchangedDocument = new invoice_service.ExchangedDocumentType_2();
                    sa.invoiceUploadRequest.invoiceList[0].HeaderExchangedDocument.ID = new invoice_service.IDType[1];
                    sa.invoiceUploadRequest.invoiceList[0].HeaderExchangedDocument.ID[0] = new invoice_service.IDType();
                    sa.invoiceUploadRequest.invoiceList[0].HeaderExchangedDocument.ID[0].Value = reader["DocumentNumber"].ToString();
                    sa.invoiceUploadRequest.invoiceList[0].HeaderExchangedDocument.IssueDateTime = DateTime.Now.ToString("yyyy-MM-dd");
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment = new invoice_service.SupplyChainConsignmentType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0] = new invoice_service.SupplyChainConsignmentType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction = new invoice_service.SupplyChainTradeTransactionType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0] = new invoice_service.SupplyChainTradeTransactionType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].LineItemQuantity = new invoice_service.QuantityType();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].LineItemQuantity.Value = 1;

                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement = new invoice_service.SupplyChainTradeSettlementType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0] = new invoice_service.SupplyChainTradeSettlementType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].BillingSpecifiedPeriod = new invoice_service.SpecifiedPeriodType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].BillingSpecifiedPeriod[0] = new invoice_service.SpecifiedPeriodType_2();
                    list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].BillingSpecifiedPeriod[0].StartDateTime = list.DocumentDate.ToString("yyyy-MM-dd");
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].BillingSpecifiedPeriod[0].EndDateTime = list.DocumentDate.ToString("yyyy-MM-dd");
                    list.CurrencyCode = reader["CurrencyCode"].ToString().Trim();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].InvoiceApplicableTradeCurrencyExchange = new invoice_service.TradeCurrencyExchangeType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].InvoiceApplicableTradeCurrencyExchange[0] = new invoice_service.TradeCurrencyExchangeType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].InvoiceApplicableTradeCurrencyExchange[0].SourceCurrencyCode = new invoice_service.CodeType();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeSettlement[0].InvoiceApplicableTradeCurrencyExchange[0].SourceCurrencyCode.Value = list.CurrencyCode;

                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement = new invoice_service.SupplyChainTradeAgreementType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0] = new invoice_service.SupplyChainTradeAgreementType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem = new invoice_service.SupplyChainTradeLineItemType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0] = new invoice_service.SupplyChainTradeLineItemType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement = new invoice_service.SupplyChainTradeSettlementType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation = new invoice_service.TradeSettlementMonetarySummationType_2[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0] = new invoice_service.TradeSettlementMonetarySummationType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0].LineTotalAmount = new invoice_service.AmountType[1];
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0].LineTotalAmount[0] = new invoice_service.AmountType();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0].LineTotalAmount[0].Value = reader.GetFieldValueOrDefault<decimal>("GCost");
                    //sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0].LineTotalAmount[0].currencyCode = new invoice_service.CurrencyCodeContentType();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0].GrandTotal = new invoice_service.TextType();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0].GrandTotal.Value = reader.GetFieldValueOrDefault<string>("GCost");

                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty = new invoice_service.TradePartyType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty = new invoice_service.TradePartyType_2();
                    list.InvoiceSeller = reader["InvoiceSeller"].ToString().Trim();
                    list.InvoiceByer = reader["InvoiceByer"].ToString().Trim();
                    list.DocumentID = reader["DocumentID"].ToString().Trim();

                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeDelivery = new invoice_service.SupplyChainTradeDeliveryType_2();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeDelivery.BilledQuantity = new invoice_service.QuantityType();
                    sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeDelivery.BilledQuantity.Value = reader.GetFieldValueOrDefault<decimal>("PlacesQuantity");
                }
                reader.Close();

                var sellr = invfirm(list.InvoiceSeller);
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.GlobalID = new invoice_service.IDType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.GlobalID[0] = new invoice_service.IDType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.GlobalID[0].Value = list.InvoiceSeller;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.Name = new invoice_service.TextType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.Name[0] = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.Name[0].Value = sellr.org_name;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress = new invoice_service.TradeAddressType_2[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0] = new invoice_service.TradeAddressType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].CityName = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].CityName.Value = sellr.company_region;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].StreetName = new invoice_service.TextType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].StreetName[0] = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].StreetName[0].Value = sellr.org_type;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry = new invoice_service.TradeCountryType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry.Name = new invoice_service.TextType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry.Name[0] = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry.Name[0].Value = sellr.org_residency;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.DefinedTradeContact = new invoice_service.TradeContactType_2[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.DefinedTradeContact[0] = new invoice_service.TradeContactType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication = new invoice_service.UniversalCommunicationType_2[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication[0] = new invoice_service.UniversalCommunicationType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication[0].CompleteNumber = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].SellerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication[0].CompleteNumber.Value = sellr.company_contacts;
                var buyr = invfirm(list.InvoiceByer);
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.GlobalID = new invoice_service.IDType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.GlobalID[0] = new invoice_service.IDType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.GlobalID[0].Value = list.InvoiceByer;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.Name = new invoice_service.TextType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.Name[0] = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.Name[0].Value = buyr.org_name;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress = new invoice_service.TradeAddressType_2[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0] = new invoice_service.TradeAddressType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].CityName = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].CityName.Value = buyr.company_region;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].StreetName = new invoice_service.TextType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].StreetName[0] = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].StreetName[0].Value = buyr.org_type;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry = new invoice_service.TradeCountryType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry.Name = new invoice_service.TextType[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry.Name[0] = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.PostalTradeAddress[0].CountryIdentificationTradeCountry.Name[0].Value = buyr.org_residency;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.DefinedTradeContact = new invoice_service.TradeContactType_2[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.DefinedTradeContact[0] = new invoice_service.TradeContactType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication = new invoice_service.UniversalCommunicationType_2[1];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication[0] = new invoice_service.UniversalCommunicationType_2();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication[0].CompleteNumber = new invoice_service.TextType();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].BuyerTradeParty.DefinedTradeContact[0].DirectTelephoneUniversalCommunication[0].CompleteNumber.Value = buyr.company_contacts;

                var product = new List<GoodsModel>();
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage = new invoice_service.LogisticsPackageType_2[10];
                int cnt = 0;
                query = $"SELECT currency_a3_code FROM currencies WHERE currency_code='{list.CurrencyCode}'";
                string curr = Provider.RunQueryStr(query);
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].NetPriceProductTradePrice = new invoice_service.TradePriceType_2[10];
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation[0].LineTotalAmount[0].currencyCode = new invoice_service.CurrencyCodeContentType();
                //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeSettlement.SpecifiedTradeSettlementMonetarySummation.LineTotalAmount.currencyCode = curr;
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement = new invoice_service.SupplyChainTradeAgreementType_2();
                var query1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                var reader1 = Provider.RunQuery(query1);
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice = new invoice_service.TradePriceType_2[10];
                if (reader1 != null)
                {

                    while (reader1.Read())
                    {
                        var rep1 = new GoodsModel
                        {
                            GoodsCode = reader1["GoodsCode"].ToString(),
                        };

                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt] = new invoice_service.LogisticsPackageType_2();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].Description = new invoice_service.TextType[1];
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].Description[0] = new invoice_service.TextType();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].Description[0].Value = reader1["GoodsDescription"].ToString();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].ItemQuantity = new invoice_service.QuantityType[1];
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].ItemQuantity[0] = new invoice_service.QuantityType();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].ItemQuantity[0].Value = reader1.GetFieldValueOrDefault<decimal>("GoodsQuantity");
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].NetWeightMeasure = new invoice_service.MeasureType[1];
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].NetWeightMeasure[0] = new invoice_service.MeasureType();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].NetWeightMeasure[0].Value = reader1.GetFieldValueOrDefault<decimal>("NetWeightQuantity");
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].GrossWeightMeasure = new invoice_service.MeasureType[1];
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].GrossWeightMeasure[0] = new invoice_service.MeasureType();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].SpecifiedLogisticsPackage[cnt].GrossWeightMeasure[0].Value = reader1.GetFieldValueOrDefault<decimal>("GrossWeightQuantity");

                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt] = new invoice_service.TradePriceType_2();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].ChargeAmount = new invoice_service.AmountType[1];
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].ChargeAmount[0] = new invoice_service.AmountType();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].ChargeAmount[0].Value = reader1.GetFieldValueOrDefault<decimal>("Price");
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].BasisQuantity = new invoice_service.QuantityType[1];
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].BasisQuantity[0] = new invoice_service.QuantityType();
                        sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].BasisQuantity[0].Value = reader1.GetFieldValueOrDefault<decimal>("GoodsQuantity");
                        //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].ChargeAmount.currencyCode = curr;
                        //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].BasisQuantity = new IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceBasisQuantity();
                        //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice[cnt].BasisQuantity.Value = reader1.GetFieldValueOrDefault<float>("GoodsQuantity");
                        cnt++;

                    }
                    reader.Close();
                }
                //list.product = new List<GoodsModel>(product);
                sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice = sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].IncludedSupplyChainTradeLineItem[0].SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice.Where(s => s != null).ToArray();
                //lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice = lst.SpecifiedLogisticsConsignment.IncludedSupplyChainConsignment.RelatedSupplyChainTradeTransaction.IncludedSupplyChainTradeLineItem.SpecifiedSupplyChainTradeAgreement.NetPriceProductTradePrice.Where(s => s != null).ToArray();

            }


            //sa.invoiceUploadRequest.invoiceList[0].SpecifiedLogisticsConsignment[0].RelatedSupplyChainTradeTransaction[0].ApplicableSupplyChainTradeAgreement[0].NetPriceProductTradePrice[0].ChargeAmount[0].Value = 1;
            upl.ClientCredentials.UserName.UserName = "Aldiyar";
            upl.ClientCredentials.UserName.Password = "123456";
            //upl.ClientCredentials.ClientCertificate.Certificate.
            var res = upl.invoiceUpload(sa);
            return res.ToString();
            //return "{status:ok}";


        }

        public ActionResult XmlEpi(string id, string language)
        {
            //string sqlQuery = @"SELECT attis_contract_id FROM attis_contracts WHERE attis_contract_id=@p0";
            //System.Data.IDataReader read = this.Provider.RunQuery(sqlQuery, 155);
            //string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{id}'";

            query = $"SELECT t1.doc_guid, t1.attis_contract_doc_contract, t1.attis_contract_doc_date, t2.*, t3.*, t4.*, t5.*, " +
                $"t6.ap_memb_organization_name as ap_memb_organization_name_1, t6.ap_memb_short_name as ap_memb_short_name_1, t6.ap_memb_bin as ap_memb_bin_1, t6.ap_memb_itn as ap_memb_itn_1,t6.ap_member_postal_code as ap_member_postal_code_1, t6.ap_member_country_name as ap_member_country_name_1, t6.ap_member_region as ap_member_region_1, t6.ap_member_city as ap_member_city_1, t6.ap_member_street_house as ap_member_street_house_1, " +
                $"t7.ap_memb_organization_name as ap_memb_organization_name_2, t7.ap_memb_short_name as ap_memb_short_name_2, t7.ap_memb_bin as ap_memb_bin_2, t7.ap_memb_itn as ap_memb_itn_2, t7.ap_member_postal_code as ap_member_postal_code_2, t7.ap_member_country_name as ap_member_country_name_2, t7.ap_member_region as ap_member_region_2, t7.ap_member_city as ap_member_city_2, t7.ap_member_street_house as ap_member_street_house_2, " +
                $"t8.ap_memb_organization_name as ap_memb_organization_name_3, t8.ap_memb_short_name as ap_memb_short_name_3, t8.ap_memb_bin as ap_memb_bin_3, t8.ap_memb_itn as ap_memb_itn_3, t8.ap_member_postal_code as ap_member_postal_code_3, t8.ap_member_country_name as ap_member_country_name_3, t8.ap_member_region as ap_member_region_3, t8.ap_member_city as ap_member_city_3, t8.ap_member_street_house as ap_member_street_house_3, " +
                $"t11.ap_memb_organization_name as ap_memb_organization_name_4, t11.ap_memb_short_name as ap_memb_short_name_4, t11.ap_memb_bin as ap_memb_bin_4, t11.ap_memb_itn as ap_memb_itn_4, t11.ap_member_postal_code as ap_member_postal_code_4, t11.ap_member_country_name as ap_member_country_name_4, t11.ap_member_region as ap_member_region_4, t11.ap_member_city as ap_member_city_4, t11.ap_member_street_house as ap_member_street_house_4, " +
                $"t9.*, t10.*, t12.ap_person_reg_country_code as ap_person_reg_country_code_2, t12.ap_person_person_surname as ap_person_person_surname_2, t12.ap_person_person_post as ap_person_person_post_2, " +
                $"t12.ap_person_person_name as ap_person_person_name_2, t12.ap_person_person_middle_name as ap_person_person_middle_name_2 FROM attis_contract_docs t1 " +
                $"LEFT JOIN ap_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                $"LEFT JOIN ap_goods t3 ON t2.ap_main_id = t3.ap_good_main_id " +
                $"LEFT JOIN ap_send_rec t4 ON t2.ap_main_id = t4.ap_main_id " +
                $"LEFT JOIN ap_members t5 ON t4.sender_id = t5.ap_memb_id " +
                $"LEFT JOIN ap_members t6 ON t4.recipient_id = t6.ap_memb_id " +
                $"LEFT JOIN ap_members t7 ON t4.fin_reg_id = t7.ap_memb_id " +
                $"LEFT JOIN ap_members t8 ON t4.declarant_id = t8.ap_memb_id " +
                $"LEFT JOIN ap_members t11 ON t4.driver_id = t11.ap_memb_id " +
                $"LEFT JOIN ap_transportations t9 ON t2.ap_main_id = t9.ap_main_id " +
                $"LEFT JOIN ap_persons t10 ON t4.decl_officer_id = t10.ap_person_id " +
                $"LEFT JOIN ap_persons t12 ON t4.person1_id = t12.ap_person_id WHERE t1.attis_contract_doc_id = {id};";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            //var list = new AutoPreliminary();
            var list = new ESADout_CU();
            //var upl = new Lawyers.Web.App.invoice_service.InvoiceWebServiceClient();

            //var sa = new Lawyers.Web.App.invoice_service.invoiceUpload();
            //var sa = new Lawyers.Web.App.customs_service.AutoPreliminaryInformationClient(); //. invoice_service.invoiceUpload();
            //var lst = new Lawyers.Web.App.customs_service.AutoPISearchRequest(); //. invoice_service.invoiceUpload();
            //lst.
            //sa.search()

            var apd = "";
            int ctr = 0;
            if (reader != null)
            {
                while (reader.Read())
                {
                    apd = reader["ap_main_id"].ToString();
                    ctr = (int)reader["attis_contract_doc_contract"];
                    list.DocumentID = reader["doc_guid"].ToString();
                    string co1 = reader["ap_transp_customs_office"].ToString();
                    list.CustomsOffice = 1;
                    list.RecipientCountryCode = reader["ap_transp_destination_country_code"].ToString();
                    list.ExecutionDate = GetDateTimeFromString(reader["ap_main_reg_date"].ToString());

                    list.ESADout_CUGoodsShipment = new ESADout_CUESADout_CUGoodsShipment();
                    list.ESADout_CUGoodsShipment.OriginCountryName = reader["ap_good_origin_country_name"].ToString();
                    list.ESADout_CUGoodsShipment.CustCostCurrencyCode = reader["ap_good_cust_cost_currency_code"].ToString();

                    list.ESADout_CUGoodsShipment.TotalGoodsNumber = reader.GetFieldValueOrDefault<byte>("ap_good_total_goods_number");
                    string pkn = reader["ap_good_total_package_number"].ToString().TrimEnd();
                    if (!String.IsNullOrEmpty(pkn))
                        list.ESADout_CUGoodsShipment.TotalPackageNumber = Convert.ToByte(pkn);
                    string shn = reader["ap_good_specification_list_number"].ToString().TrimEnd();
                    if (!String.IsNullOrEmpty(shn))
                        list.ESADout_CUGoodsShipment.TotalSheetNumber = Convert.ToByte(shn);
                    list.ESADout_CUGoodsShipment.TotalCustCost = reader.GetFieldValueOrDefault<decimal>("ap_good_total_cust_cost");

                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor = new ESADout_CUESADout_CUGoodsShipmentESADout_CUConsignor();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor.OrganizationName = reader["ap_memb_organization_name"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor.ShortName = reader["ap_memb_short_name"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor.Address = new Address();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor.Address.CounryName = reader["ap_member_country_name"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor.Address.City = reader["ap_member_city"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor.Address.StreetHouse = reader["ap_member_street_house"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsignor.Address.CountryCode = reader["ap_member_postal_code"].ToString();

                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant = new ESADout_CUESADout_CUGoodsShipmentESADout_CUDeclarant();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.OrganizationName = reader["ap_memb_organization_name_3"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.ShortName = reader["ap_memb_short_name_3"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.RKOrganizationFeatures = new RKOrganizationFeatures();//new RKOrganizationFeatures();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.RKOrganizationFeatures.BIN = reader["ap_memb_bin_3"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.RKOrganizationFeatures.ITN = reader["ap_memb_itn_3"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.Address = new Address();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.Address.CounryName = reader["ap_member_country_name"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.Address.City = reader["ap_member_city"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.Address.StreetHouse = reader["ap_member_street_house"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUDeclarant.Address.CountryCode = reader["ap_member_postal_code"].ToString();

                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment = new ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigment();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.DispatchCountryName = reader["ap_transp_dispatch_country_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.DispatchCountryCode = reader["ap_transp_dispatch_country_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.DestinationCountryCode = reader["ap_transp_destination_country_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.DestinationCountryName = reader["ap_transp_destination_country_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.BorderCustomsOffice = new BorderCustomsOffice();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.BorderCustomsOffice.CustomsCountryCode = 1;// reader.GetFieldValueOrDefault<ushort>("ap_transp_customs_country_code");
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.BorderCustomsOffice.Code = 1;// reader.GetFieldValueOrDefault<ushort>("ap_transp_customs_office"); 
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUDepartureArrivalTransport = new ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransport();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUDepartureArrivalTransport.TransportModeCode = reader.GetFieldValueOrDefault<byte>("ap_transp_transport_mode_code");
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUDepartureArrivalTransport.TransportNationalityCode = reader["ap_transp_transport_nationality_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUDepartureArrivalTransport.TransportMeans = new ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUDepartureArrivalTransportTransportMeans();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUDepartureArrivalTransport.TransportMeans.TransportIdentifier = reader["ap_transp_transport_identifier"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUDepartureArrivalTransport.TransportMeans.TransportMeansNationalityCode = reader["ap_transp_transport_nationality_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUBorderTransport = new ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransport();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUBorderTransport.TransportModeCode = reader.GetFieldValueOrDefault<byte>("ap_transp_transport_mode_code");
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUBorderTransport.TransportNationalityCode = reader["ap_transp_transport_nationality_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUBorderTransport.TransportMeans = new ESADout_CUESADout_CUGoodsShipmentESADout_CUConsigmentESADout_CUBorderTransportTransportMeans();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUBorderTransport.TransportMeans.TransportIdentifier = reader["ap_transp_transport_identifier"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUConsigment.ESADout_CUBorderTransport.TransportMeans.TransportMeansNationalityCode = reader["ap_transp_transport_nationality_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUMainContractTerms = new ESADout_CUESADout_CUGoodsShipmentESADout_CUMainContractTerms();
                    list.ESADout_CUGoodsShipment.ESADout_CUMainContractTerms.ContractCurrencyCode = reader["ap_good_cust_cost_currency_code"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUMainContractTerms.TotalInvoiceAmount = reader.GetFieldValueOrDefault<decimal>("ap_good_total_cust_cost");
                    list.ESADout_CUGoodsShipment.ESADout_CUMainContractTerms.TradeCountryCode = reader["ap_member_country_name"].ToString();
                    list.ESADout_CUGoodsShipment.ESADout_CUMainContractTerms.CUESADDeliveryTerms = new CUESADDeliveryTerms();
                    list.ESADout_CUGoodsShipment.ESADout_CUMainContractTerms.CUESADDeliveryTerms.DeliveryPlace = reader["ap_main_recipient_country_code"].ToString().TrimEnd();
                    list.ESADout_CUGoodsShipment.ESADout_CUMainContractTerms.CUESADDeliveryTerms.DeliveryTermsStringCode = "";
                    list.FilledPerson = new ESADout_CUFilledPerson();
                    list.FilledPerson.PersonSurname = reader["ap_person_person_surname"].ToString();
                    list.FilledPerson.PersonName = reader["ap_person_person_name"].ToString();
                    list.FilledPerson.PersonMiddleName = reader["ap_person_person_middle_name"].ToString();
                    //list.FilledPerson.IdentityCard = new IdentityCard();
                    //var aa2 = reader["ap_send_rec_identity_card_code"].ToString();
                    //list.FilledPerson.IdentityCard.IdentityCardCode = 1;
                    //list.FilledPerson.IdentityCard.IdentityCardSeries = reader["ap_send_rec_identity_card_series"].ToString();
                    //list.FilledPerson.IdentityCard.IdentityCardNumber = reader["ap_send_rec_identity_card_number"].ToString();
                    //list.FilledPerson.IdentityCard.IdentityCardDate = GetDateTimeFromString(reader["ap_send_rec_identity_card_date"].ToString());

                    list.ESADout_CUGoodsShipment.ESADout_CUGoods = new ESADout_CUESADout_CUGoodsShipmentESADout_CUGoods[10];
                    string date = GetDateTimeFromString(reader["ap_transp_date_expected_arrival"].ToString()).ToString("yyyy-MM-dd");
                }
                reader.Close();
                query = $"SELECT t1.*, t2.attis_doc_type_name_ru FROM attis_contract_docs t1 LEFT JOIN  attis_doc_types t2 ON t1.attis_contract_doc_type = t2.attis_doc_type_code WHERE attis_contract_doc_contract = '{ctr}'";
                reader = Provider.RunQuery(query);
                int cnt = 0;
                var prdl = new ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUPresentedDocument[10];
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        int tp = (int)reader["attis_contract_doc_type"];
                        if (tp < 5)
                        {
                            prdl[cnt] = new ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUPresentedDocument();
                            prdl[cnt].PrDocumentName = reader["attis_doc_type_name_ru"].ToString();
                            prdl[cnt].PrDocumentNumber = reader["attis_contract_doc_number"].ToString();
                            //var date = GetDateTimeFromString(reader["attis_contract_doc_date"].ToString()).ToString("yyyy-MM-dd");
                            prdl[cnt].PrDocumentDate = GetDateTimeFromString(reader["attis_contract_doc_date"].ToString()); //ap_prev_doc_preceding_document_date
                            cnt++;
                        }
                    }
                    reader.Close();
                }
                prdl = prdl.Where(s => s != null).ToArray();
                //list.ESADout_CUGoodsShipment.ESADout_CUGoods.ESADout_CUPresentedDocument = new ESADout_CUESADout_CUGoodsShipmentESADout_CUGoodsESADout_CUPresentedDocument[prdl.Count()];
                //list.ESADout_CUGoodsShipment.ESADout_CUGoods.ESADout_CUPresentedDocument = prdl;
                //qery = $"SELECT country_name_ru FROM countries WHERE country_2a_code='{list.MainConsignmentDetails.ConsignmentDetails[0].ConsigneeDetails.SubjectAddressDetails[0].CounryName}'";

                var query1 = $"SELECT * FROM ap_good_data WHERE ap_main_id = '{apd}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<EpGoods>();
                //var curr = list.MainConsignmentDetails.ConsignmentDetails[0].CAInvoiceValueAmount.CurrencyCode;
                cnt = 0;
                //query = $"SELECT COUNT(t2.*) FROM  public.subjects WHERE t3.doc_widget_id = "{ }";
                int lnt = prdl.Count(s => s != null);
                //list.MainConsignmentDetails.ConsignmentDetails[0].GoodsItem = new AutoPreliminaryMainConsignmentDetailsConsignmentDetailsGoodsItem[10];
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        //var mcdi = new AutoPreliminaryMainConsignmentDetailsConsignmentDetailsCAInvoiceValueAmount();
                        string nr = reader1["ap_good_data_list_numeric"].ToString();
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt] = new ESADout_CUESADout_CUGoodsShipmentESADout_CUGoods();
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].GoodsNumeric = Convert.ToByte(nr);
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].GoodsDescription = reader1["ap_good_data_goods_description"].ToString();
                        float gw = reader1.GetFieldValueOrDefault<float>("ap_good_data_gross_weight_quantity");
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].GrossWeightQuantity = (ushort)gw;//reader1.GetFieldValueOrDefault<ushort>("ap_good_data_gross_weight_quantity");
                        float nw = reader1.GetFieldValueOrDefault<float>("ap_good_data_net_weight_quantity");
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].NetWeightQuantity = (ushort)nw;
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].InvoicedCost = reader1.GetFieldValueOrDefault<decimal>("ap_good_data_invoiced_cost");
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].CustomsCost = reader1.GetFieldValueOrDefault<decimal>("ap_good_data_customs_cost");
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].StatisticalCost = reader1.GetFieldValueOrDefault<decimal>("ap_good_data_statistical_cost");
                        float tnv = reader1.GetFieldValueOrDefault<float>("ap_good_data_goods_tnved_code");
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].GoodsTNVEDCode = (ulong)tnv;
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].OriginCountryCode = reader1["ap_good_data_origin_country_code"].ToString();
                        //list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].OriginCountryName
                        list.ESADout_CUGoodsShipment.ESADout_CUGoods[cnt].ESADout_CUPresentedDocument = prdl;
                        cnt++;
                    }
                    reader.Close();
                }
                list.ESADout_CUGoodsShipment.ESADout_CUGoods = list.ESADout_CUGoodsShipment.ESADout_CUGoods.Where(s => s != null).ToArray();

                XmlSerializer xsSubmit = new XmlSerializer(typeof(ESADout_CU));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, list);
                        xml = sww.ToString(); // Your XML
                    }
                }/*
                xml = xml.Replace("xmlns=\"dsp\"", "");
                xml = xml.Replace("xmlns=\"ddc\"", "");
                xml = xml.Replace("xmlns=\"cav\"", "");
                xml = xml.Replace("xmlns=\"urnx\"", "");
                */
                //return xml;
                //var file = Provider.GetFileByID(id);
                var contentType = "text/xml";
                var bytes = Encoding.UTF8.GetBytes(xml);
                var result = new FileContentResult(bytes, contentType);
                string fn = DateTime.Now.ToString();
                result.FileDownloadName = fn + ".xml";
                return result;
            }
            return null;
        }
        public string LoadInvoice(string doc_id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{doc_id}'";
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            query = $"SELECT t1.doc_guid, t3.org_name, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" LEFT JOIN organizations t3 ON t2.\"InvoiceSeller\" = t3.org_code WHERE t1.attis_contract_doc_id = '{doc_id}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            var list = new DocModel();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.DocumentID = reader["DocumentID"].ToString();
                    list.DocGuid = reader["doc_guid"].ToString();
                    list.DocumentNumber = reader["DocumentNumber"].ToString();
                    list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                    list.CurrencyCode = reader["CurrencyCode"].ToString();
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.PlacesDescription = reader["PlacesDescription"].ToString();
                    list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                    list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                    list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                    list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                    list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                    list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                    list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                    list.InvoiceByer = reader["InvoiceByer"].ToString();
                    list.InvoiceSeller = reader["InvoiceSeller"].ToString();
                    list.SellerName = reader["org_name"].ToString();
                }
                reader.Close();
                var query1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<GoodsModel>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new GoodsModel
                        {
                            GoodsCode = reader1["GoodsCode"].ToString(),
                        };
                        rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                        rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                        rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                        rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                        rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                        rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                        rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                        rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                        rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                list.product = new List<GoodsModel>(product);
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }

        public string LoadInvoiceXML(string doc_id, string language)
        {
            //string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{doc_id}'";
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            query = $"SELECT t1.doc_guid, t3.org_name, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" LEFT JOIN organizations t3 ON t2.\"InvoiceSeller\" = t3.org_code WHERE t1.attis_contract_doc_id = '{doc_id}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            var list = new DocModel();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.DocumentID = reader["DocumentID"].ToString();
                    list.DocGuid = reader["doc_guid"].ToString();
                    list.DocumentNumber = reader["DocumentNumber"].ToString();
                    list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                    list.CurrencyCode = reader["CurrencyCode"].ToString();
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.PlacesDescription = reader["PlacesDescription"].ToString();
                    list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                    list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                    list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                    list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                    list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                    list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                    list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                    list.InvoiceByer = reader["InvoiceByer"].ToString();
                    list.InvoiceSeller = reader["InvoiceSeller"].ToString();
                    list.SellerName = reader["org_name"].ToString();
                }
                reader.Close();
                var query1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<GoodsModel>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new GoodsModel
                        {
                            GoodsCode = reader1["GoodsCode"].ToString(),
                        };
                        rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                        rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                        rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                        rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                        rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                        rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                        rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                        rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                        rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                list.product = new List<GoodsModel>(product);

                XmlSerializer xsSubmit = new XmlSerializer(typeof(DocModel));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, list);
                        xml = sww.ToString(); // Your XML
                    }
                }
                return xml;
            }
            return "[]";
        }
        public string LoadCMRXML(string doc_id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{doc_id}'";
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            query = $"SELECT t1.doc_guid, t1.attis_contract_doc_date, t2.*, t3.* FROM attis_contract_docs t1 " +
                $"LEFT JOIN \"CMR\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" " +
                $"LEFT JOIN \"TakingCargoPlace\" t3 ON t2.cmr_id = t3.cmr_id WHERE t1.attis_contract_doc_id = '{doc_id}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            var list = new CMRModel();
            string cmrid = "";
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.PrDocumentNumber = doc_id;
                    list.DocumentID = reader["DocumentID"].ToString();
                    list.DocGuid = reader["doc_guid"].ToString();
                    list.cmr_number = reader["cmr_number"].ToString();
                    list.PrDocumentDate = GetDateTimeFromString(reader["attis_contract_doc_date"].ToString());
                    list.cmr_date = GetDateTimeFromString(reader["cmr_date"].ToString());
                    list.cmr_courier = reader["cmr_courier"].ToString();
                    list.cmr_courier_next = reader["cmr_courier_next"].ToString();
                    list.cmr_track = reader["cmr_track"].ToString();
                    list.cmr_trailer = reader["cmr_trailer"].ToString();
                    list.cmr_sender = reader["cmr_sender_id"].ToString();
                    list.cmr_recipient = reader["cmr_recipient_id"].ToString();
                    list.DeliveryPlace = reader["delivery_place"].ToString();
                    list.DeliveryTermsStringCode = reader["delivery_terms"].ToString();
                    list.TermsDescription = reader["terms_desc"].ToString();
                    list.TakingCargoDate = GetDateTimeFromString(reader["TakingCargoDate"].ToString());
                    string vv = reader["TakingCargoDate"].ToString();
                    list.WarehouseName = reader["warehouse"].ToString();
                    list.CountryCode = reader["CountryCode"].ToString();
                    list.City = reader["City"].ToString();
                    list.StreetHouse = reader["StreetHouse"].ToString();
                    list.PostalCode = reader["PostalCode"].ToString();
                    list.CurrencyCode = reader["CarrierNotice"].ToString();
                    list.custom_code = reader["custom_code"].ToString();
                    list.courier_notes = reader["courier_notes"].ToString();
                    list.cmr_track_reg_country = reader["cmr_track_reg_country"].ToString();
                    list.GoodsCost = reader.GetFieldValueOrDefault<float>("GoodsCost");
                    cmrid = reader["cmr_id"].ToString();
                }
                reader.Close();

                var query1 = $"SELECT * FROM \"CMRGoods\" WHERE \"CmrId\" = '{cmrid}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<CMRGoodsModel>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new CMRGoodsModel
                        {
                            GoodMarking = reader1["GoodsMarking"].ToString(),
                        };
                        //rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.GoodsNomenclatureCode = reader1["GoodsNomenclatureCode"].ToString();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString().TrimEnd();
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.VolumeQuantity = reader1.GetFieldValueOrDefault<float>("VolumeQuantity"); //(float)reader1["Price"];
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                list.product = new List<CMRGoodsModel>(product);

                XmlSerializer xsSubmit = new XmlSerializer(typeof(CMRModel));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, list);
                        xml = sww.ToString(); // Your XML
                    }
                }
                return xml;

            }
            return "[]";
        }
        public string LoadCMR(string doc_id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{doc_id}'";
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            query = $"SELECT t1.doc_guid, t1.attis_contract_doc_date, t1.attis_contract_doc_contract, t2.*, t3.* FROM attis_contract_docs t1 " +
                $"LEFT JOIN \"CMR\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" " +
                $"LEFT JOIN \"TakingCargoPlace\" t3 ON t2.cmr_id = t3.cmr_id WHERE t1.attis_contract_doc_id = '{doc_id}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            var list = new CMRModel();
            string cmrid = "";
            int contract = 0;
            if (reader != null)
            {
                while (reader.Read())
                {
                    contract = reader.GetFieldValueOrDefault<int>("attis_contract_doc_contract");
                    list.PrDocumentNumber = doc_id;
                    list.DocumentID = reader["DocumentID"].ToString();
                    list.DocGuid = reader["doc_guid"].ToString();
                    list.cmr_number = reader["cmr_number"].ToString();
                    list.PrDocumentDate = GetDateTimeFromString(reader["attis_contract_doc_date"].ToString());
                    list.cmr_date = GetDateTimeFromString(reader["cmr_date"].ToString());
                    list.cmr_courier = reader["cmr_courier"].ToString();
                    list.cmr_courier_next = reader["cmr_courier_next"].ToString();
                    list.cmr_track = reader["cmr_track"].ToString();
                    list.cmr_trailer = reader["cmr_trailer"].ToString();
                    list.cmr_sender = reader["cmr_sender_id"].ToString();
                    list.cmr_recipient = reader["cmr_recipient_id"].ToString();
                    list.DeliveryPlace = reader["delivery_place"].ToString();
                    list.DeliveryTermsStringCode = reader["delivery_terms"].ToString();
                    list.TermsDescription = reader["terms_desc"].ToString();
                    list.TakingCargoDate = GetDateTimeFromString(reader["TakingCargoDate"].ToString());
                    string vv = reader["TakingCargoDate"].ToString();
                    list.WarehouseName = reader["warehouse"].ToString();
                    list.CountryCode = reader["CountryCode"].ToString();
                    list.City = reader["City"].ToString();
                    list.StreetHouse = reader["StreetHouse"].ToString();
                    list.PostalCode = reader["PostalCode"].ToString();
                    list.CurrencyCode = reader["CarrierNotice"].ToString();
                    list.custom_code = reader["custom_code"].ToString();
                    list.courier_notes = reader["courier_notes"].ToString();
                    list.cmr_track_reg_country = reader["cmr_track_reg_country"].ToString();
                    list.GoodsCost = reader.GetFieldValueOrDefault<float>("GoodsCost");
                    cmrid = reader["cmr_id"].ToString();
                }
                reader.Close();
                if (language.IsNullOrWhiteSpace())
                    language = "ru";
                list.cmr_track_reg_country_name = country(list.cmr_track_reg_country, language);
                list.sender = new comp();
                list.recipient = new comp();
                list.courier = new comp();
                list.courier_next = new comp();
                if (list.cmr_sender != "" || list.cmr_sender != "undefined")
                    list.sender = getComp(list.cmr_sender);
                if (list.cmr_recipient != "" || list.cmr_recipient != "undefined")
                    list.recipient = getComp(list.cmr_recipient);
                if (list.cmr_courier != "" || list.cmr_courier != "undefined")
                    list.courier = getComp(list.cmr_courier);
                if (list.cmr_courier_next != "" || list.cmr_courier_next != "undefined")
                    list.courier_next = getComp(list.cmr_courier_next);
                var query2 = $"SELECT t1.*, t2.pack_name_ru FROM places_list t1 LEFT JOIN packagin t2 ON t1.packing_code = t2.pack_code WHERE cmr_id = '{cmrid}'";
                var reader2 = Provider.RunQuery(query2);
                List<CMRPlacesModel> allPlaces = new List<CMRPlacesModel>();
                if (reader2 != null)
                {
                    while (reader2.Read())
                    {
                        var rep2 = new CMRPlacesModel();
                        rep2.PackagingTypeCode = reader2["packing_code"].ToString();
                        rep2.PlacesCount = reader2["packing_quantity"].ToString();
                        rep2.Description = reader2["packing_description"].ToString();
                        rep2.PlacesPartCount = reader2["package_part_quantity"].ToString();
                        rep2.PackagingType = new LibModel();
                        rep2.PackagingType.value = rep2.PackagingTypeCode;
                        rep2.PackagingType.display_text = reader2["pack_name_ru"].ToString();
                        rep2.GoodId = reader2["good_id"].ToString();
                        allPlaces.Add(rep2);
                    }
                    reader2.Close();
                }
                var query1 = $"SELECT * FROM \"CMRGoods\" WHERE \"CmrId\" = '{cmrid}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<CMRGoodsModel>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new CMRGoodsModel
                        {
                            GoodMarking = reader1["GoodsMarking"].ToString(),
                        };
                        //rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.Id = reader1["cmr_good_id"].ToString();
                        rep1.GoodsNomenclatureCode = reader1["GoodsNomenclatureCode"].ToString().TrimEnd();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString().TrimEnd();
                        rep1.GoodsPrice = reader1.GetFieldValueOrDefault<float>("GoodsPrice");
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.VolumeQuantity = reader1.GetFieldValueOrDefault<float>("VolumeQuantity"); //(float)reader1["Price"];
                        rep1.places = allPlaces.Where(p => p.GoodId == rep1.Id).ToList();
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                list.product = new List<CMRGoodsModel>(product);
                query1 = $"SELECT * FROM attis_contract_docs WHERE attis_contract_doc_contract = '{contract}' AND (attis_contract_doc_type=1 OR attis_contract_doc_type=7)";
                reader1 = Provider.RunQuery(query1);
                var docs = new List<cmr_doc>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new cmr_doc
                        {
                            document_number = reader1["attis_contract_doc_id"].ToString(),
                        };
                        //rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.document_date = GetDateTimeFromString(reader1["attis_contract_doc_date"].ToString());
                        rep1.document_kind = reader1["attis_contract_doc_type"].ToString().TrimEnd();
                        docs.Add(rep1);
                    }
                    reader1.Close();
                }
                list.docs = new List<cmr_doc>(docs);

                query2 = $"SELECT t1.*, t2.* FROM custom_offices t1 LEFT JOIN countries t2 on t1.custom_country=t2.country_2a_code WHERE custom_code = '{list.custom_code}'";
                reader2 = Provider.RunQuery(query2);
                var custom = new customs();
                if (reader2 != null)
                {
                    while (reader2.Read())
                    {
                        custom.custom_code = reader2["custom_code"].ToString();
                        custom.custom_name = reader2["custom_name"].ToString();
                        custom.custom_country = new LibModel();
                        custom.custom_country.value = reader2["country_2a_code"].ToString();
                        custom.custom_country.display_text = reader2["country_name_ru"].ToString();
                        custom.custom_addr = reader2["custom_addr"].ToString();
                        custom.custom_email = reader2["custom_email"].ToString();
                        custom.custom_phone = reader2["custom_phone"].ToString();
                        custom.custom_fax = reader2["custom_fax"].ToString();
                        custom.custom_id = reader2["custom_id"].ToString();
                        custom.custom_cust_code = reader2["custom_cust_code"].ToString();
                        custom.custom_sovam = reader2["custom_sovam"].ToString();

                    }
                    reader2.Close();
                }
                list.customs_office = custom;
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }

        public string LoadFm1(string id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{id}'";
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            var fmi = "";
            query = $"SELECT t1.doc_guid, t1.attis_contract_doc_date, t2.*, t3.*, t4.*, t5.*, t6.*, t8.*," +
                   // $"t9.fm1_addrr_region as region_kaz_2, t9.fm1_addrr_state as state_kaz_2, t9.fm1_addrr_city as sity_kaz_2," +
                  //  $"t9.fm1_addrr_street as street_2, t9.fm1_addrr_house_num as house_num_2, t9.fm1_addrr_flat_num as flat_num_2, " +
                 //   $"t9.fm1_addrr_post_index as post_index_2, t9.phone as fm1_memb_contact_phone_2, t9.mail as fm1_memb_email_2, " +
                   // $"t10.fm1_addrr_region as region_kaz_3, t10.fm1_addrr_state as state_kaz_3, " +
                    //$"t10.fm1_addrr_city as sity_kaz_3, t10.fm1_addrr_street as street_3, t10.fm1_addrr_house_num as house_num_3, " +
                    //$"t10.fm1_addrr_flat_num as flat_num_3, t10.fm1_addrr_post_index as post_index_3, t10.addition as add_info_3, " +
                    $"t11.fm1_person_name as gn2, t11.fm1_person_secondname as ln2, t11.fm1_person_middle_name as mn2 " +
                   // $"t12.doc_series as doc_series_2, t12.doc_goverm_office as goverm_office_2, t12.doc_date as doc_date_2 " +
                    $"FROM attis_contract_docs t1 " +
                    $"LEFT JOIN fm1_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                    $"LEFT JOIN fm1_subject t3 ON t2.fm1_main_id = t3.fm1_main_id " +
                    $"LEFT JOIN fm1_addrr t4 ON t2.fm1_main_id = t4.fm1_main_id " +
                    $"LEFT JOIN fm1_docs t5 ON t2.fm1_main_id = t5.fm1_main_id " +
                    $"LEFT JOIN fm1_operations t6 ON t2.fm1_main_id = t6.fm1_main_id " +
                    $"LEFT JOIN fm1_persons t8 ON t2.fm1_main_id = t8.fm1_main_id " +
                    $"LEFT JOIN fm1_persons1 t11 ON t2.fm1_main_id = t11.fm1_main_id WHERE t1.attis_contract_doc_id = '{id}';";
            var reader = Provider.RunQuery(query);
            var list = new Fm1Model();
            if (reader != null)
            {
                while (reader.Read())
                {
                    fmi = reader["fm1_main_id"].ToString(); 
                    list.fm1_main_related_number = reader["fm1_main_related_number"].ToString();
                    list.fm1_main_related_date = GetDateTimeFromString(reader["fm1_main_related_date"].ToString());
                    list.fm1_main_date = GetDateTimeFromString(reader["attis_contract_doc_date"].ToString());
                    list.fm1_main_doc_kind = reader["fm1_main_form_kind"].ToString();
                    list.fm1_main_form_state = reader["fm1_main_form_state"].ToString();
                    list.fm1_main_reason = reader["fm1_main_reason"].ToString();
                    list.fm1_main_subreason = reader["fm1_main_subreason"].ToString();
                    list.fm1_subj_code = reader["fm1_subj_code"].ToString();
                    list.fm1_subj_org_form = reader["fm1_subj_org_form"].ToString();
                    list.fm1_subj_name = reader["fm1_subj_name"].ToString();
                    list.fm1_subj_pers_second_name = reader["fm1_subj_pers_second_name"].ToString();
                    list.fm1_subj_pers_name = reader["fm1_subj_pers_name"].ToString();
                    list.fm1_subj_pers_middle_name = reader["fm1_subj_pers_middle_name"].ToString();
                    list.fm1_subj_rnn = reader["fm1_subj_rnn"].ToString();
                    list.fm1_subj_iin_bin = reader["fm1_subj_iin_bin"].ToString();
                    list.fm1_subj_manager_second_name = reader["fm1_subj_manager_second_name"].ToString();
                    list.fm1_subj_manager_name = reader["fm1_subj_manager_name"].ToString();
                    list.fm1_subj_manager_patronymic = reader["fm1_subj_manager_patronymic"].ToString();
                    list.fm1_subj_position = reader["fm1_subj_position"].ToString();
                    list.fm1_subj_phone = reader["fm1_subj_phone"].ToString();
                    list.fm1_subj_email = reader["fm1_subj_email"].ToString();
                    list.state_kaz_1 = reader["fm1_addrr_state"].ToString();
                    list.region_kaz_1 = reader["fm1_addrr_region"].ToString();
                    list.sity_kaz_1 = reader["fm1_addrr_city"].ToString();
                    list.street_1 = reader["fm1_addrr_street"].ToString();
                    list.house_num_1 = reader["fm1_addrr_house_num"].ToString();
                    list.flat_num_1 = reader["fm1_addrr_flat_num"].ToString();
                    list.post_index_1 = reader["fm1_addrr_post_index"].ToString();
                    list.doc_num = reader["doc_num"].ToString();
                    list.doc_series = reader["doc_series"].ToString();
                    list.goverm_office = reader["doc_goverm_office"].ToString();
                    list.doc_date = GetDateTimeFromString(reader["doc_date"].ToString());
                    list.fm1_oper_number = reader["fm1_oper_number"].ToString();
                    list.fm1_oper_code_type = reader["fm1_oper_kind"].ToString();
                    list.fm1_oper_eknp = reader["fm1_oper_eknp"].ToString();
                    list.fm1_oper_members_quant = reader["fm1_oper_members_quant"].ToString();
                    list.fm1_oper_currency = reader["fm1_oper_curr_code"].ToString();
                    list.fm1_oper_curr_code = reader.GetFieldValueOrDefault<float>("fm1_oper_curr_sum");
                    list.fm1_oper_tenge_sum = reader.GetFieldValueOrDefault<float>("fm1_oper_tenge_sum"); //reader["fm1_oper_tenge_sum"].ToString();
                    list.fm1_oper_basis = reader["fm1_oper_basis"].ToString();
                    list.fm1_oper_basis_doc_date = GetDateTimeFromString(reader["fm1_oper_basis_doc_date"].ToString());
                    list.fm1_oper_basis_doc_num = reader["fm1_oper_basis_doc_num"].ToString();
                    list.fm1_oper_1code = reader["fm1_oper_1code"].ToString();
                    list.fm1_oper_2code = reader["fm1_oper_2code"].ToString();
                    list.fm1_oper_3code = reader["fm1_oper_3code"].ToString();
                    list.fm1_oper_trouble_desc = reader["fm1_oper_trouble_desc"].ToString();
                    list.fm1_oper_add_info = reader["fm1_oper_add_info"].ToString();
                    
                }
                reader.Close();

                query = $"SELECT t1.*, t2.*, t3.*, t3.fm1_person_secondname as ln2, t3.fm1_person_name as gn2, t3.fm1_person_middle_name as mn2, t4.*, t5.*, t6.*, " +
                    $"t6.fm1_addrr_state as state_3, t6.fm1_addrr_region as region_3, t6.fm1_addrr_city as sity_3, t6.fm1_addrr_street as street_3, t6.fm1_addrr_house_num as house_num_3, t6.fm1_addrr_flat_num as flat_num_3, " +
                    $" t6.fm1_addrr_post_index as post_index_3, t6.addition as add_info_3 FROM fm1_members t1 " +
                    $"LEFT JOIN fm1_persons t2 ON t2.fm1_memb_id = t1.fm1_memb_id " +
                    $"LEFT JOIN fm1_persons1 t3 ON t3.fm1_memb_id = t1.fm1_memb_id " +
                    $"LEFT JOIN fm1_docs1 t4 ON t4.fm1_memb_id = t1.fm1_memb_id " +
                    $"LEFT JOIN fm1_addrr1 t5 ON t5.fm1_memb_id = t1.fm1_memb_id " +
                    $"LEFT JOIN fm1_addrr2 t6 ON t6.fm1_memb_id = t1.fm1_memb_id " +
                    $" WHERE t1.fm1_main_id='{fmi}'";  
                reader = Provider.RunQuery(query);
                var mbm = new List<fmembers>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new fmembers
                        {
                            fm1_member = reader["fm1_member"].ToString(),
                        };
                        rep1.fm1_memb_is_subj = reader["fm1_memb_is_subj"].ToString();
                        rep1.fm1_memb_subj_kind = reader["fm1_memb_subj_kind"].ToString();
                        rep1.fm1_memb_country = reader["fm1_memb_country"].ToString();
                        rep1.fm1_memb_type = reader["fm1_memb_type"].ToString();
                        rep1.fm1_memb_foreign = reader["fm1_memb_foreign"].ToString();
                        rep1.fm1_memb_bank_branch_place = reader["fm1_memb_bank_branch_place"].ToString();
                        rep1.fm1_memb_bank_branch = reader["fm1_memb_bank_branch"].ToString();
                        rep1.fm1_memb_sdp = reader["fm1_memb_sdp"].ToString();
                        rep1.fm1_memb_branch_code = reader["fm1_memb_branch_code"].ToString();
                        rep1.fm1_memb_acc = reader["fm1_memb_acc"].ToString();
                        rep1.fm1_memb_bank_place = reader["fm1_memb_bank_place"].ToString();
                        rep1.fm1_memb_bank_name = reader["fm1_memb_bank_name"].ToString();
                        rep1.fm1_memb_org_form = reader["fm1_memb_org_form"].ToString();
                        rep1.fm1_memb_company_name = reader["fm1_memb_company_name"].ToString();
                        rep1.fm1_memb_noname = reader["fm1_memb_noname"].ToString();
                        rep1.fm1_memb_founder_org_form = reader["fm1_memb_founder_org_form"].ToString();
                        //list.fm1_memb_founder= reader["fm1_main_form_kind"].ToString();
                        rep1.fm1_memb_founder_secondname = reader["fm1_memb_founder_secondname"].ToString();
                        rep1.fm1_memb_founder_ = reader["fm1_memb_founder_"].ToString();
                        rep1.fm1_memb_founder_name = reader["fm1_memb_founder_name"].ToString();
                        rep1.fm1_memb_founder_patronymic = reader["fm1_memb_founder_middle_name"].ToString();
                        rep1.fm1_memb_country_2 = reader["fm1_memb_country2"].ToString();
                        rep1.fm1_memb_member_addrr = reader["fm1_memb_member_addrr"].ToString();
                        rep1.fm1_memb_member_fact_addrr = reader["fm1_memb_member_fact_addrr"].ToString();
                        rep1.fm1_member_name = reader["fm1_member_name"].ToString();
                        rep1.fm1_member_middle_name = reader["fm1_member_middle_name"].ToString();
                        rep1.fm1_member_secondname = reader["fm1_member_secondname"].ToString();
                        rep1.fm1_member_birth_place = reader["fm1_member_birth_place"].ToString();
                        rep1.fm1_member_birth_date = GetDateTimeFromString(reader["fm1_member_birth_date"].ToString());

                        rep1.oked = reader["oked"].ToString();
                        rep1.iin_bin = reader["iin_bin"].ToString();
                        rep1.fm1_person_secondname = reader["fm1_person_secondname"].ToString();
                        rep1.fm1_person_name = reader["fm1_person_name"].ToString();
                        rep1.fm1_person_midle_name = reader["fm1_person_middle_name"].ToString();
                        rep1.fm1_person_secondname_2 = reader["ln2"].ToString();
                        rep1.fm1_person_name_2 = reader["gn2"].ToString();
                        rep1.fm1_person_middle_name_2 = reader["mn2"].ToString();
                        rep1.fm1_person_birth_date = GetDateTimeFromString(reader["fm1_person_birth_date"].ToString());
                        rep1.fm1_person_birth_place = reader["fm1_person_birth_place"].ToString();

                        rep1.doc_type_2 = reader["doc_type"].ToString();
                        rep1.doc_num_2 = reader["doc_num"].ToString();
                        rep1.doc_series_2 = reader["doc_series"].ToString();
                        rep1.goverm_office_2 = reader["doc_goverm_office"].ToString();
                        rep1.doc_date_2 = GetDateTimeFromString(reader["doc_date"].ToString());
                        rep1.state_kaz_2 = reader["fm1_addrr_state"].ToString();
                        rep1.region_kaz_2 = reader["fm1_addrr_region"].ToString();
                        rep1.sity_kaz_2 = reader["fm1_addrr_city"].ToString();
                        rep1.street_2 = reader["fm1_addrr_street"].ToString();
                        rep1.house_num_2 = reader["fm1_addrr_house_num"].ToString();
                        rep1.flat_num_2 = reader["fm1_addrr_flat_num"].ToString();
                        rep1.post_index_2 = reader["fm1_addrr_post_index"].ToString();
                        rep1.fm1_memb_contact_phone_2 = reader["phone"].ToString();
                        rep1.fm1_memb_email_2 = reader["mail"].ToString();
                        rep1.state_kaz_3 = reader["state_3"].ToString();
                        rep1.region_kaz_3 = reader["region_3"].ToString();
                        rep1.sity_kaz_3 = reader["sity_3"].ToString();
                        rep1.street_3 = reader["street_3"].ToString();
                        rep1.house_num_3 = reader["house_num_3"].ToString();
                        rep1.flat_num_3 = reader["flat_num_3"].ToString();
                        rep1.post_index_3 = reader["post_index_3"].ToString();
                        rep1.fm1_memb_memb_add_info_3 = reader["add_info_3"].ToString();
                        mbm.Add(rep1);
                    }
                    reader.Close();
                }
                list.members = new List<fmembers>(mbm);

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }

        public ActionResult LoadFm1Xml(string id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{id}'";

            var fmi = "";
            query = $"SELECT t1.doc_guid, t1.attis_contract_doc_date, t2.*, t3.*, t4.*, t5.*, t6.*, t8.*," +
                    $"t9.fm1_addrr_region as region_kaz_2, t9.fm1_addrr_state as state_kaz_2, t9.fm1_addrr_city as sity_kaz_2," +
                    $"t9.fm1_addrr_street as street_2, t9.fm1_addrr_house_num as house_num_2, t9.fm1_addrr_flat_num as flat_num_2, " +
                    $"t9.fm1_addrr_post_index as post_index_2, t9.phone as fm1_memb_contact_phone_2, t9.mail as fm1_memb_email_2, " +
                    $"t10.fm1_addrr_region as region_kaz_3, t10.fm1_addrr_state as state_kaz_3, " +
                    $"t10.fm1_addrr_city as sity_kaz_3, t10.fm1_addrr_street as street_3, t10.fm1_addrr_house_num as house_num_3, " +
                    $"t10.fm1_addrr_flat_num as flat_num_3, t10.fm1_addrr_post_index as post_index_3, t10.addition as add_info_3, " +
                    $"t11.fm1_person_name as gn2, t11.fm1_person_secondname as ln2, t11.fm1_person_middle_name as mn2, t12.doc_type as doc_type_2, t12.doc_num as doc_num_2, " +
                    $"t12.doc_series as doc_series_2, t12.doc_goverm_office as goverm_office_2, t12.doc_date as doc_date_2 FROM attis_contract_docs t1 " +
                    $"LEFT JOIN fm1_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                    $"LEFT JOIN fm1_subject t3 ON t2.fm1_main_id = t3.fm1_main_id " +
                    $"LEFT JOIN fm1_addrr t4 ON t2.fm1_main_id = t4.fm1_main_id " +
                    $"LEFT JOIN fm1_addrr1 t9 ON t2.fm1_main_id = t9.fm1_main_id " +
                    $"LEFT JOIN fm1_addrr2 t10 ON t2.fm1_main_id = t10.fm1_main_id " +
                    $"LEFT JOIN fm1_docs t5 ON t2.fm1_main_id = t5.fm1_main_id " +
                    $"LEFT JOIN fm1_docs1 t12 ON t2.fm1_main_id = t12.fm1_main_id " +
                    $"LEFT JOIN fm1_operations t6 ON t2.fm1_main_id = t6.fm1_main_id " +
                    $"LEFT JOIN fm1_persons t8 ON t2.fm1_main_id = t8.fm1_main_id " +
                    $"LEFT JOIN fm1_persons1 t11 ON t2.fm1_main_id = t11.fm1_main_id WHERE t1.attis_contract_doc_id = '{id}';";
            var reader = Provider.RunQuery(query);
            //var list = new Fm1Model();
            var exp = new ExportData();
            exp.SignedData = new SignedData();
            exp.SignedData.Data = new Data();
            exp.SignedData.Data.Root = new Root();
            exp.SignedData.Data.Root.PersonalData = new PersonalData();
            exp.SignedData.Data.Root.PersonalData.AdditionalAcData = new AdditionalAcData();
            exp.SignedData.Data.Root.MessageInformation = new MessageInformation();
            exp.SignedData.Data.Root.References = new References();
            exp.SignedData.Data.Root.References.Reference = new Reference();
            exp.SignedData.Data.Root.Participants = new Participants();
            exp.SignedData.Data.Root.Participants.Participant = new List<Participant>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    exp.SignedData.Data.Root.PersonalData.FirstName = reader["fm1_subj_pers_name"].ToString(); 
                    exp.SignedData.Data.Root.PersonalData.SecondName = reader["fm1_subj_pers_second_name"].ToString();
                    exp.SignedData.Data.Root.PersonalData.MiddleName = reader["fm1_subj_pers_middle_name"].ToString();
                    exp.SignedData.Data.Root.PersonalData.JobName = reader["fm1_subj_position"].ToString();
                    exp.SignedData.Data.Root.PersonalData.Phone = reader["fm1_subj_phone"].ToString();
                    exp.SignedData.Data.Root.PersonalData.Email = reader["fm1_subj_email"].ToString();
                    exp.SignedData.Data.Root.PersonalData.OrganisationCode = reader["fm1_subj_code"].ToString();
                    exp.SignedData.Data.Root.PersonalData.OrganisationOPF = reader["fm1_subj_org_form"].ToString();
                    exp.SignedData.Data.Root.PersonalData.Organisation = reader["fm1_subj_name"].ToString();
                    exp.SignedData.Data.Root.PersonalData.OrganisationArea = reader["fm1_addrr_region"].ToString();
                    exp.SignedData.Data.Root.PersonalData.OrganisationCity = reader["fm1_addrr_city"].ToString();
                    //exp.SignedData.Data.Root.PersonalData.OrganisationDistrict
                    exp.SignedData.Data.Root.PersonalData.OrganisationStreet = reader["fm1_addrr_street"].ToString();
                    exp.SignedData.Data.Root.PersonalData.OrganisationHouse = reader["fm1_addrr_house_num"].ToString();
                    exp.SignedData.Data.Root.PersonalData.OrganisationOffice = reader["fm1_addrr_flat_num"].ToString();
                    exp.SignedData.Data.Root.PersonalData.OrganisationPostalIndex = reader["fm1_addrr_post_index"].ToString();
                    exp.SignedData.Data.Root.PersonalData.IINBIN = reader["fm1_subj_iin_bin"].ToString();
                    
                    fmi = reader["fm1_main_id"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.DocumentType = reader["fm1_main_form_kind"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.MessageNumber = reader["fm1_main_related_number"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.LastModifyDate = GetDateTimeFromString(reader["attis_contract_doc_date"].ToString());
                    exp.SignedData.Data.Root.MessageInformation.TransactionDate = GetDateTimeFromString(reader["fm1_main_related_date"].ToString());
                    exp.SignedData.Data.Root.MessageInformation.ViewOperationId = reader["fm1_oper_kind"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.EknpId = reader["fm1_oper_eknp"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.OperationNumber = reader["fm1_oper_number"].ToString();

                    exp.SignedData.Data.Root.MessageInformation.DocOperationDate = GetDateTimeFromString(reader["doc_date"].ToString());
                    exp.SignedData.Data.Root.MessageInformation.DocOperationNumber = reader["doc_num"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.CurrencyCodeId = reader["fm1_oper_curr_code"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.AmountCurrency = reader.GetFieldValueOrDefault<float>("fm1_oper_curr_sum");
                    exp.SignedData.Data.Root.MessageInformation.AmountCurrencyTenge = reader.GetFieldValueOrDefault<float>("fm1_oper_tenge_sum");
                    exp.SignedData.Data.Root.MessageInformation.OperationStatusId = reader["fm1_oper_basis"].ToString();
                    exp.SignedData.Data.Root.MessageInformation.ParticipantCount = reader["fm1_oper_members_quant"].ToString();
                    exp.SignedData.Data.Root.PersonalData.AdditionalAcData.FirstName = reader["fm1_subj_manager_name"].ToString();
                    exp.SignedData.Data.Root.PersonalData.AdditionalAcData.LastName = reader["fm1_subj_manager_second_name"].ToString();
                    exp.SignedData.Data.Root.PersonalData.AdditionalAcData.MiddleName = reader["fm1_subj_manager_patronymic"].ToString();
                    //exp.SignedData.Data.Root.PersonalData.AdditionalAcData.DocumentIdentity
                    exp.SignedData.Data.Root.PersonalData.AdditionalAcData.SeriesDocIdentity = reader["doc_series"].ToString();
                    exp.SignedData.Data.Root.PersonalData.AdditionalAcData.NumberDocIdentity = reader["fm1_oper_basis_doc_num"].ToString();
                    exp.SignedData.Data.Root.PersonalData.AdditionalAcData.DateIssuance = GetDateTimeFromString(reader["fm1_oper_basis_doc_date"].ToString());
                    //exp.SignedData.Data.Root.PersonalData.AdditionalAcData.DocumentIssued

                    exp.SignedData.Data.Root.References.Reference.ReferenceId = reader["fm1_main_form_state"].ToString();
                    exp.SignedData.Data.Root.References.Reference.ReferenceOperationNumber = reader["doc_series"].ToString();
                    exp.SignedData.Data.Root.References.Reference.ReferenceDocOperationDate = GetDateTimeFromString(reader["fm1_oper_basis_doc_date"].ToString());
                    exp.SignedData.Data.Root.References.Reference.ReferenceDocOperationNumber = reader["fm1_oper_basis_doc_num"].ToString();

                    //list.fm1_main_reason = reader["fm1_main_reason"].ToString();
                    //list.fm1_main_subreason = reader["fm1_main_subreason"].ToString();


                    //list.goverm_office = reader["doc_goverm_office"].ToString();

                    //list.fm1_oper_1code = reader["fm1_oper_1code"].ToString();
                    //list.fm1_oper_2code = reader["fm1_oper_2code"].ToString();
                    //list.fm1_oper_3code = reader["fm1_oper_3code"].ToString();
                    //list.fm1_oper_trouble_desc = reader["fm1_oper_trouble_desc"].ToString();
                    //list.fm1_oper_add_info = reader["fm1_oper_add_info"].ToString();
                }
                reader.Close();

                query = $"SELECT * FROM fm1_members WHERE fm1_main_id='{fmi}'";
                reader = Provider.RunQuery(query);
                //var mbm = new List<fmembers>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var par = new Participant();
                        par.CorrespondentBank = new CorrespondentBank();
                        par.CorrespondentBank.BankAddress = new BankAddress();
                        par.Founders = new Founders();
                        par.Founders.Founder = new Founder();
                        par.AdditionalPersonInfo = new AdditionalPersonInfo();
                        par.AdditionalPersonInfo.AdditionalInformationAc = new AdditionalInformationAc();
                        par.AdditionalPersonInfo.AdditionalInformationAc.FIO = new FIO();
                        par.MemberId = reader["fm1_member"].ToString();
                        par.ParticipantsView = reader["fm1_memb_type"].ToString();
                        par.ParticipantsType = reader["fm1_memb_subj_kind"].ToString();
                        par.IsClientSubject = reader["fm1_memb_is_subj"].ToString();
                        par.Residence = reader["fm1_memb_country"].ToString();
                        par.ForeignPerson = reader["fm1_memb_foreign"].ToString();

                        par.AdditionalPersonInfo.AdditionalInformationAc.URAddress = reader["fm1_memb_member_addrr"].ToString();
                        par.AdditionalPersonInfo.AdditionalInformationAc.ACAddress = reader["fm1_memb_member_fact_addrr"].ToString();
                        par.AdditionalPersonInfo.AdditionalInformationAc.FIO.FirstName = reader["fm1_member_name"].ToString();
                        par.AdditionalPersonInfo.AdditionalInformationAc.FIO.MiddleName = reader["fm1_member_middle_name"].ToString();
                        par.AdditionalPersonInfo.AdditionalInformationAc.FIO.SecondName = reader["fm1_member_secondname"].ToString();
                        par.AdditionalPersonInfo.AdditionalInformationAc.PlaceBirth = reader["fm1_member_birth_place"].ToString();
                        par.AdditionalPersonInfo.AdditionalInformationAc.DateBirth = GetDateTimeFromString(reader["fm1_member_birth_date"].ToString());
                        par.OKED = reader["fm1_memb_org_form"].ToString();
                        par.CorrespondentBank.AccountNumber = reader["fm1_memb_acc"].ToString();
                        par.CorrespondentBank.Name = reader["fm1_memb_bank_name"].ToString();
                        par.CorrespondentBank.Code = reader["fm1_memb_branch_code"].ToString();
                        par.CorrespondentBank.BankAddress.BankCity = reader["fm1_memb_bank_place"].ToString();
                        par.CorrespondentBank.BankAddress.BankCountry = reader["fm1_memb_bank_branch_place"].ToString();
                        //par.PhoneNumber
                        //par.Email
                        par.Founders.Founder.FirstName= reader["fm1_memb_founder_name"].ToString();
                        par.Founders.Founder.MiddleName = reader["fm1_memb_founder_middle_name"].ToString();
                        par.Founders.Founder.SecondName = reader["fm1_memb_founder_secondname"].ToString();
                        par.Founders.Founder.FounderType = reader["fm1_memb_founder_"].ToString();
                        par.Founders.Founder.FounderOPF= reader["fm1_memb_founder_org_form"].ToString();
                        
                        //list.fm1_memb_bank_branch = reader["fm1_memb_bank_branch"].ToString();
                        //list.fm1_memb_sdp = reader["fm1_memb_sdp"].ToString();
                        //list.fm1_memb_company_name = reader["fm1_memb_company_name"].ToString();
                        //list.fm1_memb_noname = reader["fm1_memb_noname"].ToString();
                        //list.fm1_memb_country_2 = reader["fm1_memb_country2"].ToString();
                        exp.SignedData.Data.Root.Participants.Participant.Add(par);
                    }
                    reader.Close();
                }
                //list.members = new List<fmembers>(mbm);

                XmlSerializer xsSubmit = new XmlSerializer(typeof(ExportData));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, exp);
                        xml = sww.ToString(); // Your XML
                    }
                }/*
                xml = xml.Replace("xmlns=\"dsp\"", "");
                xml = xml.Replace("xmlns=\"ddc\"", "");
                xml = xml.Replace("xmlns=\"cav\"", "");
                xml = xml.Replace("xmlns=\"urnx\"", "");
                */
                //return xml;
                //var file = Provider.GetFileByID(id);
                var contentType = "text/xml";
                var bytes = Encoding.UTF8.GetBytes(xml);
                var result = new FileContentResult(bytes, contentType);
                string fn = DateTime.Now.ToString();
                result.FileDownloadName = fn + ".xml";
                return result;
            }
            return null;
        }

        public string LoadEpi(string id, string language)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{id}'";
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            query = $"SELECT t1.doc_guid, t1.attis_contract_doc_date, t2.*, t3.*, t4.*, t5.*, " +
                            $"t6.ap_memb_organization_name as mb_on_1, t6.ap_memb_short_name as mb_sn_1, t6.ap_memb_bin as mb_bin_1, t6.ap_memb_itn as ap_memb_itn_1,t6.ap_member_postal_code as ap_member_postal_code_1, t6.ap_member_country_name as ap_member_country_name_1, t6.ap_member_region as ap_member_region_1, t6.ap_member_city as ap_member_city_1, t6.ap_member_street_house as ap_member_street_house_1, " +
                            $"t7.ap_memb_organization_name as ap_memb_organization_name_2, t7.ap_memb_short_name as ap_memb_short_name_2, t7.ap_memb_bin as ap_memb_bin_2, t7.ap_memb_itn as ap_memb_itn_2, t7.ap_member_postal_code as ap_member_postal_code_2, t7.ap_member_country_name as ap_member_country_name_2, t7.ap_member_region as ap_member_region_2, t7.ap_member_city as ap_member_city_2, t7.ap_member_street_house as ap_member_street_house_2, " +
                            $"t8.ap_memb_organization_name as ap_memb_organization_name_3, t8.ap_memb_short_name as ap_memb_short_name_3, t8.ap_memb_bin as ap_memb_bin_3, t8.ap_memb_itn as ap_memb_itn_3, t8.ap_member_postal_code as ap_member_postal_code_3, t8.ap_member_country_name as ap_member_country_name_3, t8.ap_member_region as ap_member_region_3, t8.ap_member_city as ap_member_city_3, t8.ap_member_street_house as ap_member_street_house_3, " +
                            $"t11.ap_memb_organization_name as ap_memb_organization_name_4, t11.ap_memb_short_name as ap_memb_short_name_4, t11.ap_memb_bin as ap_memb_bin_4, t11.ap_memb_itn as ap_memb_itn_4, t11.ap_member_postal_code as ap_member_postal_code_4, t11.ap_member_country_name as ap_member_country_name_4, t11.ap_member_region as ap_member_region_4, t11.ap_member_city as ap_member_city_4, t11.ap_member_street_house as ap_member_street_house_4, " +
                            $"t9.*, t10.*, t12.ap_person_reg_country_code as ap_person_reg_country_code_2, t12.ap_person_person_surname as ap_person_person_surname_2, t12.ap_person_person_post as ap_person_person_post_2, " +
                            $"t12.ap_person_person_name as ap_person_person_name_2, t12.ap_person_person_middle_name as ap_person_person_middle_name_2 FROM attis_contract_docs t1 " +
                            $"LEFT JOIN ap_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                            $"LEFT JOIN ap_goods t3 ON t2.ap_main_id = t3.ap_good_main_id " +
                            $"LEFT JOIN ap_send_rec t4 ON t2.ap_main_id = t4.ap_main_id " +
                            $"LEFT JOIN ap_members t5 ON t4.sender_id = t5.ap_memb_id " +
                            $"LEFT JOIN ap_members t6 ON t4.recipient_id = t6.ap_memb_id " +
                            $"LEFT JOIN ap_members t7 ON t4.fin_reg_id = t7.ap_memb_id " +
                            $"LEFT JOIN ap_members t8 ON t4.declarant_id = t8.ap_memb_id " +
                            $"LEFT JOIN ap_members t11 ON t4.driver_id = t11.ap_memb_id " +
                            $"LEFT JOIN ap_transportations t9 ON t2.ap_main_id = t9.ap_main_id " +
                            $"LEFT JOIN ap_persons t10 ON t4.decl_officer_id = t10.ap_person_id " +
                            $"LEFT JOIN ap_persons t12 ON t4.person1_id = t12.ap_person_id WHERE t1.attis_contract_doc_id = '{id}';";
            var reader = Provider.RunQuery(query);
            var list = new EpiModel();
            string apd = "0";
            if (reader != null)
            {
                while (reader.Read())
                {
                    apd = reader["ap_main_id"].ToString();

                    list.ap_memb_organization_name_1 = reader["ap_memb_organization_name"].ToString();
                    list.ap_memb_short_name_1 = reader["ap_memb_short_name"].ToString();
                    list.ap_memb_bin_1 = reader["ap_memb_bin"].ToString();
                    list.ap_memb_itn_1 = reader["ap_memb_itn"].ToString();
                    list.ap_member_postal_code_1 = reader["ap_member_postal_code"].ToString();
                    list.ap_member_country_name_1 = reader["ap_member_country_name"].ToString();
                    list.ap_member_region_1 = reader["ap_member_region"].ToString();
                    list.ap_member_city_1 = reader["ap_member_city"].ToString();
                    list.ap_member_street_house_1 = reader["ap_member_street_house"].ToString();

                    list.ap_memb_organization_name_2 = reader["mb_on_1"].ToString();
                    list.ap_memb_short_name_2 = reader["mb_sn_1"].ToString();
                    list.ap_memb_bin_2 = reader["mb_bin_1"].ToString();
                    list.ap_memb_itn_2 = reader["ap_memb_itn_1"].ToString();
                    list.ap_member_postal_code_2 = reader["ap_member_postal_code_1"].ToString();
                    list.ap_member_country_name_2 = reader["ap_member_country_name_1"].ToString();
                    list.ap_member_region_2 = reader["ap_member_region_1"].ToString();
                    list.ap_member_city_2 = reader["ap_member_city_1"].ToString();
                    list.ap_member_street_house_2 = reader["ap_member_street_house_1"].ToString();

                    list.ap_memb_organization_name_3 = reader["ap_memb_organization_name_2"].ToString();
                    list.ap_memb_short_name_3 = reader["ap_memb_short_name_2"].ToString();
                    list.ap_memb_bin_3 = reader["ap_memb_bin_2"].ToString();
                    list.ap_memb_itn_3 = reader["ap_memb_itn_2"].ToString();
                    list.ap_member_postal_code_3 = reader["ap_member_postal_code_2"].ToString();
                    list.ap_member_country_name_3 = reader["ap_member_country_name_2"].ToString();
                    list.ap_member_region_3 = reader["ap_member_region_2"].ToString();
                    list.ap_member_city_3 = reader["ap_member_city_2"].ToString();
                    list.ap_member_street_house_3 = reader["ap_member_street_house_2"].ToString();

                    list.ap_memb_organization_name_4 = reader["ap_memb_organization_name_3"].ToString();
                    list.ap_memb_short_name_4 = reader["ap_memb_short_name_3"].ToString();
                    list.ap_memb_bin_4 = reader["ap_memb_bin_3"].ToString();
                    list.ap_memb_itn_4 = reader["ap_memb_itn_3"].ToString();
                    list.ap_member_postal_code_4 = reader["ap_member_postal_code_3"].ToString();
                    list.ap_member_country_name_4 = reader["ap_member_country_name_3"].ToString();
                    list.ap_member_region_4 = reader["ap_member_region_3"].ToString();
                    list.ap_member_city_4 = reader["ap_member_city_3"].ToString();
                    list.ap_member_street_house_4 = reader["ap_member_street_house_3"].ToString();

                    list.ap_memb_organization_name_5 = reader["ap_memb_organization_name_4"].ToString();
                    list.ap_memb_short_name_5 = reader["ap_memb_short_name_4"].ToString();
                    list.ap_memb_bin_5 = reader["ap_memb_bin_4"].ToString();
                    list.ap_memb_itn_5 = reader["ap_memb_itn_4"].ToString();
                    list.ap_member_postal_code_5 = reader["ap_member_postal_code_4"].ToString();
                    list.ap_member_country_name_5 = reader["ap_member_country_name_4"].ToString();
                    list.ap_member_region_5 = reader["ap_member_region_4"].ToString();
                    list.ap_member_city_5 = reader["ap_member_city_4"].ToString();
                    list.ap_member_street_house_5 = reader["ap_member_street_house_4"].ToString();

                    list.ap_person_person_surname_1 = reader["ap_person_person_surname"].ToString();
                    list.ap_person_person_name_1 = reader["ap_person_person_name"].ToString();
                    list.ap_person_person_middle_name_1 = reader["ap_person_person_middle_name"].ToString();
                    list.ap_person_person_post_1 = reader["ap_person_person_post"].ToString();
                    list.ap_person_contact_phone_1 = reader["ap_person_contact_phone"].ToString();
                    list.ap_person_person_surname_2 = reader["ap_person_person_surname_2"].ToString();
                    list.ap_person_person_name_2 = reader["ap_person_person_name_2"].ToString();
                    list.ap_person_person_middle_name_2 = reader["ap_person_person_middle_name_2"].ToString();
                    list.ap_person_person_post_2 = reader["ap_person_person_post_2"].ToString();
                    list.ap_person_reg_country_code_2 = reader["ap_person_reg_country_code_2"].ToString();
                    list.ap_send_rec_identity_card_code = reader["ap_send_rec_identity_card_code"].ToString();
                    list.ap_send_rec_identity_card_series = reader["ap_send_rec_identity_card_series"].ToString();
                    list.ap_send_rec_identity_card_number = reader["ap_send_rec_identity_card_number"].ToString();
                    list.ap_send_rec_identity_card_date = GetDateTimeFromString(reader["ap_send_rec_identity_card_date"].ToString());
                    list.ap_send_rec_organization_name = reader["ap_send_rec_organization_name"].ToString();
                    list.ap_good_origin_country_name = reader["ap_good_origin_country_name"].ToString();
                    list.ap_good_specification_number = reader["ap_good_specification_number"].ToString();
                    list.ap_good_specification_list_number = reader["ap_good_specification_list_number"].ToString();
                    list.ap_good_total_goods_number = reader["ap_good_total_goods_number"].ToString();
                    list.ap_good_total_package_number = reader["ap_good_total_package_number"].ToString();
                    list.ap_good_total_sheet_number = reader["ap_good_total_sheet_number"].ToString();
                    list.ap_good_total_cust_cost = reader.GetFieldValueOrDefault<float>("ap_good_total_cust_cost");
                    list.ap_good_cust_cost_currency_code = reader["ap_good_cust_cost_currency_code"].ToString();
                    list.ap_main_reg_num = Regex.Replace(reader["ap_main_reg_num"].ToString(), @"\s+", "");
                    list.ap_main_country_code = reader["ap_main_country_code"].ToString();
                    list.ap_main_reg_date = GetDateTimeFromString(reader["ap_main_reg_date"].ToString());
                    list.ap_main_trans_kind_code = Regex.Replace(reader["ap_main_trans_kind_code"].ToString(), @"\s+", "");
                    list.ap_main_transit_direction_code = Regex.Replace(reader["ap_main_transit_direction_code"].ToString(), @"\s+", "");
                    list.ap_main_electronic_document_sign = reader["ap_main_electronic_document_sign"].ToString();
                    list.ap_main_declaration_kind = reader["ap_main_declaration_kind"].ToString();
                    list.ap_main_subsoil_sign = reader["ap_main_subsoil_sign"].ToString();
                    list.ap_main_seal_number = Regex.Replace(reader["ap_main_seal_number"].ToString(), @"\s+", ""); //Regex.Replace(list.UsageCode, @"\s+", "");
                    list.ap_main_seal_quantity = Regex.Replace(reader["ap_main_seal_quantity"].ToString(), @"\s+", "");
                    list.ap_main_language_cuesad = reader["ap_main_language_cuesad"].ToString();//"ru"
                    list.ap_main_recipient_country_code = Regex.Replace(reader["ap_main_recipient_country_code"].ToString(), @"\s+", "");
                    list.ap_main_movement_code = Regex.Replace(reader["ap_main_movement_code"].ToString(), @"\s+", "");
                    list.ap_main_decl_num = Regex.Replace(reader["ap_main_decl_num"].ToString(), @"\s+", "");
                    list.ap_main_decl_date = GetDateTimeFromString(reader["ap_main_decl_date"].ToString());
                    list.ap_main_carnet = reader.GetFieldValueOrDefault<int>("ap_main_carnet");
                    list.ap_transp_information_type_code = reader["ap_transp_information_type_code"].ToString();
                    list.ap_transp_customs_office = reader["ap_transp_customs_office"].ToString();
                    list.ap_transp_customs_country_code = reader["ap_transp_customs_country_code"].ToString();
                    list.ap_transp_container_indicator = reader["ap_transp_container_indicator"].ToString();
                    list.ap_transp_dispatch_country_code = reader["ap_transp_dispatch_country_code"].ToString();
                    list.ap_transp_destination_country_code = reader["ap_transp_destination_country_code"].ToString();
                    list.ap_transp_customs_office_inout = reader["ap_transp_customs_office_inout"].ToString();
                    list.ap_transp_customs_country_code_io = reader["ap_transp_customs_country_code_io"].ToString();
                    list.ap_transp_date_expected_arrival = GetDateTimeFromString(reader["ap_transp_date_expected_arrival"].ToString());
                    list.ap_transp_transport_mode_code = reader["ap_transp_transport_mode_code"].ToString();
                    list.ap_transp_transport_nationality_code = reader["ap_transp_transport_nationality_code"].ToString();
                    list.ap_transp_vin = reader["ap_transp_vin"].ToString();
                    list.ap_transp_transport_identifier = reader["ap_transp_transport_identifier"].ToString();
                    list.ap_transp_active_transport_identifier = reader["ap_transp_active_transport_identifier"].ToString();
                    list.ap_transp_date_expected_arrival_time = reader["ap_transp_date_expected_arrival_time"].ToString();
                }
                reader.Close();
                if (language == null) language = "ru";
                list.ap_member_country_3 = country(list.ap_member_country_name_3, language);
                list.ap_person_reg_country_2 = country(list.ap_person_reg_country_code_2, language);
                list.ap_good_origin_country = country(list.ap_good_origin_country_name, language);
                list.ap_main_recipient_country = country(list.ap_main_recipient_country_code, language);
                list.ap_transp_customs_country = country(list.ap_transp_customs_country_code, language);
                list.ap_transp_dispatch_country = country(list.ap_transp_dispatch_country_code, language);
                list.ap_transp_destination_country = country(list.ap_transp_destination_country_code, language);
                list.ap_transp_customs_country_io = country(list.ap_transp_customs_country_code_io, language);
                list.ap_transp_transport_nationality = country(list.ap_transp_transport_nationality_code, language);
                var query1 = $"SELECT * FROM ap_good_data WHERE ap_main_id = '{apd}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<EpGoods>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new EpGoods
                        {
                            ap_good_data_goods_numeric = reader1["ap_good_data_goods_numeric"].ToString(),
                        };
                        //rep1.GoodsCode = reader1["GoodsCode"].ToString();
                        rep1.ap_good_data_list_numeric = reader1["ap_good_data_list_numeric"].ToString();
                        rep1.ap_good_data_goods_description = reader1["ap_good_data_goods_description"].ToString();
                        rep1.ap_good_data_gross_weight_quantity = reader1.GetFieldValueOrDefault<float>("ap_good_data_gross_weight_quantity");
                        rep1.ap_good_data_net_weight_quantity = reader1.GetFieldValueOrDefault<float>("ap_good_data_net_weight_quantity");
                        rep1.ap_good_data_invoiced_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_invoiced_cost");
                        rep1.ap_good_data_customs_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_customs_cost");
                        rep1.ap_good_data_statistical_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_statistical_cost");
                        rep1.ap_good_data_goods_tnved_code = reader1["ap_good_data_goods_tnved_code"].ToString();
                        rep1.ap_good_data_origin_country_code = reader1["ap_good_data_origin_country_code"].ToString();
                        rep1.ap_good_data_delivery_terms_string_code = reader1["ap_good_data_delivery_terms_string_code"].ToString();
                        rep1.ap_good_data_quant = reader1.GetFieldValueOrDefault<float>("ap_good_data_quant");
                        rep1.ap_good_data_ext_measure = reader1["ap_good_data_ext_measure"].ToString();
                        rep1.ap_good_data_container_num = reader1["ap_good_data_container_num"].ToString();
                        rep1.ap_good_data_places = reader1.GetFieldValueOrDefault<float>("ap_good_data_places");
                        rep1.ap_good_data_places_name = reader1["ap_good_data_places_name"].ToString();
                        rep1.ap_good_data_packet = reader1.GetFieldValueOrDefault<int>("ap_good_data_packet");
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                list.product = new List<EpGoods>(product);
                foreach (var prd in list.product)
                {
                    prd.ap_good_data_origin_country = country(prd.ap_good_data_origin_country_code, language);
                }
                query = $"SELECT * FROM ap_prev_docs WHERE ap_main_id = '{apd}'";
                reader = Provider.RunQuery(query);
                var prdoc = new List<prev_doc>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new prev_doc
                        {
                            ap_prev_doc_preceding_document_number = reader["ap_prev_doc_preceding_document_number"].ToString(),
                        };
                        rep1.ap_prev_doc_preceding_document_date = reader.GetFieldValueOrDefault<DateTime>("ap_prev_doc_kind");
                        rep1.PrecedingDocumentName = reader["PrecedingDocumentName"].ToString();
                        rep1.ap_prev_doc_kind = reader["ap_prev_doc_kind"].ToString();
                        prdoc.Add(rep1);
                    }
                    reader.Close();
                }
                list.prev_docs = new List<prev_doc>(prdoc);

                query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{id}' and doc_widget_id ='epi xls'";
                reader = Provider.RunQuery(query1);
                var files = new List<Kfiles>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        rep.name = reader["img_file_name"].ToString();
                        files.Add(rep);
                    }
                    reader.Close();
                }
                list.files = new List<Kfiles>(files);

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }

        private LibModel country(string code, string lang)
        {
            var news = new LibModel();
            string ln = "country_name_ru";
            if (lang.Equals("en")) ln = "country_name_en";
            try
            {
                string query1 = $"SELECT * FROM countries WHERE country_2a_code = '{code}' LIMIT '{1}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = Provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.value = reader["country_2a_code"].ToString();
                        news.display_text = reader[ln].ToString();
                    }
                    reader.Close();
                }
            }
            catch (Exception) { return news; }
            return news;
        }

        public string GetExcel(string id)
        {
            var query = $"SELECT t1.doc_guid, t1.attis_contract_doc_date, t2.*, t3.*, t4.*, t5.*, " +
                $"t6.ap_memb_organization_name as mb_on_1, t6.ap_memb_short_name as mb_sn_1, t6.ap_memb_bin as mb_bin_1, t6.ap_memb_itn as ap_memb_itn_1,t6.ap_member_postal_code as ap_member_postal_code_1, t6.ap_member_country_name as ap_member_country_name_1, t6.ap_member_region as ap_member_region_1, t6.ap_member_city as ap_member_city_1, t6.ap_member_street_house as ap_member_street_house_1, " +
                $"t7.ap_memb_organization_name as ap_memb_organization_name_2, t7.ap_memb_short_name as ap_memb_short_name_2, t7.ap_memb_bin as ap_memb_bin_2, t7.ap_memb_itn as ap_memb_itn_2, t7.ap_member_postal_code as ap_member_postal_code_2, t7.ap_member_country_name as ap_member_country_name_2, t7.ap_member_region as ap_member_region_2, t7.ap_member_city as ap_member_city_2, t7.ap_member_street_house as ap_member_street_house_2, " +
                $"t8.ap_memb_organization_name as ap_memb_organization_name_3, t8.ap_memb_short_name as ap_memb_short_name_3, t8.ap_memb_bin as ap_memb_bin_3, t8.ap_memb_itn as ap_memb_itn_3, t8.ap_member_postal_code as ap_member_postal_code_3, t8.ap_member_country_name as ap_member_country_name_3, t8.ap_member_region as ap_member_region_3, t8.ap_member_city as ap_member_city_3, t8.ap_member_street_house as ap_member_street_house_3, " +
                $"t11.ap_memb_organization_name as ap_memb_organization_name_4, t11.ap_memb_short_name as ap_memb_short_name_4, t11.ap_memb_bin as ap_memb_bin_4, t11.ap_memb_itn as ap_memb_itn_4, t11.ap_member_postal_code as ap_member_postal_code_4, t11.ap_member_country_name as ap_member_country_name_4, t11.ap_member_region as ap_member_region_4, t11.ap_member_city as ap_member_city_4, t11.ap_member_street_house as ap_member_street_house_4, " +
                $"t9.*, t10.*, t12.ap_person_reg_country_code as ap_person_reg_country_code_2, t12.ap_person_person_surname as ap_person_person_surname_2, t12.ap_person_person_post as ap_person_person_post_2, " +
                $"t12.ap_person_person_name as ap_person_person_name_2, t12.ap_person_person_middle_name as ap_person_person_middle_name_2 FROM attis_contract_docs t1 " +
                $"LEFT JOIN ap_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                $"LEFT JOIN ap_goods t3 ON t2.ap_main_id = t3.ap_good_main_id " +
                $"LEFT JOIN ap_send_rec t4 ON t2.ap_main_id = t4.ap_main_id " +
                $"LEFT JOIN ap_members t5 ON t4.sender_id = t5.ap_memb_id " +
                $"LEFT JOIN ap_members t6 ON t4.recipient_id = t6.ap_memb_id " +
                $"LEFT JOIN ap_members t7 ON t4.fin_reg_id = t7.ap_memb_id " +
                $"LEFT JOIN ap_members t8 ON t4.declarant_id = t8.ap_memb_id " +
                $"LEFT JOIN ap_members t11 ON t4.driver_id = t11.ap_memb_id " +
                $"LEFT JOIN ap_transportations t9 ON t2.ap_main_id = t9.ap_main_id " +
                $"LEFT JOIN ap_persons t10 ON t4.decl_officer_id = t10.ap_person_id " +
                $"LEFT JOIN ap_persons t12 ON t4.person1_id = t12.ap_person_id WHERE t1.attis_contract_doc_id = '{id}';";
            var reader = Provider.RunQuery(query);
            var list = new EpiModel();
            string apd = "0";
            if (reader != null)
            {
                while (reader.Read())
                {
                    apd = reader["ap_main_id"].ToString();

                    list.ap_memb_organization_name_1 = reader["ap_memb_organization_name"].ToString();
                    list.ap_memb_short_name_1 = reader["ap_memb_short_name"].ToString();
                    list.ap_memb_bin_1 = reader["ap_memb_bin"].ToString();
                    list.ap_memb_itn_1 = reader["ap_memb_itn"].ToString();
                    list.ap_member_postal_code_1 = reader["ap_member_postal_code"].ToString();
                    list.ap_member_country_name_1 = reader["ap_member_country_name"].ToString();
                    list.ap_member_region_1 = reader["ap_member_region"].ToString();
                    list.ap_member_city_1 = reader["ap_member_city"].ToString();
                    list.ap_member_street_house_1 = reader["ap_member_street_house"].ToString();

                    list.ap_memb_organization_name_2 = reader["mb_on_1"].ToString();
                    list.ap_memb_short_name_2 = reader["mb_sn_1"].ToString();
                    list.ap_memb_bin_2 = reader["mb_bin_1"].ToString();
                    list.ap_memb_itn_2 = reader["ap_memb_itn_1"].ToString();
                    list.ap_member_postal_code_2 = reader["ap_member_postal_code_1"].ToString();
                    list.ap_member_country_name_2 = reader["ap_member_country_name_1"].ToString();
                    list.ap_member_region_2 = reader["ap_member_region_1"].ToString();
                    list.ap_member_city_2 = reader["ap_member_city_1"].ToString();
                    list.ap_member_street_house_2 = reader["ap_member_street_house_1"].ToString();

                    list.ap_memb_organization_name_3 = reader["ap_memb_organization_name_2"].ToString();
                    list.ap_memb_short_name_3 = reader["ap_memb_short_name_2"].ToString();
                    list.ap_memb_bin_3 = reader["ap_memb_bin_2"].ToString();
                    list.ap_memb_itn_3 = reader["ap_memb_itn_2"].ToString();
                    list.ap_member_postal_code_3 = reader["ap_member_postal_code_2"].ToString();
                    list.ap_member_country_name_3 = reader["ap_member_country_name_2"].ToString();
                    list.ap_member_region_3 = reader["ap_member_region_2"].ToString();
                    list.ap_member_city_3 = reader["ap_member_city_2"].ToString();
                    list.ap_member_street_house_3 = reader["ap_member_street_house_2"].ToString();

                    list.ap_memb_organization_name_4 = reader["ap_memb_organization_name_3"].ToString();
                    list.ap_memb_short_name_4 = reader["ap_memb_short_name_3"].ToString();
                    list.ap_memb_bin_4 = reader["ap_memb_bin_3"].ToString();
                    list.ap_memb_itn_4 = reader["ap_memb_itn_3"].ToString();
                    list.ap_member_postal_code_4 = reader["ap_member_postal_code_3"].ToString();
                    list.ap_member_country_name_4 = reader["ap_member_country_name_3"].ToString();
                    list.ap_member_region_4 = reader["ap_member_region_3"].ToString();
                    list.ap_member_city_4 = reader["ap_member_city_3"].ToString();
                    list.ap_member_street_house_4 = reader["ap_member_street_house_3"].ToString();

                    list.ap_memb_organization_name_5 = reader["ap_memb_organization_name_4"].ToString();
                    list.ap_memb_short_name_5 = reader["ap_memb_short_name_4"].ToString();
                    list.ap_memb_bin_5 = reader["ap_memb_bin_4"].ToString();
                    list.ap_memb_itn_5 = reader["ap_memb_itn_4"].ToString();
                    list.ap_member_postal_code_5 = reader["ap_member_postal_code_4"].ToString();
                    list.ap_member_country_name_5 = reader["ap_member_country_name_4"].ToString();
                    list.ap_member_region_5 = reader["ap_member_region_4"].ToString();
                    list.ap_member_city_5 = reader["ap_member_city_4"].ToString();
                    list.ap_member_street_house_5 = reader["ap_member_street_house_4"].ToString();

                    list.ap_person_person_surname_1 = reader["ap_person_person_surname"].ToString();
                    list.ap_person_person_name_1 = reader["ap_person_person_name"].ToString();
                    list.ap_person_person_middle_name_1 = reader["ap_person_person_middle_name"].ToString();
                    list.ap_person_person_post_1 = reader["ap_person_person_post"].ToString();
                    list.ap_person_contact_phone_1 = reader["ap_person_contact_phone"].ToString();
                    list.ap_person_person_surname_2 = reader["ap_person_person_surname_2"].ToString();
                    list.ap_person_person_name_2 = reader["ap_person_person_name_2"].ToString();
                    list.ap_person_person_middle_name_2 = reader["ap_person_person_middle_name_2"].ToString();
                    list.ap_person_person_post_2 = reader["ap_person_person_post_2"].ToString();
                    list.ap_person_reg_country_code_2 = reader["ap_person_reg_country_code_2"].ToString();
                    list.ap_send_rec_identity_card_code = reader["ap_send_rec_identity_card_code"].ToString();
                    list.ap_send_rec_identity_card_series = reader["ap_send_rec_identity_card_series"].ToString();
                    list.ap_send_rec_identity_card_number = reader["ap_send_rec_identity_card_number"].ToString();
                    list.ap_send_rec_identity_card_date = GetDateTimeFromString(reader["ap_send_rec_identity_card_date"].ToString());
                    list.ap_send_rec_organization_name = reader["ap_send_rec_organization_name"].ToString();
                    list.ap_good_origin_country_name = reader["ap_good_origin_country_name"].ToString();
                    list.ap_good_specification_number = reader["ap_good_specification_number"].ToString();
                    list.ap_good_specification_list_number = reader["ap_good_specification_list_number"].ToString();
                    list.ap_good_total_goods_number = reader["ap_good_total_goods_number"].ToString();
                    list.ap_good_total_package_number = reader["ap_good_total_package_number"].ToString();
                    list.ap_good_total_sheet_number = reader["ap_good_total_sheet_number"].ToString();
                    list.ap_good_total_cust_cost = reader.GetFieldValueOrDefault<float>("ap_good_total_cust_cost");
                    list.ap_good_cust_cost_currency_code = reader["ap_good_cust_cost_currency_code"].ToString();
                    list.ap_main_reg_num = Regex.Replace(reader["ap_main_reg_num"].ToString(), @"\s+", "");
                    list.ap_main_country_code = reader["ap_main_country_code"].ToString();
                    list.ap_main_reg_date = GetDateTimeFromString(reader["ap_main_reg_date"].ToString());
                    list.ap_main_trans_kind_code = Regex.Replace(reader["ap_main_trans_kind_code"].ToString(), @"\s+", "");
                    list.ap_main_transit_direction_code = Regex.Replace(reader["ap_main_transit_direction_code"].ToString(), @"\s+", "");
                    list.ap_main_electronic_document_sign = reader["ap_main_electronic_document_sign"].ToString();
                    list.ap_main_declaration_kind = reader["ap_main_declaration_kind"].ToString();
                    list.ap_main_subsoil_sign = reader["ap_main_subsoil_sign"].ToString();
                    list.ap_main_seal_number = Regex.Replace(reader["ap_main_seal_number"].ToString(), @"\s+", ""); //Regex.Replace(list.UsageCode, @"\s+", "");
                    list.ap_main_seal_quantity = Regex.Replace(reader["ap_main_seal_quantity"].ToString(), @"\s+", "");
                    list.ap_main_language_cuesad = reader["ap_main_language_cuesad"].ToString();//"ru"
                    list.ap_main_recipient_country_code = Regex.Replace(reader["ap_main_recipient_country_code"].ToString(), @"\s+", "");
                    list.ap_main_movement_code = Regex.Replace(reader["ap_main_movement_code"].ToString(), @"\s+", "");
                    list.ap_main_decl_num = Regex.Replace(reader["ap_main_decl_num"].ToString(), @"\s+", "");
                    list.ap_main_decl_date = GetDateTimeFromString(reader["ap_main_decl_date"].ToString());
                    list.ap_main_carnet = reader.GetFieldValueOrDefault<int>("ap_main_carnet");
                    list.ap_transp_information_type_code = reader["ap_transp_information_type_code"].ToString();
                    list.ap_transp_customs_office = reader["ap_transp_customs_office"].ToString();
                    list.ap_transp_customs_country_code = reader["ap_transp_customs_country_code"].ToString();
                    list.ap_transp_container_indicator = reader["ap_transp_container_indicator"].ToString();
                    list.ap_transp_dispatch_country_code = reader["ap_transp_dispatch_country_code"].ToString().TrimEnd();
                    list.ap_transp_destination_country_code = reader["ap_transp_destination_country_code"].ToString().TrimEnd();
                    list.ap_transp_customs_office_inout = reader["ap_transp_customs_office_inout"].ToString();
                    list.ap_transp_customs_country_code_io = reader["ap_transp_customs_country_code_io"].ToString();
                    list.ap_transp_date_expected_arrival = GetDateTimeFromString(reader["ap_transp_date_expected_arrival"].ToString());
                    list.ap_transp_transport_mode_code = reader["ap_transp_transport_mode_code"].ToString();
                    list.ap_transp_transport_nationality_code = reader["ap_transp_transport_nationality_code"].ToString();
                    list.ap_transp_vin = reader["ap_transp_vin"].ToString();
                    list.ap_transp_transport_identifier = reader["ap_transp_transport_identifier"].ToString();
                    list.ap_transp_active_transport_identifier = reader["ap_transp_active_transport_identifier"].ToString();
                    list.ap_transp_date_expected_arrival_time = reader["ap_transp_date_expected_arrival_time"].ToString();
                }
                reader.Close();
                var query1 = $"SELECT * FROM ap_good_data WHERE ap_main_id = '{apd}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<EpGoods>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new EpGoods
                        {
                            ap_good_data_goods_numeric = reader1["ap_good_data_goods_numeric"].ToString(),
                        };
                        //rep1.GoodsCode = reader1["GoodsCode"].ToString();
                        rep1.ap_good_data_list_numeric = reader1["ap_good_data_list_numeric"].ToString();
                        rep1.ap_good_data_goods_description = reader1["ap_good_data_goods_description"].ToString();
                        rep1.ap_good_data_gross_weight_quantity = reader1.GetFieldValueOrDefault<float>("ap_good_data_gross_weight_quantity");
                        rep1.ap_good_data_net_weight_quantity = reader1.GetFieldValueOrDefault<float>("ap_good_data_net_weight_quantity");
                        rep1.ap_good_data_invoiced_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_invoiced_cost");
                        rep1.ap_good_data_customs_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_customs_cost");
                        rep1.ap_good_data_statistical_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_statistical_cost");
                        rep1.ap_good_data_goods_tnved_code = reader1["ap_good_data_goods_tnved_code"].ToString();
                        rep1.ap_good_data_origin_country_code = reader1["ap_good_data_origin_country_code"].ToString();
                        rep1.ap_good_data_delivery_terms_string_code = reader1["ap_good_data_delivery_terms_string_code"].ToString();
                        rep1.ap_good_data_quant = reader1.GetFieldValueOrDefault<float>("ap_good_data_quant");
                        rep1.ap_good_data_ext_measure = reader1["ap_good_data_ext_measure"].ToString();
                        rep1.ap_good_data_container_num = reader1["ap_good_data_container_num"].ToString();
                        rep1.ap_good_data_places = reader1.GetFieldValueOrDefault<float>("ap_good_data_places");
                        rep1.ap_good_data_places_name = reader1["ap_good_data_places_name"].ToString();
                        rep1.ap_good_data_packet = reader1.GetFieldValueOrDefault<int>("ap_good_data_packet");
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                list.product = new List<EpGoods>(product);
                using (var package = new ExcelPackage())
                {
                    //string user = User.Identity.GetUserId();
                    int oid = Provider.RunScalar(query);
                    query = $"SELECT company_contacts FROM organizations WHERE org_name='{list.ap_memb_organization_name_1}'";
                    string cont = Provider.RunQueryStr(query);
                    query = $"SELECT company_contacts FROM organizations WHERE org_name='{list.ap_memb_organization_name_2}'";
                    string cont1 = Provider.RunQueryStr(query);
                    string full_add = country(list.ap_member_country_name_2, "ru").display_text + " " + list.ap_member_city_2 + " " + list.ap_member_street_house_2 + " " + list.ap_member_postal_code_2;
                    var worksheet = package.Workbook.Worksheets.Add("doc");
                    worksheet.Cells[1, 1].Value = list.ap_memb_organization_name_1 + " ADRECC: " + list.ap_member_country_name_1 + " " + list.ap_member_region_1 + " " + list.ap_member_city_1 + " " + list.ap_member_street_house_1 + " " + list.ap_member_postal_code_1 + " Tel: " + cont + " ИНВОЙС Номер Контракта: № " + list.ap_main_decl_num + " Номер Инвойса: " + list.ap_main_reg_num + " Дата Инвойса: " + list.ap_main_decl_date?.ToString("dd-mm-yyyy");
                    worksheet.Cells[1, 1].Style.WrapText = true;
                    worksheet.Row(1).Height = 30;
                    var border = OfficeOpenXml.Style.ExcelBorderStyle.Thick;
                    worksheet.Cells[2, 1].Value = "Отправитель: " + list.ap_memb_organization_name_1;
                    worksheet.Cells[3, 1].Value = "Адрес: " + list.ap_member_country_name_1 + " " + list.ap_member_region_1 + " " + list.ap_member_city_1 + " " + list.ap_member_street_house_1 + " " + list.ap_member_postal_code_1;
                    worksheet.Cells[4, 1].Value = "Tel: " + cont;
                    worksheet.Cells[5, 1].Value = "Получатель груза: " + list.ap_memb_organization_name_2;
                    worksheet.Cells[6, 1].Value = "Адрес: " + full_add;
                    worksheet.Cells[7, 1].Value = "Tel: " + cont1;

                    worksheet.Cells[8, 1].Value = "Декларант: " + list.ap_memb_organization_name_4;
                    worksheet.Cells[9, 1].Value = "Адрес декларанта: " + list.ap_member_country_name_4 + " " + list.ap_member_city_4 + " " + list.ap_member_street_house_4;
                    worksheet.Cells[10, 1].Value = "Количество грузовых мест: " + list.ap_good_total_package_number;
                    query = $"SELECT transp_kind_name FROM transport_kinds WHERE transp_kind_code ='{list.ap_transp_transport_mode_code}';";
                    string trsn = Provider.RunQueryStr(query);
                    worksheet.Cells[11, 1].Value = "Вид транспорта: " + trsn;
                    var disp = country(list.ap_transp_dispatch_country_code, "ru");
                    var dest = country(list.ap_transp_destination_country_code, "ru");
                    worksheet.Cells[12, 1].Value = "Страна отправления: " + disp.display_text;
                    worksheet.Cells[13, 1].Value = "Страна назначения: " + dest.display_text;
                    query = $"SELECT custom_name FROM custom_offices WHERE custom_code='{list.ap_transp_customs_office_inout}';";
                    string cstm = Provider.RunQueryStr(query);
                    worksheet.Cells[14, 1].Value = "Таможенный орган назначения: " + list.ap_transp_customs_office_inout + " " + cstm;

                    query = $"SELECT country_name_ru FROM countries WHERE country_2a_code='{list.ap_good_origin_country_name}'";
                    string oc = Provider.RunQueryStr(query);
                    worksheet.Cells[16, 1].Value = "Страна происхождения: " + oc;

                    worksheet.Cells[17, 1].Value = "Номер машины: " + list.ap_transp_transport_identifier;
                    worksheet.Row(18).Height = 60;
                    worksheet.Row(18).Style.WrapText = true;
                    worksheet.Cells[18, 1].Value = "№";

                    worksheet.Cells[18, 1].Style.Border.BorderAround(border);
                    worksheet.Cells[18, 2].Value = "Наименование";
                    worksheet.Cells[18, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                    worksheet.Cells[18, 2].Style.Border.BorderAround(border);
                    worksheet.Cells[18, 3].Value = "Код ТНВЭД/ HS Code";
                    worksheet.Cells[18, 3].Style.Border.BorderAround(border);
                    worksheet.Cells[18, 4].Value = "Кол-во (ШТ.)";
                    worksheet.Cells[18, 4].Style.Border.BorderAround(border);
                    worksheet.Cells[18, 5].Value = "Цена за (долл США)";
                    worksheet.Cells[18, 5].Style.Border.BorderAround(border);
                    worksheet.Cells[18, 6].Value = "Общая Сумма (долл США)";
                    worksheet.Cells[18, 6].Style.Border.BorderAround(border);
                    int ii = 19; float? dd = 0; string cd = "";
                    foreach (var prod in list.product)
                    {
                        worksheet.Cells[ii, 2].Value = prod.ap_good_data_goods_description;
                        worksheet.Cells[ii, 2].Style.Border.BorderAround(border);
                        worksheet.Cells[ii, 3].Value = prod.ap_good_data_goods_tnved_code;
                        worksheet.Cells[ii, 3].Style.Border.BorderAround(border);
                        worksheet.Cells[ii, 4].Value = prod.ap_good_data_quant;
                        worksheet.Cells[ii, 4].Style.Border.BorderAround(border);
                        worksheet.Cells[ii, 5].Value = prod.ap_good_data_invoiced_cost;
                        worksheet.Cells[ii, 5].Style.Border.BorderAround(border);
                        worksheet.Cells[ii, 6].Value = prod.ap_good_data_invoiced_cost * prod.ap_good_data_quant;
                        worksheet.Cells[ii, 6].Style.Border.BorderAround(border);
                        dd = dd + prod.ap_good_data_invoiced_cost * prod.ap_good_data_quant;
                        cd = prod.ap_good_data_delivery_terms_string_code;
                        ii++;
                    }
                    query = $"SELECT inkoterms_name_ru FROM inkoterms WHERE inkoterms_code='{cd}'";
                    string tr = Provider.RunQueryStr(query);
                    worksheet.Cells[15, 1].Value = "Условия поставки: " + tr;
                    worksheet.Cells[ii, 1].Value = "Итого";
                    worksheet.Cells[ii, 1, ii, 4].Merge = true; //Merge columns start and end range
                    worksheet.Cells[ii, 1, ii, 4].Style.Font.Bold = true; //Font should be bold
                    worksheet.Cells[ii, 1, ii, 4].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                    worksheet.Cells[ii, 1, ii, 4].Style.Border.BorderAround(border);
                    worksheet.Cells[ii, 6].Value = " " + dd;
                    worksheet.Cells[ii, 5, ii, 6].Style.Border.BorderAround(border);
                    worksheet.Column(1).Width = 80;
                    worksheet.Column(2).Width = 40;
                    worksheet.Column(1).Style.Font.Bold = true;

                    //worksheet.Cells["A1:C1,C3"].Style.Font.Bold = true;
                    /*range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.DarkBlue);
                    range.Style.Font.Color.SetColor(Color.White);
                     var FirstTableRange = wsMyWorkSheet.Cells[2, 2, 5, 11];
 FirstTableRange.Style.Border.BorderAround(ExcelBorderStyle.Thick);*/

                    var excelData = package.GetAsByteArray();
                    var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    var fileName = DateTime.Now.ToString("dd.MM.yy_HH-mm") + ".xlsx";

                    MemoryStream file = new MemoryStream(excelData);

                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = id,
                        Name = fileName,
                        Length = excelData.Length,
                        Type = contentType,
                        Date = DateTime.Now,
                        Image = file,
                        WidgetId = "inv xls"
                    };

                    Provider.SaveFile(imgFile);
                    return "ok";
                }
            }
            return "error";
        }

        public string GetInvExcel(string id)
        {
            var query = $"SELECT t1.doc_guid, t3.org_name, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" LEFT JOIN organizations t3 ON t2.\"InvoiceSeller\" = t3.org_code WHERE t1.attis_contract_doc_id = '{id}';";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader = Provider.RunQuery(query);
            //string contract_id = "";
            var list = new DocModel();
            if (reader != null)
            {
                while (reader.Read())
                {
                    //contract_id = reader["attis_contract_doc_contract"].ToString();
                    list.DocumentID = reader["DocumentID"].ToString();
                    list.DocGuid = reader["doc_guid"].ToString();
                    list.DocumentNumber = reader["DocumentNumber"].ToString();
                    list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                    list.CurrencyCode = reader["CurrencyCode"].ToString();
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.PlacesDescription = reader["PlacesDescription"].ToString();
                    list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                    list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                    list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                    list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                    list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                    list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                    list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                    list.InvoiceByer = reader["InvoiceByer"].ToString();
                    list.InvoiceSeller = reader["InvoiceSeller"].ToString();
                    list.SellerName = reader["org_name"].ToString();
                }
                reader.Close();
                var query1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<GoodsModel>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new GoodsModel
                        {
                            GoodsCode = reader1["GoodsCode"].ToString(),
                        };
                        rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                        rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                        rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                        rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                        rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                        rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                        rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                        rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                        rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                list.product = new List<GoodsModel>(product);
                using (var package = new ExcelPackage())
                {
                    //string user = User.Identity.GetUserId();
                    var worksheet = package.Workbook.Worksheets.Add("doc");
                    worksheet.Cells[1, 1].Value = "Наименование товара";
                    worksheet.Cells[1, 2].Value = "Код ТНВЭД";
                    worksheet.Cells[1, 3].Value = "Страна происхождения товара";
                    worksheet.Cells[1, 4].Value = "Фактурная стоимость";
                    worksheet.Cells[1, 5].Value = "Количество товара";
                    worksheet.Cells[1, 6].Value = "Единица измерения количества товара";
                    worksheet.Cells[1, 7].Value = "Количество физического объема 1";
                    worksheet.Cells[1, 8].Value = "Единица измерения физического объема 1";
                    worksheet.Cells[1, 9].Value = "Вес нетто";
                    worksheet.Cells[1, 10].Value = "Вес брутто";
                    worksheet.Cells[1, 11].Value = "Количество мест";
                    worksheet.Cells[1, 12].Value = "Количество индивид. упаковки";
                    worksheet.Cells[1, 13].Value = "Вид упаковки";
                    worksheet.Cells[1, 14].Value = "Производитель";
                    worksheet.Cells[1, 15].Value = "Марка товара";
                    worksheet.Cells[1, 16].Value = "Модель товара";
                    worksheet.Cells[1, 17].Value = "Серийные номера";
                    worksheet.Cells[1, 18].Value = "Товарный знак";
                    worksheet.Cells[1, 19].Value = "Размеры";
                    worksheet.Cells[1, 20].Value = "Дата выпуска";
                    worksheet.Cells[1, 21].Value = "Наименование сортимента для 4403";
                    worksheet.Cells[1, 22].Value = "Код документа 1";
                    worksheet.Cells[1, 23].Value = "Номер документа 1";
                    worksheet.Cells[1, 24].Value = "Дата документа 1";
                    worksheet.Cells[1, 25].Value = "Номер инвойса";
                    worksheet.Cells[1, 26].Value = "Дата инвойса";
                    //worksheet.Cells[1, 27].Value = "Сведения о поддонах и паллетах (вид упаковки)";
                    //worksheet.Cells[1, 28].Value = "Сведения о поддонах и паллетах (количество)";
                    //worksheet.Cells[1, 29].Value = "Сведения о поддонах и паллетах (описание)";
                    //worksheet.Cells[1, 30].Value = "Рег. № ОИС";
                    //worksheet.Cells[1, 31].Value = "Количество контейнеров";
                    //worksheet.Cells[1, 32].Value = "Тип контейнера";
                    //worksheet.Cells[1, 33].Value = "Номер контейнера";

                    int ii = 2; //float? dd = 0; string cd = "";
                    foreach (var prod in list.product)
                    { /*
                       * worksheet.Cells[ii, 1].Value = prod.ap_good_data_goods_description;
                        worksheet.Cells[ii, 2].Value = prod.ap_good_data_goods_description;
                        worksheet.Cells[ii, 3].Value = prod.ap_good_data_goods_tnved_code;
                        worksheet.Cells[ii, 4].Value = prod.ap_good_data_quant;
                        worksheet.Cells[ii, 5].Value = prod.ap_good_data_invoiced_cost;
                        worksheet.Cells[ii, 6].Value = prod.ap_good_data_invoiced_cost * prod.ap_good_data_quant;
                        dd = dd + prod.ap_good_data_invoiced_cost * prod.ap_good_data_quant;
                        cd = prod.ap_good_data_delivery_terms_string_code;*/
                        worksheet.Cells[ii, 1].Value = prod.GoodsDescription;
                        worksheet.Cells[ii, 2].Value = prod.GoodsCode;
                        var cont = country(prod.OriginCountryCode, "ru");
                        worksheet.Cells[ii, 3].Value = cont.display_text;
                        worksheet.Cells[ii, 4].Value = prod.Price;
                        worksheet.Cells[ii, 5].Value = prod.GoodsQuantity;
                        query1 = $"SELECT measure_name_ru FROM measures WHERE measure_code = '{prod.SupplementaryQualifierName}';";
                        worksheet.Cells[ii, 6].Value = Provider.RunQueryStr(query);// "Единица измерения количества товара";
                        worksheet.Cells[ii, 7].Value = list.PlacesQuantity;
                        worksheet.Cells[ii, 9].Value = prod.NetWeightQuantity;//"Вес нетто";
                        worksheet.Cells[ii, 10].Value = prod.GrossWeightQuantity;// "Вес брутто";
                        worksheet.Cells[ii, 13].Value = list.PlacesDescription;
                        //worksheet.Cells[ii, 14].Value = "Производитель";
                        worksheet.Cells[ii, 15].Value = prod.GoodMarking;// "Марка товара";
                        //worksheet.Cells[ii, 21].Value = "";
                        worksheet.Cells[ii, 22].Value = list.DocumentID;
                        worksheet.Cells[ii, 23].Value = list.DocumentNumber;
                        worksheet.Cells[ii, 24].Value = list.DocumentDate.ToString("dd.MM.yyyy");
                        worksheet.Cells[ii, 25].Value = list.DocumentNumber;//"Номер инвойса";
                        worksheet.Cells[ii, 26].Value = list.DocumentDate.ToString("dd.MM.yyyy");//"Дата инвойса";
                        ii++;
                    }
                    

                    var excelData = package.GetAsByteArray();
                    var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    var fileName = DateTime.Now.ToString("dd.MM.yy_HH-mm") + ".xlsx";

                    MemoryStream file = new MemoryStream(excelData);

                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = id,
                        Name = fileName,
                        Length = excelData.Length,
                        Type = contentType,
                        Date = DateTime.Now,
                        Image = file,
                        WidgetId = "inv xls"
                    };

                    Provider.SaveFile(imgFile);
                    return "ok";
                }
            }
            return "error";
        }

        public string LoadAwb(string id, string language)
        {
            var query = $"SELECT t1.doc_guid, t2.* FROM attis_contract_docs t1 LEFT JOIN awb t2 ON t1.attis_contract_doc_id = t2.ref_doc_id WHERE t1.attis_contract_doc_id = '{id}';";
            var reader = Provider.RunQuery(query);
            var list = new AwbModel();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.awb_id = reader["awb_id"].ToString();
                    list.awb_guid = reader["awb_guid"].ToString();
                    list.awb_imp_date = reader["awb_imp_date"].ToString();
                    list.awb_inp_time = reader["awb_inp_time"].ToString();
                    list.user_id = reader["user_id"].ToString();
                    list.airport_code = reader["1_airport_code"].ToString();
                    list.acompany_code = reader["1a_acompany_code"].ToString();
                    list.serial_num = reader["1b_serial_num"].ToString();
                    list.acomp_name_addr = reader["1c_acomp_name_addr"].ToString();
                    list.sender_name_addr = reader["2_sender_name_addr"].ToString();
                    list.recipient_name_addr = reader["4_recipient_name_addr"].ToString();
                    list.agent_name_addr = reader["6_agent_name_addr"].ToString();
                    list.agent_iata_code = reader["7_agent_iata_code"].ToString();
                    list.agent_acc = reader["8_agent_acc"].ToString();
                    list.dest_airport = reader["9_dest_airport"].ToString();
                    list.payment_data = reader["10_payment_data"].ToString();
                    list.first_carrier_dest_point = reader["11a_first_carrier_dest_point"].ToString();
                    list.fist_carrier_name = reader["11b_fist_carrier_name"].ToString();
                    list.second_carrier_dest_point = reader["11c_second_carrier_dest_point"].ToString();
                    list.second_carrier_name = reader["11d_second_carrier_name"].ToString();
                    list.third_carrier_dest_point = reader["11e_third_carrier_dest_point"].ToString();
                    list.third_carrier_name = reader["11f_third_carrier_name"].ToString();
                    list.curr_code = reader["12_curr_code"].ToString();
                    list.pr_o = reader["14a_pr_o"].ToString();
                    list.col_l = reader["14b_col_l"].ToString();
                    list.pr_d = reader["15a_pr_d"].ToString();
                    list.col_l1 = reader["15b_col_l"].ToString();
                    list.decl_value_carr = reader["16_decl_value_carr"].ToString();
                    list.decl_value_cust = reader["17_decl_value_cust"].ToString();
                    list.dest_airport1 = reader["18_dest_airport"].ToString();
                    list.flight_date = reader["19ab_flight_date"].ToString();
                    list.insuranse_amount = reader["20_insuranse_amount"].ToString();
                    list.handling_info = reader["21_handling_info"].ToString();
                    list.custom_status = reader["21a_custom_status"].ToString();
                    list.pieses_no = reader["22a_pieses_no"].ToString();
                    list.brutto = reader["22b_brutto"].ToString();
                    list.measure = reader["22c_measure"].ToString();
                    list.rate_class = reader["22d_rate_class"].ToString();
                    list.commodity_item = reader["22e_commodity_item"].ToString();
                    list.chargeable_weight = reader["22f_chargeable_weight"].ToString();
                    list.rate_charge = reader["22g_rate_charge"].ToString();
                    list.total = reader["22h_total"].ToString();
                    list.nature_quant = reader["22i_nature_quant"].ToString();
                    list.total_pieses = reader["22j_total_pieses"].ToString();
                    list.total_sum_rev = reader["22l_total_sum_rev"].ToString();
                    list.total_brutto = reader["22k_total_brutto"].ToString();
                    list.other_charges = reader["23_other_charges"].ToString();
                    list.weight_charge_sum = reader["24_weight_charge_sum"].ToString();
                    list.valuation_sum = reader["25_valuation_sum"].ToString();
                    list.tax_sum = reader["26_tax_sum"].ToString();
                    list.total_other_charges = reader["27_total_other_charges"].ToString();
                    list.carrier_total_other_charges = reader["28_carrier_total_other_charges"].ToString();
                    list.total_prepaid_collect = reader["30_total_prepaid_collect"].ToString();
                    list.awb_create_date = reader["32a_awb_create_date"].ToString();
                    list.awb_place = reader["32b_awb_place"].ToString();
                    list.signature = reader["32c_signature"].ToString();
                    /*
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];;*/
                }
                reader.Close();
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }


        public string LoadInsurance(string doc_id)
        {
            var query = $"SELECT * FROM cargo_insurance_form WHERE doc_id = '{doc_id}';";
            var reader = Provider.RunQuery(query);
            var list = new cargo_insurance();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.doc_id = reader["doc_id"].ToString();
                    list.policy_holder_name = reader["policy_holder_name"].ToString();
                    list.represented_by = reader["represented_by"].ToString();
                    list.legal_address = reader["legal_address"].ToString();
                    list.actual_address = reader["actual_address"].ToString();
                    list.is_public_person = reader.GetFieldValueOrDefault<int>("is_public_person");
                    list.insured_details = reader["insured_details"].ToString();
                    list.insured_activity = reader["insured_activity"].ToString();
                    list.beneficiary = reader["beneficiary"].ToString();
                    list.beneficiary_details = reader["beneficiary_details"].ToString();
                    list.shipping_name = reader["shipping_name"].ToString();
                    list.package_info = reader["package_info"].ToString();
                    list.cargo_cost = reader.GetFieldValueOrDefault<float>("cargo_cost");
                    list.package_count = reader.GetFieldValueOrDefault<int>("package_count");
                    list.total_cost = reader.GetFieldValueOrDefault<float>("total_cost");
                    list.release_date = GetDateTimeFromString(reader["release_date"].ToString());
                    list.containerization = reader.GetFieldValueOrDefault<int>("containerization");
                    list.cargo_placing = reader["cargo_placing"].ToString();
                    list.route = reader["route"].ToString();
                    list.security_measures = reader["security_measures"].ToString();
                    list.transport_means = reader["transport_means"].ToString();
                    list.transfer_points = reader["transfer_points"].ToString();
                    list.shipping_details = reader["shipping_details"].ToString();
                    list.risk_a = reader.GetFieldValueOrDefault<int>("risk_a");
                    list.risk_b1 = reader.GetFieldValueOrDefault<int>("risk_b1");
                    list.risk_b2 = reader.GetFieldValueOrDefault<int>("risk_b2");
                    list.additional_conditions = reader["additional_conditions"].ToString();
                    list.max_value_a = reader.GetFieldValueOrDefault<float>("max_value_a");
                    list.max_value_b = reader.GetFieldValueOrDefault<float>("max_value_b");
                    list.max_value_c = reader.GetFieldValueOrDefault<float>("max_value_c");
                    list.max_value_d = reader.GetFieldValueOrDefault<float>("max_value_d");
                    list.max_value_e = reader.GetFieldValueOrDefault<float>("max_value_e");
                    list.max_value_f = reader.GetFieldValueOrDefault<float>("max_value_f");
                    list.insured_transport = reader.GetFieldValueOrDefault<int>("insured_transport");
                    list.insured_transport_amount = reader.GetFieldValueOrDefault<float>("insured_transport_amount");
                    list.franchise = reader["franchise"].ToString();
                    list.shipment_date = GetDateTimeFromString(reader["shipment_date"].ToString());
                    list.shipment_duration = reader["shipment_duration"].ToString();
                    list.insurance_stats = reader["insurance_stats"].ToString();
                    list.relevant_info = reader["relevant_info"].ToString();
                    list.other = reader["other"].ToString();
                    /*
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];;*/
                }
                reader.Close();
                //query = $"SELECT attis_contract_doc_contract FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}'";
                //var id = Provider.RunQueryStr(query);
                var query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{doc_id}' and doc_widget_id ='insurance'";
                reader = Provider.RunQuery(query1);
                var files = new List<Kfiles>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        rep.name = reader["img_file_name"].ToString();
                        files.Add(rep);
                    }
                    reader.Close();
                }
                list.files = new List<Kfiles>(files);
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }

        [HttpPost]
        public JsonResult UploadFile(string docid, string type)
        {
            var r = new List<ImageFile>();

            foreach (string file in Request.Files)
            {
                var hpf = Request.Files[file];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = docid,
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = type
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }

            return Json(new { r[0].ID, r[0].Name });
        }

        public string LoadLiabilityInsurance(string doc_id)
        {
            var query = $"SELECT * FROM liability_insurance WHERE doc_id = '{doc_id}';";
            var reader = Provider.RunQuery(query);
            var list = new liability_insurance();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.doc_id = reader["doc_id"].ToString();
                    list.policy_holder_name = reader["policy_holder_name"].ToString();
                    list.policy_holder_address = reader["policy_holder_address"].ToString();
                    list.policy_holder_phone = reader["policy_holder_phone"].ToString();
                    list.policy_holder_email = reader["policy_holder_email"].ToString();
                    list.policy_holder_bank = reader["policy_holder_bank"].ToString();
                    list.policy_holder_bin = reader["policy_holder_bin"].ToString();
                    list.policy_holder_bik = reader["policy_holder_bik"].ToString();
                    list.is_resident = reader.GetFieldValueOrDefault<int>("is_resident");
                    list.license_no = reader["license_no"].ToString();
                    list.economy_sector = reader["economy_sector"].ToString();
                    list.activity_type = reader["activity_type"].ToString();
                    list.object_teritory = reader["object_teritory"].ToString();
                    list.insured_details = reader["insured_details"].ToString();
                    list.life_insured_sum = reader.GetFieldValueOrDefault<float>("life_insured_sum");
                    list.property_insured_sum = reader.GetFieldValueOrDefault<float>("property_insured_sum");
                    list.cargo_insured_sum = reader.GetFieldValueOrDefault<float>("cargo_insured_sum");
                    list.total_insured_sum = reader.GetFieldValueOrDefault<float>("total_insured_sum");
                    list.insurance_term = reader["insurance_term"].ToString();
                    list.insurance_teritory = reader["insurance_teritory"].ToString();
                    list.transport_type = reader["transport_type"].ToString();
                    list.transport_model = reader["transport_model"].ToString();
                    list.transport_name = reader["transport_name"].ToString();
                    list.transport_reg_number = reader["transport_reg_number"].ToString();
                    list.transport_body_number = reader["transport_body_number"].ToString();
                    list.transport_release_date = reader["transport_release_date"].ToString(); 
                    list.vehicles_number = reader.GetFieldValueOrDefault<int>("vehicles_number");
                    list.previous_insurance_info = reader["previous_insurance_info"].ToString();
                    list.valid_contracts_info = reader["valid_contracts_info"].ToString();
                    list.insurer_name = reader["insurer_name"].ToString();
                    list.insurer_address = reader["insurer_address"].ToString();
                    list.insurer_phone = reader["insurer_phone"].ToString();
                    list.insurance_date = GetDateTimeFromString(reader["insurance_date"].ToString());                                       
                }
                reader.Close();
                query = $"SELECT attis_contract_doc_contract FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}'";
                var id = Provider.RunQueryStr(query);
                var query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{id}' and doc_widget_id ='liability-insurance'";
                reader = Provider.RunQuery(query1);
                var files = new List<Kfiles>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Kfiles
                        {
                            id = reader["id"].ToString(), 
                        };
                        rep.name = reader["img_file_name"].ToString();
                        files.Add(rep);
                    }
                    reader.Close();
                }
                list.files = new List<Kfiles>(files);
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }
        public ActionResult GetFile(int id)
        {
            var file = Provider.GetFileByID(id);
            Response.AppendHeader("content-disposition", "inline; filename=" + file.Name);
            Response.AppendHeader("Content-Length", file.Image.Length.ToString());
            return new FileStreamResult(file.Image, file.ContentType);
        }

        public int GetFirmId(string bin)
        {
            string query = $"SELECT org_id FROM organizations WHERE org_code='{bin}'";
            int res = 0;
            res = Provider.RunScalar(query);
            return res;
        }

        [HttpPost]
        public string Create(DocModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "invoice"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, doc_guid, file_type, category, attis_contract_doc_date)" +
                    $" VALUES ('{sell.DocumentNumber}', '{response}', '1', '{rid}', '{type}', 'finance', now() ) RETURNING \"attis_contract_doc_id\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                var docid = Provider.RunScalar(query);
                string aa = "2020.01.01";
                if (sell.DocumentDate != null)
                    aa = sell.DocumentDate.ToString("yyyy.MM.dd");

                query = $"INSERT INTO \"Invoice\" (user_id, \"RefDocumentID\", \"DocumentNumber\", \"DocumentDate\", \"CurrencyCode\", \"PlacesQuantity\", " +
                    $"\"PlacesDescription\", \"GrossWeightQuantity\", \"NetWeightQuantity\", \"GCost\", \"Discount\", \"TransportCharges\", " +
                    $"\"InsuranceCharges\", \"OtherCharges\", \"TotalCost\", \"PaymentPeriod\", \"InvoiceByer\", \"InvoiceSeller\")" +
                    $" VALUES ('{user}', '{docid}', '{sell.DocumentNumber}', '{aa}', '{sell.CurrencyCode}', '{sell.PlacesQuantity}'," +
                    $" '{sell.PlacesDescription}', '{sell.GrossWeightQuantity}', '{sell.NetWeightQuantity}', '{sell.GCost}', '{sell.Discount}', '{sell.TransportCharges}'," +
                    $" '{sell.InsuranceCharges}', '{sell.OtherCharges}', '{sell.TotalCost}', '{sell.PaymentPeriod}', '{sell.InvoiceByer}', '{sell.InvoiceSeller}') RETURNING \"DocumentID\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                                                                                                                                                                                               // registration missed subj_id in organisations
                var invc = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewInvoice}', '{LogDocument.NewInvoice}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                
                if (sell.product != null && invc > 0)
                    foreach (var ln in sell.product)
                    {
                        float tc = ln.Price + ln.ServiceCharges + ln.TransportCharges + ln.OtherCharges;
                        query = $"INSERT INTO \"InvoiceGoods\" (\"GoodsCode\", \"OriginCountryCode\", \"SupplementaryQualifierName\", \"GoodMarking\", \"GoodsDescription\"," +
                                    $" \"GoodsQuantity\", \"GrossWeightQuantity\", \"NetWeightQuantity\", \"Price\", \"Discount\", \"DiscountPercentage\", \"ServiceCharges\"," +
                                    $" \"TransportCharges\", \"OtherCharges\", \"TotalCost\", \"InvoiceId\") " +
                                $"VALUES('{ln.GoodsCode}', '{ln.OriginCountryCode}', '{ln.SupplementaryQualifierName}', '{ln.GoodMarking}', '{ln.GoodsDescription}'," +
                                $" '{ln.GoodsQuantity}', '{ln.GrossWeightQuantity}', '{ln.NetWeightQuantity}', '{ln.Price}', '{ln.Discount}', '{ln.DiscountPercentage}'," +
                                $" '{ln.ServiceCharges}', '{ln.TransportCharges}', '{ln.OtherCharges}', '{tc}', '{invc}');";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewInvoiceGoods}', '{LogDocument.NewInvoiceGoods}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (invc > 0)
                {
                    log.Info("new invoice " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewInvoice}', '{LogDocument.NewInvoice}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "{\"status\":\"ok\", \"doc_id\":" + docid + "}";
                }
                else return "error " + invc;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewInvoice}', '{LogDocument.NewInvoice}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        [HttpPost]
        public string CreateCMR(CMRModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "cmr"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, doc_guid, file_type, category, attis_contract_doc_date)" +
                    $" VALUES ('{sell.cmr_number}', '{response}', '3', '{rid}', '{type}', 'transport', now() ) RETURNING \"attis_contract_doc_id\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                var docid = Provider.RunScalar(query);
                string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd");
                if (sell.PrDocumentDate != null)
                    aa = sell.PrDocumentDate.ToString("yyyy.MM.dd");
                if (sell.cmr_date != null)
                    bb = sell.cmr_date.ToString("yyyy.MM.dd");
                if (sell.TakingCargoDate != null)
                    cc = sell.TakingCargoDate.ToString("yyyy.MM.dd");
                query = $"INSERT INTO \"CMR\" (\"RefDocumentID\", cmr_number, cmr_date, \"CarrierNotice\", cmr_sender_id, cmr_recipient_id, cmr_track, cmr_trailer, " +
                    $"cmr_courier, cmr_courier_next, delivery_place, delivery_terms, terms_desc, custom_code, courier_notes, cmr_track_reg_country, \"GoodsCost\")" +
                    $" VALUES ('{docid}', '{sell.cmr_number}', '{bb}', '{sell.CurrencyCode}', '{sell.cmr_sender}', '{sell.cmr_recipient}', '{sell.cmr_track}'," +
                    $" '{sell.cmr_trailer}', '{sell.cmr_courier}', '{sell.cmr_courier_next}', '{sell.DeliveryPlace}', '{sell.DeliveryTermsStringCode}', " +
                    $"'{sell.TermsDescription}', '{sell.custom_code}', '{sell.courier_notes}', '{sell.cmr_track_reg_country}', " +
                    $"{sell.GoodsCost.GetValueOrDefault()}) RETURNING cmr_id;"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                                                                                                                   // registration missed subj_id in organisations
                var cmri = Provider.RunScalar(query); // '{sell.attis_contract_contragent}',
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewCMR}', '{LogDocument.NewCMR}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"INSERT INTO \"TakingCargoPlace\" (cmr_id, \"PostalCode\", \"CountryCode\", \"City\", \"StreetHouse\", \"TakingCargoDate\", warehouse)" +
                    $" VALUES ('{cmri}', '{sell.PostalCode}', '{sell.CountryCode}', '{sell.City}', '{sell.StreetHouse}', '{cc}', '{sell.WarehouseName}');";
                var adri = Provider.RunNonQuery(query); //adr
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewCMRCargo}', '{LogDocument.NewCMRCargo}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (sell.product != null && cmri > 0)
                    foreach (var ln in sell.product)
                    {
                        query = $"INSERT INTO \"CMRGoods\" (\"GoodsNomenclatureCode\", \"VolumeQuantity\", \"GoodsMarking\", \"GoodsDescription\"," +
                            $" \"GoodsQuantity\", \"GrossWeightQuantity\", \"CmrId\", \"GoodsPrice\") " +
                        $"VALUES('{ln.GoodsNomenclatureCode}', '{ln.VolumeQuantity}', '{ln.GoodMarking}', '{ln.GoodsDescription}'," +
                        $" '{ln.GoodsQuantity}', '{ln.GrossWeightQuantity}', '{cmri}', {ln.GoodsPrice.GetValueOrDefault()}) RETURNING cmr_good_id;";
                        var goodId = Provider.RunScalar(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewCMRGoods}', '{LogDocument.NewCMRGoods}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        if (ln.places != null && goodId > 0)
                        {
                            foreach (var pl in ln.places)
                            {
                                query = $"INSERT INTO places_list (packing_code, packing_quantity, packing_description, package_part_quantity, cmr_id, good_id)" +
                                $"VALUES('{pl.PackagingTypeCode}', '{pl.PlacesCount}', '{pl.Description}', '{pl.PlacesCount}', '{cmri}', '{goodId}');";
                                Provider.RunNonQuery(query);
                            }
                        }
                    }
                if (cmri > 0)
                {
                    log.Info("new cmr " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewCMR}', '{LogDocument.NewCMR}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + cmri;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewCMR}', '{LogDocument.NewCMR}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error ";
            }

        }

        [HttpPost]
        public string CreateFm1(Fm1Model sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "fm1"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, doc_guid, file_type, category, attis_contract_doc_date)" +
                    $" VALUES ('{sell.doc_num}', '{response}', '4', '{rid}', '{type}', 'finance', now() ) RETURNING \"attis_contract_doc_id\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                var docid = Provider.RunScalar(query);

                string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"),
                    dd = DateTime.Now.ToString("yyyy.MM.dd");
                if (sell.fm1_main_date != null)
                    aa = sell.fm1_main_date.ToString("yyyy.MM.dd");
                if (sell.fm1_oper_basis_doc_date != null)
                    bb = sell.fm1_oper_basis_doc_date.ToString("yyyy.MM.dd");
                
                if (sell.fm1_person_birth_date != null)
                    dd = sell.doc_date.ToString("yyyy.MM.dd");
                
                query = $"INSERT INTO fm1_main (ref_doc_id, fm1_main_number, fm1_main_related_number, fm1_main_related_date, " +
                    $"fm1_main_form_kind, fm1_main_form_state, fm1_main_reason, fm1_main_subreason)" +
                        $" VALUES ('{docid}', '{sell.fm1_main_number}', '{sell.fm1_main_related_number}', '{aa}', " +
                        $"'{sell.fm1_main_doc_kind}', '{sell.fm1_main_form_state}', '{sell.fm1_main_reason}', '{sell.fm1_main_subreason}') RETURNING fm1_main_id;";
                var fmi = Provider.RunScalar(query); //main
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"INSERT INTO fm1_subject (fm1_main_id, fm1_subj_code, fm1_subj_org_form, fm1_subj_name, fm1_subj_pers_second_name, " +
                    $"fm1_subj_pers_name, fm1_subj_pers_middle_name, fm1_subj_rnn, fm1_subj_iin_bin, fm1_subj_manager_second_name, " +
                    $"fm1_subj_manager_name, fm1_subj_manager_patronymic, fm1_subj_position, fm1_subj_phone, fm1_subj_email)" +
                        $" VALUES ('{fmi}', '{sell.fm1_subj_code}', '{sell.fm1_subj_org_form}', '{sell.fm1_subj_name}', '{sell.fm1_subj_pers_second_name}', " +
                        $"'{sell.fm1_subj_pers_name}', '{sell.fm1_subj_pers_middle_name}', '{sell.fm1_subj_rnn}', '{sell.fm1_subj_iin_bin}', '{sell.fm1_subj_manager_second_name}'," +
                        $" '{sell.fm1_subj_manager_name}', '{sell.fm1_subj_manager_patronymic}', '{sell.fm1_subj_position}','{sell.fm1_subj_phone}', '{sell.fm1_subj_email}') RETURNING fm1_subj_id;";
                var subi = Provider.RunScalar(query); //subj
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"INSERT INTO fm1_addrr (fm1_main_id, fm1_addrr_state, fm1_addrr_region, fm1_addrr_city, fm1_addrr_street, fm1_addrr_house_num, fm1_addrr_flat_num, fm1_addrr_post_index)" +
                    $" VALUES ('{fmi}', '{sell.state_kaz_1}', '{sell.region_kaz_1}', '{sell.sity_kaz_1}', '{sell.street_1}', '{sell.house_num_1}', '{sell.flat_num_1}', '{sell.post_index_1}') RETURNING fm1_addrr_id;";
                var adri = Provider.RunScalar(query); //adr
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
               
                query = $"INSERT INTO fm1_docs (fm1_main_id, doc_num, doc_series, doc_goverm_office, doc_date)" +
                    $" VALUES ('{fmi}', '{sell.doc_num}', '{sell.doc_series}', '{sell.goverm_office}', '{dd}') RETURNING fm1_doc_id;"; ///*, '{sell.doc_type}'
                var doci = Provider.RunScalar(query); //doc
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                
                query = $"INSERT INTO fm1_operations (fm1_main_id, fm1_oper_number, fm1_oper_kind, fm1_oper_eknp, fm1_oper_members_quant, " +
                    $"fm1_oper_curr_code, fm1_oper_curr_sum, fm1_oper_tenge_sum, fm1_oper_basis, fm1_oper_basis_doc_date, fm1_oper_basis_doc_num, " +
                    $"fm1_oper_1code, fm1_oper_2code, fm1_oper_3code, fm1_oper_trouble_desc, fm1_oper_add_info)" +
                    $" VALUES ('{fmi}', '{sell.fm1_oper_number}', '{sell.fm1_oper_code_type}', '{sell.fm1_oper_eknp}', '{sell.fm1_oper_members_quant}', " +
                    $"'{sell.fm1_oper_currency}', '{sell.fm1_oper_curr_code}', '{sell.fm1_oper_tenge_sum}', '{sell.fm1_oper_basis}', '{bb}', '{sell.fm1_oper_basis_doc_num}', " +
                    $"'{sell.fm1_oper_1code}','{sell.fm1_oper_2code}','{sell.fm1_oper_3code}','{sell.fm1_oper_trouble_desc}', '{sell.fm1_oper_add_info}') RETURNING fm1_operation_id;";
                var opi = Provider.RunScalar(query); //oper
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }

                if (sell.members != null)
                    foreach (var sl in sell.members)
                    {
                        string bd = DateTime.Now.ToString("yyyy.MM.dd");
                        if (sl.fm1_member_birth_date != null)
                            bd = sell.fm1_main_date.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO fm1_members (fm1_main_id, fm1_member, fm1_memb_is_subj, fm1_memb_subj_kind, fm1_memb_country, fm1_memb_type, " +
                        $"fm1_memb_foreign, fm1_memb_bank_branch_place, fm1_memb_bank_branch, fm1_memb_sdp, fm1_memb_branch_code, fm1_memb_acc, " +
                        $"fm1_memb_bank_place, fm1_memb_bank_name, fm1_memb_org_form, fm1_memb_company_name, fm1_memb_noname, fm1_memb_founder_org_form, " +
                        $"fm1_memb_founder_secondname, fm1_memb_founder_name, fm1_memb_founder_, fm1_memb_founder_middle_name, fm1_memb_memb_add_info, " +
                        $"fm1_memb_country2, fm1_memb_member_addrr, fm1_memb_member_fact_addrr, fm1_member_name, fm1_member_middle_name, fm1_member_secondname," +
                        $"fm1_member_birth_date, fm1_member_birth_place)" +
                        $" VALUES ('{fmi}', '{sl.fm1_member}', '{sl.fm1_memb_is_subj}', '{sl.fm1_memb_subj_kind}', '{sl.fm1_memb_country}', '{sl.fm1_memb_type}'," +
                        $" '{sl.fm1_memb_foreign}', '{sl.fm1_memb_bank_branch_place}', '{sl.fm1_memb_bank_branch}', '{sl.fm1_memb_sdp}', '{sl.fm1_memb_branch_code}', '{sl.fm1_memb_acc}'," +
                        $" '{sl.fm1_memb_bank_place}', '{sl.fm1_memb_bank_name}', '{sl.fm1_memb_org_form}', '{sell.fm1_memb_company_name}', '{sl.fm1_memb_noname}', '{sl.fm1_memb_founder_org_form}', " +
                        $" '{sl.fm1_memb_founder_secondname}', '{sl.fm1_memb_founder_name}', '{sl.fm1_memb_founder_}', '{sl.fm1_memb_founder_patronymic}'," +
                        $" '{sl.fm1_memb_memb_add_info}', '{sl.fm1_memb_country_2}', '{sl.fm1_memb_member_addrr}', '{sl.fm1_memb_member_fact_addrr}'," +
                        $" '{sl.fm1_member_name}', '{sl.fm1_member_middle_name}', '{sl.fm1_member_secondname}', '{bd}', '{sl.fm1_member_birth_place}') RETURNING fm1_memb_id;";
                        var memi = Provider.RunScalar(query); //membr
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        string cc = DateTime.Now.ToString("yyyy.MM.dd");
                        string ee = DateTime.Now.ToString("yyyy.MM.dd");
                        if (sl.fm1_person_birth_date != null)
                            cc = sl.fm1_person_birth_date?.ToString("yyyy.MM.dd");
                        if (sell.fm1_person_birth_date != null)
                            ee = sell.doc_date_2.ToString("yyyy.MM.dd");

                        query = $"INSERT INTO fm1_persons (fm1_main_id, fm1_person_secondname, fm1_person_name, fm1_person_middle_name, fm1_person_birth_date, fm1_person_birth_place, oked, iin_bin, fm1_memb_id)" +
                        $" VALUES ('{fmi}', '{sl.fm1_person_secondname}', '{sl.fm1_person_name}', '{sl.fm1_person_midle_name}', '{cc}', '{sl.fm1_person_birth_place}', '{sl.oked}', '{sl.iin_bin}', '{memi}') RETURNING fma_person_id;";
                        var pri = Provider.RunScalar(query); //persn
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_persons1 (fm1_main_id, fm1_person_secondname, fm1_person_name, fm1_person_middle_name, fm1_memb_id)" +
                            $" VALUES ('{fmi}', '{sl.fm1_person_secondname_2}', '{sl.fm1_person_name_2}', '{sl.fm1_person_middle_name_2}', '{memi}') RETURNING fma_person_id;";
                        var pri1 = Provider.RunScalar(query); //persn
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_docs1 (fm1_main_id, doc_num, doc_series, doc_goverm_office, doc_date, doc_type, fm1_memb_id)" +
                           $" VALUES ('{fmi}', '{sl.doc_num_2}', '{sl.doc_series_2}', '{sl.goverm_office_2}', '{ee}', '{sl.doc_type_2}','{memi}') RETURNING fm1_doc_id;"; ///*, '{sell.doc_type}'
                        var doci1 = Provider.RunScalar(query); //doc
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            //return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_addrr1 (fm1_main_id, fm1_addrr_state, fm1_addrr_region, fm1_addrr_city, fm1_addrr_street, fm1_addrr_house_num, fm1_addrr_flat_num, fm1_addrr_post_index, phone, mail, fm1_memb_id)" +
                            $" VALUES ('{fmi}', '{sl.state_kaz_2}', '{sl.region_kaz_2}', '{sl.sity_kaz_2}', '{sl.street_2}', '{sl.house_num_2}', '{sl.flat_num_2}', '{sl.post_index_2}', '{sl.fm1_memb_contact_phone_2}', '{sl.fm1_memb_email_2}', '{memi}') RETURNING fm1_addrr_id;";
                        var adri1 = Provider.RunScalar(query); //adr1
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_addrr2 (fm1_main_id, fm1_addrr_state, fm1_addrr_region, fm1_addrr_city, fm1_addrr_street, fm1_addrr_house_num, fm1_addrr_flat_num, fm1_addrr_post_index, addition, fm1_memb_id)" +
                            $" VALUES ('{fmi}', '{sl.state_kaz_3}', '{sl.region_kaz_3}', '{sl.sity_kaz_3}', '{sl.street_3}', '{sl.house_num_3}', '{sl.flat_num_3}', '{sl.post_index_3}', '{sl.fm1_memb_memb_add_info_3}', '{memi}') RETURNING fm1_addrr_id;";
                        var adri2 = Provider.RunScalar(query); //adr2
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }

                if (fmi > 0)
                {
                    log.Info("new fm1 " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + fmi;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error ";
            }

        }

        public string CreateEpi(EpiModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {
                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, category, attis_contract_doc_date)" +
                $" VALUES ('{sell.ap_main_reg_num}', '{response}', '5', 'customs', now() ) RETURNING \"attis_contract_doc_id\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                var docid = Provider.RunScalar(query);

                string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"), dd = "null";
                if (sell.ap_main_reg_date != null)
                    aa = sell.ap_main_reg_date.ToString("yyyy.MM.dd");
                if (sell.ap_send_rec_identity_card_date != null)
                    bb = sell.ap_send_rec_identity_card_date?.ToString("yyyy.MM.dd");
                if (sell.ap_transp_date_expected_arrival != null)
                    cc = sell.ap_transp_date_expected_arrival?.ToString("yyyy.MM.dd");
                if (sell.ap_main_decl_date != null)
                    dd = sell.ap_main_decl_date?.ToString("yyyy.MM.dd");
                query = $"INSERT INTO ap_main (ref_doc_id, ap_main_reg_num, ap_main_country_code, ap_main_reg_date, ap_main_trans_kind_code, " +
                    $"ap_main_transit_direction_code, ap_main_electronic_document_sign, ap_main_declaration_kind, ap_main_subsoil_sign, " +
                    $"ap_main_seal_number, ap_main_seal_quantity, ap_main_language_cuesad, ap_main_recipient_country_code, ap_main_movement_code," +
                    $" ap_main_decl_num, ap_main_decl_date, ap_main_carnet)" +
                        $" VALUES ('{docid}', '{sell.ap_main_reg_num}', '{sell.ap_main_country_code}', '{aa}', '{sell.ap_main_trans_kind_code}', " +
                        $"'{sell.ap_main_transit_direction_code}', '{sell.ap_main_electronic_document_sign}', '{sell.ap_main_declaration_kind}', " +
                        $"'{sell.ap_main_subsoil_sign}', '{sell.ap_main_seal_number}', '{sell.ap_main_seal_quantity}', '{sell.ap_main_language_cuesad}', " +
                        $"'{sell.ap_main_recipient_country_code}', '{sell.ap_main_movement_code}','{sell.ap_main_decl_num}','{dd}', {sell.ap_main_carnet ?? 0}) RETURNING ap_main_id;";
                var fmi = Provider.RunScalar(query); //main
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (fmi < 0) return "error" + fmi;
                var r = new List<ImageFile>();
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "epi"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                query = $"INSERT INTO ap_send_rec (ap_main_id, ap_send_rec_identity_card_code, ap_send_rec_identity_card_series, ap_send_rec_identity_card_number, ap_send_rec_identity_card_date, ap_send_rec_organization_name)" +
        $" VALUES ('{fmi}', '{sell.ap_send_rec_identity_card_code}', '{sell.ap_send_rec_identity_card_series}', '{sell.ap_send_rec_identity_card_number}', '{bb}', '{sell.ap_send_rec_organization_name}') RETURNING ap_send_rec_id;";
                var doci = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"INSERT INTO ap_members (ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                    $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                        $" VALUES ('{sell.ap_memb_organization_name_1}', '{sell.ap_memb_short_name_1}', '{sell.ap_memb_bin_1}', '{sell.ap_memb_itn_1}', " +
                        $"'{sell.ap_member_postal_code_1}', '{sell.ap_member_country_name_1}', '{sell.ap_member_region_1}', '{sell.ap_member_city_1}', '{sell.ap_member_street_house_1}') RETURNING ap_memb_id;";
                var send = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_send_rec SET sender_id='{send}' WHERE ap_send_rec_id='{doci}';";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO ap_members (ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                $" VALUES ('{sell.ap_memb_organization_name_2}', '{sell.ap_memb_short_name_2}', '{sell.ap_memb_bin_2}', '{sell.ap_memb_itn_2}', " +
                $"'{sell.ap_member_postal_code_2}', '{sell.ap_member_country_name_2}', '{sell.ap_member_region_2}', '{sell.ap_member_city_2}', '{sell.ap_member_street_house_2}') RETURNING ap_memb_id;";
                var recp = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_send_rec SET recipient_id='{recp}' WHERE ap_send_rec_id='{doci}';";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO ap_members (ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                $" VALUES ('{sell.ap_memb_organization_name_3}', '{sell.ap_memb_short_name_3}', '{sell.ap_memb_bin_3}', '{sell.ap_memb_itn_3}', " +
                $"'{sell.ap_member_postal_code_3}', '{sell.ap_member_country_name_3}', '{sell.ap_member_region_3}', '{sell.ap_member_city_3}', '{sell.ap_member_street_house_3}') RETURNING ap_memb_id;";
                var finr = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_send_rec SET fin_reg_id='{finr}' WHERE ap_send_rec_id='{doci}';";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO ap_members (ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                $" VALUES ('{sell.ap_memb_organization_name_4}', '{sell.ap_memb_short_name_4}', '{sell.ap_memb_bin_4}', '{sell.ap_memb_itn_4}', " +
                $"'{sell.ap_member_postal_code_4}', '{sell.ap_member_country_name_4}', '{sell.ap_member_region_4}', '{sell.ap_member_city_4}', '{sell.ap_member_street_house_4}') RETURNING ap_memb_id;";
                var dclr = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_send_rec SET declarant_id='{dclr}' WHERE ap_send_rec_id='{doci}';";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO ap_members (ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                    $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                        $" VALUES ('{sell.ap_memb_organization_name_5}', '{sell.ap_memb_short_name_5}', '{sell.ap_memb_bin_5}', '{sell.ap_memb_itn_5}', " +
                        $"'{sell.ap_member_postal_code_5}', '{sell.ap_member_country_name_5}', '{sell.ap_member_region_5}', '{sell.ap_member_city_5}', '{sell.ap_member_street_house_5}') RETURNING ap_memb_id;";
                var drvr = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_send_rec SET driver_id='{drvr}' WHERE ap_send_rec_id='{doci}';";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO ap_persons (ap_send_rec_id, ap_person_person_surname, ap_person_person_name,ap_person_person_middle_name, ap_person_person_post, ap_person_contact_phone)" +
                $" VALUES ('{fmi}', '{sell.ap_person_person_surname_1}', '{sell.ap_person_person_name_1}', '{sell.ap_person_person_middle_name_1}', '{sell.ap_person_person_post_1}', " +
                $"'{sell.ap_person_contact_phone_1}') RETURNING ap_person_id;";
                var pers = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_send_rec SET decl_officer_id='{pers}' WHERE ap_send_rec_id='{doci}';";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO ap_persons (ap_send_rec_id, ap_person_person_surname, ap_person_person_name,ap_person_person_middle_name, ap_person_person_post, ap_person_reg_country_code)" +
                $" VALUES ('{fmi}', '{sell.ap_person_person_surname_2}', '{sell.ap_person_person_name_2}', '{sell.ap_person_person_middle_name_2}', '{sell.ap_person_person_post_2}', " +
                $"'{sell.ap_person_reg_country_code_2}') RETURNING ap_person_id;";
                var pers1 = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_send_rec SET person1_id='{pers1}' WHERE ap_send_rec_id='{doci}';";
                Provider.RunNonQuery(query);
                query = $"INSERT INTO ap_transportations (ap_main_id, ap_transp_information_type_code, ap_transp_customs_office, ap_transp_customs_country_code, " +
                    $"ap_transp_container_indicator, ap_transp_dispatch_country_code, ap_transp_destination_country_code, ap_transp_customs_office_inout, " +
                    $"ap_transp_customs_country_code_io, ap_transp_date_expected_arrival, ap_transp_transport_mode_code, ap_transp_transport_nationality_code, " +
                    $"ap_transp_vin, ap_transp_transport_identifier, ap_transp_active_transport_identifier, ap_transp_date_expected_arrival_time)" +
                    $" VALUES ('{fmi}', '{sell.ap_transp_information_type_code}', '{sell.ap_transp_customs_office}', '{sell.ap_transp_customs_country_code}'," +
                    $" '{sell.ap_transp_container_indicator}', '{sell.ap_transp_dispatch_country_code}', '{sell.ap_transp_destination_country_code}', '{sell.ap_transp_customs_office_inout}', " +
                    $"'{sell.ap_transp_customs_country_code_io}', '{cc}', '{sell.ap_transp_transport_mode_code}', '{sell.ap_transp_transport_nationality_code}'," +
                    $" '{sell.ap_transp_vin}', '{sell.ap_transp_transport_identifier}', '{sell.ap_transp_active_transport_identifier}', '{sell.ap_transp_date_expected_arrival_time ?? "0:0"}') RETURNING ap_transp_id;";
                var tran = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (tran < 0) query = $"INSERT INTO ap_transportations ap_main_id = '{fmi}'"; //w_ar
                var ss = sell.ap_good_total_cust_cost.GetValueOrDefault();
                //string currency_code = "1";
                query = $"INSERT INTO ap_goods (ap_good_main_id, ap_good_origin_country_name, ap_good_specification_number, ap_good_specification_list_number, " +
                    $"ap_good_total_goods_number, ap_good_total_package_number, ap_good_total_sheet_number, ap_good_total_cust_cost, ap_good_cust_cost_currency_code)" +
                    $" VALUES ('{fmi}', '{sell.ap_good_origin_country_name}', '{sell.ap_good_specification_number}', '{sell.ap_good_specification_list_number}', " +
                    $"'{sell.ap_good_total_goods_number}', '{sell.ap_good_total_package_number}', '{sell.ap_good_total_sheet_number}', '{ss}', '{sell.ap_good_cust_cost_currency_code}') RETURNING ap_good_id;";
                var apgi = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (sell.product != null && fmi > 0)
                    foreach (var ln in sell.product)
                    {
                        string country_code = "";
                        country_code = ln.ap_good_data_origin_country_code ?? "";
                        query = $"INSERT INTO ap_good_data (ap_main_id, ap_good_data_goods_numeric, ap_good_data_list_numeric, ap_good_data_goods_description," +
                            $" ap_good_data_gross_weight_quantity, ap_good_data_net_weight_quantity, ap_good_data_invoiced_cost, ap_good_data_customs_cost," +
                            $" ap_good_data_statistical_cost, ap_good_data_goods_tnved_code, ap_good_data_origin_country_code, ap_good_data_delivery_terms_string_code," +
                            $" ap_good_data_quant, ap_good_data_ext_measure, ap_good_data_container_num, ap_good_data_places_name,ap_good_data_places, ap_good_data_packet) " +
                        $"VALUES('{fmi}', '{ln.ap_good_data_goods_numeric}', '{ln.ap_good_data_list_numeric}', '{ln.ap_good_data_goods_description}', '{ln.ap_good_data_gross_weight_quantity.GetValueOrDefault()}'," +
                        $" '{ln.ap_good_data_net_weight_quantity.GetValueOrDefault()}', '{ln.ap_good_data_invoiced_cost.GetValueOrDefault()}'," +
                        $" '{ln.ap_good_data_customs_cost.GetValueOrDefault()}', '{ln.ap_good_data_statistical_cost.GetValueOrDefault()}'," +
                        $" '{ln.ap_good_data_goods_tnved_code}', '{country_code}', '{ln.ap_good_data_delivery_terms_string_code}', '{ln.ap_good_data_quant}'," +
                        $"'{ln.ap_good_data_ext_measure}', '{ln.ap_good_data_container_num}', '{ln.ap_good_data_places_name}', {ln.ap_good_data_places ?? 0}, {ln.ap_good_data_packet ?? 0});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (sell.prev_docs != null)
                    foreach (var ln in sell.prev_docs)
                    {
                        query = $"INSERT INTO ap_prev_docs (ap_main_id, ap_prev_doc_preceding_document_date, ap_prev_doc_preceding_document_number, PrecedingDocumentName, ap_prev_doc_kind) " +
                        $"VALUES('{fmi}', '{ln.ap_prev_doc_preceding_document_date}', '{ln.ap_prev_doc_preceding_document_number}', '{ln.PrecedingDocumentName}', '{ln.ap_prev_doc_kind}');";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (fmi > 0)
                {
                    log.Info("new epi " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "{\"status\":\"ok\", \"doc_id\":" + docid + "}";
                }
                else return "error " + fmi;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });

                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewEpi}', '{LogDocument.NewEpi}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }


        }

        public string CreateAWB(AwbModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "awb"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, doc_guid, file_type, category, attis_contract_doc_date)" +
                    $" VALUES ('', '{response}', '6', '{rid}', '{type}', 'transport', now() ) RETURNING \"attis_contract_doc_id\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                var docid = Provider.RunScalar(query);
                query = $"INSERT INTO awb (awb_guid,awb_imp_date,awb_inp_time,user_id,1_airport_code,1a_acompany_code,1b_serial_num," +
                    $"1c_acomp_name_addr,2_sender_name_addr,4_recipient_name_addr,6_agent_name_addr,7_agent_iata_code,8_agent_acc,9_dest_airport," +
                    $"10_payment_data,11a_first_carrier_dest_point,11b_fist_carrier_name,11c_second_carrier_dest_point,11d_second_carrier_name," +
                    $"11e_third_carrier_dest_point,11f_third_carrier_name,12_curr_code,14a_pr_o,14b_col_l,15a_pr_d,15b_col_l,16_decl_value_carr," +
                    $"17_decl_value_cust,18_dest_airport,19ab_flight_date,20_insuranse_amount,21_handling_info,21a_custom_status,22a_pieses_no," +
                    $"22b_brutto,22c_measure,22d_rate_class,22e_commodity_item,22f_chargeable_weight,22g_rate_charge,22h_total,22i_nature_quant," +
                    $"22j_total_pieses,22l_total_sum_rev,22k_total_brutto,23_other_charges,24_weight_charge_sum,25_valuation_sum,26_tax_sum," +
                    $"27_total_other_charges,28_carrier_total_other_charges,30_total_prepaid_collect,32a_awb_create_date,32b_awb_place,32c_signature)" +
                    $" VALUES ('{sell.awb_guid}','{sell.awb_imp_date}','{sell.awb_inp_time}','{sell.user_id}','{sell.airport_code}'," +
                    $"'{sell.acompany_code}','{sell.serial_num}','{sell.acomp_name_addr}','{sell.sender_name_addr}','{sell.recipient_name_addr}'," +
                    $"'{sell.agent_name_addr}','{sell.agent_iata_code}','{sell.agent_acc}','{sell.dest_airport}','{sell.payment_data}'," +
                    $"'{sell.first_carrier_dest_point}','{sell.fist_carrier_name}','{sell.second_carrier_dest_point}','{sell.second_carrier_name}'," +
                    $"'{sell.third_carrier_dest_point}','{sell.third_carrier_name}','{sell.curr_code}','{sell.pr_o}','{sell.col_l}','{sell.pr_d}'," +
                    $"'{sell.col_l1}','{sell.decl_value_carr}','{sell.decl_value_cust}','{sell.dest_airport1}','{sell.flight_date}','{sell.insuranse_amount}'," +
                    $"'{sell.handling_info}','{sell.custom_status}','{sell.pieses_no}','{sell.brutto}','{sell.measure}','{sell.rate_class}'," +
                    $"'{sell.commodity_item}','{sell.chargeable_weight}','{sell.rate_charge}','{sell.total}','{sell.nature_quant}','{sell.total_pieses}'," +
                    $"'{sell.total_sum_rev}','{sell.total_brutto}','{sell.other_charges}','{sell.weight_charge_sum}','{sell.valuation_sum}','{sell.tax_sum}'," +
                    $"'{sell.total_other_charges}','{sell.carrier_total_other_charges}','{sell.total_prepaid_collect}','{sell.awb_create_date}'," +
                    $"'{sell.awb_place}','{sell.signature}') RETURNING awb_id";
                var abwid = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewAWB}', '{LogDocument.NewAWB}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (abwid > 0)
                {
                    log.Info("new awb " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewAWB}', '{LogDocument.NewAWB}', '{LogSection.Document}', '{user}', '{docid}',  '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + abwid;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewAWB}', '{LogDocument.NewAWB}', '{LogSection.Document}', '{user}',  @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error ";
            }

        }

        [HttpPost]
        public string CreateInsurance(cargo_insurance sell, string contract_id)
        {
            string user = User.Identity.GetUserId();
            try
            {

                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, category, attis_contract_doc_date)" +
                    $" VALUES ('{sell.doc_id}', '{contract_id}', 9, 'finance', now() ) RETURNING \"attis_contract_doc_id\";"; 
                var docid = Provider.RunScalar(query);
                string aa = "2020.01.01", ab = "2020.01.01";
                if (sell.release_date != null)
                    aa = sell.release_date?.ToString("yyyy.MM.dd");
                if (sell.shipment_date != null)
                    ab = sell.shipment_date?.ToString("yyyy.MM.dd");

                query = $"INSERT INTO cargo_insurance_form (doc_id, policy_holder_name,	represented_by,	legal_address, actual_address," +
                    $"is_public_person, insured_details, insured_activity, beneficiary,	beneficiary_details, shipping_name,	package_info," +
                    $"cargo_cost, package_count, total_cost, release_date, containerization, cargo_placing,	route, security_measures," +
                    $"transport_means, transfer_points,	shipping_details,risk_a, risk_b1, risk_b2, additional_conditions, max_value_a, " +
                    $"max_value_b, max_value_c, max_value_d, max_value_e, max_value_f, insured_transport, insured_transport_amount,	franchise," +
                    $"shipment_date, shipment_duration,	insurance_stats, relevant_info,	other)" +
                    $" VALUES ('{docid}', '{sell.policy_holder_name}', '{sell.represented_by}', '{sell.legal_address}', '{sell.actual_address}'," +
                    $"{sell.is_public_person.GetValueOrDefault()},'{sell.insured_details}', '{sell.insured_activity}', '{sell.beneficiary}', '{sell.beneficiary_details}'," +
                    $"'{sell.shipping_name}','{sell.package_info}', {sell.cargo_cost.GetValueOrDefault()},{sell.package_count.GetValueOrDefault()}, {sell.total_cost.GetValueOrDefault()}," +
                    $"'{aa}', {sell.containerization.GetValueOrDefault()},'{sell.cargo_placing}','{sell.route}', '{sell.security_measures}','{sell.transport_means}', " +
                    $"'{sell.transfer_points}','{sell.shipping_details}',{sell.risk_a.GetValueOrDefault()},{sell.risk_b1.GetValueOrDefault()}, {sell.risk_b2.GetValueOrDefault()}," +
                    $"'{sell.additional_conditions}', {sell.max_value_a.GetValueOrDefault()}, {sell.max_value_b.GetValueOrDefault()}," +
                    $"{sell.max_value_c.GetValueOrDefault()}, {sell.max_value_d.GetValueOrDefault()},{sell. max_value_e.GetValueOrDefault()}," +
                    $"{sell.max_value_f.GetValueOrDefault()}, {sell.insured_transport.GetValueOrDefault()}," +
                    $"{sell.insured_transport_amount.GetValueOrDefault()}, '{sell.franchise}','{ab}', '{sell.shipment_duration}','{sell.insurance_stats}', " +
                    $"'{sell.relevant_info}', '{sell.other}') RETURNING \"id\";"; 
                                                                                                                                                                                   
                var insc = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewInsurance}', '{LogDocument.NewInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
               
                if (insc > 0)
                {
                    if (sell.files != null)
                        foreach (var fl in sell.files)
                        {
                            query = $"UPDATE docimages SET doc_guid='{docid}' WHERE id='{fl.id}'";
                            Provider.RunNonQuery(query);
                        }
                    log.Info("new insurance " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewInsurance}', '{LogDocument.NewInsurance}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + insc;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewInsurance}', '{LogDocument.NewInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        [HttpPost]
        public string CreateLiabilityInsurance(liability_insurance sell, string contract_id)
        {
            string user = User.Identity.GetUserId();
            try
            {

                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, category, attis_contract_doc_date)" +
                    $" VALUES ('{sell.doc_id}', '{contract_id}', 10, 'finance', now() ) RETURNING \"attis_contract_doc_id\";";
                var docid = Provider.RunScalar(query);
                string aa = "2020.01.01";
                if (sell.insurance_date != null)
                    aa = sell.insurance_date?.ToString("yyyy.MM.dd");
                
                query = $"INSERT INTO liability_insurance (doc_id, policy_holder_name, policy_holder_address, policy_holder_phone, policy_holder_email," +
                    $"policy_holder_bank, policy_holder_bin, policy_holder_bik,	is_resident, license_no, economy_sector, activity_type, " +
                    $"object_teritory, insured_details, life_insured_sum, property_insured_sum, cargo_insured_sum, total_insured_sum, " +
                    $"insurance_term, insurance_teritory, transport_type, transport_model, transport_name, transport_reg_number, " +
                    $"transport_body_number, transport_release_date, vehicles_number, previous_insurance_info, valid_contracts_info, " +
                    $"insurer_name, insurer_address, insurer_phone, insurance_date)" +
                    $" VALUES ('{docid}', '{sell.policy_holder_name}', '{sell.policy_holder_address}', '{sell.policy_holder_phone}', '{sell.policy_holder_email}'," +
                    $"'{sell.policy_holder_bank}','{sell.policy_holder_bin}', '{sell.policy_holder_bik}', {sell.is_resident.GetValueOrDefault()}, '{sell.license_no}'," +
                    $"'{sell.economy_sector}','{sell.activity_type}', '{sell.object_teritory}','{sell.insured_details}', {sell.life_insured_sum.GetValueOrDefault()}," +
                    $"{sell.property_insured_sum.GetValueOrDefault()},{sell.cargo_insured_sum.GetValueOrDefault()},{sell.total_insured_sum.GetValueOrDefault()}," +
                    $"'{sell.insurance_term}','{sell.insurance_teritory}', '{sell.transport_type}','{sell.transport_model}','{sell.transport_name}', " +
                    $"'{sell.transport_reg_number}','{sell.transport_body_number}','{sell.transport_release_date}','{sell.vehicles_number}'," +
                    $"'{sell.previous_insurance_info}', '{sell.valid_contracts_info}','{sell.insurer_name}', '{sell.insurer_address}', '{sell.insurer_phone}','{aa}') RETURNING id;";

                var insc = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewLiabilityInsurance}', '{LogDocument.NewLiabilityInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }

                if (insc > 0)
                {
                    if (sell.files != null)
                        foreach (var fl in sell.files)
                        {
                            query = $"UPDATE docimages SET doc_guid='{docid}' WHERE id='{fl.id}'";
                            Provider.RunNonQuery(query);
                        }
                    log.Info("new liability insurance " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewLiabilityInsurance}', '{LogDocument.NewLiabilityInsurance}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + insc;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewInsurance}', '{LogDocument.NewInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        [HttpPost]
        public string Update(DocModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            string aa = DateTime.Now.ToString("yyyy.MM.dd");
            try
            {
                /*
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{response}'";
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }
            else*/
                {
                    var r = new List<ImageFile>();
                    int? rid = null; string type = "";
                    foreach (string fil in Request.Files)
                    {
                        var hpf = Request.Files[fil];
                        if (hpf.ContentLength == 0)
                            continue;

                        // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                        // hpf.SaveAs(savedFileName);
                        var imgFile = new ImageFile
                        {
                            ID = 0,
                            EntityId = response,
                            Name = hpf.FileName,
                            Length = hpf.ContentLength,
                            Type = hpf.ContentType,
                            Date = DateTime.Now,
                            Image = new MemoryStream(),
                            WidgetId = "invoice"
                        };

                        hpf.InputStream.CopyTo(imgFile.Image);

                        Provider.SaveFile(imgFile);

                        r.Add(imgFile);
                    }
                    if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                    if (sell.DocumentDate != null)
                        aa = sell.DocumentDate.ToString("yyyy.MM.dd");
                    var query = $"UPDATE \"Invoice\" SET(\"DocumentNumber\", \"DocumentDate\", \"CurrencyCode\", \"PlacesQuantity\", " +
       $"\"PlacesDescription\", \"GrossWeightQuantity\", \"NetWeightQuantity\", \"GCost\", \"Discount\", \"TransportCharges\", " +
       $"\"InsuranceCharges\", \"OtherCharges\", \"TotalCost\", \"PaymentPeriod\", \"InvoiceByer\", \"InvoiceSeller\")=" +
       $" ('{sell.DocumentNumber}', '{aa}', '{sell.CurrencyCode}', '{sell.PlacesQuantity}'," +
       $" '{sell.PlacesDescription}', '{sell.GrossWeightQuantity}', '{sell.NetWeightQuantity}', '{sell.GCost}', '{sell.Discount}', '{sell.TransportCharges}'," +
       $" '{sell.InsuranceCharges}', '{sell.OtherCharges}', '{sell.TotalCost}', '{sell.PaymentPeriod}', '{sell.InvoiceByer}', '{sell.InvoiceSeller}') WHERE \"RefDocumentID\" ='{response}' RETURNING \"DocumentID\";";
                    var contr = Provider.RunScalar(query);
                    if (Provider.lastError != "")
                    {
                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.InvoiceUpdate}', '{LogDocument.InvoiceUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                        Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                    if (r.Count > 0)
                        query = $"UPDATE attis_contract_docs SET attis_contract_doc_number='{sell.DocumentNumber}', doc_guid='{rid}', file_type='{type}' where attis_contract_doc_id='{response}'";
                    else query = $"UPDATE attis_contract_docs SET attis_contract_doc_number='{sell.DocumentNumber}' where attis_contract_doc_id='{response}'";
                    Provider.RunNonQuery(query);
                    query = $"DELETE FROM \"InvoiceGoods\" WHERE \"InvoiceId\"='{contr}'";
                    var del = Provider.RunScalar(query);
                    if (sell.product != null)
                        foreach (var ln in sell.product)
                        {
                            float tc = ln.Price + ln.ServiceCharges + ln.TransportCharges + ln.OtherCharges;
                            query = $"INSERT INTO \"InvoiceGoods\" (\"GoodsCode\", \"OriginCountryCode\", \"SupplementaryQualifierName\", \"GoodMarking\", \"GoodsDescription\"," +
                                $" \"GoodsQuantity\", \"GrossWeightQuantity\", \"NetWeightQuantity\", \"Price\", \"Discount\", \"DiscountPercentage\", \"ServiceCharges\"," +
                                $" \"TransportCharges\", \"OtherCharges\", \"TotalCost\", \"InvoiceId\") " +
                            $"VALUES('{ln.GoodsCode}', '{ln.OriginCountryCode}', '{ln.SupplementaryQualifierName}', '{ln.GoodMarking}', '{ln.GoodsDescription}'," +
                            $" '{ln.GoodsQuantity}', '{ln.GrossWeightQuantity}', '{ln.NetWeightQuantity}', '{ln.Price}', '{ln.Discount}', '{ln.DiscountPercentage}'," +
                            $" '{ln.ServiceCharges}', '{ln.TransportCharges}', '{ln.OtherCharges}', '{tc}', '{contr}');";
                            Provider.RunNonQuery(query);
                            if (Provider.lastError != "")
                            {
                                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                        $"VALUES('NOW()', '{(int)LogDocument.InvoiceUpdate}', '{LogDocument.InvoiceUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                return "{\"status\":\"error " + Provider.lastError + "\"}";
                            }
                        }
                    log.Info("invoice update " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.InvoiceUpdate}', '{LogDocument.InvoiceUpdate}', '{LogSection.Document}', '{user}', '{response}','{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "{\"status\":\"ok\", \"doc_id\":" + response + "}";
                }
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id,log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.InvoiceUpdate}', '{LogDocument.InvoiceUpdate}', '{LogSection.Document}', '{user}',@p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }
        [HttpPost]
        public string UpdateCMR(CMRModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();/*
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{response}'";
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }
            */
            try
            {
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "cmr"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd");
                if (sell.PrDocumentDate != null)
                    aa = sell.PrDocumentDate.ToString("yyyy.MM.dd");
                if (sell.cmr_date != null)
                    bb = sell.cmr_date.ToString("yyyy.MM.dd");
                if (sell.TakingCargoDate != null)
                    cc = sell.TakingCargoDate.ToString("yyyy.MM.dd");
                var query = $"UPDATE \"CMR\" SET( cmr_number, cmr_date, \"CarrierNotice\", cmr_sender_id, cmr_recipient_id, cmr_track, cmr_trailer," +
                    $" cmr_courier, cmr_courier_next, delivery_place, delivery_terms, terms_desc, custom_code, courier_notes, cmr_track_reg_country, \"GoodsCost\")" +
                    $" = ('{sell.cmr_number}', '{bb}', '{sell.CurrencyCode}', '{sell.cmr_sender}', '{sell.cmr_recipient}', '{sell.cmr_track}', '{sell.cmr_trailer}', " +
                    $"'{sell.cmr_courier}', '{sell.cmr_courier_next}', '{sell.DeliveryPlace}', '{sell.DeliveryTermsStringCode}', " +
                    $"'{sell.TermsDescription}', '{sell.custom_code}', '{sell.courier_notes}', '{sell.cmr_track_reg_country}'," +
                    $" {sell.GoodsCost.GetValueOrDefault()}) WHERE \"RefDocumentID\"='{response}' RETURNING cmr_id;"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'            
                var cmri = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.CMRUpdate}', '{LogDocument.CMRUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (r.Count > 0)
                    query = $"UPDATE attis_contract_docs SET attis_contract_doc_number='{sell.cmr_number}', doc_guid='{rid}', file_type='{type}' where attis_contract_doc_id='{response}'";
                else query = $"UPDATE attis_contract_docs SET attis_contract_doc_number='{sell.cmr_number}' where attis_contract_doc_id='{response}'";
                Provider.RunNonQuery(query);
                query = $"UPDATE \"TakingCargoPlace\" SET(\"PostalCode\", \"CountryCode\", \"City\", \"StreetHouse\", \"TakingCargoDate\", warehouse)" +
                    $" = ('{sell.PostalCode}', '{sell.CountryCode}', '{sell.City}', '{sell.StreetHouse}', '{cc}', '{sell.WarehouseName}') WHERE cmr_id='{cmri}';";
                var adri = Provider.RunScalar(query); //adr
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.CMRUpdate}', '{LogDocument.CMRUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"DELETE FROM \"CMRGoods\" WHERE \"CmrId\"='{cmri}'";
                var del = Provider.RunScalar(query);
                query = $"DELETE FROM places_list WHERE cmr_id='{cmri}'";
                del = Provider.RunScalar(query);
                if (sell.product != null)
                    foreach (var ln in sell.product)
                    {
                        query = $"INSERT INTO \"CMRGoods\" (\"GoodsNomenclatureCode\", \"VolumeQuantity\", \"GoodsMarking\", \"GoodsDescription\"," +
                            $" \"GoodsQuantity\", \"GrossWeightQuantity\", \"CmrId\", \"GoodsPrice\") " +
                        $"VALUES('{ln.GoodsNomenclatureCode}', '{ln.VolumeQuantity}', '{ln.GoodMarking}', '{ln.GoodsDescription}'," +
                        $" '{ln.GoodsQuantity}', '{ln.GrossWeightQuantity}', '{cmri}'. {ln.GoodsPrice.GetValueOrDefault()}) RETURNING cmr_good_id;";
                        var goodId = Provider.RunScalar(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.CMRUpdate}', '{LogDocument.CMRUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                        if (ln.places != null && goodId > 0)
                        {
                            foreach (var pl in ln.places)
                            {
                                query = $"INSERT INTO places_list (packing_code, packing_quantity, packing_description, package_part_quantity, cmr_id, good_id)" +
                                $"VALUES('{pl.PackagingTypeCode}', '{pl.PlacesCount}', '{pl.Description}', '{pl.PlacesCount}', '{cmri}', '{goodId}');";
                                Provider.RunNonQuery(query);
                            }
                        }
                    }
                log.Info("cmr update " + user + JsonConvert.SerializeObject(sell));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.CMRUpdate}', '{LogDocument.CMRUpdate}', '{LogSection.Document}', '{user}', '{response}', '{JsonConvert.SerializeObject(sell)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.CMRUpdate}', '{LogDocument.CMRUpdate}', '{LogSection.Document}', '{user}', p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        public string UpdateFm1(Fm1Model sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();/*
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{response}'";
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }
            */
            try
            {
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "fm1"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"),
                    dd = DateTime.Now.ToString("yyyy.MM.dd");
                if (sell.fm1_main_date != null)
                    aa = sell.fm1_main_date.ToString("yyyy.MM.dd");
                if (sell.fm1_oper_basis_doc_date != null)
                    bb = sell.fm1_oper_basis_doc_date.ToString("yyyy.MM.dd");
                if (sell.doc_date != null)
                    dd = sell.doc_date.ToString("yyyy.MM.dd");
                var query = $"UPDATE fm1_main SET(fm1_main_number, fm1_main_related_number, fm1_main_related_date, " +
                    $"fm1_main_form_kind, fm1_main_form_state, fm1_main_reason, fm1_main_subreason)" +
                        $" = ( '{sell.fm1_main_number}', '{sell.fm1_main_related_number}', '{aa}', " +
                        $"'{sell.fm1_main_doc_kind}', '{sell.fm1_main_form_state}', '{sell.fm1_main_reason}', '{sell.fm1_main_subreason}') WHERE ref_doc_id='{response}' RETURNING fm1_main_id;";
                var fmi = Provider.RunScalar(query); //main
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.Fm1Update}', '{LogDocument.Fm1Update}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (r.Count > 0)
                    query = $"UPDATE attis_contract_docs SET attis_contract_doc_number='{sell.fm1_main_number}', doc_guid='{rid}', file_type='{type}' where attis_contract_doc_id='{response}'";
                else query = $"UPDATE attis_contract_docs SET attis_contract_doc_number='{sell.fm1_main_number}' where attis_contract_doc_id='{response}'";
                Provider.RunNonQuery(query);
                query = $"UPDATE fm1_subject SET(fm1_subj_code, fm1_subj_org_form, fm1_subj_name, fm1_subj_pers_second_name, " +
                    $"fm1_subj_pers_name, fm1_subj_pers_middle_name, fm1_subj_rnn, fm1_subj_iin_bin, fm1_subj_manager_second_name, " +
                    $"fm1_subj_manager_name, fm1_subj_manager_patronymic, fm1_subj_position, fm1_subj_phone, fm1_subj_email)" +
                        $" = ( '{sell.fm1_subj_code}', '{sell.fm1_subj_org_form}', '{sell.fm1_subj_name}', '{sell.fm1_subj_pers_second_name}', " +
                        $"'{sell.fm1_subj_pers_name}', '{sell.fm1_subj_pers_middle_name}', '{sell.fm1_subj_rnn}', '{sell.fm1_subj_iin_bin}', '{sell.fm1_subj_manager_second_name}'," +
                        $" '{sell.fm1_subj_manager_name}', '{sell.fm1_subj_manager_patronymic}', '{sell.fm1_subj_position}','{sell.fm1_subj_phone}', '{sell.fm1_subj_email}') WHERE fm1_main_id='{fmi}';";
                var subi = Provider.RunScalar(query); //subj
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.Fm1Update}', '{LogDocument.Fm1Update}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE fm1_addrr SET(fm1_addrr_state, fm1_addrr_region, fm1_addrr_city, fm1_addrr_street, fm1_addrr_house_num, fm1_addrr_flat_num, fm1_addrr_post_index)" +
                    $" = ('{sell.state_kaz_1}', '{sell.region_kaz_1}', '{sell.sity_kaz_1}', '{sell.street_1}', '{sell.house_num_1}', '{sell.flat_num_1}', '{sell.post_index_1}') WHERE fm1_main_id='{fmi}';";
                var adri = Provider.RunScalar(query); //adr
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.Fm1Update}', '{LogDocument.Fm1Update}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE fm1_docs SET(doc_num, doc_series, doc_goverm_office, doc_date)" +
                    $" = ('{sell.doc_num}', '{sell.doc_series}', '{sell.goverm_office}', '{dd}') WHERE fm1_main_id='{fmi}';"; ///*, '{sell.doc_type}'
                var doci = Provider.RunScalar(query); //doc
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.Fm1Update}', '{LogDocument.Fm1Update}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE fm1_operations SET(fm1_oper_number, fm1_oper_kind, fm1_oper_eknp, fm1_oper_members_quant, " +
                    $"fm1_oper_curr_code, fm1_oper_tenge_sum, fm1_oper_curr_sum, fm1_oper_basis, fm1_oper_basis_doc_date, fm1_oper_basis_doc_num, " +
                    $"fm1_oper_1code, fm1_oper_2code, fm1_oper_3code, fm1_oper_trouble_desc, fm1_oper_add_info)" +
                    $" = ( '{sell.fm1_oper_number}', '{sell.fm1_oper_code_type}', '{sell.fm1_oper_eknp}', '{sell.fm1_oper_members_quant}', " +
                    $"'{sell.fm1_oper_currency}', {sell.fm1_oper_tenge_sum}, {sell.fm1_oper_curr_code}, '{sell.fm1_oper_basis}', '{bb}', '{sell.fm1_oper_basis_doc_num}', " +
                    $"'{sell.fm1_oper_1code}','{sell.fm1_oper_2code}','{sell.fm1_oper_3code}','{sell.fm1_oper_trouble_desc}', '{sell.fm1_oper_add_info}') WHERE fm1_main_id='{fmi}';";
                var opi = Provider.RunScalar(query); //oper
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.Fm1Update}', '{LogDocument.Fm1Update}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"DELETE FROM fm1_members WHERE fm1_main_id='{fmi}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_persons WHERE fm1_main_id='{fmi}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_persons1 WHERE fm1_main_id='{fmi}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_addrr1 WHERE fm1_main_id='{fmi}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_addrr2 WHERE fm1_main_id='{fmi}'";
                Provider.RunNonQuery(query);
                if (sell.members != null)
                    foreach (var sl in sell.members)
                    {
                        string bd = DateTime.Now.ToString("yyyy.MM.dd");
                        if (sl.fm1_member_birth_date != null)
                            bd = sell.fm1_main_date.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO fm1_members (fm1_main_id, fm1_member, fm1_memb_is_subj, fm1_memb_subj_kind, fm1_memb_country, fm1_memb_type, " +
                        $"fm1_memb_foreign, fm1_memb_bank_branch_place, fm1_memb_bank_branch, fm1_memb_sdp, fm1_memb_branch_code, fm1_memb_acc, " +
                        $"fm1_memb_bank_place, fm1_memb_bank_name, fm1_memb_org_form, fm1_memb_company_name, fm1_memb_noname, fm1_memb_founder_org_form, " +
                        $"fm1_memb_founder_secondname, fm1_memb_founder_name, fm1_memb_founder_, fm1_memb_founder_middle_name, fm1_memb_memb_add_info, " +
                        $"fm1_memb_country2, fm1_memb_member_addrr, fm1_memb_member_fact_addrr, fm1_member_name, fm1_member_middle_name, fm1_member_secondname," +
                        $"fm1_member_birth_date, fm1_member_birth_place)" +
                        $" VALUES ('{fmi}', '{sl.fm1_member}', '{sl.fm1_memb_is_subj}', '{sl.fm1_memb_subj_kind}', '{sl.fm1_memb_country}', '{sl.fm1_memb_type}'," +
                        $" '{sl.fm1_memb_foreign}', '{sl.fm1_memb_bank_branch_place}', '{sl.fm1_memb_bank_branch}', '{sl.fm1_memb_sdp}', '{sl.fm1_memb_branch_code}', '{sl.fm1_memb_acc}'," +
                        $" '{sl.fm1_memb_bank_place}', '{sl.fm1_memb_bank_name}', '{sl.fm1_memb_org_form}', '{sell.fm1_memb_company_name}', '{sl.fm1_memb_noname}', '{sl.fm1_memb_founder_org_form}', " +
                        $" '{sl.fm1_memb_founder_secondname}', '{sl.fm1_memb_founder_name}', '{sl.fm1_memb_founder_}', '{sl.fm1_memb_founder_patronymic}'," +
                        $" '{sl.fm1_memb_memb_add_info}', '{sl.fm1_memb_country_2}', '{sl.fm1_memb_member_addrr}', '{sl.fm1_memb_member_fact_addrr}'," +
                        $" '{sl.fm1_member_name}', '{sl.fm1_member_middle_name}', '{sl.fm1_member_secondname}', '{bd}', '{sl.fm1_member_birth_place}') RETURNING fm1_memb_id;";
                        var memi = Provider.RunScalar(query); //membr
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        string cc = DateTime.Now.ToString("yyyy.MM.dd");
                        string ee = DateTime.Now.ToString("yyyy.MM.dd");
                        if (sl.fm1_person_birth_date != null)
                            cc = sl.fm1_person_birth_date?.ToString("yyyy.MM.dd");
                        if (sell.fm1_person_birth_date != null)
                            ee = sell.doc_date_2.ToString("yyyy.MM.dd");

                        query = $"INSERT INTO fm1_persons (fm1_main_id, fm1_person_secondname, fm1_person_name, fm1_person_middle_name, fm1_person_birth_date, fm1_person_birth_place, oked, iin_bin, fm1_memb_id)" +
                        $" VALUES ('{fmi}', '{sl.fm1_person_secondname}', '{sl.fm1_person_name}', '{sl.fm1_person_midle_name}', '{cc}', '{sl.fm1_person_birth_place}', '{sl.oked}', '{sl.iin_bin}', '{memi}') RETURNING fma_person_id;";
                        var pri = Provider.RunScalar(query); //persn
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_persons1 (fm1_main_id, fm1_person_secondname, fm1_person_name, fm1_person_middle_name, fm1_memb_id)" +
                            $" VALUES ('{fmi}', '{sl.fm1_person_secondname_2}', '{sl.fm1_person_name_2}', '{sl.fm1_person_middle_name_2}', '{memi}') RETURNING fma_person_id;";
                        var pri1 = Provider.RunScalar(query); //persn
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_docs1 (fm1_main_id, doc_num, doc_series, doc_goverm_office, doc_date, doc_type, fm1_memb_id)" +
                           $" VALUES ('{fmi}', '{sl.doc_num_2}', '{sl.doc_series_2}', '{sl.goverm_office_2}', '{ee}', '{sl.doc_type_2}','{memi}') RETURNING fm1_doc_id;"; ///*, '{sell.doc_type}'
                        var doci1 = Provider.RunScalar(query); //doc
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            //return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_addrr1 (fm1_main_id, fm1_addrr_state, fm1_addrr_region, fm1_addrr_city, fm1_addrr_street, fm1_addrr_house_num, fm1_addrr_flat_num, fm1_addrr_post_index, phone, mail, fm1_memb_id)" +
                            $" VALUES ('{fmi}', '{sl.state_kaz_2}', '{sl.region_kaz_2}', '{sl.sity_kaz_2}', '{sl.street_2}', '{sl.house_num_2}', '{sl.flat_num_2}', '{sl.post_index_2}', '{sl.fm1_memb_contact_phone_2}', '{sl.fm1_memb_email_2}', '{memi}') RETURNING fm1_addrr_id;";
                        var adri1 = Provider.RunScalar(query); //adr1
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }

                        query = $"INSERT INTO fm1_addrr2 (fm1_main_id, fm1_addrr_state, fm1_addrr_region, fm1_addrr_city, fm1_addrr_street, fm1_addrr_house_num, fm1_addrr_flat_num, fm1_addrr_post_index, addition, fm1_memb_id)" +
                            $" VALUES ('{fmi}', '{sl.state_kaz_3}', '{sl.region_kaz_3}', '{sl.sity_kaz_3}', '{sl.street_3}', '{sl.house_num_3}', '{sl.flat_num_3}', '{sl.post_index_3}', '{sl.fm1_memb_memb_add_info_3}', '{memi}') RETURNING fm1_addrr_id;";
                        var adri2 = Provider.RunScalar(query); //adr2
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogDocument.NewFm1}', '{LogDocument.NewFm1}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }

                log.Info("fm1 update " + user + JsonConvert.SerializeObject(sell));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.Fm1Update}', '{LogDocument.Fm1Update}', '{LogSection.Document}', '{user}', '{response}', '{JsonConvert.SerializeObject(sell)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.Fm1Update}', '{LogDocument.Fm1Update}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        public string UpdateEpi(EpiModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();/*
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{response}'";
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }
            */
            try
            {
                var r = new List<ImageFile>();

                string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"), dd = "null";
                if (sell.ap_main_reg_date != null)
                    aa = sell.ap_main_reg_date.ToString("yyyy.MM.dd");
                if (sell.ap_send_rec_identity_card_date != null)
                    bb = sell.ap_send_rec_identity_card_date?.ToString("yyyy.MM.dd");
                if (sell.ap_transp_date_expected_arrival != null)
                    cc = sell.ap_transp_date_expected_arrival?.ToString("yyyy.MM.dd");
                if (sell.ap_main_decl_date != null)
                    dd = sell.ap_main_decl_date?.ToString("yyyy.MM.dd");
                var query = $"UPDATE ap_main SET(ap_main_reg_num, ap_main_country_code, ap_main_reg_date, ap_main_trans_kind_code, " +
                    $"ap_main_transit_direction_code, ap_main_electronic_document_sign, ap_main_declaration_kind, ap_main_subsoil_sign, " +
                    $"ap_main_seal_number, ap_main_seal_quantity, ap_main_language_cuesad, ap_main_recipient_country_code, ap_main_movement_code," +
                    $" ap_main_decl_num, ap_main_decl_date, ap_main_carnet)" +
                        $" = ('{sell.ap_main_reg_num}', '{sell.ap_main_country_code}', '{aa}', '{sell.ap_main_trans_kind_code}', " +
                        $"'{sell.ap_main_transit_direction_code}', '{sell.ap_main_electronic_document_sign}', '{sell.ap_main_declaration_kind}', " +
                        $"'{sell.ap_main_subsoil_sign}', '{sell.ap_main_seal_number}', '{sell.ap_main_seal_quantity}', '{sell.ap_main_language_cuesad}', " +
                        $"'{sell.ap_main_recipient_country_code}', '{sell.ap_main_movement_code}', '{sell.ap_main_decl_num}','{dd}', {sell.ap_main_carnet ?? 0} ) WHERE ref_doc_id='{response}' RETURNING ap_main_id;";
                var fmi = Provider.RunScalar(query); //main
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE attis_contract_docs SET attis_contract_doc_number='{sell.ap_main_reg_num}' where attis_contract_doc_id='{response}'";
                Provider.RunNonQuery(query);
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "epi"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }

                query = $"UPDATE ap_send_rec SET(ap_send_rec_identity_card_code, ap_send_rec_identity_card_series, ap_send_rec_identity_card_number, ap_send_rec_identity_card_date, ap_send_rec_organization_name)" +
                $" = ('{sell.ap_send_rec_identity_card_code}', '{sell.ap_send_rec_identity_card_series}', '{sell.ap_send_rec_identity_card_number}', '{bb}', '{sell.ap_send_rec_organization_name}') WHERE ap_main_id='{fmi}';";
                var doci = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"SELECT sender_id FROM ap_send_rec WHERE ap_main_id='{fmi}';";
                var send = Provider.RunScalar(query);
                query = $"UPDATE ap_members SET(ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                    $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                        $" = ('{sell.ap_memb_organization_name_1}', '{sell.ap_memb_short_name_1}', '{sell.ap_memb_bin_1}', '{sell.ap_memb_itn_1}', " +
                        $"'{sell.ap_member_postal_code_1}', '{sell.ap_member_country_name_1}', '{sell.ap_member_region_1}', '{sell.ap_member_city_1}', '{sell.ap_member_street_house_1}') WHERE ap_memb_id='{send}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"SELECT recipient_id FROM ap_send_rec WHERE ap_main_id='{fmi}';";
                var recp = Provider.RunScalar(query);
                query = $"UPDATE ap_members SET(ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                $" = ('{sell.ap_memb_organization_name_2}', '{sell.ap_memb_short_name_2}', '{sell.ap_memb_bin_2}', '{sell.ap_memb_itn_2}', " +
                $"'{sell.ap_member_postal_code_2}', '{sell.ap_member_country_name_2}', '{sell.ap_member_region_2}', '{sell.ap_member_city_2}', '{sell.ap_member_street_house_2}') WHERE ap_memb_id='{recp}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"SELECT fin_reg_id FROM ap_send_rec WHERE ap_main_id='{fmi}';";
                var finr = Provider.RunScalar(query);
                query = $"UPDATE ap_members SET(ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                $" = ('{sell.ap_memb_organization_name_3}', '{sell.ap_memb_short_name_3}', '{sell.ap_memb_bin_3}', '{sell.ap_memb_itn_3}', " +
                $"'{sell.ap_member_postal_code_3}', '{sell.ap_member_country_name_3}', '{sell.ap_member_region_3}', '{sell.ap_member_city_3}', '{sell.ap_member_street_house_3}') WHERE ap_memb_id='{finr}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"SELECT declarant_id FROM ap_send_rec WHERE ap_main_id='{fmi}';";
                var dclr = Provider.RunScalar(query);
                query = $"UPDATE ap_members SET(ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                $" = ('{sell.ap_memb_organization_name_4}', '{sell.ap_memb_short_name_4}', '{sell.ap_memb_bin_4}', '{sell.ap_memb_itn_4}', " +
                $"'{sell.ap_member_postal_code_4}', '{sell.ap_member_country_name_4}', '{sell.ap_member_region_4}', '{sell.ap_member_city_4}', '{sell.ap_member_street_house_4}') WHERE ap_memb_id='{dclr}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"SELECT driver_id FROM ap_send_rec WHERE ap_main_id='{fmi}';";
                var drvr = Provider.RunScalar(query);
                query = $"UPDATE ap_members SET(ap_memb_organization_name, ap_memb_short_name, ap_memb_bin, ap_memb_itn, " +
                $"ap_member_postal_code, ap_member_country_name, ap_member_region, ap_member_city, ap_member_street_house)" +
                $" = ('{sell.ap_memb_organization_name_5}', '{sell.ap_memb_short_name_5}', '{sell.ap_memb_bin_5}', '{sell.ap_memb_itn_5}', " +
                $"'{sell.ap_member_postal_code_5}', '{sell.ap_member_country_name_5}', '{sell.ap_member_region_5}', '{sell.ap_member_city_5}', '{sell.ap_member_street_house_5}') WHERE ap_memb_id='{drvr}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"SELECT decl_officer_id FROM ap_send_rec WHERE ap_main_id='{fmi}';";
                var pers = Provider.RunScalar(query);
                query = $"UPDATE ap_persons SET(ap_person_person_surname, ap_person_person_name,ap_person_person_middle_name, ap_person_person_post, ap_person_contact_phone)" +
                $" = ('{sell.ap_person_person_surname_1}', '{sell.ap_person_person_name_1}', '{sell.ap_person_person_middle_name_1}', '{sell.ap_person_person_post_1}', " +
                $"'{sell.ap_person_contact_phone_1}') WHERE ap_person_id='{pers}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"SELECT person1_id FROM ap_send_rec WHERE ap_main_id='{fmi}';";
                var pers1 = Provider.RunScalar(query);
                query = $"UPDATE ap_persons SET(ap_person_person_surname, ap_person_person_name,ap_person_person_middle_name, ap_person_person_post, ap_person_reg_country_code)" +
                $" = ('{sell.ap_person_person_surname_2}', '{sell.ap_person_person_name_2}', '{sell.ap_person_person_middle_name_2}', '{sell.ap_person_person_post_2}', " +
                $"'{sell.ap_person_reg_country_code_2}') WHERE ap_person_id='{pers1}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"UPDATE ap_transportations SET(ap_transp_information_type_code, ap_transp_customs_office, ap_transp_customs_country_code, " +
                    $"ap_transp_container_indicator, ap_transp_dispatch_country_code, ap_transp_destination_country_code, ap_transp_customs_office_inout, " +
                    $"ap_transp_customs_country_code_io, ap_transp_date_expected_arrival, ap_transp_transport_mode_code, ap_transp_transport_nationality_code, " +
                    $"ap_transp_vin, ap_transp_transport_identifier, ap_transp_active_transport_identifier, ap_transp_date_expected_arrival_time)" +
                    $" = ('{sell.ap_transp_information_type_code}', '{sell.ap_transp_customs_office}', '{sell.ap_transp_customs_country_code}'," +
                    $" '{sell.ap_transp_container_indicator}', '{sell.ap_transp_dispatch_country_code}', '{sell.ap_transp_destination_country_code}', '{sell.ap_transp_customs_office_inout}', " +
                    $"'{sell.ap_transp_customs_country_code_io}', '{cc}', '{sell.ap_transp_transport_mode_code}', '{sell.ap_transp_transport_nationality_code}'," +
                    $" '{sell.ap_transp_vin}', '{sell.ap_transp_transport_identifier}', '{sell.ap_transp_active_transport_identifier}', '{sell.ap_transp_date_expected_arrival_time ?? "0:0"}') WHERE ap_main_id='{fmi}';";
                var tran = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                var ss = sell.ap_good_total_cust_cost.GetValueOrDefault();

                var oc = "";
                if (sell.ap_good_origin_country_name != "null") oc = sell.ap_good_origin_country_name;
                query = $"UPDATE ap_goods SET(ap_good_origin_country_name, ap_good_specification_number, ap_good_specification_list_number, " +
                    $"ap_good_total_goods_number, ap_good_total_package_number, ap_good_total_sheet_number, ap_good_total_cust_cost, ap_good_cust_cost_currency_code)" +
                    $" = ('{oc}', '{sell.ap_good_specification_number}', '{sell.ap_good_specification_list_number}', " +
                    $"'{sell.ap_good_total_goods_number}', '{sell.ap_good_total_package_number}', '{sell.ap_good_total_sheet_number}', '{ss}', '{sell.ap_good_cust_cost_currency_code}') WHERE ap_good_main_id='{fmi}';";
                var apgi = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"DELETE FROM ap_good_data WHERE ap_main_id='{fmi}'";
                var del = Provider.RunScalar(query);
                if (sell.product != null)
                    foreach (var ln in sell.product)
                    {
                        query = $"INSERT INTO ap_good_data (ap_main_id, ap_good_data_goods_numeric, ap_good_data_list_numeric, ap_good_data_goods_description," +
                            $" ap_good_data_gross_weight_quantity, ap_good_data_net_weight_quantity, ap_good_data_invoiced_cost, ap_good_data_customs_cost, " +
                            $"ap_good_data_statistical_cost, ap_good_data_goods_tnved_code, ap_good_data_origin_country_code, " +
                            $"ap_good_data_delivery_terms_string_code, ap_good_data_quant, ap_good_data_ext_measure, ap_good_data_container_num, ap_good_data_places_name, ap_good_data_places, ap_good_data_packet) " +
                        $"VALUES('{fmi}', '{ln.ap_good_data_goods_numeric}', '{ln.ap_good_data_list_numeric}', '{ln.ap_good_data_goods_description}', '{ln.ap_good_data_gross_weight_quantity.GetValueOrDefault()}'," +
                        $" '{ln.ap_good_data_net_weight_quantity.GetValueOrDefault()}', '{ln.ap_good_data_invoiced_cost.GetValueOrDefault()}', " +
                        $"'{ln.ap_good_data_customs_cost.GetValueOrDefault()}', {ln.ap_good_data_statistical_cost.GetValueOrDefault()}, " +
                        $"'{ln.ap_good_data_goods_tnved_code}', '{ln.ap_good_data_origin_country_code}', '{ln.ap_good_data_delivery_terms_string_code}'," +
                        $" {ln.ap_good_data_quant ?? 0},'{ln.ap_good_data_ext_measure}', '{ln.ap_good_data_container_num}', '{ln.ap_good_data_places_name}', {ln.ap_good_data_places ?? 0}, {ln.ap_good_data_packet ?? 0});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM ap_prev_docs WHERE ap_main_id='{fmi}'";
                Provider.RunNonQuery(query);
                if (sell.prev_docs != null)
                    foreach (var ln in sell.prev_docs)
                    {
                        query = $"INSERT INTO ap_prev_docs (ap_main_id, ap_prev_doc_preceding_document_date, ap_prev_doc_preceding_document_number, PrecedingDocumentName, ap_prev_doc_kind) " +
                        $"VALUES('{fmi}', '{ln.ap_prev_doc_preceding_document_date}', '{ln.ap_prev_doc_preceding_document_number}', '{ln.PrecedingDocumentName}', '{ln.ap_prev_doc_kind}');";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                log.Info("epi update " + user + JsonConvert.SerializeObject(sell));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', '{response}', '{JsonConvert.SerializeObject(sell)}', 0);";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\", \"doc_id\":" + response + "}";
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.EpiUpdate}', '{LogDocument.EpiUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        [HttpPost]
        public string AddAwb(AwbModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {
                //var r = new List<ImageFile>();
                //int? rid = null; string type = "";
                //foreach (string fil in Request.Files)
                //{
                //    var hpf = Request.Files[fil];
                //    if (hpf.ContentLength == 0)
                //        continue;

                //    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                //    // hpf.SaveAs(savedFileName);
                //    var imgFile = new ImageFile
                //    {
                //        ID = 0,
                //        EntityId = response,
                //        Name = hpf.FileName,
                //        Length = hpf.ContentLength,
                //        Type = hpf.ContentType,
                //        Date = DateTime.Now,
                //        Image = new MemoryStream(),
                //        WidgetId = "awb"
                //    };

                //    hpf.InputStream.CopyTo(imgFile.Image);

                //    Provider.SaveFile(imgFile);

                //    r.Add(imgFile);
                //}
                //if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }

                //var docid = Provider.RunScalar(query);
                var query = $"INSERT INTO awb (awb_guid,awb_imp_date,awb_inp_time,user_id,1_airport_code,1a_acompany_code,1b_serial_num," +
                    $"1c_acomp_name_addr,2_sender_name_addr,4_recipient_name_addr,6_agent_name_addr,7_agent_iata_code,8_agent_acc,9_dest_airport," +
                    $"10_payment_data,11a_first_carrier_dest_point,11b_fist_carrier_name,11c_second_carrier_dest_point,11d_second_carrier_name," +
                    $"11e_third_carrier_dest_point,11f_third_carrier_name,12_curr_code,14a_pr_o,14b_col_l,15a_pr_d,15b_col_l,16_decl_value_carr," +
                    $"17_decl_value_cust,18_dest_airport,19ab_flight_date,20_insuranse_amount,21_handling_info,21a_custom_status,22a_pieses_no," +
                    $"22b_brutto,22c_measure,22d_rate_class,22e_commodity_item,22f_chargeable_weight,22g_rate_charge,22h_total,22i_nature_quant," +
                    $"22j_total_pieses,22l_total_sum_rev,22k_total_brutto,23_other_charges,24_weight_charge_sum,25_valuation_sum,26_tax_sum," +
                    $"27_total_other_charges,28_carrier_total_other_charges,30_total_prepaid_collect,32a_awb_create_date,32b_awb_place,32c_signature)" +
                    $" VALUES ('{sell.awb_guid}','{sell.awb_imp_date}','{sell.awb_inp_time}','{sell.user_id}','{sell.airport_code}'," +
                    $"'{sell.acompany_code}','{sell.serial_num}','{sell.acomp_name_addr}','{sell.sender_name_addr}','{sell.recipient_name_addr}'," +
                    $"'{sell.agent_name_addr}','{sell.agent_iata_code}','{sell.agent_acc}','{sell.dest_airport}','{sell.payment_data}'," +
                    $"'{sell.first_carrier_dest_point}','{sell.fist_carrier_name}','{sell.second_carrier_dest_point}','{sell.second_carrier_name}'," +
                    $"'{sell.third_carrier_dest_point}','{sell.third_carrier_name}','{sell.curr_code}','{sell.pr_o}','{sell.col_l}','{sell.pr_d}'," +
                    $"'{sell.col_l1}','{sell.decl_value_carr}','{sell.decl_value_cust}','{sell.dest_airport1}','{sell.flight_date}','{sell.insuranse_amount}'," +
                    $"'{sell.handling_info}','{sell.custom_status}','{sell.pieses_no}','{sell.brutto}','{sell.measure}','{sell.rate_class}'," +
                    $"'{sell.commodity_item}','{sell.chargeable_weight}','{sell.rate_charge}','{sell.total}','{sell.nature_quant}','{sell.total_pieses}'," +
                    $"'{sell.total_sum_rev}','{sell.total_brutto}','{sell.other_charges}','{sell.weight_charge_sum}','{sell.valuation_sum}','{sell.tax_sum}'," +
                    $"'{sell.total_other_charges}','{sell.carrier_total_other_charges}','{sell.total_prepaid_collect}','{sell.awb_create_date}'," +
                    $"'{sell.awb_place}','{sell.signature}') ";
                var abwid = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewAWB}', '{LogDocument.NewAWB}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (abwid > 0)
                {
                    log.Info("new awb  " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewAWB}', '{LogDocument.NewAWB}', '{LogSection.Document}', '{user}', '{abwid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + abwid;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewAWB}', '{LogDocument.NewAWB}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        public string UpdateAWB(AwbModel sell)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "awb"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }

                //var docid = Provider.RunScalar(query);
                var query = $"UPDATE awb SET(awb_guid,awb_imp_date,awb_inp_time,user_id,1_airport_code,1a_acompany_code,1b_serial_num," +
                    $"1c_acomp_name_addr,2_sender_name_addr,4_recipient_name_addr,6_agent_name_addr,7_agent_iata_code,8_agent_acc,9_dest_airport," +
                    $"10_payment_data,11a_first_carrier_dest_point,11b_fist_carrier_name,11c_second_carrier_dest_point,11d_second_carrier_name," +
                    $"11e_third_carrier_dest_point,11f_third_carrier_name,12_curr_code,14a_pr_o,14b_col_l,15a_pr_d,15b_col_l,16_decl_value_carr," +
                    $"17_decl_value_cust,18_dest_airport,19ab_flight_date,20_insuranse_amount,21_handling_info,21a_custom_status,22a_pieses_no," +
                    $"22b_brutto,22c_measure,22d_rate_class,22e_commodity_item,22f_chargeable_weight,22g_rate_charge,22h_total,22i_nature_quant," +
                    $"22j_total_pieses,22l_total_sum_rev,22k_total_brutto,23_other_charges,24_weight_charge_sum,25_valuation_sum,26_tax_sum," +
                    $"27_total_other_charges,28_carrier_total_other_charges,30_total_prepaid_collect,32a_awb_create_date,32b_awb_place,32c_signature)" +
                    $" = ('{sell.awb_guid}','{sell.awb_imp_date}','{sell.awb_inp_time}','{sell.user_id}','{sell.airport_code}'," +
                    $"'{sell.acompany_code}','{sell.serial_num}','{sell.acomp_name_addr}','{sell.sender_name_addr}','{sell.recipient_name_addr}'," +
                    $"'{sell.agent_name_addr}','{sell.agent_iata_code}','{sell.agent_acc}','{sell.dest_airport}','{sell.payment_data}'," +
                    $"'{sell.first_carrier_dest_point}','{sell.fist_carrier_name}','{sell.second_carrier_dest_point}','{sell.second_carrier_name}'," +
                    $"'{sell.third_carrier_dest_point}','{sell.third_carrier_name}','{sell.curr_code}','{sell.pr_o}','{sell.col_l}','{sell.pr_d}'," +
                    $"'{sell.col_l1}','{sell.decl_value_carr}','{sell.decl_value_cust}','{sell.dest_airport1}','{sell.flight_date}','{sell.insuranse_amount}'," +
                    $"'{sell.handling_info}','{sell.custom_status}','{sell.pieses_no}','{sell.brutto}','{sell.measure}','{sell.rate_class}'," +
                    $"'{sell.commodity_item}','{sell.chargeable_weight}','{sell.rate_charge}','{sell.total}','{sell.nature_quant}','{sell.total_pieses}'," +
                    $"'{sell.total_sum_rev}','{sell.total_brutto}','{sell.other_charges}','{sell.weight_charge_sum}','{sell.valuation_sum}','{sell.tax_sum}'," +
                    $"'{sell.total_other_charges}','{sell.carrier_total_other_charges}','{sell.total_prepaid_collect}','{sell.awb_create_date}'," +
                    $"'{sell.awb_place}','{sell.signature}') WHERE awb_id='{response}'";
                var abwid = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.AWBUpdate}', '{LogDocument.AWBUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (abwid > 0)
                {
                    log.Info("awb update " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.AWBUpdate}', '{LogDocument.AWBUpdate}', '{LogSection.Document}', '{user}', '{abwid}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + abwid;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
               $"VALUES('NOW()', '{(int)LogDocument.AWBUpdate}', '{LogDocument.AWBUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        [HttpPost]
        public string UpdateInsurance(cargo_insurance sell, string doc_id)
        {
            var response = Request["attis_contract_id"];
            string user = User.Identity.GetUserId();
            try
            {

                string aa = "2020.01.01", ab = "2020.01.01";
                if (sell.release_date != null)
                    aa = sell.release_date?.ToString("yyyy.MM.dd");
                if (sell.shipment_date != null)
                    ab = sell.shipment_date?.ToString("yyyy.MM.dd");

                var query = $"UPDATE cargo_insurance_form SET(policy_holder_name,represented_by, legal_address,actual_address," +
                    $"is_public_person,insured_details,insured_activity,beneficiary,beneficiary_details,shipping_name,package_info," +
                    $"cargo_cost,package_count,total_cost,release_date,containerization,cargo_placing, route, security_measures," +
                    $"transport_means, transfer_points, shipping_details,risk_a,risk_b1,risk_b2,additional_conditions, max_value_a, " +
                    $"max_value_b, max_value_c, max_value_d, max_value_e, max_value_f,insured_transport,insured_transport_amount,franchise," +
                    $"shipment_date,shipment_duration,insurance_stats,relevant_info,other)" +
                    $" = ('{sell.policy_holder_name}', '{sell.represented_by}', '{sell.legal_address}', '{sell.actual_address}'," +
                    $"{sell.is_public_person.GetValueOrDefault()},'{sell.insured_details}', '{sell.insured_activity}', '{sell.beneficiary}', '{sell.beneficiary_details}'," +
                    $"'{sell.shipping_name}','{sell.package_info}', {sell.cargo_cost.GetValueOrDefault()},{sell.package_count.GetValueOrDefault()}, {sell.total_cost.GetValueOrDefault()}," +
                    $"'{aa}', {sell.containerization.GetValueOrDefault()},'{sell.cargo_placing}','{sell.route}', '{sell.security_measures}','{sell.transport_means}', " +
                    $"'{sell.transfer_points}','{sell.shipping_details}',{sell.risk_a.GetValueOrDefault()},{sell.risk_b1.GetValueOrDefault()}, {sell.risk_b2.GetValueOrDefault()}," +
                    $"'{sell.additional_conditions}', {sell.max_value_a.GetValueOrDefault()}, {sell.max_value_b.GetValueOrDefault()}," +
                    $"{sell.max_value_c.GetValueOrDefault()}, {sell.max_value_d.GetValueOrDefault()},{sell.max_value_e.GetValueOrDefault()}," +
                    $"{sell.max_value_f.GetValueOrDefault()}, {sell.insured_transport.GetValueOrDefault()}," +
                    $"{sell.insured_transport_amount.GetValueOrDefault()}, '{sell.franchise}','{ab}', '{sell.shipment_duration}','{sell.insurance_stats}', " +
                    $"'{sell.relevant_info}', '{sell.other}') WHERE doc_id = '{doc_id}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.UpdateInsurance}', '{LogDocument.UpdateInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (sell.files != null)
                    foreach (var fl in sell.files)
                    {
                        query = $"UPDATE docimages SET doc_guid='{doc_id}' WHERE id='{fl.id}'";
                        Provider.RunNonQuery(query);
                    }
                log.Info("update insurance " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.UpdateInsurance}', '{LogDocument.UpdateInsurance}', '{LogSection.Document}', '{user}', '{doc_id}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";

            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewInsurance}', '{LogDocument.NewInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        [HttpPost]
        public string UpdateLiabilityInsurance(liability_insurance sell, string doc_id)
        {
            string user = User.Identity.GetUserId();
            try
            {
                
                string aa = "2020.01.01";
                if (sell.insurance_date != null)
                    aa = sell.insurance_date?.ToString("yyyy.MM.dd");

                var query = $"UPDATE liability_insurance SET(policy_holder_name, policy_holder_address, policy_holder_phone, policy_holder_email," +
                    $"policy_holder_bank, policy_holder_bin, policy_holder_bik,	is_resident, license_no, economy_sector, activity_type, " +
                    $"object_teritory, insured_details, life_insured_sum, property_insured_sum, cargo_insured_sum, total_insured_sum, " +
                    $"insurance_term, insurance_teritory, transport_type, transport_model, transport_name, transport_reg_number, " +
                    $"transport_body_number, transport_release_date, vehicles_number, previous_insurance_info, valid_contracts_info, " +
                    $"insurer_name, insurer_address, insurer_phone, insurance_date)" +
                    $" = ('{sell.policy_holder_name}', '{sell.policy_holder_address}', '{sell.policy_holder_phone}', '{sell.policy_holder_email}'," +
                    $"'{sell.policy_holder_bank}','{sell.policy_holder_bin}', '{sell.policy_holder_bik}', {sell.is_resident.GetValueOrDefault()}, '{sell.license_no}'," +
                    $"'{sell.economy_sector}','{sell.activity_type}', '{sell.object_teritory}','{sell.insured_details}', {sell.life_insured_sum.GetValueOrDefault()}," +
                    $"{sell.property_insured_sum.GetValueOrDefault()},{sell.cargo_insured_sum.GetValueOrDefault()},{sell.total_insured_sum.GetValueOrDefault()}," +
                    $"'{sell.insurance_term}','{sell.insurance_teritory}', '{sell.transport_type}','{sell.transport_model}','{sell.transport_name}', " +
                    $"'{sell.transport_reg_number}','{sell.transport_body_number}','{sell.transport_release_date}','{sell.vehicles_number}'," +
                    $"'{sell.previous_insurance_info}', '{sell.valid_contracts_info}','{sell.insurer_name}', '{sell.insurer_address}', '{sell.insurer_phone}','{aa}') WHERE doc_id='{doc_id}';";

                var insc = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.UpdateLiabilityInsurance}', '{LogDocument.UpdateLiabilityInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                else
                {
                    if (sell.files != null)
                        foreach (var fl in sell.files)
                        {
                            query = $"UPDATE docimages SET doc_guid='{doc_id}' WHERE id='{fl.id}'";
                            Provider.RunNonQuery(query);
                        }
                    log.Info("update liability insurance " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.UpdateLiabilityInsurance}', '{LogDocument.UpdateLiabilityInsurance}', '{LogSection.Document}', '{user}', '{doc_id}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewInsurance}', '{LogDocument.NewInsurance}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        public string DeleteInsurance(string doc_id)
        {
            var user = User.Identity.GetUserId();
            //string query = $"SELECT t2.attis_contract_owner FROM attis_contract_docs t1 LEFT JOIN attis_contracts t2 ON t1.attis_contract_doc_contract = t2.attis_contract_id WHERE t1.attis_contract_doc_id='{doc_id}'";
            /*string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }*/
            string query = $"DELETE FROM cargo_insurance_form WHERE doc_id='{doc_id}' RETURNING document_id;";
            var result = Provider.RunScalar(query);
           
            query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}' ;";
            Provider.RunNonQuery(query);
            
            log.Info("delete insurance " + user + JsonConvert.SerializeObject(doc_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.DeleteInsurance}', '{LogDocument.DeleteInsurance}', '{LogSection.Document}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
            Provider.RunNonQuery(query);
            return "\"ok\"";
        }

        public string DeleteLiabilityInsurance(string doc_id)
        {
            var user = User.Identity.GetUserId();
            //string query = $"SELECT t2.attis_contract_owner FROM attis_contract_docs t1 LEFT JOIN attis_contracts t2 ON t1.attis_contract_doc_contract = t2.attis_contract_id WHERE t1.attis_contract_doc_id='{doc_id}'";
            /*string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }*/
            string query = $"DELETE FROM liability_insurance WHERE doc_id='{doc_id}' RETURNING document_id;";
            var result = Provider.RunScalar(query);

            query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}' ;";
            Provider.RunNonQuery(query);

            log.Info("delete insurance " + user + JsonConvert.SerializeObject(doc_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.DeleteLiabilityInsurance}', '{LogDocument.DeleteLiabilityInsurance}', '{LogSection.Document}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
            Provider.RunNonQuery(query);
            return "\"ok\"";
        }
        public string getPackingList(string doc_id)
        {
            //string user = User.Identity.GetUserId();
            var query = $"SELECT * FROM packing_list WHERE ref_document_id = '{doc_id}';";
            lock (Provider.Locker)
            {
                var reader = Provider.RunQuery(query);
                var lists = new List<PackingList>();
                var pklist = new List<PackingList>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var lis = new PackingList
                        {
                            list_id = reader.GetFieldValueOrDefault<int>("list_id"),
                        };
                        lis.DocumentID = reader["document_id"].ToString();
                        lis.ref_document_id = reader["ref_document_id"].ToString();
                        lis.gross_weight_quantity = reader.GetFieldValueOrDefault<float>("gross_weight_quantity");
                        lis.net_weight_quantity = reader.GetFieldValueOrDefault<float>("net_weight_quantity");
                        lis.comp2 = reader["consignor"].ToString();
                        lis.comp1 = reader["consignee"].ToString();
                        lis.delivery_terms = new LibModel();
                        lis.delivery_terms.value = reader["delivery_terms_numeric_code"].ToString();
                        lis.delivery_terms.display_text = reader["delivery_terms_string_code"].ToString();
                        lis.terms_description = reader["terms_description"].ToString();
                        lis.contract_pr_document_name = reader["contract_pr_document_name"].ToString();
                        lis.contract_pr_document_number = reader["contract_pr_document_number"].ToString();
                        lis.contract_pr_document_date = GetDateTimeFromString(reader["contract_pr_document_date"].ToString());
                        lis.invoice_pr_document_name = reader["invoice_pr_document_name"].ToString();
                        lis.invoice_pr_document_number = reader["invoice_pr_document_number"].ToString();
                        lis.invoice_pr_document_date = GetDateTimeFromString(reader["invoice_pr_document_date"].ToString());
                        lis.registration_pr_document_name = reader["registration_pr_document_name"].ToString();
                        lis.registration_pr_document_number = reader["registration_pr_document_number"].ToString();
                        lis.registration_pr_document_date = GetDateTimeFromString(reader["registration_pr_document_date"].ToString());
                        lists.Add(lis);
                    }
                    reader.Close();
                    var settings = new JsonSerializerSettings
                    {
                        DateFormatString = "yyyy-MM-dd",
                        DateTimeZoneHandling = DateTimeZoneHandling.Utc
                    };

                    foreach (var lst in lists)
                    {
                        query = $"SELECT t1.doc_guid, t3.org_name, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" LEFT JOIN organizations t3 ON t2.\"InvoiceSeller\" = t3.org_code WHERE t2.\"DocumentID\" = '{lst.DocumentID}';";
                        //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
                        reader = Provider.RunQuery(query);
                        var list = new DocModel();
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                list.DocumentID = reader["DocumentID"].ToString();
                                list.DocGuid = reader["doc_guid"].ToString();
                                list.DocumentNumber = reader["DocumentNumber"].ToString();
                                list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                                list.CurrencyCode = reader["CurrencyCode"].ToString();
                                list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                                list.PlacesDescription = reader["PlacesDescription"].ToString();
                                list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                                list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                                list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                                list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                                list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                                list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                                list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                                list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                                list.InvoiceByer = reader["InvoiceByer"].ToString();
                                list.InvoiceSeller = reader["InvoiceSeller"].ToString();
                                list.SellerName = reader["org_name"].ToString();
                            }
                            reader.Close();
                            reader = null;
                            lst.invoice = list;
                            var query1 = $"SELECT * FROM pkglist_goods WHERE list_id = '{list.DocumentID}'";
                            var reader1 = Provider.RunQuery(query1);
                            var product = new List<pkglist_goods>();
                            if (reader1 != null)
                            {
                                while (reader1.Read())
                                {
                                    var rep1 = new pkglist_goods
                                    {
                                        goodsdescription = reader1["goodsdescription"].ToString(),
                                    };
                                    rep1.id = reader1.GetFieldValueOrDefault<int>("id");
                                    rep1.goodsquantity = reader1.GetFieldValueOrDefault<float>("goodsquantity");
                                    rep1.placegoodsquantity = reader1.GetFieldValueOrDefault<float>("placegoodsquantity");
                                    rep1.measureunitqualifiercode = reader1["measureunitqualifiercode"].ToString();
                                    rep1.grossweightquantity = reader1.GetFieldValueOrDefault<float>("grossweightquantity");
                                    rep1.netweightquantity = reader1.GetFieldValueOrDefault<float>("netweightquantity");
                                    rep1.dimensions = reader1["dimensions"].ToString();
                                    rep1.goodsvolume = reader1.GetFieldValueOrDefault<float>("goodsvolume");
                                    rep1.volumeunitqualifier = new LibModel();
                                    rep1.volumeunitqualifier.display_text = reader1["volumeunitqualifiername"].ToString();
                                    rep1.measureunitqualifiername = reader1["measureunitqualifiername"].ToString();
                                    rep1.measureunitqualifier = new LibModel();
                                    rep1.measureunitqualifier.display_text = reader1["measureunitqualifiername"].ToString();
                                    rep1.measureunitqualifier.value = reader1["measureunitqualifiercode"].ToString();
                                    rep1.goodmarking = reader1["goodmarking"].ToString();
                                    product.Add(rep1);
                                }
                                reader1.Close();
                                reader1 = null;
                            }
                            lst.goods = new List<pkglist_goods>(product);
                            if (reader == null)
                                lst.transports = new List<pkglist_transportmeans>(getPkgTransp(lst.list_id));
                            lst.places = new List<pkglist_totalplacesquantity>(getPkgPlacesTotal(lst.list_id));
                            if (reader == null)
                            {
                                lst.consignee = new comp();
                                lst.consignee = getComp(lst.comp1);
                            }
                            if (reader == null)
                            {
                                lst.consignor = new comp();
                                lst.consignor = getComp(lst.comp2);
                            }
                            foreach (var gd in lst.goods)
                            {
                                gd.packagings = new List<pkglist_goods_placesquantity>(getPkgPlaces(lst.list_id, gd.id)); //T.D. invoice id
                            }
                        }
                    }
                    //return Json(san, JsonRequestBehavior.AllowGet);
                    return JsonConvert.SerializeObject(lists, settings);
                }
            }

            return Provider.lastError;

        }

        private List<pkglist_transportmeans> getPkgTransp(int doc_id)
        {
            var list = new List<pkglist_transportmeans>();
            var query = $"SELECT * FROM pkglist_transportmeans WHERE list_id = '{doc_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var ls = new pkglist_transportmeans();
                    ls.packaging_transport_number = reader["number"].ToString();
                    ls.packaging_transporttypecode = new LibModel();
                    ls.packaging_transporttypecode.value = reader["modecode"].ToString();
                    ls.packaging_transportcountrycode = new LibModel();
                    ls.packaging_transportcountrycode.value = reader["nationalitycode"].ToString();
                    ls.packaging_transportleading = reader.GetFieldValueOrDefault<int>("moverindicator");
                    list.Add(ls);
                }
                reader.Close();
                reader = null;
                return list;
            }
            return list;
        }

        private List<pkglist_goods_packinginfo> getPkgPkInfo(int doc_id)
        {
            var list = new List<pkglist_goods_packinginfo>();
            var query = $"SELECT * FROM pkglist_goods_packinginfo WHERE goods_id = '{doc_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var ls = new pkglist_goods_packinginfo();
                    ls.packingcode = new LibModel();
                    ls.packingcode.value = reader["packingcode"].ToString();
                    ls.placesdescription = reader["placesdescription"].ToString();
                    ls.placesquantity = reader["placesquantity"].ToString();
                    list.Add(ls);
                }
                reader.Close();
                reader = null;
                return list;
            }
            return list;
        }
        private List<pkglist_goods_placesquantity> getPkgPlaces(int lstid, int? doc_id)
        {
            var list = new List<pkglist_goods_placesquantity>();
            var query = $"SELECT * FROM pkglist_goods_placesquantity WHERE list_id = '{lstid}' AND goods_id = '{doc_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var ls = new pkglist_goods_placesquantity();
                    ls.packging_placescount = reader.GetFieldValueOrDefault<int>("placesquantity");
                    ls.packaging_packagingtypecode = new LibModel();
                    ls.packaging_packagingtypecode.value = reader["packingcode"].ToString();
                    ls.packaging_partialplacescount = reader["placespartquantity"].ToString();
                    ls.packaging_placesdescription = reader["placesdescription"].ToString();
                    list.Add(ls);
                }
                reader.Close();
                reader = null;
                return list;
            }
            return list;
        }

        private List<pkglist_totalplacesquantity> getPkgPlacesTotal(int doc_id)
        {
            var list = new List<pkglist_totalplacesquantity>();
            var query = $"SELECT * FROM pkglist_totalplacesquantity WHERE list_id = '{doc_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var ls = new pkglist_totalplacesquantity();
                    ls.packging_placescount = reader["placesquantity"].ToString();
                    ls.packaging_packagingtypecode = new LibModel();
                    ls.packaging_packagingtypecode.value = reader["packingcode"].ToString();
                    ls.packaging_placesdescription = reader["placesdescription"].ToString();
                    //ls.packaging_partialplacescount = reader["packaging_partialplacescount"].ToString();
                    list.Add(ls);
                }
                reader.Close();
                reader = null;
                return list;
            }
            return list;
        }

        [HttpPost]
        public string AddPackingList(List<PackingList> packs, string attis_contract_id, string doc_id)
        {
            string user = User.Identity.GetUserId();
            int lstid = 0;
            if (packs != null)
                foreach (var pklst in packs)
                {
                    try
                    {
                        var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, category, attis_contract_doc_date)" +
                        $" VALUES ('1', '{attis_contract_id}', '7', 'commerce', now() ) RETURNING \"attis_contract_doc_id\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
                        var docid = Provider.RunScalar(query);
                        string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), ab = DateTime.Now.ToString("yyyy.MM.dd");
                        string cg = "", ce = "";
                        if (pklst.consignor != null)
                            cg = pklst.consignor.org_code;
                        if (pklst.consignee != null)
                            ce = pklst.consignee.org_code;
                        if (pklst.invoice_pr_document_date != null)
                            aa = pklst.invoice_pr_document_date?.ToString("yyyy.MM.dd");
                        if (pklst.registration_pr_document_date != null)
                            bb = pklst.registration_pr_document_date?.ToString("yyyy.MM.dd");
                        if (pklst.contract_pr_document_date != null)
                            ab = pklst.contract_pr_document_date?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO packing_list (document_id, ref_document_id, gross_weight_quantity, net_weight_quantity, consignor, " +
                            $"consignee, delivery_terms_numeric_code, delivery_terms_string_code, terms_description, contract_pr_document_name, " +
                            $"contract_pr_document_number, contract_pr_document_date, invoice_pr_document_name,invoice_pr_document_number, " +
                            $"invoice_pr_document_date, registration_pr_document_name, registration_pr_document_number, registration_pr_document_date) " +
                            $"VALUES('{pklst.invoice.DocumentID}', '{docid}', {pklst.gross_weight_quantity}, {pklst.net_weight_quantity}, " +
                            $"'{cg}', '{ce}', '{pklst.delivery_terms.value}', '{pklst.delivery_terms.display_text}', " +
                            $"'{pklst.terms_description}', '{pklst.contract_pr_document_name}', '{pklst.contract_pr_document_number}', " +
                            $"'{ab}', '{pklst.invoice_pr_document_name}', '{pklst.invoice_pr_document_number}', " +
                            $"'{aa}', '{pklst.registration_pr_document_name}', '{pklst.registration_pr_document_number}', '{bb}') RETURNING list_id;";
                        lstid = Provider.RunScalar(query);
                        if (Provider.lastError != "")
                        {
                            var tes = query;
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', @p0, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"list error " + Provider.lastError + "\"}";
                        }
                        if (lstid > 0)
                        {
                            if (pklst.goods != null)
                                foreach (var gds in pklst.goods)
                                {
                                    query = $"INSERT INTO pkglist_goods (list_id, goodsdescription, goodsquantity, placegoodsquantity," +
                                        $"measureunitqualifiername, grossweightquantity, netweightquantity, dimensions, goodsvolume," +
                                        $"volumeunitqualifiername, measureunitqualifiercode, goodmarking) " +
                                        $"VALUES ({pklst.invoice.DocumentID}, '{gds.goodsdescription}', {gds.goodsquantity.GetValueOrDefault()}, {gds.placegoodsquantity.GetValueOrDefault()}, " +
                                        $"'{gds.measureunitqualifiername}', {gds.grossweightquantity.GetValueOrDefault()}, {gds.netweightquantity.GetValueOrDefault()}, '{gds.dimensions}'," +
                                        $"{gds.goodsvolume.GetValueOrDefault()}, '{gds.volumeunitqualifier.display_text}', '{gds.measureunitqualifiercode}', '{gds.goodmarking}') RETURNING id;";
                                    var gdi = Provider.RunScalar(query);
                                    if (Provider.lastError != "")
                                    {

                                        var query1 = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                        Provider.RunNonQuery(query1, JsonConvert.SerializeObject(Provider.lastError));
                                        return "{\"status\":\"goods error " + Provider.lastError + "\"}";
                                    }
                                    if (gds.packagings != null)
                                        foreach (var pkg in gds.packagings)
                                        {
                                            query = $"INSERT INTO pkglist_goods_placesquantity (list_id, goods_id, placesquantity, placesdescription, packingcode, placespartquantity) " +
                                            $"VALUES ('{lstid}', '{gdi}', {pkg.packging_placescount.GetValueOrDefault()}, '{pkg.packaging_placesdescription}', '{pkg.packaging_packagingtypecode.value}', '{pkg.packaging_partialplacescount}');";
                                            Provider.RunNonQuery(query);
                                            if (Provider.lastError != "")
                                            {
                                                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                        $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                                return "{\"status\":\"places error " + Provider.lastError + "\"}";
                                            }
                                        }
                                }
                            if (pklst.transports != null)
                                foreach (var trs in pklst.transports)
                                {
                                    query = $"INSERT INTO pkglist_transportmeans (list_id, number, modecode, nationalitycode, moverindicator) " +
                                        $"VALUES ('{lstid}', '{trs.packaging_transport_number}', '{trs.packaging_transporttypecode.value}', " +
                                        $"'{trs.packaging_transportcountrycode.value}', {trs.packaging_transportleading.GetValueOrDefault()});";
                                    Provider.RunNonQuery(query);
                                }
                            if (pklst.places != null)
                                foreach (var pls in pklst.places)
                                {
                                    query = $"INSERT INTO pkglist_totalplacesquantity (list_id, placesquantity, placesdescription, packingcode) " +
                                        $"VALUES ('{lstid}', '{pls.packging_placescount}', '{pls.packaging_placesdescription}', '{pls.packaging_packagingtypecode.value}');";
                                    Provider.RunNonQuery(query);
                                    if (Provider.lastError != "")
                                    {
                                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                        Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                        return "{\"status\":\"places error " + Provider.lastError + "\"}";
                                    }
                                }

                            log.Info("new package list  " + user + JsonConvert.SerializeObject(pklst));
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                        $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(pklst)}', 0);";
                            Provider.RunNonQuery(query);
                            return "{\"status\":\"ok\", \"doc_id\":" + docid + "}";
                        }
                        else return "error " + lstid;
                    }
                    catch (Exception ex)
                    {
                        var exception = JsonConvert.SerializeObject(new xp
                        {
                            Exception = ex.Message,
                            InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                        });
                        var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                        $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                        Provider.RunNonQuery(query, JsonConvert.SerializeObject(exception));
                        return "error" + ex.Message;
                    }
                }
            if (lstid > 0)
                return "ok";
            else return "empty list";
        }

        [HttpPost]
        public string UpdatePackingList(List<PackingList> packs, string list_id)
        {
            string user = User.Identity.GetUserId();
            foreach (var pklst in packs)
            {
                try
                {
                    string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), ab = DateTime.Now.ToString("yyyy.MM.dd");
                    if (pklst.invoice_pr_document_date != null)
                        aa = pklst.invoice_pr_document_date?.ToString("yyyy.MM.dd");
                    if (pklst.registration_pr_document_date != null)
                        bb = pklst.registration_pr_document_date?.ToString("yyyy.MM.dd");
                    if (pklst.contract_pr_document_date != null)
                        ab = pklst.contract_pr_document_date?.ToString("yyyy.MM.dd");
                    var query = $"UPDATE packing_list SET(document_id, gross_weight_quantity, net_weight_quantity, consignor, " +
                        $"consignee, delivery_terms_numeric_code, delivery_terms_string_code, terms_description, contract_pr_document_name, " +
                        $"contract_pr_document_number, contract_pr_document_date, invoice_pr_document_name,invoice_pr_document_number, " +
                        $"invoice_pr_document_date, registration_pr_document_name, registration_pr_document_number, registration_pr_document_date) " +
                        $"=('{pklst.invoice.DocumentID}',{pklst.gross_weight_quantity}, {pklst.net_weight_quantity}, " +
                        $"'{pklst.consignor.org_code}', '{pklst.consignee.org_code}', '{pklst.delivery_terms.value}', '{pklst.delivery_terms.display_text}', " +
                        $"'{pklst.terms_description}', '{pklst.contract_pr_document_name}', '{pklst.contract_pr_document_number}', " +
                        $"'{ab}', '{pklst.invoice_pr_document_name}', '{pklst.invoice_pr_document_number}', " +
                        $"'{aa}', '{pklst.registration_pr_document_name}', '{pklst.registration_pr_document_number}', '{bb}') WHERE ref_document_id='{list_id}' RETURNING list_id;";
                    var lstid = Provider.RunScalar(query);
                    if (Provider.lastError != "")
                    {
                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                        Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                        return "{\"status\":\"list error " + Provider.lastError + "\"}";
                    }
                    if (lstid > 0)
                    {
                        query = $"DELETE FROM pkglist_goods WHERE list_id='{pklst.invoice.DocumentID}';";
                        Provider.RunNonQuery(query);
                        query = $"DELETE FROM pkglist_goods_placesquantity WHERE list_id='{lstid}';";
                        Provider.RunNonQuery(query);
                        if (pklst.goods != null)
                            foreach (var gds in pklst.goods)
                            {
                                query = $"INSERT INTO pkglist_goods (list_id, goodsdescription, goodsquantity, placegoodsquantity," +
                                    $"measureunitqualifiername, grossweightquantity, netweightquantity, dimensions, goodsvolume," +
                                    $"volumeunitqualifiername, measureunitqualifiercode, goodmarking) " +
                                    $"VALUES ({pklst.invoice.DocumentID}, '{gds.goodsdescription}', {gds.goodsquantity.GetValueOrDefault()}, {gds.placegoodsquantity.GetValueOrDefault()}, " +
                                    $"'{gds.measureunitqualifiername}', {gds.grossweightquantity.GetValueOrDefault()}, {gds.netweightquantity.GetValueOrDefault()}, '{gds.dimensions}'," +
                                    $"{gds.goodsvolume.GetValueOrDefault()}, '{gds.volumeunitqualifier.display_text}', '{gds.measureunitqualifiercode}', '{gds.goodmarking}') RETURNING id;";
                                var gdi = Provider.RunScalar(query);
                                if (Provider.lastError != "")
                                {
                                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                    return "{\"status\":\"goods error " + Provider.lastError + "\"}";
                                }
                                if (gds.packagings != null)
                                    foreach (var pkg in gds.packagings)
                                    {
                                        query = $"INSERT INTO pkglist_goods_placesquantity (list_id, goods_id, placesquantity, placesdescription, packingcode, placespartquantity) " +
                                        $"VALUES ('{lstid}', '{gdi}', {pkg.packging_placescount.GetValueOrDefault()}, '{pkg.packaging_placesdescription}', '{pkg.packaging_packagingtypecode.value}', '{pkg.packaging_partialplacescount}');";
                                        Provider.RunNonQuery(query);
                                        if (Provider.lastError != "")
                                        {
                                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                                    $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                            return "{\"status\":\"packagings error " + Provider.lastError + "\"}";
                                        }
                                    }
                            }

                        query = $"DELETE FROM pkglist_transportmeans WHERE list_id='{lstid}';";
                        Provider.RunNonQuery(query);
                        if (pklst.transports != null)
                            foreach (var trs in pklst.transports)
                            {
                                query = $"INSERT INTO pkglist_transportmeans (list_id, number, modecode, nationalitycode, moverindicator) " +
                                    $"VALUES ('{lstid}', '{trs.packaging_transport_number}', '{trs.packaging_transporttypecode.value}', " +
                                    $"'{trs.packaging_transportcountrycode.value}', {trs.packaging_transportleading.GetValueOrDefault()});";
                                Provider.RunNonQuery(query);
                                if (Provider.lastError != "")
                                {
                                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                    return "{\"status\":\"transports error " + Provider.lastError + "\"}";
                                }
                            }

                        query = $"DELETE FROM pkglist_totalplacesquantity WHERE list_id='{lstid}';";
                        Provider.RunNonQuery(query);
                        if (pklst.places != null)
                            foreach (var pls in pklst.places)
                            {
                                query = $"INSERT INTO pkglist_totalplacesquantity (list_id, placesquantity, placesdescription, packingcode) " +
                                $"VALUES ('{lstid}', '{pls.packging_placescount}', '{pls.packaging_placesdescription}', '{pls.packaging_packagingtypecode.value}');";
                                Provider.RunNonQuery(query);
                                if (Provider.lastError != "")
                                {
                                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                    return "{\"status\":\"places error " + Provider.lastError + "\"}";
                                }
                            }
                        log.Info("update  package list " + user + JsonConvert.SerializeObject(pklst));
                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', '{list_id}', '{JsonConvert.SerializeObject(pklst)}', 0);";
                        Provider.RunNonQuery(query);
                        return "{\"status\":\"ok\", \"doc_id\":" + list_id + "}";
                    }
                    else return "error " + lstid;
                }
                catch (Exception ex)
                {
                    var exception = JsonConvert.SerializeObject(new xp
                    {
                        Exception = ex.Message,
                        InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                    });
                    var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, exception);
                    return "error";
                }
            }
            return "ok";
        }
        public string DeletePackingList(string list_id)
        {
            var user = User.Identity.GetUserId();
            //string query = $"SELECT t2.attis_contract_owner FROM attis_contract_docs t1 LEFT JOIN attis_contracts t2 ON t1.attis_contract_doc_contract = t2.attis_contract_id WHERE t1.attis_contract_doc_id='{doc_id}'";
            /*string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }*/
            string query = $"DELETE FROM packing_list WHERE ref_document_id='{list_id}' RETURNING document_id;";
            var result = Provider.RunScalar(query);
            query = $"DELETE FROM pkglist_goods WHERE list_id='{result}';";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{list_id}' ;";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM pkglist_goods_placesquantity WHERE list_id='{result}' ;";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM pkglist_transportmeans WHERE list_id='{result}' ;";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM pkglist_totalplacesquantity WHERE list_id='{result}' ;";
            Provider.RunNonQuery(query);
            log.Info("delete package list " + user + JsonConvert.SerializeObject(list_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.DeletePackingList}', '{LogDocument.DeletePackingList}', '{LogSection.Document}', '{user}', '', '{list_id}', '{JsonConvert.SerializeObject(list_id)}', 0);";
            Provider.RunNonQuery(query);
            return "\"ok\"";
        }

        public string DeleteCMR(string doc_id)
        {
            var user = User.Identity.GetUserId();
            string query = $"SELECT cmr_id FROM \"CMR\" WHERE RefDocumentID = '{doc_id}'";
            var cmr_id = Provider.RunScalar(query);

            if (cmr_id > 0)
            {
                query = $"DELETE FROM places_list WHERE cmr_id = '{cmr_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM \"CMRGoods\" WHERE \"CmrId\" = '{cmr_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM \"TakingCargoPlace\" WHERE cmr_id = '{cmr_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM \"CMR\" WHERE cmr_id = '{cmr_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}'";
                Provider.RunNonQuery(query);
                log.Info("delete document " + user + JsonConvert.SerializeObject(doc_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogContract.DeleteDocument}', '{LogContract.DeleteDocument}', '{LogSection.Contract}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
                Provider.RunNonQuery(query);
            }

            return "\"ok\"";
        }

        public string DeleteInvoice(string doc_id)
        {
            var user = User.Identity.GetUserId();
            string query = $"SELECT \"DocumentID\" FROM \"Invoice\" WHERE RefDocumentID = '{doc_id}'";
            var invoice_id = Provider.RunScalar(query);

            if (invoice_id > 0)
            {
                query = $"DELETE FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{invoice_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM \"Invoice\" WHERE \"DocumentID\" = '{invoice_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}'";
                Provider.RunNonQuery(query);
                log.Info("delete document " + user + JsonConvert.SerializeObject(doc_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogContract.DeleteDocument}', '{LogContract.DeleteDocument}', '{LogSection.Contract}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
                Provider.RunNonQuery(query);
            }
            return "\"ok\"";
        }

        public string DeleteFm1(string doc_id)
        {
            var user = User.Identity.GetUserId();
            string query = $"SELECT fm1_main_id FROM fm1_main WHERE ref_doc_id = '{doc_id}'";
            var fm1_id = Provider.RunScalar(query);

            if (fm1_id > 0)
            {
                query = $"DELETE FROM fm1_addrr2 WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_addrr1 WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_docs1 WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_persons1 WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_persons WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_members WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_operations WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_docs WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_addrr WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_subject WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM fm1_main WHERE fm1_main_id = '{fm1_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}'";
                Provider.RunNonQuery(query);
                log.Info("delete document " + user + JsonConvert.SerializeObject(doc_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogContract.DeleteDocument}', '{LogContract.DeleteDocument}', '{LogSection.Contract}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
                Provider.RunNonQuery(query);
            }
            return "\"ok\"";
        }

        public string DeleteEPI(string doc_id)
        {
            var user = User.Identity.GetUserId();
            string query = $"SELECT ap_main_id FROM ap_main WHERE ref_doc_id = '{doc_id}'";
            var epi_id = Provider.RunScalar(query);


            if (epi_id > 0)
            {
                query = $"DELETE FROM ap_prev_docs WHERE ap_main_id = '{epi_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM ap_good_data WHERE ap_main_id = '{epi_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM ap_goods WHERE ap_main_id = '{epi_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM ap_transportations WHERE ap_main_id = '{epi_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM ap_send_rec WHERE ap_main_id = '{epi_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM ap_main WHERE ap_main_id = '{epi_id}'";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}'";
                Provider.RunNonQuery(query);
                log.Info("delete document " + user + JsonConvert.SerializeObject(doc_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                                $"VALUES('NOW()', '{(int)LogContract.DeleteDocument}', '{LogContract.DeleteDocument}', '{LogSection.Contract}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
                Provider.RunNonQuery(query);
            }
            return "\"ok\"";
        }

        public string DeleteAWB(string doc_id)
        {

            return "\"ok\"";
        }

        public string GetFirmName()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
            var result = Provider.RunQueryStr(query);
            query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id =@p0;";
            var res = Provider.RunNoStr(query, user);

            return result;
        }

        public string GetFirm()
        {
            var user = User.Identity.GetUserId();
            //var name = User.Identity.GetUserName();
            var list = new Firm();
            if (user != null)
            {
                string query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
                list.org_name = Provider.RunQueryStr(query);
                query = "SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + user + "';";
                list.org_code = Provider.RunQueryStr(query);
                return JsonConvert.SerializeObject(list);
            }
            else return "login first";
        }

        public string Delete(string doc_id)
        {
            var user = User.Identity.GetUserId();
            string query = $"SELECT t2.attis_contract_owner FROM attis_contract_docs t1 LEFT JOIN attis_contracts t2 ON t1.attis_contract_doc_contract = t2.attis_contract_id WHERE t1.attis_contract_doc_id='{doc_id}'";
            /*string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {
                return Json("Unauthorized");
            }*/
            query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}';";
            var result = Provider.RunScalar(query);
            log.Info("delete document " + user + JsonConvert.SerializeObject(doc_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogContract.DeleteDocument}', '{LogContract.DeleteDocument}', '{LogSection.Contract}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
            Provider.RunNonQuery(query);
            return "\"ok\"";
        }

        public string getFirmCeo(string user_id)
        {
            var user = User.Identity.GetUserId();
            //var name = User.Identity.GetUserName();
            var list = new Ceos();
            if (user != null)
            {
                lock (Provider.Locker)
                {
                    string query = $"SELECT t2.* FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user_id}';";
                    var reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            list.org_name = reader["org_name"].ToString();
                            list.org_code = reader["org_code"].ToString();
                            list.company_address = reader["company_address"].ToString();
                            list.company_ceo = reader["company_ceo"].ToString();
                        }
                        reader.Close();
                        //list.persons = per;
                        return JsonConvert.SerializeObject(list);
                    }
                }
            }
            return "login first";
        }

        public string getFirmCeoXML(string user_id)
        {
            var user = User.Identity.GetUserId();
            //var name = User.Identity.GetUserName();
            var list = new Ceos();
            if (user != null)
            {
                lock (Provider.Locker)
                {
                    string query = $"SELECT t2.* FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user_id}';";
                    var reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            list.org_name = reader["org_name"].ToString();
                            list.org_code = reader["org_code"].ToString();
                            list.company_address = reader["company_address"].ToString();
                            list.company_ceo = reader["company_ceo"].ToString();
                        }
                        reader.Close();

                        XmlSerializer xsSubmit = new XmlSerializer(typeof(Ceos));
                        var xml = "";

                        using (var sww = new StringWriter())
                        {
                            using (XmlWriter writer = XmlWriter.Create(sww))
                            {
                                xsSubmit.Serialize(writer, list);
                                xml = sww.ToString(); // Your XML
                            }
                        }
                        return xml;
                    }
                }
            }
            return "login first";
        }

        public comp getComp(string bin)
        {
            var list = new comp();
            lock (Provider.Locker)
            {
                string query = "SELECT t1.*, t4.person_email, t5.person_phone_number, t2.*, t2.country as ctr, t6.*, t3.* FROM organizations t2" +
    " LEFT JOIN persons t1 ON t1.org_id = t2.org_id " +
    "LEFT JOIN persons_emails t4 ON t1.person_id = t4.person_id LEFT JOIN persons_phones t5 ON t1.person_id = t5.person_id " +
    "LEFT JOIN organization_networks t6 ON t1.org_id = t6.org_id " +
    "LEFT JOIN countries t3 ON t2.org_residency=t3.country_2a_code WHERE org_code ='" + bin + "' LIMIT 1;";
                var reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        list.org_name = reader["org_name"].ToString();
                        list.org_code = reader["org_code"].ToString();
                        list.org_type = reader["org_type"].ToString();
                        list.org_reg_date = GetDateTimeFromString(reader["org_reg_date"].ToString()).ToString("yyyy.MM.dd");
                        list.org_reregdate = GetDateTimeFromString(reader["org_reregdate"].ToString()).ToString("yyyy.MM.dd");
                        list.company_region = reader["company_region"].ToString();
                        list.org_oked = reader["org_oked"].ToString();
                        list.secondary_oked = reader["secondary_oked"].ToString();
                        list.company_status = reader["company_status"].ToString();
                        list.company_contacts = reader["company_contacts"].ToString();
                        list.company_main_sphere = reader["company_main_sphere"].ToString();
                        list.company_additional_sphere = reader["company_additional_sphere"].ToString();
                        list.company_ceo = reader["company_ceo"].ToString();
                        list.company_ceo_date = GetDateTimeFromString(reader["company_ceo_date"].ToString()).ToString("yyyy.MM.dd");
                        list.company_founder = reader["company_founder"].ToString();
                        list.company_website = reader["company_website"].ToString();
                        list.company_email = reader["company_email"].ToString();
                        list.company_address = reader["company_address"].ToString();
                        list.org_post_infex = reader["org_post_infex"].ToString();
                        list.org_custom_code = reader["org_custom_code"].ToString();
                        list.organization_kpveds = reader["organization_kpveds"].ToString();
                        list.company_filials = reader["company_filials"].ToString();
                        list.country = reader["ctr"].ToString();
                        list.logo = reader["logo"].ToString();
                        list.skype = reader["skype"].ToString();
                        list.linkedin = reader["linkedin"].ToString();
                        list.fb = reader["fb"].ToString();
                        list.instagram = reader["instagram"].ToString();
                        list.vk = reader["vk"].ToString();
                        list.wechat = reader["wechat"].ToString();
                        list.org_is_bank = reader.GetFieldValueOrDefault<int>("org_is_bank");
                        list.org_is_broker = reader.GetFieldValueOrDefault<int>("org_is_broker");
                        list.org_is_carrier = reader.GetFieldValueOrDefault<int>("org_is_carrier");
                        list.org_is_insurer = reader.GetFieldValueOrDefault<int>("org_is_insurer");
                        list.org_is_twh = reader.GetFieldValueOrDefault<int>("org_is_twh");
                    }
                    reader.Close();
                    reader = null;
                }
            }
            return list;
        }
        public string getFirmFull()
        {
            var user = User.Identity.GetUserId();
            if (user == null) return "login first";
            //var name = User.Identity.GetUserName();
            var list = new comp();
            var rsd = new resid();
            var per = new person();
            var fin = new fullComp();
            int oid = 0;
            lock (Provider.Locker)
            {
                string query = "SELECT t1.*, t7.oked_name_ru as oname, t8.oked_name_ru as oname2, t4.person_email, t5.person_phone_number, t2.*, t2.country as ctr, t6.*, t3.* FROM persons t1 " +
                    "LEFT JOIN persons_emails t4 ON t1.person_id = t4.person_id LEFT JOIN persons_phones t5 ON t1.person_id = t5.person_id " +
                    "LEFT JOIN organizations t2 ON t1.org_id = t2.org_id LEFT JOIN organization_networks t6 ON t1.org_id = t6.org_id " +
                    "LEFT JOIN oked t7 ON t2.org_oked = t7.oked_code LEFT JOIN oked t8 ON t2.secondary_oked = t8.oked_code " +
                    "LEFT JOIN countries t3 ON t2.org_residency=t3.country_2a_code WHERE user_id ='" + user + "';";
                var reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        oid = (int)reader["org_id"];
                        list.org_name = reader["org_name"].ToString();
                        list.org_code = reader["org_code"].ToString().Trim();
                        list.org_type = reader["org_type"].ToString();
                        list.org_reg_date = GetDateTimeFromString(reader["org_reg_date"].ToString()).ToString("yyyy.MM.dd");
                        list.org_reregdate = GetDateTimeFromString(reader["org_reregdate"].ToString()).ToString("yyyy.MM.dd");
                        list.company_region = reader["company_region"].ToString();
                        list.oked_name = reader["oname"].ToString();
                        list.sec_oked_name = reader["oname2"].ToString();
                        list.org_oked = reader["org_oked"].ToString();
                        list.secondary_oked = reader["secondary_oked"].ToString();
                        list.company_status = reader["company_status"].ToString();
                        list.company_contacts = reader["company_contacts"].ToString();
                        list.company_main_sphere = reader["company_main_sphere"].ToString();
                        list.company_additional_sphere = reader["company_additional_sphere"].ToString();
                        list.company_ceo = reader["company_ceo"].ToString();
                        list.company_ceo_date = GetDateTimeFromString(reader["company_ceo_date"].ToString()).ToString("yyyy.MM.dd");
                        list.company_founder = reader["company_founder"].ToString();
                        list.company_website = reader["company_website"].ToString();
                        list.company_email = reader["company_email"].ToString();
                        list.org_custom_code = reader["org_custom_code"].ToString();
                        list.organization_kpveds = reader["organization_kpveds"].ToString();
                        list.company_filials = reader["company_filials"].ToString();
                        list.country = reader["ctr"].ToString();
                        list.logo = reader["logo"].ToString();
                        list.skype = reader["skype"].ToString();
                        list.linkedin = reader["linkedin"].ToString();
                        list.fb = reader["fb"].ToString();
                        list.instagram = reader["instagram"].ToString();
                        list.vk = reader["vk"].ToString();
                        list.wechat = reader["wechat"].ToString();
                        list.org_is_bank = reader.GetFieldValueOrDefault<int>("org_is_bank");
                        list.org_is_broker = reader.GetFieldValueOrDefault<int>("org_is_broker");
                        list.org_is_carrier = reader.GetFieldValueOrDefault<int>("org_is_carrier");
                        list.org_is_insurer = reader.GetFieldValueOrDefault<int>("org_is_insurer");
                        list.org_is_twh = reader.GetFieldValueOrDefault<int>("org_is_twh");
                        rsd.value = reader["org_residency"].ToString();
                        rsd.display_text = reader["country_name_ru"].ToString();
                        per.person_code = reader["person_code"].ToString();
                        per.given_name = reader["given_name"].ToString();
                        per.last_name = reader["last_name"].ToString();
                        per.middle_name = reader["middle_name"].ToString();
                        per.position = reader["position"].ToString();
                        per.gender = reader.GetFieldValueOrDefault<int>("gender");
                        per.date_of_birth = GetDateTimeFromString(reader["date_of_birth"].ToString()).ToString("yyyy.MM.dd");
                        per.residency = reader["residency"].ToString();
                        per.user_id = reader["user_id"].ToString();
                        per.post_address = reader["post_address"].ToString();
                        per.person_email = reader["person_email"].ToString();
                        per.person_phone_number = reader["person_phone_number"].ToString();
                        per.avatar = reader["avatar"].ToString();
                        per.country = reader["country"].ToString();
                        per.image_id = reader.GetFieldValueOrDefault<int>("image_id");
                    }
                    reader.Close();/*
                    var bnk = new List<BankModel>();
                    var fnd = new List<Founders>();
                    var adr = new List<OrgAdress>();
                    query = $"SELECT * FROM subj_bank_accounts WHERE org_id='{oid}'";
                    var reader1 = Provider.RunQuery(query);                    
                    if (reader1 != null)
                    {
                        while (reader1.Read())
                        {
                            var rep1 = new BankModel
                            {
                                subj_bank_name= reader1["subj_bank_name"].ToString(),
                            };
                            rep1.subj_bank_acc_number = reader1["subj_bank_acc_number"].ToString();
                            rep1.subj_bank_acc_curr = reader1["subj_bank_acc_curr"].ToString();
                            rep1.subj_bank_acc_status = reader1["subj_bank_acc_status"].ToString();
                            bnk.Add(rep1);
                        }
                        reader1.Close();
                    }
                    query = $"SELECT * FROM organizations_founders WHERE org_id='{oid}'";
                    reader1 = Provider.RunQuery(query);
                    if (reader1 != null)
                    {
                        while (reader1.Read())
                        {
                            var rep1 = new Founders
                            {
                                org_founders_person_name = reader1["org_founders_person_name"].ToString(),
                            };
                            rep1.org_founders_company = reader1["org_founders_company"].ToString();
                            rep1.org_founders_country = reader1["org_founders_country"].ToString();
                            rep1.org_founders_share = reader1["org_founders_share"].ToString();
                            fnd.Add(rep1);
                        }
                        reader1.Close();
                    }
                    query = $"SELECT * FROM subj_post_addresses WHERE org_id='{oid}'";
                    reader1 = Provider.RunQuery(query);
                    if (reader1 != null)
                    {
                        while (reader1.Read())
                        {
                            var rep1 = new OrgAdress
                            {
                                subj_post_addr_type = reader1["subj_post_addr_type"].ToString(),
                            };                            
                            rep1.subj_post_addr_type = reader1["subj_post_addr_type"].ToString(); 
                            rep1.post_addr_index = reader1["post_addr_index"].ToString(); 
                            rep1.post_addr_country = reader1["post_addr_country"].ToString();
                            rep1.post_addr_region = reader1["post_addr_region"].ToString(); 
                            rep1.post_addr_district = reader1["post_addr_district"].ToString(); 
                            rep1.post_addr_town = reader1["post_addr_town"].ToString();
                            rep1.post_addr_city = reader1["post_addr_city"].ToString(); 
                            rep1.post_addr_streethouse = reader1["post_addr_streethouse"].ToString(); 
                            rep1.post_addr_house = reader1["post_addr_house"].ToString(); 
                            rep1.post_addr_room = reader1["post_addr_room"].ToString(); 
                            rep1.post_addr_comm_kind = reader1["post_addr_comm_kind"].ToString(); 
                            rep1.post_addr_comm_number = reader1["post_addr_comm_number"].ToString();
                            adr.Add(rep1);
                        }
                        reader1.Close();
                    }*/
                    fin.addresses = load_addresses_by_bin(list.org_code);
                    fin.socials = load_socials_by_bin(list.org_code);
                    fin.person_socials = load_socials_personal_by_bin(list.org_code);
                    fin.banks = load_banks_bin(list.org_code);
                    fin.organizations = list;
                    fin.persons = per;
                    fin.org_residency = rsd;
                    return JsonConvert.SerializeObject(fin);
                }
            }
            return "{}";
        }

        private List<OrgAdress> load_addresses_by_bin(string bin)
        {
            string query = "SELECT t2.* FROM organizations t1 LEFT JOIN subj_post_addresses t2 ON t1.org_id=t2.org_id WHERE t1.org_code ='" + bin + "';";
            var adr = new List<OrgAdress>();
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new OrgAdress
                    {
                        subj_post_addr_type = reader1["subj_post_addr_type"].ToString(),
                    };
                    rep1.subj_post_addr_type = reader1["subj_post_addr_type"].ToString();
                    rep1.post_addr_index = reader1["post_addr_index"].ToString();
                    rep1.post_addr_country = reader1["post_addr_country"].ToString();
                    rep1.post_addr_region = reader1["post_addr_region"].ToString();
                    rep1.post_addr_district = reader1["post_addr_district"].ToString();
                    rep1.post_addr_town = reader1["post_addr_town"].ToString();
                    rep1.post_addr_city = reader1["post_addr_city"].ToString();
                    rep1.post_addr_streethouse = reader1["post_addr_streethouse"].ToString();
                    rep1.post_addr_house = reader1["post_addr_house"].ToString();
                    rep1.post_addr_room = reader1["post_addr_room"].ToString();
                    rep1.post_addr_comm_kind = reader1["post_addr_comm_kind"].ToString();
                    rep1.post_addr_comm_number = reader1["post_addr_comm_number"].ToString();
                    adr.Add(rep1);
                }
                reader1.Close();
                return adr;
            }
            return null;
        }
        private social load_socials_by_bin(string bin)
        {
            string query = $"SELECT t3.* FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id " +
                $"LEFT JOIN person_networks t3 ON t1.person_id=t3.person_id WHERE t2.org_code='{bin}' LIMIT 1;";
            var list = new social();
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.skype = reader["skype"].ToString();
                    if (list.skype == "null") list.skype = "";
                    list.linkedin = reader["linkedin"].ToString();
                    if (list.linkedin == "null") list.linkedin = "";
                    list.fb = reader["fb"].ToString();
                    if (list.fb == "null") list.fb = "";
                    list.instagram = reader["instagram"].ToString();
                    if (list.instagram == "null") list.instagram = "";
                    list.vk = reader["vk"].ToString();
                    if (list.vk == "null") list.vk = "";
                    list.wechat = reader["wechat"].ToString();
                    if (list.wechat == "null") list.wechat = "";
                }
                reader.Close();
                return list;
            }
            return null;
        }
        private social load_socials_personal_by_bin(string bin)
        {
            //var user = User.Identity.GetUserId();
            string query = "SELECT t2.* FROM organizations t1 LEFT JOIN organization_networks t2 ON t1.org_id=t2.org_id WHERE t1.org_code ='" + bin + "' LIMIT 1;";
            var list = new social();
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.skype = reader["skype"].ToString();
                    if (list.skype == "null") list.skype = "";
                    list.linkedin = reader["linkedin"].ToString();
                    if (list.linkedin == "null") list.linkedin = "";
                    list.fb = reader["fb"].ToString();
                    if (list.fb == "null") list.fb = "";
                    list.instagram = reader["instagram"].ToString();
                    if (list.instagram == "null") list.instagram = "";
                    list.vk = reader["vk"].ToString();
                    if (list.vk == "null") list.vk = "";
                    list.wechat = reader["wechat"].ToString();
                    if (list.wechat == "null") list.wechat = "";
                }
                reader.Close();
                return list;
            }
            return null;
        }
        private List<BankModel> load_banks_bin(string bin)
        {
            //var user = User.Identity.GetUserId();
            string query = "SELECT t2.*, t3.bank_name, t3.bank_address, t3.bank_bin FROM organizations t1 LEFT JOIN subj_bank_accounts t2 ON t1.org_id=t2.org_id LEFT JOIN banks t3 on t3.bic = t2.subj_bank_name WHERE t1.org_code ='" + bin + "';";
            var bnk = new List<BankModel>();
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new BankModel
                    {
                        subj_bank = reader1["subj_bank_name"].ToString(),
                    };
                    rep1.subj_bank_acc_number = reader1["subj_bank_acc_number"].ToString();
                    rep1.subj_bank_acc_curr = reader1["subj_bank_acc_curr"].ToString();
                    rep1.subj_bank_acc_status = reader1["subj_bank_acc_status"].ToString();
                    rep1.subj_bank_address = reader1["bank_address"].ToString();
                    rep1.subj_bank_name = reader1["bank_name"].ToString();
                    rep1.subj_bank_bin = reader1["bank_bin"].ToString();
                    bnk.Add(rep1);
                }
                reader1.Close();
                return bnk;
            }
            return null;
        }
        public List<Founders> load_founders_bin(string bin)
        {
            //var user = User.Identity.GetUserId();
            string query = "SELECT t2.* FROM organizations t1 LEFT JOIN organizations_founders t2 ON t1.org_id=t2.org_id WHERE t1.org_code ='" + bin + "';";
            var fnd = new List<Founders>();
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new Founders
                    {
                        org_founders_person_name = reader1["org_founders_person_name"].ToString(),
                    };
                    rep1.org_founders_company = reader1["org_founders_company"].ToString();
                    rep1.org_founders_country = reader1["org_founders_country"].ToString();
                    rep1.org_founders_share = reader1["org_founders_share"].ToString();
                    fnd.Add(rep1);
                }
                reader1.Close();
                return fnd;
            }
            return null;
        }
        /*
        public string saveFirmFull(Orgs comp)
        {          
            string aa = DateTime.Now.ToString("yyyy.MM.dd");
            if (comp.date_of_birth != null)
                aa = comp.date_of_birth?.ToString("yyyy.MM.dd");
            string query = $"UPDATE persons SET(person_code, given_name, last_name, middle_name, gender, date_of_birth, residency)" +
                $" = ('{comp.person_code}', '{comp.given_name}', '{comp.last_name}', '{comp.middle_name}', '{comp.gender}', '{aa}', '{comp.residency}') WHERE user_id ='{comp.user_id}';";
            Provider.RunNonQuery(query);
            query = $"UPDATE organizations SET(org_name, org_code, org_type, org_reg_date, company_region, org_oked, company_contacts, " +
                $"company_main_sphere, company_additional_sphere,company_ceo, company_founder, company_website, company_email) =" +
                $" ('{comp.org_name}', '{comp.org_code}', '{comp.org_type}', '{comp.org_reg_date}', '{comp.company_region}', '{comp.org_oked}', " +
                $"'{comp.company_contacts}', '{comp.company_main_sphere}', '{comp.company_additional_sphere}', '{comp.company_ceo}', " +
                $"'{comp.company_founder}', '{comp.company_website}', '{comp.company_email}') WHERE org_code='{comp.org_code}'";
            Provider.RunNonQuery(query);
            return "ok";
        }
        */
        public string getFirmbyBin(string bin)
        {
            var user = User.Identity.GetUserId();
            //var name = User.Identity.GetUserName();
            var list = new comp();
            var rsd = new resid();
            var per = new person();
            var fin = new fullComp();
            if (user != null)
            {
                string query = "SELECT t1.*, t4.person_email, t5.person_phone_number, t2.*, t2.country as ctr, t6.*, t3.* FROM organizations t2 LEFT JOIN persons t1 ON t1.org_id = t2.org_id " +
                    "LEFT JOIN persons_emails t4 ON t1.person_id = t4.person_id LEFT JOIN persons_phones t5 ON t1.person_id = t5.person_id " +
                    "LEFT JOIN organization_networks t6 ON t1.org_id = t6.org_id " +
                    "LEFT JOIN countries t3 ON t2.org_residency=t3.country_2a_code WHERE org_code ='" + bin + "' LIMIT 1;";
                var reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        list.org_name = reader["org_name"].ToString();
                        list.org_code = reader["org_code"].ToString();
                        list.org_type = reader["org_type"].ToString();
                        list.org_reg_date = GetDateTimeFromString(reader["org_reg_date"].ToString()).ToString("yyyy.MM.dd");
                        list.org_reregdate = GetDateTimeFromString(reader["org_reregdate"].ToString()).ToString("yyyy.MM.dd");
                        list.company_region = reader["company_region"].ToString();
                        list.org_oked = reader["org_oked"].ToString();
                        list.company_status = reader["company_status"].ToString();
                        list.company_contacts = reader["company_contacts"].ToString();
                        list.company_main_sphere = reader["company_main_sphere"].ToString();
                        list.company_additional_sphere = reader["company_additional_sphere"].ToString();
                        list.company_ceo = reader["company_ceo"].ToString();
                        list.company_ceo_date = GetDateTimeFromString(reader["company_ceo_date"].ToString()).ToString("yyyy.MM.dd");
                        list.company_founder = reader["company_founder"].ToString();
                        list.company_website = reader["company_website"].ToString();
                        list.company_email = reader["company_email"].ToString();
                        list.org_custom_code = reader["org_custom_code"].ToString();
                        list.organization_kpveds = reader["organization_kpveds"].ToString();
                        list.company_filials = reader["company_filials"].ToString();
                        list.country = reader["ctr"].ToString();
                        list.logo = reader["logo"].ToString();
                        list.skype = reader["skype"].ToString();
                        list.linkedin = reader["linkedin"].ToString();
                        list.fb = reader["fb"].ToString();
                        list.instagram = reader["instagram"].ToString();
                        list.vk = reader["vk"].ToString();
                        list.wechat = reader["wechat"].ToString();
                        list.org_is_bank = reader.GetFieldValueOrDefault<int>("org_is_bank");
                        list.org_is_broker = reader.GetFieldValueOrDefault<int>("org_is_broker");
                        list.org_is_carrier = reader.GetFieldValueOrDefault<int>("org_is_carrier");
                        list.org_is_insurer = reader.GetFieldValueOrDefault<int>("org_is_insurer");
                        list.org_is_twh = reader.GetFieldValueOrDefault<int>("org_is_twh");
                        rsd.value = reader["org_residency"].ToString();
                        rsd.display_text = reader["country_name_ru"].ToString();
                        per.person_code = reader["person_code"].ToString();
                        per.given_name = reader["given_name"].ToString();
                        per.last_name = reader["last_name"].ToString();
                        per.middle_name = reader["middle_name"].ToString();
                        per.position = reader["position"].ToString();
                        per.gender = reader.GetFieldValueOrDefault<int>("gender");
                        per.date_of_birth = GetDateTimeFromString(reader["date_of_birth"].ToString()).ToString("yyyy.MM.dd");
                        per.residency = reader["residency"].ToString();
                        per.user_id = reader["user_id"].ToString();
                        per.post_address = reader["post_address"].ToString();
                        per.person_email = reader["person_email"].ToString();
                        per.person_phone_number = reader["person_phone_number"].ToString();
                        per.avatar = reader["avatar"].ToString();
                        per.country = reader["country"].ToString();
                        per.image_id = reader.GetFieldValueOrDefault<int>("image_id");
                    }
                    reader.Close();
                    fin.addresses = load_addresses_by_bin(bin);
                    fin.socials = load_socials_by_bin(bin);
                    fin.person_socials = load_socials_personal_by_bin(bin);
                    fin.banks = load_banks_bin(bin);
                    fin.founders = load_founders_bin(bin);
                    fin.organizations = list;
                    fin.persons = per;
                    fin.person_documents = LoadPersonDocumentsByCode(per.person_code);
                    fin.org_residency = rsd;
                    
                    return JsonConvert.SerializeObject(fin);
                }
            }
            return "[]";
        }

        public string getCourier(string bin)
        {
            var res = getFirmDetails(bin);
            return res;
        }
        public string getFirmDetails(string bin)
        {
            var user = User.Identity.GetUserId();
            //var name = User.Identity.GetUserName();
            var list = new Orgs();
            var rsd = new resid();
            if (user != null)
            {
                lock (Provider.Locker)
                {
                    string query = $"SELECT t2.*, t3.* FROM organizations t2 LEFT JOIN countries t3 ON t2.org_residency=t3.country_2a_code WHERE t2.org_code ='{bin}';";
                    var reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            list.org_name = reader["org_name"].ToString();
                            list.org_code = reader["org_code"].ToString();
                            list.org_type = reader["org_type"].ToString();
                            list.org_reg_date = GetDateTimeFromString(reader["org_reg_date"].ToString()).ToString("yyyy.MM.dd");
                            list.company_region = reader["company_region"].ToString();
                            list.org_oked = reader["org_oked"].ToString();
                            list.company_contacts = reader["company_contacts"].ToString();
                            list.company_main_sphere = reader["company_main_sphere"].ToString();
                            list.company_additional_sphere = reader["company_additional_sphere"].ToString();
                            list.company_ceo = reader["company_ceo"].ToString();
                            list.company_founder = reader["company_founder"].ToString();
                            list.company_website = reader["company_website"].ToString();
                            list.company_email = reader["company_email"].ToString();
                            rsd.value = reader["org_residency"].ToString();
                            rsd.display_text = reader["country_name_ru"].ToString();
                        }
                        reader.Close();
                        //list.persons = per;
                        list.org_residency = rsd;
                        return JsonConvert.SerializeObject(list);
                    }
                }
            }
            //return "login first";
            return "[]";
        }

        public string uploadfile(int documentid)
        {
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    EntityId = documentid.ToString(),
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "epi"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);
            }

            string query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{documentid}' and doc_widget_id ='epi'";
            var reader = Provider.RunQuery(query);
            var files = new List<Kfiles>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new Kfiles
                    {
                        id = reader["id"].ToString(), //"/picture/getfile/"
                    };
                    rep.name = reader["img_file_name"].ToString();
                    files.Add(rep);
                }
                reader.Close();
            }
            return JsonConvert.SerializeObject(files);
        }
        /*
        public string AML(string bin)
        {
            string query = $"SELECT company_website FROM organizations WHERE org_code ='{bin}';";
            var ts = Provider.RunQueryStr(query);
            string ret = "{\"url\": \"" + ts + "\"}"; 
            return ret;
        }

        public string AML(string query)
        {            
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://api.complyadvantage.com/searches?api_key=Bq0l7lG76InG8tYZKtXs2xMnZEyENRcn");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = "{\"search_term\":\"skill\"," +
                              "\"fuzziness\":\"0.6\"}";

                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
            }
            return "";
        }
        */
        class Search
        {
            public string search_term { get; set; }
            public double fuzziness { get; set; }
            //public string share_url { get; set; }
        }
        public string aml(string query)
        {
            var user = User.Identity.GetUserId();
            var person = new Search();
            person.search_term = query;
            person.fuzziness = 0.6;
            //string sr = "{search_term:Dandong Hongxiang}";

            var json = JsonConvert.SerializeObject(person);
            //var data = new StringContent(json, Encoding.UTF8, "application/json");

            var url = "https://api.complyadvantage.com/searches?api_key=Bq0l7lG76InG8tYZKtXs2xMnZEyENRcn";
            //var client = new HttpClient();
            var aa = POSTData(json, url);
            //var response = client.PostAsync(url, data);

            var sqlQuery = $"INSERT INTO comply_advantage_request (search_query, search_user_id, response_data) " +
                $"VALUES ('{query}', '{user}', @p0::jsonb)";
            Provider.RunNonQuery(sqlQuery, aa);
            return aa;
        }
        private static HttpClient _httpClient = new HttpClient();
        public string POSTData(string json, string url)
        {
            using (var content = new StringContent(json, Encoding.UTF8, "application/json"))
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                                                | SecurityProtocolType.Ssl3;
                HttpResponseMessage result = _httpClient.PostAsync(url, content).Result;
                if (result.StatusCode == System.Net.HttpStatusCode.Created)
                    return "true";
                string returnValue = result.Content.ReadAsStringAsync().Result;
                return returnValue;
                //throw new Exception($"Failed to POST data: ({result.StatusCode}): {returnValue}");
            }
        }

        [HttpPost]
        public string AddDocumentSignature(string docId, string signature)
        {
            string user = User.Identity.GetUserId();
            var query = $"UPDATE attis_contract_docs SET sign_data='{signature}', sign_date = now() where attis_contract_doc_id='{docId}'";

            Provider.RunNonQuery(query);
            return "ok";
        }
        [HttpPost]
        public bool CheckSignature(string docId, string signature)
        {
            string user = User.Identity.GetUserId();
            var query = $"SELECT sign_data from attis_contract_docs where attis_contract_doc_id='{docId}'";
            string DBSignature = Provider.RunQueryStr(query);
            if (DBSignature == signature)
                return true;
            else
                return false;
        }

        public class sign
        {
            public string signature { get; set; }
            public DateTime? date { get; set; }
        }
        public string LoadSignature(int doc_id)
        {
            var sig = new sign();
            var query = $"SELECT sign_data from attis_contract_docs where attis_contract_doc_id='{doc_id}'";
            sig.signature = Provider.RunQueryStr(query);
            query = $"SELECT sign_date from attis_contract_docs where attis_contract_doc_id='{doc_id}'";
            sig.date = GetDateTimeFromString(Provider.RunQueryStr(query));
            if (string.IsNullOrEmpty(Provider.lastError))
                return JsonConvert.SerializeObject(sig);
            return JsonConvert.SerializeObject(Provider.lastError);
        }

        //[HttpPost]
        public string ContragentCreate(string number, string name, string address, string country, string bank, string account)
        {
            string user = User.Identity.GetUserId();
            if (user.IsNullOrWhiteSpace()) return "login first";
            //string query = $"SELECT attis_contract_seller FROM attis_contracts WHERE attis_contract_id ='{attis_contract_id}';";
            //string query1 = $"SELECT attis_contract_buyer FROM attis_contracts WHERE attis_contract_id ='{attis_contract_id}';";
            /*string org_code = GetFirmName();/*
            if (contragent_type == "seller")
                org_code = Provider.RunScalar(query);
            if (contragent_type == "buyer")
                org_code = Provider.RunScalar(query1);
            */
            if (country == "")
                country = "RU";
            var dd = Provider.RunScalarStoredProcedure("add_new_inv_subject", number, name, address, country, bank, account);
            if (Provider.lastError != "")
            {
                var err = JsonConvert.SerializeObject(Provider.lastError);
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.NewContract}', '{LogContract.NewContract}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, err);
                return Provider.lastError;
            }
            return "ok";
        }
        public class PlacesItem
        {
            public string packing_code { get; set; }
            public int packing_quantity { get; set; }
            public string packing_description { get; set; }
            public int package_part_quantity { get; set; }
            public string cmr_id { get; set; }
        }
        public string GetPlaces(string id)
        {
            var list = new List<PlacesItem>();
            string user = User.Identity.GetUserId();
            var query = $"SELECT * from places_list where \"Id\" = {id};";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    PlacesItem item = new PlacesItem();
                    item.packing_code = reader["packing_code"].ToString();
                    item.packing_quantity = (int)reader["packing_quantity"];
                    item.packing_description = reader["packing_description"].ToString();
                    item.package_part_quantity = (int)reader["package_part_quantity"];
                    item.cmr_id = reader["cmr_id"].ToString();
                    list.Add(item);
                }
                reader.Close();
            }
            return JsonConvert.SerializeObject(list);
        }

        [HttpPost]
        public JsonResult AddPlaces(PlacesItem item)
        {
            string user = User.Identity.GetUserId();
            var query = $"INSERT INTO places_list (packing_code, packing_quantity, packing_description, package_part_quantity,cmr_id) "
                        + $"VALUES ('{item.packing_code}', '{item.packing_quantity}', '{item.packing_description}', '{item.package_part_quantity}', '{item.cmr_id}');";
            Provider.RunNonQuery(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.NewPlaces}', '{LogDocument.NewPlaces}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Json(Provider.lastError);
            }
            else
            {
                log.Info("new places " + user + JsonConvert.SerializeObject(item));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewPlaces}', '{LogDocument.NewPlaces}', '{LogSection.Document}', '{user}', '{item.cmr_id}', '{JsonConvert.SerializeObject(item)}', 0);";
                Provider.RunNonQuery(query);
                return Json("ok");
            }
        }

        [HttpPost]
        public JsonResult UpdatePlaces(PlacesItem item, string Id)
        {
            string user = User.Identity.GetUserId();
            var query = $"UPDATE places_list SET (packing_code, packing_quantity, packing_description, package_part_quantity,cmr_id)"
                        + $"=('{item.packing_code}', '{item.packing_quantity}', '{item.packing_description}', '{item.package_part_quantity}', '{item.cmr_id}') WHERE \"Id\" = '{Id}'";
            Provider.RunNonQuery(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.PlacesUpdate}', '{LogDocument.PlacesUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Json(Provider.lastError);
            }
            else
            {
                log.Info("update places " + user + JsonConvert.SerializeObject(item));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewPlaces}', '{LogDocument.NewPlaces}', '{LogSection.Document}', '{user}', '{item.cmr_id}', '{JsonConvert.SerializeObject(item)}', 0);";
                Provider.RunNonQuery(query);
                return Json("ok");
            }
        }

        public JsonResult DeletePlaces(string Id)
        {
            string user = User.Identity.GetUserId();
            var query = $"DELETE FROM places_list WHERE \"Id\" = '{Id}'";
            Provider.RunNonQuery(query);
            log.Info("delete places " + user + JsonConvert.SerializeObject(Id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.DeletePlaces}', '{LogDocument.DeletePlaces}', '{LogSection.Document}', '{user}', '', '{Id}', '{JsonConvert.SerializeObject(Id)}', 0);";
            Provider.RunNonQuery(query);
            return Json("ok");
        }

        public class PackingListItem
        {
            public string document_id { get; set; }
            public string ref_document_id { get; set; }
            public float gross_weight { get; set; }
            public float net_weight { get; set; }
            public string consignor { get; set; }
            public string consignee { get; set; }
            public string delivery_terms_numeric_code { get; set; }
            public string delivery_terms_string_code { get; set; }
            public string terms_description { get; set; }
            public string contract_pr_document_name { get; set; }
            public string contract_pr_document_number { get; set; }
            public DateTime? contract_pr_document_date { get; set; }
            public string invoice_pr_document_name { get; set; }
            public string invoice_pr_document_number { get; set; }
            public DateTime? invoice_pr_document_date { get; set; }
            public string registration_pr_document_name { get; set; }
            public string registration_pr_document_number { get; set; }
            public DateTime? registration_pr_document_date { get; set; }
        }

        public JsonResult GetPacking(string list_id)
        {
            string user = User.Identity.GetUserId();
            var query = $"SELECT * from packing_list where list_id = '{list_id}';";
            var reader = Provider.RunQuery(query);
            var list = new List<PackingListItem>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    PackingListItem item = new PackingListItem();
                    item.document_id = reader["document_id"].ToString();
                    item.ref_document_id = reader["ref_document_id"].ToString();
                    item.gross_weight = float.Parse(reader["gross_weight_quantity"].ToString());
                    item.net_weight = float.Parse(reader["net_weight_quantity"].ToString());
                    item.consignor = reader["consignor"].ToString();
                    item.consignee = reader["consignee"].ToString();
                    item.delivery_terms_numeric_code = reader["delivery_terms_numeric_code"].ToString();
                    item.delivery_terms_string_code = reader["delivery_terms_string_code"].ToString();
                    item.terms_description = reader["terms_description"].ToString();
                    item.contract_pr_document_name = reader["contract_pr_document_name"].ToString();
                    item.contract_pr_document_number = reader["contract_pr_document_number"].ToString();
                    item.contract_pr_document_date = GetDateTimeFromString(reader["contract_pr_document_date"].ToString());
                    item.invoice_pr_document_name = reader["invoice_pr_document_name"].ToString();
                    item.invoice_pr_document_number = reader["invoice_pr_document_number"].ToString();
                    item.invoice_pr_document_date = GetDateTimeFromString(reader["invoice_pr_document_date"].ToString());
                    item.registration_pr_document_name = reader["registration_pr_document_name"].ToString();
                    item.registration_pr_document_number = reader["registration_pr_document_number"].ToString();
                    item.registration_pr_document_date = GetDateTimeFromString(reader["registration_pr_document_date"].ToString());
                    list.Add(item);
                }
                reader.Close();
            }
            return Json(list);
        }

        public string GetRWBill(string doc_id)
        {
            string user = User.Identity.GetUserId();
            var query = $"SELECT * from rw_bill where refdocid = '{doc_id}';";
            var reader = Provider.RunQuery(query);
            var item = new rw_bill();
            if (reader != null)
            {
                while (reader.Read())
                {
                    item.id = reader.GetFieldValueOrDefault<int>("id"); 
                    item.doc_id = reader.GetFieldValueOrDefault<int>("doc_id"); 
                    item.refdocid = reader.GetFieldValueOrDefault<int>("refdocid"); 
                    item.consignor_notice = reader["consignor_notice"].ToString();
                    item.places_quantity = reader.GetFieldValueOrDefault<int>("places_quantity");
                    item.gross_weight_quantity = reader.GetFieldValueOrDefault<float>("gross_weight_quantity");
                    item.departure_mode_description = reader["departure_mode_description"].ToString(); 
                    item.loader_mode_description = reader["loader_mode_description"].ToString(); 
                    item.additional_sheet_quantity = reader.GetFieldValueOrDefault<int>("additional_sheet_quantity");
                    item.cargo_value = reader.GetFieldValueOrDefault<float>("cargo_value");
                    item.customs_notice = reader["customs_notice"].ToString(); 
                    item.weight_definition_mode_description = reader["weight_definition_mode_description"].ToString(); 
                    item.carrier_notice = reader["carrier_notice"].ToString();
                    item.commerce_akt = reader["commerce_akt"].ToString(); 
                    item.prolongation = reader["prolongation"].ToString();
                    item.issue_marks = reader["issue_marks"].ToString(); 
                    item.amount60 = reader.GetFieldValueOrDefault<float>("amount60");
                    item.amount61 = reader.GetFieldValueOrDefault<float>("amount61");
                    item.amount62 = reader.GetFieldValueOrDefault<float>("amount62"); 
                    item.amount63 = reader.GetFieldValueOrDefault<float>("amount63");
                    item.calculation_notice = reader["calculation_notice"].ToString(); 
                    item.addition_payment = reader["addition_payment"].ToString();
                    item.consignor_option_notice = reader["consignor_option_notice"].ToString();
                    item.consignor = reader["consignor"].ToString();
                    item.consignee = reader["consignee"].ToString();
                    item.departure_station_code = reader["departure_station_code"].ToString();
                    item.departure_station_name = reader["departure_station_name"].ToString();
                    item.departure_rwcode = reader["departure_rwcode"].ToString();
                    item.departure_rwname = reader["departure_rwname"].ToString();
                    item.departure_country = reader["departure_country"].ToString();
                    item.destination_rwcode = reader["destination_rwcode"].ToString();
                    item.destination_station_code = reader["destination_station_code"].ToString();
                    item.destination_rwand_station_name = reader["destination_rwand_station_name"].ToString();
                    item.border_station_code = reader["border_station_code"].ToString();
                    item.border_station_name = reader["border_station_name"].ToString();
                    item.border_rwcode = reader["border_rwcode"].ToString();
                    item.border_rwname = reader["border_rwname"].ToString();
                    item.border_country = reader["border_country"].ToString();
                    item.contract_name = reader["contract_name"].ToString();
                    item.contract_number = reader["contract_number"].ToString();
                    item.contract_date = GetDateTimeFromString(reader["contract_date"].ToString());
                    item.flat_pallet_quantity = reader.GetFieldValueOrDefault<float>("flat_pallet_quantity");
                    item.box_pallet_quantity = reader.GetFieldValueOrDefault<float>("box_pallet_quantity");
                    item.pallet_exchange_mode = reader["pallet_exchange_mode"].ToString();
                    item.work_tool_id = reader["work_tool_id"].ToString();
                    item.work_tool_container_description = reader["work_tool_container_description"].ToString();
                    item.work_tool_railway_code = reader["work_tool_railway_code"].ToString();
                    item.mark_sing = reader.GetFieldValueOrDefault<int>("mark_sing");
                    item.mark_kind = reader["mark_kind"].ToString();
                    item.mark_result_control = reader["mark_result_control"].ToString();
                    item.contract_carrier_name = reader["contract_carrier_name"].ToString();
                    item.contract_carrier_time = reader["contract_carrier_time"].ToString();
                    item.contract_carrier_date = reader["contract_carrier_date"].ToString();
                    item.contract_carrier_date_time_moscow = reader["contract_carrier_date_time_moscow"].ToString();
                    item.contract_carrier_station_code = reader["contract_carrier_station_code"].ToString();
                    item.contract_carrier_station_name = reader["contract_carrier_station_name"].ToString();
                    item.contract_carrier_rw_name = reader["contract_carrier_rw_name"].ToString();
                    item.contract_carrier_country = reader["contract_carrier_country"].ToString();
                    item.arrival_carrier_name = reader["arrival_carrier_name"].ToString();
                    item.arrival_date = reader["arrival_date"].ToString();
                    item.arrival_time = reader["arrival_time"].ToString();
                    item.arrival_date_time_moscow = reader["arrival_date_time_moscow"].ToString();
                    item.arrival_station_code = reader["arrival_station_code"].ToString();
                    item.arrival_station_name = reader["arrival_station_name"].ToString();
                    item.arrival_rw_name = reader["arrival_rw_name"].ToString();
                    item.arrival_rw_code = reader["arrival_rw_code"].ToString();
                    item.arrival_country = reader["arrival_country"].ToString();
                }
                reader.Close();
                query = $"SELECT * from rwb_goods where rwb_id = '{item.id}';";
                reader = Provider.RunQuery(query);
                item.goods = new List<rwb_goods>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        rwb_goods gd = new rwb_goods();
                        gd.container_indicator = reader.GetFieldValueOrDefault<int>("container_indicator");
                        gd.work_tool_description = reader["work_tool_description"].ToString();
                        gd.conductor_description = reader["conductor_description"].ToString();
                        gd.place_goods_quantity = reader.GetFieldValueOrDefault<double>("place_goods_quantity");
                        gd.places_quantity = reader.GetFieldValueOrDefault<double>("places_quantity");
                        gd.gross_weight_quantity = reader.GetFieldValueOrDefault<double>("gross_weight_quantity");
                        gd.places_description = reader["places_description"].ToString();
                        gd.harmonized_range_goods = reader.GetFieldValueOrDefault<int>("harmonized_range_goods");
                        gd.packing = reader["packing"].ToString();
                        gd.marking = reader["marking"].ToString();
                        gd.carriage_number = reader["carriage_number"].ToString();
                        gd.container_number = reader["container_number"].ToString();
                        gd.goods_numeric = reader.GetFieldValueOrDefault<int>("goods_numeric");
                        gd.customs_code = reader["customs_code"].ToString();
                        gd.gtd_number = reader.GetFieldValueOrDefault<int>("gtd_number");
                        gd.gcost = reader.GetFieldValueOrDefault<double>("gcost");
                        gd.currency = reader["currency"].ToString();
                        gd.mrn = reader["mrn"].ToString();
                        item.goods.Add(gd);
                    }
                    reader.Close();
                }
                item.carrier = new List<rwb_carrier>();
                query = $"SELECT * from rwb_carrier where rwb_id = '{item.id}';";
                reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        rwb_carrier cr = new rwb_carrier();
                        cr.id = reader.GetFieldValueOrDefault<int>("carrier_id");
                        cr.carrier_name = reader["carrier_name"].ToString();
                        cr.carrier_code = reader["carrier_code"].ToString();
                        cr.from_station_code = reader["from_station_code"].ToString();
                        cr.from_station_name = reader["from_station_name"].ToString();
                        cr.from_rw_name = reader["from_rw_name"].ToString();
                        cr.from_country = reader["from_country"].ToString();
                        cr.to_station_code = reader["to_station_code"].ToString();
                        cr.to_station_name = reader["to_station_name"].ToString();
                        cr.to_rw_name = reader["to_rw_name"].ToString();
                        cr.to_country = reader["to_country"].ToString();
                        item.carrier.Add(cr);
                    }
                    reader.Close();
                    foreach (var crr in item.carrier)
                    {
                        crr.tech_station = new List<rw_tech_station>();
                        query = $"SELECT * from rw_tech_station where carrier_id = '{crr.id}';";
                        reader = Provider.RunQuery(query);
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                rw_tech_station ts = new rw_tech_station();
                                ts.order_number = reader.GetFieldValueOrDefault<int>("order_number");
                                ts.tech_signs = reader["tech_signs"].ToString();
                                ts.station_code = reader["station_code"].ToString();
                                ts.station_name = reader["station_name"].ToString();
                                ts.rw_name = reader["rw_name"].ToString();
                                ts.country = reader["country"].ToString();
                                crr.tech_station.Add(ts);
                            }
                            reader.Close();
                        }
                    }
                    query = $"SELECT * from rwb_container where rwb_id = '{item.id}';";
                    reader = Provider.RunQuery(query);
                    item.container = new List<rwb_container>();
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_container ct = new rwb_container();
                            ct.container_id = reader["container_id"].ToString();
                            ct.rw_code = reader["rw_code"].ToString();
                            ct.container_kind = reader["container_kind"].ToString();
                            ct.container_mode_desc = reader["container_mode_desc"].ToString();
                            ct.container_capacity = reader.GetFieldValueOrDefault<float>("container_capacity");
                            ct.container_capacity_unit_code = reader["container_capacity_unit_code"].ToString();
                            ct.tare = reader.GetFieldValueOrDefault<double>("tare");
                            ct.goods_weight = reader.GetFieldValueOrDefault<double>("goods_weight");
                            ct.places_quentity = reader.GetFieldValueOrDefault<double>("places_quentity");
                            ct.pocket_quentity = reader.GetFieldValueOrDefault<double>("pocket_quentity");
                            ct.container_length = reader.GetFieldValueOrDefault<double>("container_length");
                            item.container.Add(ct);
                        }
                        reader.Close();
                    }
                    item.auto = new List<rwb_auto>();
                    query = $"SELECT * from rwb_auto where rwb_id = '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_auto at = new rwb_auto();
                            at.vin = reader["vin"].ToString();
                            at.transport_kind = reader["transport_kind"].ToString();
                            at.transport_mark = reader["transport_mark"].ToString();
                            at.transport_identifier = reader["transport_identifier"].ToString();
                            at.transport_nationality = reader["transport_nationality"].ToString();
                            at.active_transport_identifier = reader["active_transport_identifier"].ToString();
                            at.transport_regnumber = reader["transport_regnumber"].ToString();
                            at.wagon_number = reader.GetFieldValueOrDefault<int>("wagon_number");
                            at.tare = reader.GetFieldValueOrDefault<double>("tare");
                            at.goods_weight = reader.GetFieldValueOrDefault<double>("goods_weight");
                            at.places_quentity = reader.GetFieldValueOrDefault<double>("places_quentity");
                            at.pocket_quentity = reader.GetFieldValueOrDefault<double>("pocket_quentity");
                            at.container_length = reader.GetFieldValueOrDefault<double>("container_length");
                            item.auto.Add(at);
                        }
                        reader.Close();
                    }
                    item.carriage = new List<rwb_carriage>();
                    query = $"SELECT * from rwb_carriage where rwb_id = '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_carriage cg = new rwb_carriage();
                            cg.rw_name = reader["rw_name"].ToString();
                            cg.owner_name = reader["owner_name"].ToString();
                            cg.owner_type = reader["owner_type"].ToString();
                            cg.rw_power = reader.GetFieldValueOrDefault<double>("rw_power");
                            cg.tare = reader.GetFieldValueOrDefault<double>("tare");
                            cg.axis_quentity = reader.GetFieldValueOrDefault<double>("axis_quentity");
                            cg.goods_weight = reader.GetFieldValueOrDefault<double>("goods_weight");
                            cg.caliber = reader["caliber"].ToString();
                            item.carriage.Add(cg);
                        }
                        reader.Close();
                    }

                    item.seal = new List<rwb_seal>();
                    query = $"SELECT * from rwb_seal where rwb_id = '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_seal sl = new rwb_seal();
                            sl.seal_id = reader["seal_id"].ToString();
                            sl.seal_quentity = reader.GetFieldValueOrDefault<float>("seal_quentity");
                            sl.ident_kind = reader.GetFieldValueOrDefault<float>("ident_kind");
                            sl.ident_desc = reader["ident_desc"].ToString();
                            item.seal.Add(sl);
                        }
                        reader.Close();
                    }

                    item.carrier_charge = new List<rwb_carrier_charge>();
                    query = $"SELECT * from rwb_carrier_charge where rwb_id = '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_carrier_charge cc = new rwb_carrier_charge();
                            cc.order_no = reader.GetFieldValueOrDefault<float>("order_no");
                            cc.carrier_code = reader["carrier_code"].ToString();
                            cc.from_station_code = reader["from_station_code"].ToString();
                            cc.from_station_name = reader["from_station_name"].ToString();
                            cc.from_rw_name = reader["from_rw_name"].ToString();
                            cc.from_country = reader["from_country"].ToString();
                            cc.to_station_code = reader["to_station_code"].ToString();
                            cc.to_station_name = reader["to_station_name"].ToString();
                            cc.to_rw_name = reader["to_rw_name"].ToString();
                            cc.to_country = reader["to_country"].ToString();
                            cc.distance = reader.GetFieldValueOrDefault<float>("distance");
                            cc.calc_weight = reader.GetFieldValueOrDefault<double>("calc_weight");
                            cc.extra_charge_code = reader["extra_charge_code"].ToString();
                            cc.extra_charge_name = reader["extra_charge_name"].ToString();
                            cc.extra_charge_amount = reader.GetFieldValueOrDefault<double>("extra_charge_amount");
                            cc.tarif_code = reader["tarif_code"].ToString();
                            cc.calc_cargo_code = reader["calc_cargo_code"].ToString();
                            cc.currency_rate = reader.GetFieldValueOrDefault<float>("currency_rate");
                            cc.snd_tarif_currency_code = reader["snd_tarif_currency_code"].ToString();
                            cc.snd_payment_currency = reader["snd_payment_currency"].ToString();
                            cc.rcv_tarif_currency_code = reader["rcv_tarif_currency_code"].ToString();
                            cc.rcv_payment_currency = reader["rcv_payment_currency"].ToString();
                            cc.amount48 = reader.GetFieldValueOrDefault<double>("amount48");
                            cc.amount49 = reader.GetFieldValueOrDefault<double>("amount49");
                            cc.amount50 = reader.GetFieldValueOrDefault<double>("amount50");
                            cc.amount51 = reader.GetFieldValueOrDefault<double>("amount51");
                            cc.amount52 = reader.GetFieldValueOrDefault<double>("amount52");
                            cc.amount53 = reader.GetFieldValueOrDefault<double>("amount53");
                            cc.amount54 = reader.GetFieldValueOrDefault<double>("amount54");
                            cc.amount55 = reader.GetFieldValueOrDefault<double>("amount55");
                            cc.amount56 = reader.GetFieldValueOrDefault<double>("amount56");
                            cc.amount57 = reader.GetFieldValueOrDefault<double>("amount57");
                            cc.amount58 = reader.GetFieldValueOrDefault<double>("amount58");
                            cc.amount59 = reader.GetFieldValueOrDefault<double>("amount59");
                            item.carrier_charge.Add(cc);
                        }
                        reader.Close();
                    }

                    item.paid_rw_code = new List<paid_rw_cod>();
                    query = $"SELECT * from paid_rw_code where rwb_id = '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            paid_rw_cod pc = new paid_rw_cod();
                            pc.paid_rw_name = reader["paid_rw_name"].ToString();
                            pc.paid_rw_code = reader["paid_rw_code"].ToString();
                            pc.paid_rw_short = reader["paid_rw_short"].ToString();
                            pc.payer_code = reader["payer_code"].ToString();
                            pc.payer_name = reader["payer_name"].ToString();
                            pc.from_rw_name = reader["from_rw_name"].ToString();
                            pc.from_country = reader["from_country"].ToString();
                            item.paid_rw_code.Add(pc);
                        }
                        reader.Close();
                    }

                    item.consignor_doc = new List<rwb_doc>();
                    query = $"SELECT * from rwb_doc where rwb_id = '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_doc cd = new rwb_doc();
                            cd.doc_name = reader["doc_name"].ToString();
                            cd.doc_number = reader["doc_number"].ToString();
                            cd.doc_date = GetDateTimeFromString(reader["doc_date"].ToString());
                            cd.mode_code = reader["mode_code"].ToString();
                            cd.expiration_date = GetDateTimeFromString(reader["expiration_date"].ToString());
                            cd.release_customs = reader["release_customs"].ToString();
                            item.consignor_doc.Add(cd);
                        }
                        reader.Close();
                    }

                    item.stamp33 = new List<rwb_stamp>();
                    query = $"SELECT * from rwb_stamp where stamp_type=3 AND rwb_id= '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_stamp st = new rwb_stamp();
                            st.carrier_name = reader["carrier_name"].ToString();
                            st.date = reader["date"].ToString();
                            st.time = reader["time"].ToString();
                            st.date_time_moscow = reader["date_time_moscow"].ToString();
                            st.station_code = reader["station_code"].ToString();
                            st.station_name = reader["station_name"].ToString();
                            st.rw_name = reader["rw_name"].ToString();
                            st.rw_code = reader["rw_code"].ToString();
                            st.country = reader["country"].ToString();
                            item.stamp33.Add(st);
                        }
                        reader.Close();
                    }

                    item.stamp34 = new List<rwb_stamp>();
                    query = $"SELECT * from rwb_stamp where stamp_type=4 AND rwb_id= '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            rwb_stamp st = new rwb_stamp();
                            st.carrier_name = reader["carrier_name"].ToString();
                            st.date = reader["date"].ToString();
                            st.time = reader["time"].ToString();
                            st.date_time_moscow = reader["date_time_moscow"].ToString();
                            st.station_code = reader["station_code"].ToString();
                            st.station_name = reader["station_name"].ToString();
                            st.rw_name = reader["rw_name"].ToString();
                            st.rw_code = reader["rw_code"].ToString();
                            st.country = reader["country"].ToString();
                            item.stamp34.Add(st);
                        }
                        reader.Close();
                    }

                    item.stamp35 = new rwb_stamp();
                    query = $"SELECT * from rwb_stamp where stamp_type=5 AND rwb_id= '{item.id}';";
                    reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            item.stamp35.carrier_name = reader["carrier_name"].ToString();
                            item.stamp35.date = reader["date"].ToString();
                            item.stamp35.time = reader["time"].ToString();
                            item.stamp35.date_time_moscow = reader["date_time_moscow"].ToString();
                            item.stamp35.station_code = reader["station_code"].ToString();
                            item.stamp35.station_name = reader["station_name"].ToString();
                            item.stamp35.rw_name = reader["rw_name"].ToString();
                            item.stamp35.rw_code = reader["rw_code"].ToString();
                            item.stamp35.country = reader["country"].ToString();
                        }
                        reader.Close();
                    }
                }
                return JsonConvert.SerializeObject(item);
            }
            return "empty request";
        }

        [HttpPost]
        public JsonResult AddPacking(PackingListItem item)
        {
            string user = User.Identity.GetUserId();
            var query = $"INSERT INTO packing_list (document_id, ref_document_id, gross_weight_quantity, net_weight_quantity, consignor, consignee, delivery_terms_numeric_code, delivery_terms_string_code, "
                        + $"terms_description, contract_pr_document_name, contract_pr_document_number, contract_pr_document_date, invoice_pr_document_name, invoice_pr_document_number, invoice_pr_document_date, registration_pr_document_name, registration_pr_document_number, registration_pr_document_date) "
                        + $"VALUES ('{item.document_id}', '{item.ref_document_id}', '{item.gross_weight}', '{item.net_weight}', '{item.consignor}', '{item.consignee}', '{item.delivery_terms_numeric_code}', '{item.delivery_terms_string_code}', "
                        + $"'{item.terms_description}', '{item.contract_pr_document_name}', '{item.contract_pr_document_number}', '{item.contract_pr_document_date}', '{item.invoice_pr_document_name}', '{item.invoice_pr_document_number}', '{item.invoice_pr_document_date}', "
                        + $"'{item.registration_pr_document_name}', '{item.registration_pr_document_number}', '{item.registration_pr_document_date}')";

            Provider.RunNonQuery(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Json(Provider.lastError);
            }
            else
            {
                log.Info("add packing " + user + JsonConvert.SerializeObject(item));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', '', '{item.document_id}', '{JsonConvert.SerializeObject(item)}', 0);";
                Provider.RunNonQuery(query);
                return Json("ok");
            }
        }

        [HttpPost]
        public string AddRWBill(rw_bill item, string attis_contract_id)
        {
            string user = User.Identity.GetUserId();

            var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, category, attis_contract_doc_date)" +
                        $" VALUES ('{item.doc_id}', '{attis_contract_id}', '8', 'transport', now() ) RETURNING \"attis_contract_doc_id\";"; //'{sell.InvoiceByer}', '{sell.InvoiceSeller}'
            int docid = Provider.RunScalar(query);
            string ba = DateTime.Now.ToString("yyyy-MM-dd");
            if (item.contract_date != null) ba = item.contract_date?.ToString("yyyy-MM-dd");

            query = $"INSERT INTO rw_bill (doc_id, refdocid, consignor_notice, places_quantity, gross_weight_quantity, departure_mode_description," +
                $"loader_mode_description, additional_sheet_quantity, cargo_value, customs_notice, weight_definition_mode_description," +
                $"carrier_notice, commerce_akt, prolongation, issue_marks, amount60,amount61,amount62,amount63,calculation_notice, addition_payment," +
                $"consignor_option_notice, consignor, consignee, departure_station_code, departure_station_name, departure_rwcode, departure_rwname," +
                $"departure_country, destination_rwcode, destination_station_code, destination_rwand_station_name, border_station_code, border_station_name," +
                $"border_rwcode, border_rwname, border_country, contract_name, contract_number, contract_date, flat_pallet_quantity, box_pallet_quantity," +
                $"pallet_exchange_mode, work_tool_id, work_tool_container_description, work_tool_railway_code, mark_sing, mark_kind, mark_result_control," +
                $"contract_carrier_name, contract_carrier_time, contract_carrier_date, contract_carrier_date_time_moscow, contract_carrier_station_code," +
                $"contract_carrier_station_name, contract_carrier_rw_name, contract_carrier_country, arrival_carrier_name, arrival_date, arrival_time," +
                $"arrival_date_time_moscow, arrival_station_code, arrival_station_name, arrival_rw_name, arrival_rw_code, arrival_country)" +
                $"VALUES ({item.doc_id.GetValueOrDefault()}, {docid}, '{item.consignor_notice}', {item.places_quantity.GetValueOrDefault()}, {item.gross_weight_quantity.GetValueOrDefault()}," +
                $"'{item.departure_mode_description}', '{item.loader_mode_description}', {item.additional_sheet_quantity.GetValueOrDefault()}," +
                        $" {item.cargo_value.GetValueOrDefault()}, '{item.customs_notice}', '{item.weight_definition_mode_description}', '{item.carrier_notice}'," +
                        $" '{item.commerce_akt}', '{item.prolongation}', '{item.issue_marks}', {item.amount60.GetValueOrDefault()}, {item.amount61.GetValueOrDefault()}, {item.amount62.GetValueOrDefault()},"+
                        $" '{item.amount63.GetValueOrDefault()}', '{item.calculation_notice}', '{item.addition_payment}', '{item.consignor_notice}'," +
                        $" '{item.consignor}', '{item.consignee}', '{item.departure_station_code}', '{item.departure_station_name}', '{item.departure_rwcode}'," +
                        $" '{item.departure_rwname}', '{item.departure_country}', '{item.destination_rwcode}', '{item.destination_station_code}'," +
                        $" '{item.destination_rwand_station_name}', '{item.border_station_code}', '{item.border_station_name}', '{item.border_rwcode}'," +
                        $" '{item.border_rwname}', '{item.border_country}', '{item.contract_name}', '{item.contract_number}', '{ba}'," +
                        $" {item.flat_pallet_quantity.GetValueOrDefault()}, {item.box_pallet_quantity.GetValueOrDefault()}, '{item.pallet_exchange_mode}'," +
                        $" '{item.work_tool_id}', '{item.work_tool_container_description}', '{item.work_tool_railway_code}', {item.mark_sing.GetValueOrDefault()}," +
                        $" '{item.mark_kind}', '{item.mark_result_control}', '{item.contract_carrier_name}', '{item.contract_carrier_time}'," +
                        $" '{item.contract_carrier_date}', '{item.contract_carrier_date_time_moscow}', '{item.contract_carrier_station_code}'," +
                        $" '{item.contract_carrier_station_name}', '{item.contract_carrier_rw_name}', '{item.contract_carrier_country}'," +
                        $" '{item.arrival_carrier_name}', '{item.arrival_date}', '{item.arrival_time}', '{item.arrival_date_time_moscow}'," +
                        $" '{item.arrival_station_code}', '{item.arrival_station_name}', '{item.arrival_rw_name}', '{item.arrival_rw_code}'," +
                        $" '{item.arrival_country}') RETURNING id";
            int rwb_id = Provider.RunScalar(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Provider.lastError;
            }
            else
            {
                log.Info("add rw bill " + user + JsonConvert.SerializeObject(item));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', '', '{item.doc_id}', '{JsonConvert.SerializeObject(item)}', 0);";
                Provider.RunNonQuery(query);
                if (item.goods != null)
                    foreach (var ln in item.goods)
                    {
                        query = $"INSERT INTO rwb_goods (carriage_number, conductor_description, container_indicator, container_number, currency," +
                            $"customs_code, gcost,goods_numeric,gtd_number,gross_weight_quantity, harmonized_range_goods, mrn, marking, " +
                            $"packing, place_goods_quantity, places_quantity, places_description, work_tool_description, rwb_id) " +
                        $"VALUES('{ln.carriage_number}', '{ln.conductor_description}', {ln.container_indicator.GetValueOrDefault()}, '{ln.container_number}'," +
                        $"'{ln.currency}', '{ln.customs_code}',{ln.gcost}, {ln.goods_numeric.GetValueOrDefault()}, {ln.gtd_number.GetValueOrDefault()}," +
                        $" {ln.gross_weight_quantity}, {ln.harmonized_range_goods.GetValueOrDefault()},'{ln.mrn}', '{ln.marking}','{ln.packing}'," +
                        $" {ln.place_goods_quantity}, {ln.places_quantity},'{ln.places_description}', '{ln.work_tool_description}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.carrier != null)
                    foreach (var ln in item.carrier)
                    {
                        query = $"INSERT INTO rwb_carrier (carrier_name, carrier_code, from_station_code, from_station_name, from_rw_name," +
                            $"from_country, to_station_code, to_station_name, to_rw_name, to_country, rwb_id) " +
                        $"VALUES('{ln.carrier_name}', '{ln.carrier_code}', '{ln.from_station_code}', '{ln.from_station_name}'," +
                        $" '{ln.from_rw_name}', '{ln.from_country}','{ln.to_station_code}', '{ln.to_station_name}', '{ln.to_rw_name}', '{ln.to_country}', {rwb_id}) RETURNING carrier_id;";
                        int cr = Provider.RunScalar(query);
                        
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                        if (ln.tech_station != null && cr > 0)
                        {
                            foreach (var ts in ln.tech_station)
                            {
                                query = $"INSERT INTO rw_tech_station (order_number, tech_signs, station_code, station_name, rw_name, country, carrier_id, rwb_id)" +
                                $"VALUES('{ts.order_number}', '{ts.tech_signs}', '{ts.station_code}', '{ts.station_name}', '{ts.rw_name}', '{ts.country}', {cr}, {rwb_id});";
                                Provider.RunNonQuery(query);
                            }
                        }
                    }
                if (item.container != null)
                    foreach (var ln in item.container)
                    {
                        query = $"INSERT INTO rwb_container (container_id, rw_code, container_kind, container_mode_desc, container_capacity," +
                            $"container_capacity_unit_code, tare, goods_weight, places_quentity, pocket_quentity, container_length, rwb_id) " +
                        $"VALUES('{ln.container_id}', '{ln.rw_code}', '{ln.container_kind}', '{ln.container_mode_desc}'," +
                        $"'{ln.container_capacity}', '{ln.container_capacity_unit_code}',{ln.tare.GetValueOrDefault()}, {ln.goods_weight.GetValueOrDefault()}, {ln.places_quentity.GetValueOrDefault()}," +
                        $" {ln.pocket_quentity.GetValueOrDefault()}, {ln.container_length.GetValueOrDefault()}, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.auto != null)
                    foreach (var ln in item.auto)
                    {
                        query = $"INSERT INTO rwb_auto (vin, transport_kind, transport_mark, transport_identifier, transport_nationality," +
                            $"active_transport_identifier, transport_regnumber, wagon_number, tare, goods_weight, places_quentity, pocket_quentity, container_length, rwb_id) " +
                        $"VALUES('{ln.vin}', '{ln.transport_kind}', '{ln.transport_mark}', '{ln.transport_identifier}'," +
                        $"'{ln.transport_nationality}', '{ln.active_transport_identifier}', '{ln.transport_regnumber}', {ln.wagon_number.GetValueOrDefault()}," +
                        $" {ln.tare.GetValueOrDefault()}, {ln.goods_weight.GetValueOrDefault()}, {ln.places_quentity.GetValueOrDefault()}," +
                        $" {ln.pocket_quentity.GetValueOrDefault()}, {ln.container_length.GetValueOrDefault()}, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.carriage != null)
                    foreach (var ln in item.carriage)
                    {
                        query = $"INSERT INTO rwb_carriage (rw_name, owner_name, owner_type, rw_power," +
                            $" tare, axis_quentity, goods_weight, caliber, rwb_id) " +
                        $"VALUES('{ln.rw_name}', '{ln.owner_name}', '{ln.owner_type}', '{ln.rw_power}'," +
                        $" {ln.tare.GetValueOrDefault()}, {ln.axis_quentity.GetValueOrDefault()}, {ln.goods_weight.GetValueOrDefault()}," +
                        $" '{ln.caliber}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.seal != null)
                    foreach (var ln in item.seal)
                    {
                        query = $"INSERT INTO rwb_seal (seal_id, seal_quentity, ident_kind, ident_desc, rwb_id) " +
                        $"VALUES('{ln.seal_id}', '{ln.seal_quentity}', '{ln.ident_kind}', '{ln.ident_desc}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.carrier_charge != null)
                    foreach (var ln in item.carrier_charge)
                    {
                        query = $"INSERT INTO rwb_carrier_charge (order_no, carrier_code, from_station_code, from_station_name, from_rw_name," +
                            $" from_country, to_station_code, to_station_name, to_rw_name, to_country, distance, calc_weight," +
                            $" extra_charge_code, extra_charge_name, extra_charge_amount, tarif_code, calc_cargo_code, currency_rate," +
                            $" snd_tarif_currency_code, snd_payment_currency, rcv_tarif_currency_code, rcv_payment_currency, amount48," +
                            $" amount49, amount50, amount51, amount52, amount53, amount54, amount55, amount56, amount57, amount58, amount59, rwb_id) " +
                        $"VALUES({ln.order_no.GetValueOrDefault()}, '{ln.carrier_code}', '{ln.from_station_code}', '{ln.from_station_name}'," +
                        $"'{ln.from_rw_name}', '{ln.from_country}', '{ln.to_station_code}', '{ln.to_station_name}', '{ln.to_rw_name}', " +
                        $"'{ln.to_country}', {ln.distance.GetValueOrDefault()}, {ln.calc_weight.GetValueOrDefault()}, '{ln.extra_charge_code}', '{ln.extra_charge_name}'," +
                        $" {ln.extra_charge_amount.GetValueOrDefault()}, '{ln.tarif_code}', '{ln.calc_cargo_code}', {ln.currency_rate.GetValueOrDefault()}," +
                        $" '{ln.snd_tarif_currency_code}', '{ln.snd_payment_currency}', '{ln.rcv_tarif_currency_code}'," +
                        $" '{ln.rcv_payment_currency}', {ln.amount48.GetValueOrDefault()}, {ln.amount49.GetValueOrDefault()}," +
                        $" {ln.amount50.GetValueOrDefault()},{ln.amount51.GetValueOrDefault()}, {ln.amount52.GetValueOrDefault()}," +
                        $" {ln.amount53.GetValueOrDefault()}, {ln.amount54.GetValueOrDefault()}, {ln.amount55.GetValueOrDefault()}," +
                        $" {ln.amount56.GetValueOrDefault()}, {ln.amount57.GetValueOrDefault()}, {ln.amount58.GetValueOrDefault()}, {ln.amount59.GetValueOrDefault()},{rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.paid_rw_code != null)
                    foreach (var ln in item.paid_rw_code)
                    {
                        query = $"INSERT INTO paid_rw_code (paid_rw_name, paid_rw_code, paid_rw_short, payer_code, payer_name, from_rw_name, from_country, rwb_id) " +
                        $"VALUES('{ln.paid_rw_name}', '{ln.paid_rw_code}', '{ln.paid_rw_short}', '{ln.payer_code}', '{ln.payer_name}', '{ln.from_rw_name}'," +
                        $" '{ln.from_country}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.consignor_doc != null)
                    foreach (var ln in item.consignor_doc)
                    {
                        string da = DateTime.Now.ToString("yyyy-MM-dd"), db = DateTime.Now.ToString("yyyy-MM-dd");
                        if (ln.doc_date != null) da = ln.doc_date?.ToString("yyyy-MM-dd");
                        if (ln.expiration_date != null) db = ln.expiration_date?.ToString("yyyy-MM-dd");
                        query = $"INSERT INTO rwb_doc (doc_name, doc_number, doc_date, mode_code, expiration_date, release_customs, rwb_id) " +
                        $"VALUES('{ln.doc_name}', '{ln.doc_number}', '{da}', '{ln.mode_code}', '{db}', '{ln.release_customs}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.stamp33 != null)
                    foreach (var ln in item.stamp33)
                    {
                        //string da = DateTime.Now.ToString("yyyy-MM-dd"), db = DateTime.Now.ToString("yyyy-MM-dd");
                        //if (ln.doc_date != null) da = ln.doc_date?.ToString("yyyy-MM-dd");
                        //if (ln.expiration_date != null) db = ln.expiration_date?.ToString("yyyy-MM-dd");
                        query = $"INSERT INTO rwb_stamp (carrier_name, date, time, date_time_moscow, station_code, rw_name, rw_code, " +
                            $"country, stamp_type, rwb_id) " +
                        $"VALUES('{ln.carrier_name}', '{ln.date}', '{ln.time}', '{ln.date_time_moscow}', '{ln.station_code}'," +
                        $" '{ln.rw_name}', '{ln.rw_code}', '{ln.country}', 3, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.stamp34 != null)
                    foreach (var ln in item.stamp34)
                    {
                        query = $"INSERT INTO rwb_stamp (carrier_name, date, time, date_time_moscow, station_code, rw_name, rw_code, " +
                            $"country, stamp_type, rwb_id) " +
                        $"VALUES('{ln.carrier_name}', '{ln.date}', '{ln.time}', '{ln.date_time_moscow}', '{ln.station_code}'," +
                        $" '{ln.rw_name}', '{ln.rw_code}', '{ln.country}', 4, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.stamp35 != null)
                    //foreach (var ln in item.stamp34)
                    {
                        query = $"INSERT INTO rwb_stamp (carrier_name, date, time, date_time_moscow, station_code, rw_name, rw_code, " +
                            $"country, stamp_type, rwb_id) " +
                        $"VALUES('{item.stamp35.carrier_name}', '{item.stamp35.date}', '{item.stamp35.time}', '{item.stamp35.date_time_moscow}'," +
                        $" '{item.stamp35.station_code}', '{item.stamp35.rw_name}', '{item.stamp35.rw_code}', '{item.stamp35.country}', 5, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.NewRWBill}', '{LogDocument.NewRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                return "ok";
            }
        }

        [HttpPost]
        public string UpdateRWBill(rw_bill item, string document_id)
        {
            string user = User.Identity.GetUserId();
            string ba = DateTime.Now.ToString("yyyy-MM-dd");
            if (item.contract_date != null) ba = item.contract_date?.ToString("yyyy-MM-dd");
            var query = $"UPDATE rw_bill SET(doc_id, consignor_notice, places_quantity, gross_weight_quantity, departure_mode_description," +
                $"loader_mode_description, additional_sheet_quantity, cargo_value, customs_notice, weight_definition_mode_description," +
                $"carrier_notice, commerce_akt, prolongation, issue_marks, amount60,amount61,amount62,amount63,	calculation_notice, addition_payment," +
                $"consignor_option_notice, consignor, consignee, departure_station_code, departure_station_name, departure_rwcode, departure_rwname," +
                $"departure_country, destination_rwcode, destination_station_code, destination_rwand_station_name, border_station_code, border_station_name," +
                $"border_rwcode, border_rwname, border_country, contract_name, contract_number, contract_date, flat_pallet_quantity, box_pallet_quantity," +
                $"pallet_exchange_mode, work_tool_id, work_tool_container_description, work_tool_railway_code, mark_sing, mark_kind, mark_result_control," +
                $"contract_carrier_name, contract_carrier_time, contract_carrier_date, contract_carrier_date_time_moscow, contract_carrier_station_code," +
                $"contract_carrier_station_name, contract_carrier_rw_name, contract_carrier_country, arrival_carrier_name, arrival_date, arrival_time," +
                $"arrival_date_time_moscow, arrival_station_code, arrival_station_name, arrival_rw_name, arrival_rw_code, arrival_country)" +
                $"= ('{item.doc_id}', '{item.consignor_notice}', '{item.places_quantity.GetValueOrDefault()}', '{item.gross_weight_quantity.GetValueOrDefault()}', " +
                $"'{item.departure_mode_description}', '{item.loader_mode_description}', '{item.additional_sheet_quantity.GetValueOrDefault()}'," +
                        $" '{item.cargo_value.GetValueOrDefault()}', '{item.customs_notice}', '{item.weight_definition_mode_description}', '{item.carrier_notice}'," +
                        $" '{item.commerce_akt}', '{item.prolongation}', '{item.issue_marks}', '{item.amount60.GetValueOrDefault()}', '{item.amount61.GetValueOrDefault()}', '{item.amount62.GetValueOrDefault()}'," +
                        $" '{item.amount63.GetValueOrDefault()}', '{item.calculation_notice}', '{item.addition_payment}', '{item.consignor_notice}'," +
                        $" '{item.consignor}', '{item.consignee}', '{item.departure_station_code}', '{item.departure_station_name}', '{item.departure_rwcode}'," +
                        $" '{item.departure_rwname}', '{item.departure_country}', '{item.destination_rwcode}', '{item.destination_station_code}'," +
                        $" '{item.destination_rwand_station_name}', '{item.border_station_code}', '{item.border_station_name}', '{item.border_rwcode}'," +
                        $" '{item.border_rwname}', '{item.border_country}', '{item.contract_name}', '{item.contract_number}', '{ba}'," +
                        $" {item.flat_pallet_quantity.GetValueOrDefault()}, {item.box_pallet_quantity.GetValueOrDefault()}, '{item.pallet_exchange_mode}'," +
                        $" '{item.work_tool_id}', '{item.work_tool_container_description}', '{item.work_tool_railway_code}', '{item.mark_sing}'," +
                        $" '{item.mark_kind}', '{item.mark_result_control}', '{item.contract_carrier_name}', '{item.contract_carrier_time}'," +
                        $" '{item.contract_carrier_date}', '{item.contract_carrier_date_time_moscow}', '{item.contract_carrier_station_code}'," +
                        $" '{item.contract_carrier_station_name}', '{item.contract_carrier_rw_name}', '{item.contract_carrier_country}'," +
                        $" '{item.arrival_carrier_name}', '{item.arrival_date}', '{item.arrival_time}', '{item.arrival_date_time_moscow}'," +
                        $" '{item.arrival_station_code}', '{item.arrival_station_name}', '{item.arrival_rw_name}', '{item.arrival_rw_code}'," +
                        $" '{item.arrival_country}') WHERE refdocid='{document_id}' RETURNING id";

            int rwb_id = Provider.RunScalar(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Provider.lastError;
            }
            else
            {
                log.Info("update rw bill " + user + JsonConvert.SerializeObject(item));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', '', '{item.doc_id}', '{JsonConvert.SerializeObject(item)}', 0);";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM rwb_goods WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.goods != null)
                    foreach (var ln in item.goods)
                    {
                        query = $"INSERT INTO rwb_goods (carriage_number, conductor_description, container_indicator, container_number, currency," +
                            $"customs_code, gcost,goods_numeric,gtd_number,gross_weight_quantity, harmonized_range_goods, mrn, marking, " +
                            $"packing, place_goods_quantity, places_quantity, places_description, work_tool_description, rwb_id) " +
                        $"VALUES('{ln.carriage_number}', '{ln.conductor_description}', '{ln.container_indicator}', '{ln.container_number}'," +
                        $"'{ln.currency}', '{ln.customs_code}',{ln.gcost}, {ln.goods_numeric.GetValueOrDefault()}, {ln.gtd_number.GetValueOrDefault()}," +
                        $" {ln.gross_weight_quantity}, {ln.harmonized_range_goods.GetValueOrDefault()},'{ln.mrn}', '{ln.marking}','{ln.packing}'," +
                        $" {ln.place_goods_quantity}, {ln.places_quantity},'{ln.places_description}', '{ln.work_tool_description}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM rwb_carrier WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM rw_tech_station WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.carrier != null)
                    foreach (var ln in item.carrier)
                    {
                        query = $"INSERT INTO rwb_carrier (carrier_name, carrier_code, from_station_code, from_station_name, from_rw_name," +
                            $"from_country, to_station_code, to_station_name, to_rw_name, to_country, rwb_id) " +
                        $"VALUES('{ln.carrier_name}', '{ln.carrier_code}', '{ln.from_station_code}', '{ln.from_station_name}'," +
                        $" '{ln.from_rw_name}', '{ln.from_country}','{ln.to_station_code}', '{ln.to_station_name}', '{ln.to_rw_name}', '{ln.to_country}', {rwb_id}) RETURNING carrier_id;";
                        int cr = Provider.RunScalar(query);

                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                        if (ln.tech_station != null && cr > 0)
                        {
                            foreach (var ts in ln.tech_station)
                            {
                                query = $"INSERT INTO rw_tech_station (order_number, tech_signs, station_code, station_name, rw_name, country, carrier_id, rwb_id)" +
                                $"VALUES({ts.order_number.GetValueOrDefault()}, '{ts.tech_signs}', '{ts.station_code}', '{ts.station_name}', '{ts.rw_name}', '{ts.country}', {cr}, {rwb_id});";
                                Provider.RunNonQuery(query);
                            }
                        }
                    }
                query = $"DELETE FROM rwb_container WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.container != null)
                    foreach (var ln in item.container)
                    {
                        query = $"INSERT INTO rwb_container (container_id, rw_code, container_kind, container_mode_desc, container_capacity," +
                            $"container_capacity_unit_code, tare, goods_weight, places_quentity, pocket_quentity, container_length, rwb_id) " +
                        $"VALUES('{ln.container_id}', '{ln.rw_code}', '{ln.container_kind}', '{ln.container_mode_desc}'," +
                        $"'{ln.container_capacity}', '{ln.container_capacity_unit_code}',{ln.tare.GetValueOrDefault()}, {ln.goods_weight.GetValueOrDefault()}, {ln.places_quentity.GetValueOrDefault()}," +
                        $" {ln.pocket_quentity.GetValueOrDefault()}, {ln.container_length.GetValueOrDefault()}, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM rwb_auto WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.auto != null)
                    foreach (var ln in item.auto)
                    {
                        query = $"INSERT INTO rwb_auto (vin, transport_kind, transport_mark, transport_identifier, transport_nationality," +
                            $"active_transport_identifier, transport_regnumber, wagon_number, tare, goods_weight, places_quentity, pocket_quentity, container_length, rwb_id) " +
                        $"VALUES('{ln.vin}', '{ln.transport_kind}', '{ln.transport_mark}', '{ln.transport_identifier}'," +
                        $"'{ln.transport_nationality}', '{ln.active_transport_identifier}', '{ln.transport_regnumber}', '{ln.wagon_number}'," +
                        $" {ln.tare.GetValueOrDefault()}, {ln.goods_weight.GetValueOrDefault()}, {ln.places_quentity.GetValueOrDefault()}," +
                        $" {ln.pocket_quentity.GetValueOrDefault()}, {ln.container_length.GetValueOrDefault()}, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM rwb_carriage WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.carriage != null)
                    foreach (var ln in item.carriage)
                    {
                        query = $"INSERT INTO rwb_carriage (rw_name, owner_name, owner_type, rw_power," +
                            $" tare, axis_quentity, goods_weight, caliber, rwb_id) " +
                        $"VALUES('{ln.rw_name}', '{ln.owner_name}', '{ln.owner_type}', '{ln.rw_power}'," +
                        $" {ln.tare.GetValueOrDefault()}, {ln.axis_quentity.GetValueOrDefault()}, {ln.goods_weight.GetValueOrDefault()}," +
                        $" '{ln.caliber}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM rwb_seal WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.seal != null)
                    foreach (var ln in item.seal)
                    {
                        query = $"INSERT INTO rwb_seal (seal_id, seal_quentity, ident_kind, ident_desc, rwb_id) " +
                        $"VALUES('{ln.seal_id}', '{ln.seal_quentity}', '{ln.ident_kind}', '{ln.ident_desc}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM rwb_carrier_charge WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.carrier_charge != null)
                    foreach (var ln in item.carrier_charge)
                    {
                        query = $"INSERT INTO rwb_carrier_charge (order_no, carrier_code, from_station_code, from_station_name, from_rw_name," +
                            $" from_country, to_station_code, to_station_name, to_rw_name, to_country, distance, calc_weight," +
                            $" extra_charge_code, extra_charge_name, extra_charge_amount, tarif_code, calc_cargo_code, currency_rate," +
                            $" snd_tarif_currency_code, snd_payment_currency, rcv_tarif_currency_code, rcv_payment_currency, amount48," +
                            $" amount49, amount50, amount51, amount52, amount53, amount54, amount55, amount56, amount57, amount58, amount59, rwb_id) " +
                        $"VALUES({ln.order_no.GetValueOrDefault()}, '{ln.carrier_code}', '{ln.from_station_code}', '{ln.from_station_name}'," +
                        $"'{ln.from_rw_name}', '{ln.from_country}', '{ln.to_station_code}', '{ln.to_station_name}', '{ln.to_rw_name}', " +
                        $"'{ln.to_country}', {ln.distance.GetValueOrDefault()}, {ln.calc_weight.GetValueOrDefault()}, '{ln.extra_charge_code}', '{ln.extra_charge_name}'," +
                        $" {ln.extra_charge_amount.GetValueOrDefault()}, '{ln.tarif_code}', '{ln.calc_cargo_code}', {ln.currency_rate.GetValueOrDefault()}," +
                        $" '{ln.snd_tarif_currency_code}', '{ln.snd_payment_currency}', '{ln.rcv_tarif_currency_code}'," +
                        $" '{ln.rcv_payment_currency}', {ln.amount48.GetValueOrDefault()}, {ln.amount49.GetValueOrDefault()}," +
                        $" {ln.amount50.GetValueOrDefault()},{ln.amount51.GetValueOrDefault()}, {ln.amount52.GetValueOrDefault()}," +
                        $" {ln.amount53.GetValueOrDefault()}, {ln.amount54.GetValueOrDefault()}, {ln.amount55.GetValueOrDefault()}," +
                        $" {ln.amount56.GetValueOrDefault()}, {ln.amount57.GetValueOrDefault()}, {ln.amount58.GetValueOrDefault()}, {ln.amount59.GetValueOrDefault()},{rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM paid_rw_code WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.paid_rw_code != null)
                    foreach (var ln in item.paid_rw_code)
                    {
                        query = $"INSERT INTO paid_rw_code (paid_rw_name, paid_rw_code, paid_rw_short, payer_code, payer_name, from_rw_name, from_country, rwb_id) " +
                        $"VALUES('{ln.paid_rw_name}', '{ln.paid_rw_code}', '{ln.paid_rw_short}', '{ln.payer_code}', '{ln.payer_name}', '{ln.from_rw_name}'," +
                        $" '{ln.from_country}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM rwb_doc WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.consignor_doc != null)
                    foreach (var ln in item.consignor_doc)
                    {
                        string da = DateTime.Now.ToString("yyyy-MM-dd"), db = DateTime.Now.ToString("yyyy-MM-dd");
                        if (ln.doc_date != null) da = ln.doc_date?.ToString("yyyy-MM-dd");
                        if (ln.expiration_date != null) db = ln.expiration_date?.ToString("yyyy-MM-dd");
                        query = $"INSERT INTO rwb_doc (doc_name, doc_number, doc_date, mode_code, expiration_date, release_customs, rwb_id) " +
                        $"VALUES('{ln.doc_name}', '{ln.doc_number}', '{da}', '{ln.mode_code}', '{db}', '{ln.release_customs}', {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM rwb_stamp WHERE rwb_id={rwb_id};";
                Provider.RunNonQuery(query);
                if (item.stamp33 != null)
                    foreach (var ln in item.stamp33)
                    {
                        //string da = DateTime.Now.ToString("yyyy-MM-dd"), db = DateTime.Now.ToString("yyyy-MM-dd");
                        //if (ln.doc_date != null) da = ln.doc_date?.ToString("yyyy-MM-dd");
                        //if (ln.expiration_date != null) db = ln.expiration_date?.ToString("yyyy-MM-dd");
                        query = $"INSERT INTO rwb_stamp (carrier_name, date, time, date_time_moscow, station_code, rw_name, rw_code, " +
                            $"country, stamp_type, rwb_id) " +
                        $"VALUES('{ln.carrier_name}', '{ln.date}', '{ln.time}', '{ln.date_time_moscow}', '{ln.station_code}'," +
                        $" '{ln.rw_name}', '{ln.rw_code}', '{ln.country}', 3, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.stamp34 != null)
                    foreach (var ln in item.stamp34)
                    {
                        query = $"INSERT INTO rwb_stamp (carrier_name, date, time, date_time_moscow, station_code, rw_name, rw_code, " +
                            $"country, stamp_type, rwb_id) " +
                        $"VALUES('{ln.carrier_name}', '{ln.date}', '{ln.time}', '{ln.date_time_moscow}', '{ln.station_code}'," +
                        $" '{ln.rw_name}', '{ln.rw_code}', '{ln.country}', 4, {rwb_id});";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (item.stamp35 != null)
                //foreach (var ln in item.stamp34)
                {
                    query = $"INSERT INTO rwb_stamp (carrier_name, date, time, date_time_moscow, station_code, rw_name, rw_code, " +
                        $"country, stamp_type, rwb_id) " +
                    $"VALUES('{item.stamp35.carrier_name}', '{item.stamp35.date}', '{item.stamp35.time}', '{item.stamp35.date_time_moscow}'," +
                    $" '{item.stamp35.station_code}', '{item.stamp35.rw_name}', '{item.stamp35.rw_code}', '{item.stamp35.country}', 5, {rwb_id});";
                    Provider.RunNonQuery(query);
                    if (Provider.lastError != "")
                    {
                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.UpdateRWBill}', '{LogDocument.UpdateRWBill}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                        Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                }

                return "ok";
            }
        }

        [HttpPost]
        public string DeleteRWBill(string document_id)
        {    
            var query = "DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{document_id}';";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rw_bill WHERE refdocid='{document_id}' RETURNING id;";
            int rwb_id = Provider.RunScalar(query);
            query = $"DELETE FROM rwb_goods WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_carrier WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rw_tech_station WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_container WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_auto WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_carriage WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_seal WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_carrier_charge WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM paid_rw_code WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_doc WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            query = $"DELETE FROM rwb_stamp WHERE rwb_id={rwb_id};";
            Provider.RunNonQuery(query);
            string user = User.Identity.GetUserId();
            log.Info("delete rw bill " + user + JsonConvert.SerializeObject(document_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.DeleteRWBill}', '{LogDocument.DeleteRWBill}', '{LogSection.Document}', '{user}', '', '{document_id}', '{JsonConvert.SerializeObject(document_id)}', 0);";
            Provider.RunNonQuery(query);
            return "ok";
        }

        public string Fm1InitialData(string contragent, bool isSeller)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);
            fm1_initial_data data = new fm1_initial_data();
            fullComp seller = new fullComp();
            fullComp buyer = new fullComp();
            if (isSeller)
            {
                seller = JsonConvert.DeserializeObject<fullComp>(getFirmbyBin(org_code));
                buyer = JsonConvert.DeserializeObject<fullComp>(getFirmbyBin(contragent));
            }
            else
            {
                seller = JsonConvert.DeserializeObject<fullComp>(getFirmbyBin(contragent));
                buyer = JsonConvert.DeserializeObject<fullComp>(getFirmbyBin(org_code));
            }
            data.seller = seller;
            data.buyer = buyer;
            return JsonConvert.SerializeObject(data);
        }
        public string RwbInitialData(string attis_contract_id)
        {
            string user = User.Identity.GetUserId();
            DateTime? whenIsSigned =null;
            string org_name ="";
            string query = $"SELECT con.when_is_signed_by_owner, t1.org_name FROM attis_contracts con LEFT JOIN  courier_requests t2 on t2.contract_id='{attis_contract_id}' LEFT JOIN organizations t1 on t1.org_code = t2.countragent  WHERE attis_contract_id='{attis_contract_id}'";
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            { 
                reader1.Read();
                whenIsSigned = GetDateTimeFromString(reader1["when_is_signed_by_owner"].ToString());
                org_name = reader1["org_name"].ToString();
                reader1.Close();
            }
            query = $"SELECT t1.*, t2.attis_doc_type_name_ru FROM attis_contract_docs t1 LEFT JOIN  attis_doc_types t2 ON t1.attis_contract_doc_type = t2.attis_doc_type_code WHERE attis_contract_doc_contract = '{attis_contract_id}';";
            var reader = Provider.RunQuery(query);
            //var docs = new List<DocModel>();
            var packingListIds = new List<string>();
            var invoiceListIds = new List<string>();
            List<DocModel> invoiceList = new List<DocModel>();
            List<PackingList> packingLists = new List<PackingList>();
            comp consignor = new comp();
            comp consignee = new comp();
            if (reader != null)
            {
                while (reader.Read())
                {
                    if (reader["attis_doc_type_name_ru"].ToString() == "Инвойс")
                    {
                        invoiceListIds.Add(reader["attis_contract_doc_id"].ToString());
                        //DocModel invoice = (DocModel)JsonConvert.DeserializeObject(LoadInvoice(reader["attis_contract_doc_id"].ToString(), String.Empty));
                        //invoiceList.Add(invoice);
                    }
                    else if (reader["attis_doc_type_name_ru"].ToString() == "Пакинг лист")
                    {
                        packingListIds.Add(reader["attis_contract_doc_id"].ToString());
                        //List<PackingList> list = (List<PackingList>)JsonConvert.DeserializeObject(getPackingList(reader["attis_contract_doc_id"].ToString()));
                        //packingLists.AddRange(list);
                    }
                }
                reader.Close();
                

                //return JsonConvert.SerializeObject(docs);
            }
            if (invoiceListIds.Count > 0)
            {
                foreach(var id in invoiceListIds)
                {
                    DocModel invoice = JsonConvert.DeserializeObject<DocModel>(LoadInvoice(id, String.Empty));
                    invoiceList.Add(invoice);
                }
                foreach(var id in packingListIds)
                {
                    List<PackingList> list = JsonConvert.DeserializeObject<List<PackingList>>(getPackingList(id));
                    packingLists.AddRange(list);
                }
                if (invoiceList.Count > 0)
                {
                    if (invoiceList[0].InvoiceByer != null)
                        consignee = getComp(invoiceList[0].InvoiceByer);
                    if(invoiceList[0].InvoiceSeller != null)
                        consignor = getComp(invoiceList[0].InvoiceSeller);
                }

            }
            List<CSVModel> ktzh_resp = rwb_ktzh_resp(attis_contract_id);
            rwb_initial_data data = new rwb_initial_data();
            data.invoice_list = invoiceList;
            data.packing_lists = packingLists;
            data.ktzh_resp = ktzh_resp;
            data.consignor = consignor;
            data.consignee = consignee;
            data.when_signed_by_owner = whenIsSigned;
            data.contrac_carrier_name = org_name;


            return JsonConvert.SerializeObject(data);

        }

        public string InsuranceInitialData(string attis_contract_id)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{attis_contract_id}'";
            string owner = Provider.RunQueryStr(query);
            query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{owner}'";
            var org_code = Provider.RunQueryStr(query);
            fullComp ownerComp = new fullComp();

            if (org_code != null)
                ownerComp = JsonConvert.DeserializeObject<fullComp>(getFirmbyBin(org_code));
            else return "";


            var query1 = $"SELECT attis_cg_good_name, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price, origin FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
            var reader1 = Provider.RunQuery(query1);

            var products = new List<Product>();
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new Product
                    {
                        attis_cg_good_name = reader1["attis_cg_good_name"].ToString(),
                    };
                    rep1.attis_cg_TNVED = reader1["attis_cg_TNVED"].ToString();
                    rep1.attis_cg_quantity = reader1["attis_cg_quantity"].ToString();
                    rep1.attis_cg_measures = reader1["attis_cg_measures"].ToString();
                    rep1.attis_cg_price = reader1["attis_cg_price"].ToString();
                    rep1.origin_country = reader1["origin"].ToString();
                    products.Add(rep1);
                }
                reader1.Close();
            }


            query = $"SELECT t1.*, t2.attis_doc_type_name_ru FROM attis_contract_docs t1 LEFT JOIN  attis_doc_types t2 ON t1.attis_contract_doc_type = t2.attis_doc_type_code WHERE attis_contract_doc_contract = '{attis_contract_id}';";
            var reader = Provider.RunQuery(query);
            //var docs = new List<DocModel>();
            var packingListIds = new List<string>();
            List<PackingList> packingLists = new List<PackingList>();
            CMRModel cmr = new CMRModel();
            var cmrIds = new List<string>();
            
            if (reader != null)
            {
                while (reader.Read())
                {

                    if (reader["attis_doc_type_name_ru"].ToString() == "Пакинг лист")
                    {
                        packingListIds.Add(reader["attis_contract_doc_id"].ToString());
                        //List<PackingList> list = (List<PackingList>)JsonConvert.DeserializeObject(getPackingList(reader["attis_contract_doc_id"].ToString()));
                        //packingLists.AddRange(list);
                    }
                    if (reader["attis_doc_type_name_ru"].ToString() == "CMR")
                    {
                        cmrIds.Add(reader["attis_contract_doc_id"].ToString());
                    }
                }
                reader.Close();
                if (packingListIds.Count > 0)
                {
                    foreach (var id in packingListIds)
                    {
                        List<PackingList> list = JsonConvert.DeserializeObject<List<PackingList>>(getPackingList(id));
                        packingLists.AddRange(list);
                    }
                }
                if (cmrIds.Count > 0)
                {
                    cmr = JsonConvert.DeserializeObject<CMRModel>(LoadCMR(cmrIds[0], String.Empty));
                }


                    //return JsonConvert.SerializeObject(docs);
            }
            insurance_initial_data data = new insurance_initial_data();
            data.contract_owner = ownerComp;
            data.products = products;
            data.packing_lists = packingLists;
            data.cmr = cmr;
            return JsonConvert.SerializeObject(data);

        }

        [HttpPost]
        public JsonResult UpdatePacking(PackingListItem item, string list_id)
        {
            string user = User.Identity.GetUserId();
            var query = $"UPDATE packing_list SET (document_id, ref_document_id, gross_weight_quantity, net_weight_quantity, consignor, consignee, delivery_terms_numeric_code, delivery_terms_string_code, "
                        + $"terms_description, contract_pr_document_name, contract_pr_document_number, contract_pr_document_date, invoice_pr_document_name, invoice_pr_document_number, invoice_pr_document_date, registration_pr_document_name, registration_pr_document_number, registration_pr_document_date) "
                        + $"=('{item.document_id}', '{item.ref_document_id}', '{item.gross_weight}', '{item.net_weight}', '{item.consignor}', '{item.consignee}', '{item.delivery_terms_numeric_code}', '{item.delivery_terms_string_code}', "
                        + $"'{item.terms_description}', '{item.contract_pr_document_name}', '{item.contract_pr_document_number}', '{item.contract_pr_document_date}', '{item.invoice_pr_document_name}', '{item.invoice_pr_document_number}', '{item.invoice_pr_document_date}', "
                        + $"'{item.registration_pr_document_name}', '{item.registration_pr_document_number}', '{item.registration_pr_document_date}') WHERE list_id = '{list_id}'";
            Provider.RunNonQuery(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.PackingListUpdate}', '{LogDocument.PackingListUpdate}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Json(Provider.lastError);
            }
            else
            {
                log.Info("update packing " + user + JsonConvert.SerializeObject(item));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.NewPackingList}', '{LogDocument.NewPackingList}', '{LogSection.Document}', '{user}', '', '{item.document_id}', '{JsonConvert.SerializeObject(item)}', 0);";
                Provider.RunNonQuery(query);
                return Json("ok");
            }
        }

        [HttpPost]
        public JsonResult DeletePacking(string list_id)
        {
            string user = User.Identity.GetUserId();
            var query = $"DELETE FROM packing_list WHERE list_id = '{list_id}'";
            Provider.RunNonQuery(query);
            log.Info("delete packing " + user + JsonConvert.SerializeObject(list_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.DeletePackingList}', '{LogDocument.DeletePackingList}', '{LogSection.Document}', '{user}', '', '{list_id}', '{JsonConvert.SerializeObject(list_id)}', 0);";
            Provider.RunNonQuery(query);
            return Json("ok");
        }

        public string LoadCompanyDocuments()
        {
            var user = User.Identity.GetUserId();
            string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            List<PADocument> list = new List<PADocument>();
            query = $"SELECT pd.pa_doc_id, pd.pa_doc_type_code, pd.pa_doc_number, pd.pa_doc_series, pd.pa_doc_date, pd.pa_doc_create_org, pd.pa_doc_end_date, pd.pa_doc_active, img.id, img.img_file_name FROM pa_docs pd LEFT JOIN docimages img on img.doc_guid = cast(pd.pa_doc_id as varchar) and doc_widget_id = 'pa_doc' WHERE org_id='{oid}'";
            var reader = Provider.RunQuery(query);

            if (reader != null)
            {
                while (reader.Read())
                {
                    var document = new PADocument();
                    document.id = reader["pa_doc_id"].ToString();
                    document.document_type = reader["pa_doc_type_code"].ToString();
                    document.document_number = reader["pa_doc_number"].ToString();
                    document.document_serial = reader["pa_doc_series"].ToString();
                    document.document_date = GetDateTimeFromString(reader["pa_doc_date"].ToString());
                    document.document_issued_by = reader["pa_doc_create_org"].ToString();
                    DateTime? end_date = GetDateTimeFromString(reader["pa_doc_end_date"].ToString());
                    document.is_active = reader["pa_doc_active"].ToString();
                    document.document_exp_date = GetDateTimeFromString(reader["pa_doc_end_date"].ToString());

                    //if (end_date != DateTime.MinValue && end_date <= DateTime.Now)
                    //    document.is_active = "0";
                    //else
                    //    document.is_active = "1";
                    var image = new Kfiles
                    {
                        id = reader["id"].ToString()
                    };
                    image.name = reader["img_file_name"].ToString();
                    document.file = image;
                    list.Add(document);

                }
                reader.Close();
            }

            return JsonConvert.SerializeObject(list);
        }
        public string LoadPersonDocuments()
        {

            var user = User.Identity.GetUserId();
            string query = "SELECT person_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            List<PADocument> list = new List<PADocument>();
            query = $"SELECT pd.pa_doc_id, pd.pa_doc_type_code, pd.pa_doc_number, pd.pa_doc_series, pd.pa_doc_date, pd.pa_doc_create_org, pd.pa_doc_end_date, pa_doc_active, img.id, img.img_file_name FROM pa_docs pd LEFT JOIN docimages img on img.doc_guid = cast(pd.pa_doc_id as varchar) and doc_widget_id = 'pa_doc' WHERE person_id='{oid}'";
            var reader = Provider.RunQuery(query);

            if (reader != null)
            {
                while (reader.Read())
                {
                    var document = new PADocument();
                    document.id = reader["pa_doc_id"].ToString();
                    document.document_type = reader["pa_doc_type_code"].ToString();
                    document.document_number = reader["pa_doc_number"].ToString();
                    document.document_serial = reader["pa_doc_series"].ToString();
                    document.document_date = GetDateTimeFromString(reader["pa_doc_date"].ToString());
                    document.document_issued_by = reader["pa_doc_create_org"].ToString();
                    
                    //DateTime? end_date = GetDateTimeFromString(reader["pa_doc_end_date"].ToString());
                    int isActive = Int32.Parse(reader["pa_doc_active"].ToString());
                    document.is_active = reader["pa_doc_active"].ToString();
                    document.document_exp_date = GetDateTimeFromString(reader["pa_doc_end_date"].ToString());
                    //if (end_date != DateTime.MinValue && end_date <= DateTime.Now)
                    //    document.is_active = "0";
                    //else
                    //    document.is_active = "1";
                    var image = new Kfiles
                    {
                        id = reader["id"].ToString()
                    };
                    image.name = reader["img_file_name"].ToString();
                    document.file = image;

                    list.Add(document);

                }
                reader.Close();

            }

            return JsonConvert.SerializeObject(list);
        }

        public List<PADocument> LoadPersonDocumentsByCode(string person_code)
        {

            var user = User.Identity.GetUserId();
            string query = "SELECT person_id FROM persons WHERE person_code ='" + person_code + "';";
            int oid = Provider.RunScalar(query);
            List<PADocument> list = new List<PADocument>();
            query = $"SELECT pd.pa_doc_id, pd.pa_doc_type_code, pd.pa_doc_number, pd.pa_doc_series, pd.pa_doc_date, pd.pa_doc_create_org, pd.pa_doc_end_date, pa_doc_active, img.id, img.img_file_name FROM pa_docs pd LEFT JOIN docimages img on img.doc_guid = cast(pd.pa_doc_id as varchar) and doc_widget_id = 'pa_doc' WHERE person_id='{oid}'";
            var reader = Provider.RunQuery(query);

            if (reader != null)
            {
                while (reader.Read())
                {
                    var document = new PADocument();
                    document.id = reader["pa_doc_id"].ToString();
                    document.document_type = reader["pa_doc_type_code"].ToString();
                    document.document_number = reader["pa_doc_number"].ToString();
                    document.document_serial = reader["pa_doc_series"].ToString();
                    document.document_date = GetDateTimeFromString(reader["pa_doc_date"].ToString());
                    document.document_issued_by = reader["pa_doc_create_org"].ToString();

                    //DateTime? end_date = GetDateTimeFromString(reader["pa_doc_end_date"].ToString());
                    int isActive = Int32.Parse(reader["pa_doc_active"].ToString());
                    document.is_active = reader["pa_doc_active"].ToString();
                    document.document_exp_date = GetDateTimeFromString(reader["pa_doc_end_date"].ToString());
                    //if (end_date != DateTime.MinValue && end_date <= DateTime.Now)
                    //    document.is_active = "0";
                    //else
                    //    document.is_active = "1";
                    var image = new Kfiles
                    {
                        id = reader["id"].ToString()
                    };
                    image.name = reader["img_file_name"].ToString();
                    document.file = image;

                    list.Add(document);

                }
                reader.Close();

            }

            return list;
        }

        [HttpPost]
        public string SaveCompanyDocument(PADocument model)
        {
            var docid = "";
            try
            {
                string user = User.Identity.GetUserId();
                string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
                int oid = Provider.RunScalar(query);
                var date = String.Empty;
                var expire_date = String.Empty;
                if (model.document_date != null)
                    date = "pa_doc_date = '" + ((DateTime)model.document_date).ToString("yyyy.MM.dd") + "'";
                if (model.document_exp_date != null)
                    expire_date = "pa_doc_end_date = '" + ((DateTime)model.document_exp_date).ToString("yyyy.MM.dd") + "'";
                if (!String.IsNullOrEmpty(model.id))
                {
                    query = $"UPDATE pa_docs set pa_doc_type_code = '{model.document_type}', pa_doc_number = '{model.document_number}', pa_doc_series = '{model.document_serial}', " +
                        $"pa_doc_create_org = '{model.document_issued_by}', pa_doc_active = '{model.is_active}' where pa_doc_id = '{model.id}' RETURNING pa_doc_id";
                    docid = Provider.RunScalar(query).ToString();
                    if (Provider.lastError != "")
                    {
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                    if (!String.IsNullOrEmpty(date))
                    {
                        query = $"UPDATE pa_docs set {date} where pa_doc_id = '{model.id}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                    if (!String.IsNullOrEmpty(expire_date))
                    {
                        query = $"UPDATE pa_docs set {expire_date} where pa_doc_id = '{model.id}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                }
                else
                {
                    query = $"INSERT INTO pa_docs (pa_doc_type_code, pa_doc_number, pa_doc_series, pa_doc_create_org, org_id, pa_doc_active)" +
                        $" VALUES ('{model.document_type}', '{model.document_number}', '{model.document_serial}', '{model.document_issued_by}', '{oid}', '{model.is_active}' ) RETURNING pa_doc_id";
                    docid = Provider.RunScalar(query).ToString();
                    if (Provider.lastError != "")
                    {
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                    if (!String.IsNullOrEmpty(date))
                    {
                        query = $"UPDATE pa_docs set {date} where pa_doc_id = '{docid}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                    if (!String.IsNullOrEmpty(expire_date))
                    {
                        query = $"UPDATE pa_docs set {expire_date} where pa_doc_id = '{docid}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                }
                if (Int32.Parse(docid) > 0)
                {
                    var r = new List<ImageFile>();
                    int? rid = null; string type = "";
                    foreach (string fil in Request.Files)
                    {
                        var hpf = Request.Files[fil];
                        if (hpf.ContentLength == 0)
                            continue;

                        // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                        // hpf.SaveAs(savedFileName);
                        var imgFile = new ImageFile
                        {
                            ID = 0,
                            EntityId = docid,
                            Name = hpf.FileName,
                            Length = hpf.ContentLength,
                            Type = hpf.ContentType,
                            Date = DateTime.Now,
                            Image = new MemoryStream(),
                            WidgetId = "pa_doc"
                        };

                        hpf.InputStream.CopyTo(imgFile.Image);

                        Provider.SaveFile(imgFile);

                        r.Add(imgFile);
                    }
                    if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                }
                else
                {
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }


            }
            catch (Exception ex)
            {

            }
            return "{\"status\":\"ok\",\"id\":" + docid.ToString() + "}";
        }
        [HttpPost]
        public string SavePersonDocument(PADocument model)
        {
            var docid = "";
            try
            {
                var user = User.Identity.GetUserId();
                string query = "SELECT person_id FROM persons WHERE user_id ='" + user + "';";
                int oid = Provider.RunScalar(query);
                var date = String.Empty;
                var expire_date = String.Empty;
                if (model.document_date != null)
                    date = "pa_doc_date = '" + ((DateTime)model.document_date).ToString("yyyy.MM.dd") + "'";
                if (model.document_exp_date != null)
                    expire_date = "pa_doc_end_date = '" + ((DateTime)model.document_exp_date).ToString("yyyy.MM.dd") + "'";
                if (!String.IsNullOrEmpty(model.id))
                {
                    query = $"UPDATE pa_docs set pa_doc_type_code = '{model.document_type}', pa_doc_number = '{model.document_number}', pa_doc_series = '{model.document_serial}', " +
                        $"pa_doc_create_org = '{model.document_issued_by}', pa_doc_active = '{model.is_active}' where pa_doc_id = '{model.id}' RETURNING pa_doc_id";
                    docid = Provider.RunScalar(query).ToString();
                    if (Provider.lastError != "")
                    {
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                    if (!String.IsNullOrEmpty(date))
                    {
                        query = $"UPDATE pa_docs set {date} where pa_doc_id = '{model.id}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                    if (!String.IsNullOrEmpty(expire_date))
                    {
                        query = $"UPDATE pa_docs set {expire_date} where pa_doc_id = '{model.id}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                }
                else
                {
                    query = $"INSERT INTO pa_docs (pa_doc_type_code, pa_doc_number, pa_doc_series, pa_doc_create_org, person_id, pa_doc_active)" +
                        $" VALUES ('{model.document_type}', '{model.document_number}', '{model.document_serial}', '{model.document_issued_by}', '{oid}', '{model.is_active}' ) RETURNING pa_doc_id";
                    docid = Provider.RunScalar(query).ToString();
                    if (Provider.lastError != "")
                    {
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                    if (!String.IsNullOrEmpty(date))
                    {
                        query = $"UPDATE pa_docs set {date} where pa_doc_id = '{docid}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                    if (!String.IsNullOrEmpty(expire_date))
                    {
                        query = $"UPDATE pa_docs set {expire_date} where pa_doc_id = '{docid}'";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }

                }
                
                if (Int32.Parse(docid) > 0)
                {
                    var r = new List<ImageFile>();
                    int? rid = null; string type = "";
                    foreach (string fil in Request.Files)
                    {
                        var hpf = Request.Files[fil];
                        if (hpf.ContentLength == 0)
                            continue;

                        // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                        // hpf.SaveAs(savedFileName);
                        var imgFile = new ImageFile
                        {
                            ID = 0,
                            EntityId = docid,
                            Name = hpf.FileName,
                            Length = hpf.ContentLength,
                            Type = hpf.ContentType,
                            Date = DateTime.Now,
                            Image = new MemoryStream(),
                            WidgetId = "pa_doc"
                        };

                        hpf.InputStream.CopyTo(imgFile.Image);

                        Provider.SaveFile(imgFile);

                        r.Add(imgFile);
                    }
                    if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                }
                else
                {
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
            }
            catch (Exception ex)
            {

            }
            return "{\"status\":\"ok\",\"id\":" + docid.ToString() + "}";
        }
        [HttpPost]
        public string RemovePADocument(string docId)
        {
            if (!String.IsNullOrEmpty(docId))
            {
                string query = $"DELETE FROM pa_docs where pa_doc_id = '{docId}';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                query = $"DELETE FROM docimages where doc_guid = '{docId}' and doc_widget_id = 'pa_doc';";
                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
            }
            return "{\"status\":\"ok\"}";
        }
        [HttpPost]
        public string testservice()
        {
            //var upl = new Lawyers.Web.App.Astana1.AutoPreliminaryInformationClient();
            //var info = new Lawyers.Web.App.Astana1.AutoPreliminaryInformation();
            //var res = upl.register(info);
            string result = "das";
            return result;

            //var sa = new Lawyers.Web.App.invoice_service.invoiceUpload();
        }
        public List<CSVModel> rwb_ktzh_resp(string contract_id)
        {
            var query = $"SELECT distinct on(rsp.id) rsp.*, t1.rw_naimstan as recive_station_name, t2.rw_naimstan as dest_station_name FROM ktg_response rsp LEFT JOIN rw_stations t1 on CAST(t1.rw_kodstan6 AS VARCHAR) = rsp.recive_station_code LEFT JOIN rw_stations t2 on CAST(t2.rw_kodstan6 AS VARCHAR) = rsp.dest_station_code LEFT JOIN ktg_log t3 on t3.id = rsp.request_id  WHERE t3.contract_id='{contract_id}'";// WHERE contract_id='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var list = new List<CSVModel>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new CSVModel
                    {
                        id = (int)reader["id"],
                    };
                    rep1.invoice_un = reader["invoice_un"].ToString();
                    rep1.invoice_num = reader["invoice_num"].ToString();
                    rep1.recive_station_code = reader["recive_station_code"].ToString();
                    rep1.dest_station_code = reader["dest_station_code"].ToString();
                    rep1.recive_station_name = reader["recive_station_name"].ToString();
                    rep1.dest_station_name = reader["dest_station_name"].ToString();
                    rep1.sender_exp_no = reader["sender_exp_no"].ToString();
                    rep1.etsng_code = reader["etsng_code"].ToString();
                    rep1.fact_mass = reader.GetFieldValueOrDefault<float>("fact_mass");
                    rep1.payer_code = reader["payer_code"].ToString();
                    rep1.vag_no = reader["vag_no"].ToString();
                    rep1.vag_count = reader.GetFieldValueOrDefault<int>("vag_count");
                    rep1.gruz = reader.GetFieldValueOrDefault<float>("gruz");
                    rep1.invc_dt = GetDateTimeFromString(reader["invc_dt"].ToString());
                    rep1.container_no = reader["container_no"].ToString();
                    rep1.smgs_type = reader.GetFieldValueOrDefault<int>("smgs_type");
                    list.Add(rep1);
                }
                reader.Close();
                return list;
            }
            return null;
        }
        public class xp
        {
            public string Exception { get; set; }
            public string InnerException { get; set; }
        }

        [HttpPost]
        public string addDocNotification(docNotification doc)
        {
            var user = User.Identity.GetUserId();
            string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"),
                dd = DateTime.Now.ToString("yyyy.MM.dd"), ee = DateTime.Now.ToString("yyyy.MM.dd"), ab = DateTime.Now.ToString("yyyy.MM.dd"),
                ac = DateTime.Now.ToString("yyyy.MM.dd"), ad = DateTime.Now.ToString("yyyy.MM.dd"), ae = DateTime.Now.ToString("yyyy.MM.dd"),
                bd = DateTime.Now.ToString("yyyy.MM.dd"), be = DateTime.Now.ToString("yyyy.MM.dd"), bf = DateTime.Now.ToString("yyyy.MM.dd"),
                bg = DateTime.Now.ToString("yyyy.MM.dd");
            if (doc.driverpasspdate != null)
                aa = doc.driverpasspdate?.ToString("yyyy.MM.dd");
            if (doc.placedate != null)
                bb = doc.placedate?.ToString("yyyy.MM.dd");
            if (doc.noticedate != null)
                cc = doc.noticedate?.ToString("yyyy.MM.dd");
            if (doc.dateout != null)
                dd = doc.dateout?.ToString("yyyy.MM.dd");
            if (doc.notifcuststatusdate != null)
                ee = doc.notifcuststatusdate?.ToString("yyyy.MM.dd");
            var query = $"INSERT INTO docnotification (notifnumint,blankinnum,cbxnum,transtype,regcountry,transportmark,transportnum," +
                $"trailernum,carriername,carrierrnn,drivername,driverpasspnum,driverpasspdate,driverpasspplace,goodsforbidden,placedate," +
                $"noticedate,custmark,regnum,custofficerstampnum,custofficername,specialist,shassi,driverdocname,dcodepto,namepto," +
                $"carrieraddress,regcountrycode,purpose,notifnum,createyear,trisleave,carrierstamp1,carrierstamp2,placename,dateout," +
                $"damage,breachiden,removeiden,imposiden,bi_amount,bi_num,ri_amount,ri_num,ii_amount,ii_num,driveroffice,damcomment,newdoc," +
                $"isnew,drivertype,docscurrencycode,transcategorycode,twhplace,notifcuststatus,notifcuststatusdate,pr_vygr, user_id) " +
                $"VALUES ({doc.notifnumint.GetValueOrDefault()},'{doc.blankinnum}','{doc.cbxnum}','{doc.transtype}','{doc.regcountry}'," +
                $"'{doc.transportmark}','{doc.transportnum}','{doc.trailernum}','{doc.carriername}','{doc.carrierrnn}','{doc.drivername}'," +
                $"'{doc.driverpasspnum}','{aa}','{doc.driverpasspplace}',{doc.goodsforbidden.GetValueOrDefault()},'{bb}'," +
                $"'{cc}','{doc.custmark}','{doc.regnum}','{doc.custofficerstampnum}','{doc.custofficername}','{doc.specialist}'," +
                $"'{doc.shassi}','{doc.driverdocname}','{doc.dcodepto}','{doc.namepto}','{doc.carrieraddress}','{doc.regcountrycode}'," +
                $"'{doc.purpose}','{doc.notifnum}',{doc.createyear.GetValueOrDefault()},{doc.trisleave.GetValueOrDefault()},'{doc.carrierstamp1}','{doc.carrierstamp2}'," +
                $"'{doc.placename}','{dd}',{doc.damage.GetValueOrDefault()},{doc.breachiden.GetValueOrDefault()}," +
                $"{doc.removeiden.GetValueOrDefault()},{doc.imposiden.GetValueOrDefault()},{doc.bi_amount.GetValueOrDefault()}," +
                $"'{doc.bi_num}',{doc.ri_amount.GetValueOrDefault()},'{doc.ri_num}',{doc.ii_amount.GetValueOrDefault()},'{doc.ii_num}','{doc.driveroffice}','{doc.damcomment}'," +
                $"{doc.newdoc.GetValueOrDefault()},{doc.isnew.GetValueOrDefault()},'{doc.drivertype}','{doc.docscurrencycode}','{doc.transcategorycode}','{doc.twhplace}'," +
                $"{doc.notifcuststatus.GetValueOrDefault()},'{ee}','{doc.pr_vygr}', '{user}') RETURNING docid";
            var doc_id = Provider.RunScalar(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            if (doc_id > 0)
            {
                if (doc.docnotificationcustdocs != null)
                    foreach (var cust in doc.docnotificationcustdocs)
                    {
                        if (cust.docdate != null)
                            ab = cust.docdate?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO docnotificationcustdocs (docid, linenum, doctype, docnum, docdate, addpermfirm, custofficerstampnum, " +
                            $"custofficername, ny, nj, nn, docdkd) VALUES ({doc_id}, {cust.linenum.GetValueOrDefault()}, '{cust.doctype}'," +
                            $"'{cust.docnum}', '{ab}', '{cust.addpermfirm}', '{cust.custofficerstampnum}', '{cust.custofficername}'," +
                            $"{cust.ny.GetValueOrDefault()},{cust.nj.GetValueOrDefault()},{cust.nn.GetValueOrDefault()},'{cust.docdkd}'); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (doc.docnotificationdocs != null)
                    foreach (var dcs in doc.docnotificationdocs)
                    {
                        if (dcs.docdate != null)
                            ac = dcs.docdate?.ToString("yyyy.MM.dd");
                        if (dcs.docdatecreate != null)
                            ad = dcs.docdatecreate?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO docnotificationdocs (docid, linenum, doctype, docnum, docdate, doccomment, docfirm," +
                            $" indv, docnetto, docbrutto, doccurrencycode, docprice, sendername, docdatecreate) VALUES" +
                            $" ({doc_id}, {dcs.linenum.GetValueOrDefault()}, '{dcs.doctype}', '{dcs.docnum}', '{ac}', '{dcs.doccomment}', '{dcs.docfirm}', " +
                            $"{dcs.indv.GetValueOrDefault()}, {dcs.docnetto.GetValueOrDefault()}, {dcs.docbrutto.GetValueOrDefault()}, " +
                            $"'{dcs.doccurrencycode}', {dcs.docprice.GetValueOrDefault()}, '{dcs.sendername}', '{ad}'); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (doc.docnotificationpermdocs != null)
                    foreach (var dcs in doc.docnotificationpermdocs)
                    {
                        if (dcs.docdate != null)
                            ae = dcs.docdate?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO docnotificationpermdocs (docid, linenum, doctype, docnum, docdate, addpermfirm, " +
                            $"custofficerstampnum, docbrutto, docnetto, doccurrencycode, docprice) VALUES" +
                            $" ({doc_id}, {dcs.linenum.GetValueOrDefault()}, '{dcs.doctype}', '{dcs.docnum}', '{ae}', '{dcs.addpermfirm}', '{dcs.custofficerstampnum}', " +
                            $" {dcs.docnetto.GetValueOrDefault()}, {dcs.docbrutto.GetValueOrDefault()}, " +
                            $"'{dcs.doccurrencycode}', {dcs.docprice.GetValueOrDefault()}); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (doc.docnotificationrecipients != null)
                    foreach (var rec in doc.docnotificationrecipients)
                    {
                        query = $"INSERT INTO docnotificationrecipients (docid, linenum, recipientrnn, recipientname, recipientaddress, indf) VALUES" +
                            $" ({doc_id}, {rec.linenum.GetValueOrDefault()}, '{rec.recipientrnn}', '{rec.recipientname}', " +
                            $"'{rec.recipientaddress}', '{rec.indf}'); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (doc.documents != null)
                    foreach (var dcs in doc.documents)
                    {
                        query = $"INSERT INTO documents (docid, doctypecode, docstatus) VALUES" +
                            $" ({doc_id}, {dcs.doctypecode.GetValueOrDefault()}, {dcs.docstatus.GetValueOrDefault()}); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                if (doc.cwcardinmain != null)
                    foreach (var card in doc.cwcardinmain)
                    {
                        if (card.docdate != null)
                            bd = card.docdate?.ToString("yyyy.MM.dd");
                        if (card.enddate != null)
                            be = card.enddate?.ToString("yyyy.MM.dd");
                        if (card.enddatekd != null)
                            bf = card.enddatekd?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO cwcardinmain (docid, notifnumint, docnum, docdate, enddate, description, companyname," +
                            $" companycode, personname, officername, recipientname, recipientcode, enddatekd, isclosed, kdnum, docidnotif) VALUES" +
                            $" ({doc_id}, {card.notifnumint.GetValueOrDefault()}, '{card.docnum}', '{bd}', '{be}'," +
                            $" '{card.description}', '{card.companyname}', '{card.companycode}', '{card.personname}', '{card.officername}'," +
                            $" '{card.recipientname}', '{card.recipientcode}', '{bf}', '{card.isclosed}', '{card.kdnum}'," +
                            $" '{card.docidnotif}') RETURNING id;";
                        int crd = Provider.RunScalar(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                        if (crd > 0 && card.cwcardingoods != null)
                            foreach (var good in card.cwcardingoods)
                            {
                                query = $"INSERT INTO cwcardingoods (parentid, linenum, goodscode, goodsname, goodsplacemarks," +
                                    $" goodsplacequantity, goodsplacetype, goodsquantity, goodsmeasure, goodsweight, goodsvolume," +
                                    $" goodsprice, goodscurrency, goodscountry, goodsnumber) VALUES" +
                            $" ({crd}, '{good.linenum}', '{good.goodscode}', '{good.goodsname}', '{good.goodsplacemarks}'," +
                            $" {good.goodsplacequantity.GetValueOrDefault()}, '{good.goodsplacetype}', {good.goodsquantity.GetValueOrDefault()}, '{good.goodsmeasure}'," +
                            $" {good.goodsweight.GetValueOrDefault()}, {good.goodsvolume.GetValueOrDefault()}, {good.goodsprice.GetValueOrDefault()}, '{good.goodscurrency}', " +
                            $"'{good.goodscountry}', '{good.goodsnumber}'); ";
                                Provider.RunNonQuery(query);
                                if (Provider.lastError != "")
                                {
                                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                                }
                            }
                    }

                if (doc.cwcardoutmain != null)
                    foreach (var card in doc.cwcardoutmain)
                    {
                        if (card.docdate != null)
                            bg = card.docdate?.ToString("yyyy.MM.dd");

                        query = $"INSERT INTO cwcardinmain (docid, docnum, docdate, description, cause, officername," +
                            $" recipientname, recipientcode, personname, cardinnumber) VALUES" +
                            $" ({doc_id}, '{card.docnum}', '{bg}', '{card.description}', '{card.cause}', '{card.officername}'," +
                            $" '{card.recipientname}', '{card.recipientcode}', '{card.personname}', '{card.cardinnumber}') RETURNING id;";
                        int crd = Provider.RunScalar(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                        if (crd > 0 && card.cwcardoutgoods != null)
                            foreach (var good in card.cwcardoutgoods)
                            {
                                query = $"INSERT INTO cwcardingoods (parentid, cardingoodsid, goodsoutquantity, goodsoutplacequantity," +
                                    $" goodsoutprice, goodsoutweight, isblank, checkowner) VALUES" +
                            $" ({crd}, '{good.linenum}', '{good.cardingoodsid}', {good.goodsoutquantity.GetValueOrDefault()}, {good.goodsoutplacequantity.GetValueOrDefault()}," +
                            $"'{good.goodsoutprice.GetValueOrDefault()}, {good.goodsoutweight.GetValueOrDefault()}, '{good.isblank}', '{good.checkowner}'); ";
                                Provider.RunNonQuery(query);
                                if (Provider.lastError != "")
                                {
                                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                                }
                            }
                    }
                log.Info("new doc notification " + user + JsonConvert.SerializeObject(doc));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', '{doc_id}', '{JsonConvert.SerializeObject(doc)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            return "ok";
        }

        [HttpPost]
        public string updateDocNotification(docNotification doc, int id)
        {
            var user = User.Identity.GetUserId();
            string aa = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"),
                dd = DateTime.Now.ToString("yyyy.MM.dd"), ee = DateTime.Now.ToString("yyyy.MM.dd"), ab = DateTime.Now.ToString("yyyy.MM.dd"),
                ac = DateTime.Now.ToString("yyyy.MM.dd"), ad = DateTime.Now.ToString("yyyy.MM.dd"), ae = DateTime.Now.ToString("yyyy.MM.dd"),
                bd = DateTime.Now.ToString("yyyy.MM.dd"), be = DateTime.Now.ToString("yyyy.MM.dd"), bf = DateTime.Now.ToString("yyyy.MM.dd"),
                bg = DateTime.Now.ToString("yyyy.MM.dd");
            if (doc.driverpasspdate != null)
                aa = doc.driverpasspdate?.ToString("yyyy.MM.dd");
            if (doc.placedate != null)
                bb = doc.placedate?.ToString("yyyy.MM.dd");
            if (doc.noticedate != null)
                cc = doc.noticedate?.ToString("yyyy.MM.dd");
            if (doc.dateout != null)
                dd = doc.dateout?.ToString("yyyy.MM.dd");
            if (doc.notifcuststatusdate != null)
                ee = doc.notifcuststatusdate?.ToString("yyyy.MM.dd");
            var query = $"UPDATE docnotification SET(notifnumint,blankinnum,cbxnum,transtype,regcountry,transportmark,transportnum," +
                $"trailernum,carriername,carrierrnn,drivername,driverpasspnum,driverpasspdate,driverpasspplace,goodsforbidden,placedate," +
                $"noticedate,custmark,regnum,custofficerstampnum,custofficername,specialist,shassi,driverdocname,dcodepto,namepto," +
                $"carrieraddress,regcountrycode,purpose,notifnum,createyear,trisleave,carrierstamp1,carrierstamp2,placename,dateout," +
                $"damage,breachiden,removeiden,imposiden,bi_amount,bi_num,ri_amount,ri_num,ii_amount,ii_num,driveroffice,damcomment,newdoc," +
                $"isnew,drivertype,docscurrencycode,transcategorycode,twhplace,notifcuststatus,notifcuststatusdate,pr_vygr) " +
                $"= ({doc.notifnumint.GetValueOrDefault()},'{doc.blankinnum}','{doc.cbxnum}','{doc.transtype}','{doc.regcountry}'," +
                $"'{doc.transportmark}','{doc.transportnum}','{doc.trailernum}','{doc.carriername}','{doc.carrierrnn}','{doc.drivername}'," +
                $"'{doc.driverpasspnum}','{aa}','{doc.driverpasspplace}',{doc.goodsforbidden.GetValueOrDefault()},'{bb}'," +
                $"'{cc}','{doc.custmark}','{doc.regnum}','{doc.custofficerstampnum}','{doc.custofficername}','{doc.specialist}'," +
                $"'{doc.shassi}','{doc.driverdocname}','{doc.dcodepto}','{doc.namepto}','{doc.carrieraddress}','{doc.regcountrycode}'," +
                $"'{doc.purpose}','{doc.notifnum}',{doc.createyear.GetValueOrDefault()},{doc.trisleave.GetValueOrDefault()},'{doc.carrierstamp1}','{doc.carrierstamp2}'," +
                $"'{doc.placename}','{dd}',{doc.damage.GetValueOrDefault()},{doc.breachiden.GetValueOrDefault()}," +
                $"{doc.removeiden.GetValueOrDefault()},{doc.imposiden.GetValueOrDefault()},{doc.bi_amount.GetValueOrDefault()}," +
                $"'{doc.bi_num}',{doc.ri_amount.GetValueOrDefault()},'{doc.ri_num}',{doc.ii_amount.GetValueOrDefault()},'{doc.ii_num}','{doc.driveroffice}','{doc.damcomment}'," +
                $"{doc.newdoc.GetValueOrDefault()},{doc.isnew.GetValueOrDefault()},'{doc.drivertype}','{doc.docscurrencycode}','{doc.transcategorycode}','{doc.twhplace}'," +
                $"{doc.notifcuststatus.GetValueOrDefault()},'{ee}','{doc.pr_vygr}') WHERE docid={id}";
            var doc_id = Provider.RunScalar(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.UpdateDocNotification}', '{LogDocument.UpdateDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            else
            {
                query = $"DELETE FROM docnotificationcustdocs WHERE docid='{doc_id}'";
                Provider.RunNonQuery(query);
                if (doc.docnotificationcustdocs != null)
                    foreach (var cust in doc.docnotificationcustdocs)
                    {
                        if (cust.docdate != null)
                            ab = cust.docdate?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO docnotificationcustdocs (docid, linenum, doctype, docnum, docdate, addpermfirm, custofficerstampnum, " +
                            $"custofficername, ny, nj, nn, docdkd) VALUES ({doc_id}, {cust.linenum.GetValueOrDefault()}, '{cust.doctype}'," +
                            $"'{cust.docnum}', '{ab}', '{cust.addpermfirm}', '{cust.custofficerstampnum}', '{cust.custofficername}'," +
                            $"{cust.ny.GetValueOrDefault()},{cust.nj.GetValueOrDefault()},{cust.nn.GetValueOrDefault()},'{cust.docdkd}'); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM docnotificationdocs WHERE docid='{doc_id}'";
                Provider.RunNonQuery(query);
                if (doc.docnotificationdocs != null)
                    foreach (var dcs in doc.docnotificationdocs)
                    {
                        if (dcs.docdate != null)
                            ac = dcs.docdate?.ToString("yyyy.MM.dd");
                        if (dcs.docdatecreate != null)
                            ad = dcs.docdatecreate?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO docnotificationdocs (docid, linenum, doctype, docnum, docdate, doccomment, docfirm," +
                            $" indv, docnetto, docbrutto, doccurrencycode, docprice, sendername, docdatecreate) VALUES" +
                            $" ({doc_id}, {dcs.linenum.GetValueOrDefault()}, '{dcs.doctype}', '{dcs.docnum}', '{ac}', '{dcs.doccomment}', '{dcs.docfirm}', " +
                            $"{dcs.indv.GetValueOrDefault()}, {dcs.docnetto.GetValueOrDefault()}, {dcs.docbrutto.GetValueOrDefault()}, " +
                            $"'{dcs.doccurrencycode}', {dcs.docprice.GetValueOrDefault()}, '{dcs.sendername}', '{ad}'); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM docnotificationpermdocs WHERE docid='{doc_id}'";
                Provider.RunNonQuery(query);
                if (doc.docnotificationpermdocs != null)
                    foreach (var dcs in doc.docnotificationpermdocs)
                    {
                        if (dcs.docdate != null)
                            ae = dcs.docdate?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO docnotificationpermdocs (docid, linenum, doctype, docnum, docdate, addpermfirm, " +
                            $"custofficerstampnum, docbrutto, docnetto, doccurrencycode, docprice) VALUES" +
                            $" ({doc_id}, {dcs.linenum.GetValueOrDefault()}, '{dcs.doctype}', '{dcs.docnum}', '{ae}', '{dcs.addpermfirm}', '{dcs.custofficerstampnum}', " +
                            $" {dcs.docnetto.GetValueOrDefault()}, {dcs.docbrutto.GetValueOrDefault()}, " +
                            $"'{dcs.doccurrencycode}', {dcs.docprice.GetValueOrDefault()}); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM docnotificationrecipients WHERE docid='{doc_id}'";
                Provider.RunNonQuery(query);
                if (doc.docnotificationrecipients != null)
                    foreach (var rec in doc.docnotificationrecipients)
                    {
                        query = $"INSERT INTO docnotificationrecipients (docid, linenum, recipientrnn, recipientname, recipientaddress, indf) VALUES" +
                            $" ({doc_id}, {rec.linenum.GetValueOrDefault()}, '{rec.recipientrnn}', '{rec.recipientname}', " +
                            $"'{rec.recipientaddress}', '{rec.indf}'); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM documents WHERE docid='{doc_id}'";
                Provider.RunNonQuery(query);
                if (doc.documents != null)
                    foreach (var dcs in doc.documents)
                    {
                        query = $"INSERT INTO documents (docid, doctypecode, docstatus) VALUES" +
                            $" ({doc_id}, {dcs.doctypecode.GetValueOrDefault()}, {dcs.docstatus.GetValueOrDefault()}); ";
                        Provider.RunNonQuery(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                    }
                query = $"DELETE FROM cwcardinmain WHERE docid='{doc_id}'";
                Provider.RunNonQuery(query);
                if (doc.cwcardinmain != null)
                    foreach (var card in doc.cwcardinmain)
                    {
                        if (card.docdate != null)
                            bd = card.docdate?.ToString("yyyy.MM.dd");
                        if (card.enddate != null)
                            be = card.enddate?.ToString("yyyy.MM.dd");
                        if (card.enddatekd != null)
                            bf = card.enddatekd?.ToString("yyyy.MM.dd");
                        query = $"INSERT INTO cwcardinmain (docid, notifnumint, docnum, docdate, enddate, description, companyname," +
                            $" companycode, personname, officername, recipientname, recipientcode, enddatekd, isclosed, kdnum, docidnotif) VALUES" +
                            $" ({doc_id}, {card.notifnumint.GetValueOrDefault()}, '{card.docnum}', '{bd}', '{be}'," +
                            $" '{card.description}', '{card.companyname}', '{card.companycode}', '{card.personname}', '{card.officername}'," +
                            $" '{card.recipientname}', '{card.recipientcode}', '{bf}', '{card.isclosed}', '{card.kdnum}'," +
                            $" '{card.docidnotif}') RETURNING id;";
                        int crd = Provider.RunScalar(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                        if (crd > 0 && card.cwcardingoods != null)
                            foreach (var good in card.cwcardingoods)
                            {
                                query = $"INSERT INTO cwcardingoods (parentid, linenum, goodscode, goodsname, goodsplacemarks," +
                                    $" goodsplacequantity, goodsplacetype, goodsquantity, goodsmeasure, goodsweight, goodsvolume," +
                                    $" goodsprice, goodscurrency, goodscountry, goodsnumber) VALUES" +
                            $" ({crd}, '{good.linenum}', '{good.goodscode}', '{good.goodsname}', '{good.goodsplacemarks}'," +
                            $" {good.goodsplacequantity.GetValueOrDefault()}, '{good.goodsplacetype}', {good.goodsquantity.GetValueOrDefault()}, '{good.goodsmeasure}'," +
                            $" {good.goodsweight.GetValueOrDefault()}, {good.goodsvolume.GetValueOrDefault()}, {good.goodsprice.GetValueOrDefault()}, '{good.goodscurrency}', " +
                            $"'{good.goodscountry}', '{good.goodsnumber}'); ";
                                Provider.RunNonQuery(query);
                                if (Provider.lastError != "")
                                {
                                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                                }
                            }
                    }
                query = $"DELETE FROM cwcardoutmain WHERE docid='{doc_id}'";
                Provider.RunNonQuery(query);
                if (doc.cwcardoutmain != null)
                    foreach (var card in doc.cwcardoutmain)
                    {
                        if (card.docdate != null)
                            bg = card.docdate?.ToString("yyyy.MM.dd");

                        query = $"INSERT INTO cwcardinmain (docid, docnum, docdate, description, cause, officername," +
                            $" recipientname, recipientcode, personname, cardinnumber) VALUES" +
                            $" ({doc_id}, '{card.docnum}', '{bg}', '{card.description}', '{card.cause}', '{card.officername}'," +
                            $" '{card.recipientname}', '{card.recipientcode}', '{card.personname}', '{card.cardinnumber}') RETURNING id;";
                        int crd = Provider.RunScalar(query);
                        if (Provider.lastError != "")
                        {
                            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                            Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                            return "{\"status\":\"error " + Provider.lastError + "\"}";
                        }
                        if (crd > 0 && card.cwcardoutgoods != null)
                            foreach (var good in card.cwcardoutgoods)
                            {
                                query = $"INSERT INTO cwcardingoods (parentid, cardingoodsid, goodsoutquantity, goodsoutplacequantity," +
                                    $" goodsoutprice, goodsoutweight, isblank, checkowner) VALUES" +
                            $" ({crd}, '{good.linenum}', '{good.cardingoodsid}', {good.goodsoutquantity.GetValueOrDefault()}, {good.goodsoutplacequantity.GetValueOrDefault()}," +
                            $"'{good.goodsoutprice.GetValueOrDefault()}, {good.goodsoutweight.GetValueOrDefault()}, '{good.isblank}', '{good.checkowner}'); ";
                                Provider.RunNonQuery(query);
                                if (Provider.lastError != "")
                                {
                                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.AddDocNotification}', '{LogDocument.AddDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                                }
                            }
                    }
                log.Info("edit doc notification " + user + JsonConvert.SerializeObject(doc));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.UpdateDocNotification}', '{LogDocument.UpdateDocNotification}', '{LogSection.Document}', '{user}', '{doc_id}', '{JsonConvert.SerializeObject(doc)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            return "ok";
        }

        public string deleteDocNotification(int id)
        {
            var user = User.Identity.GetUserId();
            var query = $"DELETE FROM docnotification WHERE id = {id};";
            Provider.RunNonQuery(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.DeleteDocNotification}', '{LogDocument.DeleteDocNotification}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            else
            {
                log.Info("delete doc notification " + user + JsonConvert.SerializeObject(id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.DeleteDocNotification}', '{LogDocument.DeleteDocNotification}', '{LogSection.Document}', '{user}', '{id}', '{JsonConvert.SerializeObject(id)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
        }
        public string LoadDocNotification(int doc_id)
        {
            var query = $"SELECT * FROM docnotification WHERE docid='{doc_id}'";// WHERE contract_id='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var list = new docNotification();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.docid = (int)reader["docid"];
                    list.notifnumint = reader.GetFieldValueOrDefault<int>("notifnumint");
                    list.blankinnum = reader["blankinnum"].ToString();
                    list.cbxnum = reader["cbxnum"].ToString();
                    list.transtype = reader["transtype"].ToString();
                    list.regcountry = reader["regcountry"].ToString();
                    list.transportmark = reader["transportmark"].ToString();
                    list.transportnum = reader["transportnum"].ToString();
                    list.trailernum = reader["trailernum"].ToString();
                    list.carriername = reader["carriername"].ToString();
                    list.carrierrnn = reader["carrierrnn"].ToString();
                    list.drivername = reader["drivername"].ToString();
                    list.driverpasspnum = reader["driverpasspnum"].ToString();
                    list.driverpasspdate = GetDateTimeFromString(reader["driverpasspdate"].ToString());
                    list.driverpasspplace = reader["driverpasspplace"].ToString();
                    list.goodsforbidden = reader.GetFieldValueOrDefault<int>("goodsforbidden");
                    list.placedate = GetDateTimeFromString(reader["placedate"].ToString());
                    list.noticedate = GetDateTimeFromString(reader["noticedate"].ToString());
                    list.custmark = reader["custmark"].ToString();
                    list.regnum = reader["regnum"].ToString();
                    list.custofficerstampnum = reader["custofficerstampnum"].ToString();
                    list.custofficername = reader["custofficername"].ToString();
                    list.specialist = reader["specialist"].ToString();
                    list.shassi = reader["shassi"].ToString();
                    list.driverdocname = reader["driverdocname"].ToString();
                    list.dcodepto = reader["dcodepto"].ToString();
                    list.namepto = reader["namepto"].ToString();
                    list.carrieraddress = reader["carrieraddress"].ToString();
                    list.regcountrycode = reader["regcountrycode"].ToString();
                    list.purpose = reader["purpose"].ToString();
                    list.notifnum = reader["notifnum"].ToString();
                    list.createyear =reader.GetFieldValueOrDefault<int>("createyear");
                    list.trisleave =  reader.GetFieldValueOrDefault<int>("trisleave");
                    list.carrierstamp1 = reader["carrierstamp1"].ToString();
                    list.carrierstamp2 = reader["carrierstamp2"].ToString();
                    list.placename = reader["placename"].ToString();
                    list.dateout = GetDateTimeFromString(reader["dateout"].ToString());
                    list.damage = reader.GetFieldValueOrDefault<int>("damage");
                    list.breachiden = reader.GetFieldValueOrDefault<int>("breachiden");
                    list.removeiden = reader.GetFieldValueOrDefault<int>("removeiden");
                    list.imposiden =  reader.GetFieldValueOrDefault<int>("imposiden");
                    list.bi_amount = reader.GetFieldValueOrDefault<int>("bi_amount");
                    list.bi_num = reader["bi_num"].ToString();
                    list.ri_amount = reader.GetFieldValueOrDefault<int>("ri_amount");
                    list.ri_num = reader["ri_num"].ToString();
                    list.ii_amount = reader.GetFieldValueOrDefault<int>("ii_amount");
                    list.ii_num = reader["ii_num"].ToString();
                    list.driveroffice = reader["driveroffice"].ToString();
                    list.damcomment = reader["damcomment"].ToString();
                    list.newdoc = reader.GetFieldValueOrDefault<int>("newdoc");
                    list.isnew = reader.GetFieldValueOrDefault<int>("isnew");
                    list.drivertype = reader["drivertype"].ToString();
                    list.docscurrencycode = reader["docscurrencycode"].ToString();
                    list.transcategorycode = reader["transcategorycode"].ToString();
                    list.twhplace = reader["twhplace"].ToString();
                    list.notifcuststatus = reader.GetFieldValueOrDefault<int>("notifcuststatus");
                    list.notifcuststatusdate = GetDateTimeFromString(reader["notifcuststatusdate"].ToString());
                    list.pr_vygr = reader["pr_vygr"].ToString();

                }
                reader.Close();
                
                query = $"SELECT * FROM docnotificationcustdocs WHERE docid = '{list.docid}'";
                reader = Provider.RunQuery(query);
                var custdoc = new List<docnotificationcustdocs>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new docnotificationcustdocs();
                        rep1.recordid = reader.GetFieldValueOrDefault<int>("recordid");
                        rep1.linenum = reader.GetFieldValueOrDefault<int>("linenum");
                        rep1.doctype = reader["doctype"].ToString();
                        rep1.docnum = reader["docnum"].ToString();
                        rep1.docdate = GetDateTimeFromString(reader["docdate"].ToString());
                        rep1.addpermfirm = reader["addpermfirm"].ToString();
                        rep1.custofficerstampnum = reader["custofficerstampnum"].ToString();
                        rep1.custofficername = reader["custofficername"].ToString();
                        rep1.ny = reader.GetFieldValueOrDefault<int>("ny");
                        rep1.nj = reader.GetFieldValueOrDefault<int>("nj");
                        rep1.nn = reader.GetFieldValueOrDefault<int>("nn");
                        rep1.docdkd = reader["docdkd"].ToString();

                        custdoc.Add(rep1);
                    }
                    reader.Close();
                }
                list.docnotificationcustdocs = new List<docnotificationcustdocs>(custdoc);

                query = $"SELECT * FROM docnotificationdocs WHERE docid = '{list.docid}'";
                reader = Provider.RunQuery(query);
                var docs = new List<docnotificationdocs>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new docnotificationdocs();
                        rep1.recordid = reader.GetFieldValueOrDefault<int>("recordid");
                        rep1.linenum = reader.GetFieldValueOrDefault<int>("linenum");
                        rep1.doctype = reader["doctype"].ToString();
                        rep1.docnum = reader["docnum"].ToString();
                        rep1.docdate = GetDateTimeFromString(reader["docdate"].ToString());
                        rep1.doccomment = reader["doccomment"].ToString();
                        rep1.docfirm = reader["docfirm"].ToString();
                        rep1.indv = reader.GetFieldValueOrDefault<int>("indv");
                        rep1.docnetto = reader.GetFieldValueOrDefault<float>("docnetto");
                        rep1.docbrutto = reader.GetFieldValueOrDefault<float>("docbrutto");
                        rep1.doccurrencycode = reader["doccurrencycode"].ToString();
                        rep1.docprice = reader.GetFieldValueOrDefault<float>("docprice");
                        rep1.sendername = reader["sendername"].ToString();
                        rep1.docdatecreate = GetDateTimeFromString(reader["docdatecreate"].ToString());

                        docs.Add(rep1);
                    }
                    reader.Close();
                }
                list.docnotificationdocs = new List<docnotificationdocs>(docs);

                query = $"SELECT * FROM docnotificationdocs WHERE docid = '{list.docid}'";
                reader = Provider.RunQuery(query);
                var perm = new List<docnotificationpermdocs>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new docnotificationpermdocs();
                        rep1.recordid = reader.GetFieldValueOrDefault<int>("recordid");
                        rep1.linenum = reader.GetFieldValueOrDefault<int>("linenum");
                        rep1.doctype = reader["doctype"].ToString();
                        rep1.docnum = reader["docnum"].ToString();
                        rep1.docdate = GetDateTimeFromString(reader["docdate"].ToString());
                        rep1.addpermfirm = reader["addpermfirm"].ToString();
                        rep1.custofficerstampnum = reader["custofficerstampnum"].ToString();
                        rep1.docnetto = reader.GetFieldValueOrDefault<float>("docnetto");
                        rep1.docbrutto = reader.GetFieldValueOrDefault<float>("docbrutto");
                        rep1.doccurrencycode = reader["doccurrencycode"].ToString();
                        rep1.docprice = reader.GetFieldValueOrDefault<float>("docprice");

                        perm.Add(rep1);
                    }
                    reader.Close();
                }
                list.docnotificationpermdocs = new List<docnotificationpermdocs>(perm);

                query = $"SELECT * FROM docnotificationdocs WHERE docid = '{list.docid}'";
                reader = Provider.RunQuery(query);
                var recs = new List<docnotificationrecipients>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new docnotificationrecipients();
                        rep1.recordid = reader.GetFieldValueOrDefault<int>("recordid");
                        rep1.linenum = reader.GetFieldValueOrDefault<int>("linenum");
                        rep1.recipientrnn = reader["recipientrnn"].ToString();
                        rep1.recipientname = reader["recipientname"].ToString();
                        rep1.recipientaddress = reader["recipientaddress"].ToString();
                        rep1.indf = reader["indf"].ToString();

                        recs.Add(rep1);
                    }
                    reader.Close();
                }
                list.docnotificationrecipients = new List<docnotificationrecipients>(recs);

                query = $"SELECT * FROM documents WHERE docid = '{list.docid}'";
                reader = Provider.RunQuery(query);
                var dcs = new List<documents>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new documents();
                        rep1.doctypecode = reader.GetFieldValueOrDefault<int>("doctypecode");
                        rep1.docstatus = reader.GetFieldValueOrDefault<int>("docstatus");
 
                        dcs.Add(rep1);
                    }
                    reader.Close();
                }
                list.documents = new List<documents>(dcs);

                query = $"SELECT * FROM cwcardinmain WHERE docid = '{list.docid}'";
                reader = Provider.RunQuery(query);
                var cardin = new List<cwcardinmain>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new cwcardinmain();
                        rep1.id = reader.GetFieldValueOrDefault<int>("id");
                        rep1.notifnumint = reader.GetFieldValueOrDefault<int>("notifnumint");
                        rep1.docnum = reader["docnum"].ToString();
                        rep1.docdate = GetDateTimeFromString(reader["docdate"].ToString());
                        rep1.enddate = GetDateTimeFromString(reader["enddate"].ToString());
                        rep1.description = reader["description"].ToString();
                        rep1.companyname = reader["companyname"].ToString();
                        rep1.companycode = reader["companycode"].ToString();
                        rep1.personname = reader["personname"].ToString();
                        rep1.officername = reader["officername"].ToString();
                        rep1.recipientname = reader["recipientname"].ToString();
                        rep1.recipientcode = reader["recipientcode"].ToString();
                        rep1.enddatekd = GetDateTimeFromString(reader["enddatekd"].ToString());
                        rep1.isclosed = reader["isclosed"].ToString();
                        rep1.kdnum = reader["kdnum"].ToString();
                        rep1.docidnotif = reader["docidnotif"].ToString();

                        cardin.Add(rep1);
                    }
                    reader.Close();
                }
                foreach (var cd in cardin)
                {
                    int parn = cd.id.GetValueOrDefault();
                    cd.cwcardingoods = new List<cwcardingoods>
                        (getcardingoods(parn));
                }
                list.cwcardinmain = new List<cwcardinmain>(cardin);

                query = $"SELECT * FROM cwcardoutmain WHERE docid = '{list.docid}'";
                reader = Provider.RunQuery(query);
                var cardout = new List<cwcardoutmain>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new cwcardoutmain();
                        rep1.id = reader.GetFieldValueOrDefault<int>("id");
                        rep1.docnum = reader["docnum"].ToString();
                        rep1.docdate = GetDateTimeFromString(reader["docdate"].ToString());
                        rep1.description = reader["description"].ToString();
                        rep1.cause = reader["personname"].ToString();
                        rep1.officername = reader["officername"].ToString();
                        rep1.recipientname = reader["recipientname"].ToString();
                        rep1.recipientcode = reader["recipientcode"].ToString();
                        rep1.personname = reader["personname"].ToString();
                        rep1.cardinnumber = reader["cardinnumber"].ToString();

                        cardout.Add(rep1);
                    }
                    reader.Close();
                }
                foreach (var cd in cardout)
                {
                    int parn = cd.id.GetValueOrDefault();
                    cd.cwcardoutgoods = new List<cwcardoutgoods>
                        (getcardoutgoods(parn));
                }
                list.cwcardinmain = new List<cwcardinmain>(cardin);
                return JsonConvert.SerializeObject(list);
            }
            return "{}";
        }

        public List<cwcardingoods> getcardingoods(int id)
        {
            var query = $"SELECT * FROM cwcardingoods WHERE parentid = '{id}'";
            var reader = Provider.RunQuery(query);
            var goods = new List<cwcardingoods>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new cwcardingoods();
                    rep1.id = (int)reader["id"];
                    rep1.linenum = reader.GetFieldValueOrDefault<int>("linenum");
                    rep1.goodscode = reader["goodscode"].ToString();
                    rep1.goodsname = reader["goodsname"].ToString();
                    rep1.goodsplacemarks = reader["goodsplacemarks"].ToString();
                    rep1.goodsplacequantity = reader.GetFieldValueOrDefault<int>("goodsplacequantity");
                    rep1.goodsplacetype = reader["goodsplacetype"].ToString();
                    rep1.goodsquantity = reader.GetFieldValueOrDefault<float>("goodsquantity");
                    rep1.goodsmeasure = reader["goodsmeasure"].ToString();
                    rep1.goodsweight = reader.GetFieldValueOrDefault<float>("goodsweight");
                    rep1.goodsvolume = reader.GetFieldValueOrDefault<float>("goodsvolume");
                    rep1.goodsprice = reader.GetFieldValueOrDefault<float>("goodsprice");
                    rep1.goodscurrency = reader["goodscurrency"].ToString();
                    rep1.goodscountry = reader["goodscountry"].ToString();
                    rep1.goodsnumber = reader["goodsnumber"].ToString();

                    goods.Add(rep1);
                }
                reader.Close();
            }
            return goods;
        }

        public List<cwcardoutgoods> getcardoutgoods(int id)
        {
            var query = $"SELECT * FROM cwcardoutgoods WHERE parentid = '{id}'";
            var reader = Provider.RunQuery(query);
            var goods = new List<cwcardoutgoods>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new cwcardoutgoods();
                    rep1.id = (int)reader["id"];                 
                    rep1.linenum = reader.GetFieldValueOrDefault<int>("linenum");
                    rep1.cardingoodsid = reader["cardingoodsid"].ToString();
                    rep1.goodsoutquantity = reader.GetFieldValueOrDefault<float>("goodsoutquantity");
                    rep1.goodsoutplacequantity = reader.GetFieldValueOrDefault<float>("goodsoutplacequantity");
                    rep1.goodsoutprice = reader.GetFieldValueOrDefault<float>("goodsoutprice");
                    rep1.goodsoutweight = reader.GetFieldValueOrDefault<float>("goodsoutweight");
                    rep1.isblank = reader["isblank"].ToString();
                    rep1.checkowner = reader["checkowner"].ToString();

                    goods.Add(rep1);
                }
                reader.Close();
            }
            return goods;
        }
        public string getDocNotifications()
        {
            var user = User.Identity.GetUserId();
            var query = $"SELECT * FROM docnotification WHERE user_id='{user}'";// WHERE contract_id='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var lst = new List<docNotification>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var list = new docNotification();
                    list.docid = (int)reader["docid"];
                    list.notifnumint = reader.GetFieldValueOrDefault<int>("notifnumint");
                    list.blankinnum = reader["blankinnum"].ToString();
                    list.cbxnum = reader["cbxnum"].ToString();
                    list.transtype = reader["transtype"].ToString();
                    list.regcountry = reader["regcountry"].ToString();
                    list.transportmark = reader["transportmark"].ToString();
                    list.transportnum = reader["transportnum"].ToString();
                    list.trailernum = reader["trailernum"].ToString();
                    list.carriername = reader["carriername"].ToString();
                    list.carrierrnn = reader["carrierrnn"].ToString();
                    list.drivername = reader["drivername"].ToString();
                    list.driverpasspnum = reader["driverpasspnum"].ToString();
                    list.driverpasspdate = GetDateTimeFromString(reader["driverpasspdate"].ToString());
                    list.driverpasspplace = reader["driverpasspplace"].ToString();
                    list.goodsforbidden = reader.GetFieldValueOrDefault<int>("goodsforbidden");
                    list.placedate = GetDateTimeFromString(reader["placedate"].ToString());
                    list.noticedate = GetDateTimeFromString(reader["noticedate"].ToString());
                    list.custmark = reader["custmark"].ToString();
                    list.regnum = reader["regnum"].ToString();
                    list.custofficerstampnum = reader["custofficerstampnum"].ToString();
                    list.custofficername = reader["custofficername"].ToString();
                    list.specialist = reader["specialist"].ToString();
                    list.shassi = reader["shassi"].ToString();
                    list.driverdocname = reader["driverdocname"].ToString();
                    list.dcodepto = reader["dcodepto"].ToString();
                    list.namepto = reader["namepto"].ToString();
                    list.carrieraddress = reader["carrieraddress"].ToString();
                    list.regcountrycode = reader["regcountrycode"].ToString();
                    list.purpose = reader["purpose"].ToString();
                    list.notifnum = reader["notifnum"].ToString();
                    list.createyear = reader.GetFieldValueOrDefault<int>("createyear");
                    list.trisleave = reader.GetFieldValueOrDefault<int>("trisleave");
                    list.carrierstamp1 = reader["carrierstamp1"].ToString();
                    list.carrierstamp2 = reader["carrierstamp2"].ToString();
                    list.placename = reader["placename"].ToString();
                    list.dateout = GetDateTimeFromString(reader["dateout"].ToString());
                    list.damage = reader.GetFieldValueOrDefault<int>("damage");
                    list.breachiden = reader.GetFieldValueOrDefault<int>("breachiden");
                    list.removeiden = reader.GetFieldValueOrDefault<int>("removeiden");
                    list.imposiden = reader.GetFieldValueOrDefault<int>("imposiden");
                    list.bi_amount = reader.GetFieldValueOrDefault<int>("bi_amount");
                    list.bi_num = reader["bi_num"].ToString();
                    list.ri_amount = reader.GetFieldValueOrDefault<int>("ri_amount");
                    list.ri_num = reader["ri_num"].ToString();
                    list.ii_amount = reader.GetFieldValueOrDefault<int>("ii_amount");
                    list.ii_num = reader["ii_num"].ToString();
                    list.driveroffice = reader["driveroffice"].ToString();
                    list.damcomment = reader["damcomment"].ToString();
                    list.newdoc = reader.GetFieldValueOrDefault<int>("newdoc");
                    list.isnew = reader.GetFieldValueOrDefault<int>("isnew");
                    list.drivertype = reader["drivertype"].ToString();
                    list.docscurrencycode = reader["docscurrencycode"].ToString();
                    list.transcategorycode = reader["transcategorycode"].ToString();
                    list.twhplace = reader["twhplace"].ToString();
                    list.notifcuststatus = reader.GetFieldValueOrDefault<int>("notifcuststatus");
                    list.notifcuststatusdate = GetDateTimeFromString(reader["notifcuststatusdate"].ToString());
                    list.pr_vygr = reader["pr_vygr"].ToString();
                    lst.Add(list);
                }
                reader.Close();
                return JsonConvert.SerializeObject(lst);
            }
            return "{}";
        }

        [HttpPost]
        public string EditCWPassport(cwpassport pas)
        {
            string user = User.Identity.GetUserId();
            string aa = DateTime.Now.ToString("yyyy.MM.dd");
            if (pas.cbxdate != null)
                aa = pas.cbxdate?.ToString("yyyy.MM.dd");
            var query = $"INSERT INTO cwpassport (user_id, countryid, currencyid, city, cbxnum, cbxname, addresscbx, codepto, ptofullname," +
                $" ownerrnn, ownername, owneraddress, ownerbank, owneracc, cbxnamealt, beglettersf, codeofficesf, cbxdate, cbxlic, cbxbank," +
                $" cbxacc, cbxbankaddress, ownerbankaddress, cbxrnn, ownerokpo, cbxokpo, cbxbankcode, ownerbankcode, maxdayskeep, roundsf) " +
                $"VALUES('{user}', '{pas.countryid}', '{pas.currencyid}', '{pas.city}', '{pas.cbxnum}', '{pas.cbxname}', '{pas.addresscbx}'," +
                $" '{pas.codepto}', '{pas.ptofullname}', '{pas.ownerrnn}', '{pas.ownername}', '{pas.owneraddress}', '{pas.ownerbank}'," +
                $" '{pas.owneracc}', '{pas.cbxnamealt}', '{pas.beglettersf}', '{pas.codeofficesf}', '{aa}', '{pas.cbxlic}'," +
                $" '{pas.cbxbank}', '{pas.cbxacc}', '{pas.cbxbankaddress}', '{pas.ownerbankaddress}', '{pas.cbxrnn}', '{pas.ownerokpo}'," +
                $" '{pas.cbxokpo}', '{pas.cbxbankcode}', '{pas.ownerbankcode}', {pas.maxdayskeep.GetValueOrDefault()}, {pas.roundsf.GetValueOrDefault()}) " +
                $"ON CONFLICT(user_id) DO UPDATE SET (countryid, currencyid, city, cbxnum, cbxname, addresscbx, codepto, ptofullname," +
                $" ownerrnn, ownername, owneraddress, ownerbank, owneracc, cbxnamealt, beglettersf, codeofficesf, cbxdate, cbxlic, cbxbank," +
                $" cbxacc, cbxbankaddress, ownerbankaddress, cbxrnn, ownerokpo, cbxokpo, cbxbankcode, ownerbankcode, maxdayskeep, roundsf) =" +
                $"('{pas.countryid}', '{pas.currencyid}', '{pas.city}', '{pas.cbxnum}', '{pas.cbxname}', '{pas.addresscbx}'," +
                $" '{pas.codepto}', '{pas.ptofullname}', '{pas.ownerrnn}', '{pas.ownername}', '{pas.owneraddress}', '{pas.ownerbank}'," +
                $" '{pas.owneracc}', '{pas.cbxnamealt}', '{pas.beglettersf}', '{pas.codeofficesf}', '{aa}', '{pas.cbxlic}'," +
                $" '{pas.cbxbank}', '{pas.cbxacc}', '{pas.cbxbankaddress}', '{pas.ownerbankaddress}', '{pas.cbxrnn}', '{pas.ownerokpo}'," +
                $" '{pas.cbxokpo}', '{pas.cbxbankcode}', '{pas.ownerbankcode}', {pas.maxdayskeep.GetValueOrDefault()}, {pas.roundsf.GetValueOrDefault()}) RETURNING recordid;";
            int id = Provider.RunScalar(query);
            if (Provider.lastError != "")
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogDocument.EditCWPassport}', '{LogDocument.EditCWPassport}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            else
            {
                log.Info("edit cw passport " + user + JsonConvert.SerializeObject(id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.EditCWPassport}', '{LogDocument.EditCWPassport}', '{LogSection.Document}', '{user}', '{id}', '{JsonConvert.SerializeObject(id)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
        }
            public string LoadCWPassport()
        {
            string user = User.Identity.GetUserId();
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            var query = $"SELECT * FROM cwpassport WHERE user_id = '{user}';";
            var reader = Provider.RunQuery(query);
            var list = new cwpassport();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.id = reader["recordid"].ToString();
                    list.countryid = reader["countryid"].ToString();
                    list.currencyid = reader["currencyid"].ToString();
                    list.city = reader["city"].ToString();
                    list.cbxnum = reader["cbxnum"].ToString();
                    list.cbxname = reader["cbxname"].ToString();
                    list.addresscbx = reader["addresscbx"].ToString();
                    list.codepto = reader["codepto"].ToString();
                    list.ptofullname = reader["ptofullname"].ToString();
                    list.ownerrnn = reader["ownerrnn"].ToString();
                    list.ownername = reader["ownername"].ToString();
                    list.owneraddress = reader["owneraddress"].ToString();
                    list.ownerbank = reader["ownerbank"].ToString();
                    list.owneracc = reader["owneracc"].ToString();
                    list.cbxnamealt = reader["cbxnamealt"].ToString();
                    list.beglettersf = reader["beglettersf"].ToString();
                    list.codeofficesf = reader["codeofficesf"].ToString();
                    list.cbxdate = GetDateTimeFromString(reader["cbxdate"].ToString());
                    list.cbxlic = reader["cbxlic"].ToString();
                    list.cbxbank = reader["cbxbank"].ToString();
                    list.cbxacc = reader["cbxacc"].ToString();
                    list.cbxbankaddress = reader["cbxbankaddress"].ToString();
                    list.ownerbankaddress = reader["ownerbankaddress"].ToString();
                    list.cbxrnn = reader["cbxrnn"].ToString();
                    list.ownerokpo = reader["ownerokpo"].ToString();
                    list.cbxokpo = reader["cbxokpo"].ToString();
                    list.cbxbankcode = reader["cbxbankcode"].ToString();
                    list.ownerbankcode = reader["ownerbankcode"].ToString();
                    list.maxdayskeep = reader.GetFieldValueOrDefault<int>("maxdayskeep");
                    list.roundsf = reader.GetFieldValueOrDefault<int>("roundsf");
                }
                reader.Close();

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }

        [HttpPost]
        public string CreateGTD(gtd gtd, string contract_id)
        {
            string user = User.Identity.GetUserId();
            try
            {
                if (string.IsNullOrEmpty(contract_id)) contract_id = "1";
                var query = $"INSERT INTO attis_contract_docs (attis_contract_doc_number, attis_contract_doc_contract, attis_contract_doc_type, category, attis_contract_doc_date)" +
                    $" VALUES ('{gtd.gtd_guid}', {contract_id}, 11, 'customs', now() ) RETURNING \"attis_contract_doc_id\";";
                var docid = Provider.RunScalar(query);
                string aa = "2020.01.01", ab = "2020.01.01";/*
                if (sell.release_date != null)
                    aa = sell.release_date?.ToString("yyyy.MM.dd");
                if (sell.shipment_date != null)
                    ab = sell.shipment_date?.ToString("yyyy.MM.dd");
                */
                query = $"INSERT INTO gtd (doc_id,gtd_guid,ga,g011,g012,g013,g012_1,gk_7,g021,g022i,g023i,g031,g032,g041,g042,g081,g082,g083,g141," +
                    $"g142,g143,g091,g092,g093,g11,g11_1,g15a,g16a,g17a,g19,g20,g23,g22_curr,g22_total_price,g241,g242,g30_place)" +
                    $" VALUES ('{docid}', '{gtd.gtd_guid}','{gtd.ga}','{gtd.g011}','{gtd.g012}','{gtd.g013}','{gtd.g012_1}','{gtd.gk_7}'," +
                    $"'{gtd.g021}','{gtd.g022i}','{gtd.g023i}',{gtd.g031.GetValueOrDefault()},{gtd.g032.GetValueOrDefault()}," +
                    $"{gtd.g041.GetValueOrDefault()},{gtd.g042.GetValueOrDefault()},'{gtd.g081}','{gtd.g082}','{gtd.g083}','{gtd.g0141}','{gtd.g0142}'," +
                    $"'{gtd.g0143}','{gtd.g091}','{gtd.g092}','{gtd.g093}','{gtd.g11}','{gtd.g11_1}','{gtd.g15a}','{gtd.g16a}','{gtd.g17a}'," +
                    $"{gtd.g19.GetValueOrDefault()},{gtd.g20.GetValueOrDefault()},{gtd.g23.GetValueOrDefault()},'{gtd.g22_curr}'," +
                    $"{gtd.g22_total_price.GetValueOrDefault()},{gtd.g241.GetValueOrDefault()},{gtd.g242.GetValueOrDefault()}," +
                    $"{gtd.g30_place.GetValueOrDefault()}) RETURNING gtd_id;";

                var insc = Provider.RunScalar(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.NewGTD}', '{LogDocument.NewGTD}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }

                if (insc > 0)
                {
                    log.Info("new insurance " + user + JsonConvert.SerializeObject(gtd));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewGTD}', '{LogDocument.NewGTD}', '{LogSection.Document}', '{user}', '{docid}', '{JsonConvert.SerializeObject(gtd)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
                else return "error " + insc;
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.NewGTD}', '{LogDocument.NewGTD}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        [HttpPost]
        public string UpdateGTD(gtd gtd, string doc_id)
        {
            string user = User.Identity.GetUserId();
            try
            {
                var query = $"UPDATE gtd SET(gtd_guid,ga,g011,g012,g013,g012_1,gk_7,g021,g022i,g023i,g031,g032,g041,g042,g081,g082,g083,g141," +
                    $"g142,g143,g091,g092,g093,g11,g11_1,g15a,g16a,g17a,g19,g20,g23,g22_curr,g22_total_price,g241,g242,g30_place)" +
                    $" = ('{gtd.gtd_guid}','{gtd.ga}','{gtd.g011}','{gtd.g012}','{gtd.g013}','{gtd.g012_1}','{gtd.gk_7}'," +
                    $"'{gtd.g021}','{gtd.g022i}','{gtd.g023i}',{gtd.g031.GetValueOrDefault()},{gtd.g032.GetValueOrDefault()}," +
                    $"{gtd.g041.GetValueOrDefault()},{gtd.g042.GetValueOrDefault()},'{gtd.g081}','{gtd.g082}','{gtd.g083}','{gtd.g0141}','{gtd.g0142}'," +
                    $"'{gtd.g0143}','{gtd.g091}','{gtd.g092}','{gtd.g093}','{gtd.g11}','{gtd.g11_1}','{gtd.g15a}','{gtd.g16a}','{gtd.g17a}'," +
                    $"{gtd.g19.GetValueOrDefault()},{gtd.g20.GetValueOrDefault()},{gtd.g23.GetValueOrDefault()},'{gtd.g22_curr}'," +
                    $"{gtd.g22_total_price.GetValueOrDefault()},{gtd.g241.GetValueOrDefault()},{gtd.g242.GetValueOrDefault()}," +
                    $"{gtd.g30_place.GetValueOrDefault()}) WHERE doc_id='{doc_id}';";

                Provider.RunNonQuery(query);
                if (Provider.lastError != "")
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogDocument.UpdateGTD}', '{LogDocument.UpdateGTD}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                else
                {
                    log.Info("new insurance " + user + JsonConvert.SerializeObject(gtd));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.UpdateGTD}', '{LogDocument.UpdateGTD}', '{LogSection.Document}', '{user}', '{doc_id}', '{JsonConvert.SerializeObject(gtd)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogDocument.UpdateGTD}', '{LogDocument.UpdateGTD}', '{LogSection.Document}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }

        }

        public string DeleteGTD(int doc_id)
        {
            string user = User.Identity.GetUserId();
            string query = $"DELETE FROM gtd WHERE doc_id='{doc_id}' RETURNING gtd_id;";
            var result = Provider.RunScalar(query);

            query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_id='{doc_id}' ;";
            Provider.RunNonQuery(query);
            
            log.Info("delete gtd " + user + JsonConvert.SerializeObject(doc_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogDocument.DeleteGTD}', '{LogDocument.DeleteGTD}', '{LogSection.Document}', '{user}', '', '{doc_id}', '{JsonConvert.SerializeObject(doc_id)}', 0);";
            Provider.RunNonQuery(query);
            return "ok";
        }

        public string LoadGTD(int doc_id)
        {
            string user = User.Identity.GetUserId();
            /* check if owner is looking
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
            {var product = new List<Product>();
                return "[Unauthorized]";
            }*/
            var query = $"SELECT * FROM gtd WHERE doc_id='{doc_id}';";
            var reader = Provider.RunQuery(query);
            var list = new gtd();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.gtd_id = reader.GetFieldValueOrDefault<int>("gtd_id");
                    list.gtd_guid = reader["gtd_guid"].ToString();
                    list.ga = reader["ga"].ToString();
                    list.g011 = reader["g011"].ToString();
                    list.g012 = reader["g012"].ToString();
                    list.g013 = reader["g013"].ToString();
                    list.g012_1 = reader["g012_1"].ToString();
                    list.g542 = reader["g542"].ToString();
                    list.gk_7 = reader["gk_7"].ToString();
                    list.g021 = reader["g021"].ToString();
                    list.g022i = reader["g022i"].ToString();
                    list.g023i = reader["g023i"].ToString();
                    list.g031 = reader.GetFieldValueOrDefault<int>("g031");
                    list.g032 = reader.GetFieldValueOrDefault<int>("g032");
                    list.g041 = reader.GetFieldValueOrDefault<int>("g041");
                    list.g042 = reader.GetFieldValueOrDefault<int>("g042");
                    list.g081 = reader["g081"].ToString();
                    list.g082 = reader["g082"].ToString();
                    list.g083 = reader["g083"].ToString();
                    list.g0141 = reader["g141"].ToString();
                    list.g0142 = reader["g142"].ToString();
                    list.g0143 = reader["g143"].ToString();
                    list.g091 = reader["g091"].ToString();
                    list.g092 = reader["g092"].ToString();
                    list.g093 = reader["g093"].ToString();
                    list.g11 = reader["g11"].ToString();
                    list.g11_1 = reader["g11_1"].ToString();
                    list.g15a = reader["g15a"].ToString();
                    list.g16a = reader["g16a"].ToString();
                    list.g17a = reader["g17a"].ToString();
                    list.g19 = reader.GetFieldValueOrDefault<int>("g19");
                    list.g20 = reader.GetFieldValueOrDefault<int>("g20");
                    list.g23 = reader.GetFieldValueOrDefault<float>("g23");
                    list.g22_curr = reader["g22_curr"].ToString();
                    list.g22_total_price = reader.GetFieldValueOrDefault<float>("g22_total_price");
                    list.g241 = reader.GetFieldValueOrDefault<int>("g241");
                    list.g242 = reader.GetFieldValueOrDefault<int>("g242");
                    list.g30_place = reader.GetFieldValueOrDefault<int>("g30_place");

                }
                reader.Close();

                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd HH:mm",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }
        /*
Как видно, передают номер контракта, тип контрагента(seller или buyer)

кроме того, POST содержит такие данные:
number: 3234234 (идентификатор)
name: qwerqwerq(наименование)
address: Россия, Челябинск, улица Сони Кривой(адрес)
country: (страна из справочника)
bank: (банк)
account: (номер счета)
            */
    }
}




