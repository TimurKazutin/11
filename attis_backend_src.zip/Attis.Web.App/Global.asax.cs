﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 03-10-2015
// ***********************************************************************
// <copyright file="Global.asax.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The App namespace.
/// </summary>
namespace Lawyers.Web.App
{
    using Common;
    using Helpers;
    using System;
    using System.Globalization;
    using System.Threading;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Optimization;
    using System.Web.Routing;
    //using QuartzApp.Jobs;

    /// <summary>
    /// Class MvcApplication.
    /// </summary>
    public class MvcApplication : System.Web.HttpApplication
    {
        /// <summary>
        /// Application_s the start.
        /// </summary>
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            log4net.Config.XmlConfigurator.Configure();

            //AccountingSheduler.Start();
        }

        /// <summary>
        /// Application_s the begin request.
        /// </summary>
        protected void Application_BeginRequest()
        {
            //System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ru-Ru");
            //System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("ru-RU");
        }

        protected void Application_AcquireRequestState(object sender, EventArgs e)
        {
            var handler = Context.Handler as MvcHandler;
            var routeData = handler != null ? handler.RequestContext.RouteData : null;
            var routeCulture = (routeData != null && routeData.Values.ContainsKey("culture")) ? routeData.Values["culture"].ToString() : null;
            var languageCookie = HttpContext.Current.Request.Cookies["lang"];
            //todo write lang cookie

            //routeCulture = routeCulture ?? (languageCookie != null ? languageCookie.Value : Cultures.EnglishCultureName); //English default culture 
            routeCulture = routeCulture ?? (languageCookie != null ? languageCookie.Value : Cultures.RussianCultureName);
            var cultureInfo = new CultureInfo(Common.Cultures.GetFullLanguage(routeCulture));

            Thread.CurrentThread.CurrentUICulture = cultureInfo;
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(cultureInfo.Name);
            Thread.CurrentThread.CurrentCulture.NumberFormat = CultureInfo.InvariantCulture.NumberFormat;
        }

        /// <summary>
        /// Handles the EndRequest event of the Application control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        /// <exception cref="System.Web.HttpException">403;You are not authorized</exception>
        protected void Application_EndRequest(object sender, EventArgs e)
        {
            if (Context.Response.StatusCode == 403)
            {
                // this is important, because the 401 is not an error by default!!!
                throw new HttpException(403, "You are not authorized");
            }
        }
    }
}
