﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 11-26-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-26-2014
// ***********************************************************************
// <copyright file="ImageFile.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace Lawyers.Common.Classes
{
    using System;
    using System.Drawing;
    using System.IO;

    /// <summary>
    /// Class ImageFile.
    /// </summary>
    public class ImageFile
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int ID { get; set; }

        /// <summary>
        /// Gets or sets the document unique identifier.
        /// </summary>
        /// <value>The document unique identifier.</value>
        public Guid DocGuid { get; set; }

        /// <summary>
        /// Gets or sets the document unique identifier.
        /// </summary>
        /// <value>The document unique identifier.</value>
        public string EntityId { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the length.
        /// </summary>
        /// <value>The length.</value>
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>Widget Id</value>
        public string WidgetId { get; set; }

        /// <summary>
        /// Gets or sets the image.
        /// </summary>
        /// <value>The image.</value>
        public MemoryStream Image { get; set; }

        /// <summary>
        /// Gets or sets the date.
        /// </summary>
        /// <value>The date.</value>
        public DateTime Date { get; set; }

        public string TypeByName
        {
            get { return Name.Substring(Name.LastIndexOf(".", StringComparison.Ordinal)).ToLower(); }
        }

        public bool IsPicture
        {
            get { return MimeTypesHelper.IsPicture(TypeByName); }
        }

        public string IconPath
        {
            get { return MimeTypesHelper.GetIconPath(TypeByName); }
        }

        public string ContentType
        {
            get { return MimeTypesHelper.GetContentType(TypeByName); }
        }

        /// <summary>
        /// To the byte array.
        /// </summary>
        /// <param name="imageIn">The image in.</param>
        /// <returns>System.Byte[].</returns>
        public static byte[] ToByteArray(Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms,imageIn.RawFormat);
            return ms.ToArray();
        }

        /// <summary>
        /// To the image.
        /// </summary>
        /// <param name="byteArrayIn">The byte array in.</param>
        /// <returns>Image.</returns>
        public static Image ToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = System.Drawing.Image.FromStream(ms);
            return returnImage;
        }
    }
}