﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 11-05-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-05-2014
// ***********************************************************************
// <copyright file="RecordState.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    /// <summary>
    /// Enum RecordState
    /// </summary>
    public enum RecordState
    {
        /// <summary>
        /// The none
        /// </summary>
        None,
        /// <summary>
        /// The insert
        /// </summary>
        Insert,
        /// <summary>
        /// The update
        /// </summary>
        Update,
        /// <summary>
        /// The delete
        /// </summary>
        Delete
    }
}
