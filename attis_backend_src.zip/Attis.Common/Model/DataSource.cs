﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-28-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-28-2014
// ***********************************************************************
// <copyright file="DataSource.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Xml.Serialization;
    using Lawyers.Common.Enums;
    /// <summary>
    /// Class DataSource.
    /// </summary>
    public class DataSource
    {
        /// <summary>
        /// The _type
        /// </summary>
        [XmlIgnore]
        private DataSourceType? _type;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        [XmlAttribute("datasource_id")]
        public int ID { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        [XmlAttribute("datasource_type")]
        public DataSourceType Type
        {
            get { return this._type ?? DataSourceType.None; }
            set { this._type = value; }
        }

        /// <summary>
        /// Gets or sets the caption.
        /// </summary>
        /// <value>The caption.</value>
        [XmlAttribute("caption_en")]
        public string Caption { get; set; }

        /// <summary>
        /// Gets or sets the connection string.
        /// </summary>
        /// <value>The connection string.</value>
        [XmlAttribute("connection_string")]
        public string ConnectionString { get; set; }
    }
}
