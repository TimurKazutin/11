﻿//// ***********************************************************************
//// Assembly         : Lawyers.Web.App
//// Author           : Alexey Shumeyko
//// Created          : 11-08-2014
////
//// Last Modified By : Victor Skakun
//// Last Modified On : 8-07-2016
//// ***********************************************************************
//// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
////     Copyright (c) Algorithms & Systems JSC. All rights reserved.
//// </copyright>
//// <summary></summary>
//// ***********************************************************************
///// <summary>
///// The Models namespace.
///// </summary>
//namespace Lawyers.Web.App.Models
//{
//    using Microsoft.AspNet.Identity;
//    using System;
//    using System.Collections.Generic;
//    using System.Data;
//    using System.Linq;
//    using System.Security.Claims;
//    using System.Threading.Tasks;
//    using Lawyers.Common;
//    //using Lawyers.Database.Oracle;
//    using Engine.Configuration;
//    using Common.Interfaces;

//    /// <summary>
//    /// Class UserStore.
//    /// </summary>
//    public class UserStore : IUserStore<ApplicationUser>,
//                              IUserClaimStore<ApplicationUser>,
//                              IUserLoginStore<ApplicationUser>,
//                              IUserRoleStore<ApplicationUser>,
//                              IUserPasswordStore<ApplicationUser>,
//        IUserLockoutStore<ApplicationUser, string>,
//        IUserTwoFactorStore<ApplicationUser, string>,
//        IUserPhoneNumberStore<ApplicationUser>,
//        IUserEmailStore<ApplicationUser>
//    {
//        /// <summary>
//        /// Gets the provider.
//        /// </summary>
//        /// <value>The provider.</value>
//        private IDataProvider provider
//        {
//            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
//        }

//        /// <summary>
//        /// Gets the roles.
//        /// </summary>
//        /// <value>The roles.</value>
//        private UserRoles roles
//        {
//            get { return GlobalContainer.Instance.Get<UserRoles>(); }
//        }

//        /// <summary>
//        /// Gets the find user query.
//        /// </summary>
//        /// <value>The find user query.</value>
//        private string FindUserQuery
//        {
//            get
//            {
//                return @"select u.user_id, u.loginname, u.user_password from USERS u where ";
//            }
//        }

//        /// <summary>
//        /// Gets the select user query.
//        /// </summary>
//        /// <value>The select user query.</value>
//        private string SelectUserQuery
//        {
//            get
//            {
//                //return @"select u.user_id, u.loginname, u.user_password, u.isenable, u.date_registry, u.date_blocked, users_roles.user_role, p.given_name, p.last_name from USERS u left outer join persons p on p.person_id = u.person_id inner join users_roles on u.user_role_code = users_roles.user_role_code where ";
//                return @"select u.*, p.person_code, p.given_name, p.last_name, p.middle_name, p.gender, p.date_of_birth, p.residency, p.country from USERS u left outer join persons p on p.person_id = u.person_id where ";
//            }
//        }

//        /// <summary>
//        /// Creates the asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task CreateAsync(ApplicationUser user)
//        {
//            int result = this.provider.RunScalarStoredProcedure("ADDUSER", user.UserName, user.PasswordHash, user.Phone, user.Email, user.LastName, user.FirstName, user.MiddleName, user.PersonCode, user.Gender, user.Birthday, user.Residency, user.Country);
//            //example to run in sqldeveloper (Oracle)
//            //exec ADDUSER('aaa', 'aassddffgghh', 'LASTNAME', 'FIRSTNAME', '2352435436', 'aaaaa@tut.by', 'BY', 'DSA', 'Head', 'Dr', 'lastZh', 'firstZh', 'dep_ru', 'job_ru', 'm', '1')
//            //example to run in pgAdmin (PosgreSQL)_
//            //SELECT public.adduser('Skv', 'asf56gdhdb55xcbgdhdg', '52525252','skab@sfss.by','ASDFSDF43463','gsgs','fjfjj','sqwawr','М','04.05.1967','1','BY');
//            if (result < 0)
//            {
//                //return Task.FromResult(false);
//                return Task.FromResult<IdentityResult>(IdentityResult.Failed("Registration database call was failed")); 
//            }
//            else
//                return Task.FromResult(0);  //todo 
//        }

//        /// <summary>
//        /// Deletes the asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task DeleteAsync(ApplicationUser user)
//        {
//            this.provider.RunNonQuery("DELETE FROM USERS WHERE id = :p0 ", user.Id);

//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Finds the by identifier asynchronous.
//        /// </summary>
//        /// <param name="userId">The user identifier.</param>
//        /// <returns>Task&lt;ApplicationUser&gt;.</returns>
//        public Task<ApplicationUser> FindByIdAsync(string userId)
//        {
//            IDataReader reader = this.provider.RunQuery(this.SelectUserQuery + "u.user_id = :p0", userId);

//            return Task.FromResult<ApplicationUser>(this.GetFromReader(reader));
//        }

//        /// <summary>
//        /// Finds the by name asynchronous.
//        /// </summary>
//        /// <param name="userName">Name of the user.</param>
//        /// <returns>Task&lt;ApplicationUser&gt;.</returns>
//        public Task<ApplicationUser> FindByNameAsync(string userName)
//        {
//            IDataReader reader = this.provider.RunQuery(this.SelectUserQuery + "u.loginname = :p0", userName);

//            return Task.FromResult<ApplicationUser>(this.GetFromReader(reader));
//        }

//        /// <summary>
//        /// Updates the asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task.</returns>
//        public Task UpdateAsync(ApplicationUser user)
//        {
//            switch (user.UpdateState)
//            {
//                case UpdateStates.Password:
//                    var result = this.provider.RunQuery("update users set user_password = :p0 where ID = :p1", user.PasswordHash, user.Id);
//                    break;
//                case UpdateStates.Info:
//                    int res = this.provider.RunScalarStoredProcedure("UPDATEUSERINFO", user.Id, user.LastName, user.FirstName, user.MiddleName, user.PersonCode, user.Gender, user.Birthday, user.Residency, user.Country, user.Phone);
//                    //example to run in sqldeveloper
//                    //exec UPDATEUSERINFO(75, 'aa1', 'bb', '123 4344', 'aa@tut.by', 'BY', 'BSU', 'DSA', 'Head', 'Dr', 'bb zh', 'aa zh', 'bsu zh', 'dep zh', 'h zh', 'M');
//                    //example to run in pgAdmin
//                    //SELECT public.updateuserinfo(6,'LASTNAME1', 'FIRSTNAME1', '2352435436', 'aaaaa@tut.by', 'BY', 'DSA', 'Head', 'Dr', 'lastZh', 'firstZh', 'dep_ru', 'job_ru', 'm', 1) 
//                    if (res < 0)
//                    {
//                        //return Task.FromResult(false);  //todo add return error
//                        return Task.FromResult<IdentityResult>(IdentityResult.Failed("Update database call was failed"));
//                    }
//                    break;
//            }

//            //todo update claims
//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
//        /// </summary>
//        public void Dispose()
//        {
//            //throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Adds the claim asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="claim">The claim.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task AddClaimAsync(ApplicationUser user, Claim claim)
//        {
//            throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Gets the claims asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;IList&lt;Claim&gt;&gt;.</returns>
//        public Task<IList<Claim>> GetClaimsAsync(ApplicationUser user)
//        {
//            List<Claim> claims = new List<Claim>();
//            claims.Add(new Claim(ClaimTypes.Email, user.UserName, ClaimValueTypes.String));
//            claims.Add(new Claim(ClaimTypes.Surname, user.LastName, ClaimValueTypes.String));
//            //claims.Add(new Claim(ClaimTypes.Surname, string.IsNullOrEmpty(user.LastNameZh) ? user.LastName : user.LastNameZh, ClaimValueTypes.String));
//            claims.Add(new Claim(ClaimTypes.Name, user.FirstName, ClaimValueTypes.String));
//            //claims.Add(new Claim(ClaimTypes.Name, string.IsNullOrEmpty(user.FirstNameZh) ? user.FirstName : user.FirstNameZh, ClaimValueTypes.String));
//            claims.Add(new Claim(ClaimTypes.Hash, user.PasswordHash, ClaimValueTypes.String));
//            claims.Add(new Claim(ClaimTypes.MobilePhone, user.Phone, ClaimValueTypes.String));
//            //claims.Add(new Claim(ClaimTypes.UserData, user.CompanyName, ClaimValueTypes.String));
//            //claims.Add(new Claim(ClaimTypes.UserData, string.IsNullOrEmpty(user.CompanyNameZh) ? user.CompanyName : user.CompanyNameZh, ClaimValueTypes.String));
//            claims.Add(new Claim(ClaimTypes.GroupSid, user.UserRoles.ToString(), ClaimValueTypes.Integer32));
//            //claims.Add(new Claim(ClaimTypes.PrimarySid, user.CompanyID.ToString(), ClaimValueTypes.Integer32));

//            return Task.FromResult<IList<Claim>>(claims);
//        }

//        /// <summary>
//        /// Removes the claim asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="claim">The claim.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task RemoveClaimAsync(ApplicationUser user, Claim claim)
//        {
//            throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Adds the login asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="login">The login.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task AddLoginAsync(ApplicationUser user, UserLoginInfo login)
//        {
//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Finds the asynchronous.
//        /// </summary>
//        /// <param name="login">The login.</param>
//        /// <returns>Task&lt;ApplicationUser&gt;.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task<ApplicationUser> FindAsync(UserLoginInfo login)
//        {
//            throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Gets the logins asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;IList&lt;UserLoginInfo&gt;&gt;.</returns>
//        public Task<IList<UserLoginInfo>> GetLoginsAsync(ApplicationUser user)
//        {
//            List<UserLoginInfo> list = new List<UserLoginInfo>();
//            //list.Add(new UserLoginInfo())
//            return Task.FromResult<IList<UserLoginInfo>>(list);
//        }

//        /// <summary>
//        /// Removes the login asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="login">The login.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task RemoveLoginAsync(ApplicationUser user, UserLoginInfo login)
//        {
//            throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Adds to role asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="roleName">Name of the role.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task AddToRoleAsync(ApplicationUser user, string roleName)
//        {
//            if (!string.IsNullOrEmpty(roleName))
//            {
//                user.UserRoles = roles.Where(r => r.Value == roleName).First().Key;
//            }

//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Gets the roles asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;IList&lt;System.String&gt;&gt;.</returns>
//        public Task<IList<string>> GetRolesAsync(ApplicationUser user)
//        {
//            return Task.FromResult<IList<string>>(roles.Where(r => (r.Key & user.UserRoles) > 0).Select(r => r.Value).ToList());
//        }

//        /// <summary>
//        /// Determines whether [is in role asynchronous] [the specified user].
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="roleName">Name of the role.</param>
//        /// <returns>Task&lt;System.Boolean&gt;.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task<bool> IsInRoleAsync(ApplicationUser user, string roleName)
//        {
//            throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Removes from role asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="roleName">Name of the role.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task RemoveFromRoleAsync(ApplicationUser user, string roleName)
//        {
//            throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Gets the password hash asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.String&gt;.</returns>
//        public Task<string> GetPasswordHashAsync(ApplicationUser user)
//        {
//            return Task.FromResult<string>(user.PasswordHash);
//        }

//        /// <summary>
//        /// Determines whether [has password asynchronous] [the specified user].
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.Boolean&gt;.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task<bool> HasPasswordAsync(ApplicationUser user)
//        {
//            throw new System.NotImplementedException();
//        }

//        /// <summary>
//        /// Sets the password hash asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="passwordHash">The password hash.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetPasswordHashAsync(ApplicationUser user, string passwordHash)
//        {
//            user.UpdateState = UpdateStates.Password;
//            user.PasswordHash = passwordHash;

//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Gets from reader.
//        /// </summary>
//        /// <param name="reader">The reader.</param>
//        /// <returns>ApplicationUser.</returns>
//        private ApplicationUser GetFromReader(IDataReader reader)
//        {
//            ApplicationUser user = null;

//            if (reader.Read())
//            {
//                user = new ApplicationUser();
//                user.Id = reader[0].ToString();
//                user.UserName = reader[2].ToString();
//                user.Email = user.UserName;
//                user.PasswordHash = reader[3].ToString();
//                user.Enable = Convert.ToBoolean(reader.GetInt16(4));
//                user.UserRoles = reader.IsDBNull(5) ? 0 : reader.GetInt32(5);
//                user.DateRegistry = reader.GetDateTime(6);
//                user.DateBlocked = reader.IsDBNull(7) ? (DateTime?)null : reader.GetDateTime(7);
//                user.Phone = reader[9].ToString();
//                user.PersonCode = reader[10].ToString();
//                user.FirstName = reader[11].ToString();
//                user.LastName = reader[12].ToString();
//                user.MiddleName = reader[13].ToString();
//                user.Gender = reader[14].ToString();
//                user.Birthday = reader.IsDBNull(15) ? (DateTime?)null : reader.GetDateTime(15);
//                user.Residency = reader.GetInt16(16);
//                user.Country = reader[17].ToString();
//            }

//            return user;
//        }

//        /// <summary>
//        /// Initializes a new instance of the <see cref="UserStore"/> class.
//        /// </summary>
//        public UserStore()
//        {
//        }

//        /// <summary>
//        /// Gets the access failed count asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.Int32&gt;.</returns>
//        public Task<int> GetAccessFailedCountAsync(ApplicationUser user)
//        {
//            return Task.FromResult<int>(0);
//        }

//        /// <summary>
//        /// Gets the lockout enabled asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.Boolean&gt;.</returns>
//        public Task<bool> GetLockoutEnabledAsync(ApplicationUser user)
//        {
//            //return Task.FromResult<bool>(user.Id != user.UserCreator);
//            return Task.FromResult<bool>(true);
//        }

//        /// <summary>
//        /// Gets the lockout end date asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;DateTimeOffset&gt;.</returns>
//        public Task<DateTimeOffset> GetLockoutEndDateAsync(ApplicationUser user)
//        {
//            return Task.FromResult<DateTimeOffset>(new DateTimeOffset(user.DateRegistry));
//        }

//        /// <summary>
//        /// Increments the access failed count asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.Int32&gt;.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task<int> IncrementAccessFailedCountAsync(ApplicationUser user)
//        {
//            throw new NotImplementedException();
//        }

//        /// <summary>
//        /// Resets the access failed count asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task.</returns>
//        public Task ResetAccessFailedCountAsync(ApplicationUser user)
//        {
//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Sets the lockout enabled asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="enabled">if set to <c>true</c> [enabled].</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetLockoutEnabledAsync(ApplicationUser user, bool enabled)
//        {
//            user.Enable = enabled;
//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Sets the lockout end date asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="lockoutEnd">The lockout end.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetLockoutEndDateAsync(ApplicationUser user, DateTimeOffset lockoutEnd)
//        {

//            throw new NotImplementedException();
//        }

//        /// <summary>
//        /// Gets the two factor enabled asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.Boolean&gt;.</returns>
//        public Task<bool> GetTwoFactorEnabledAsync(ApplicationUser user)
//        {
//            return Task.FromResult<bool>(false);
//        }

//        /// <summary>
//        /// Sets the two factor enabled asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="enabled">if set to <c>true</c> [enabled].</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetTwoFactorEnabledAsync(ApplicationUser user, bool enabled)
//        {
//            throw new NotImplementedException();
//        }

//        /// <summary>
//        /// Gets the phone number asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.String&gt;.</returns>
//        public Task<string> GetPhoneNumberAsync(ApplicationUser user)
//        {
//            return Task.FromResult<string>(user.Phone);
//        }

//        /// <summary>
//        /// Gets the phone number confirmed asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.Boolean&gt;.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task<bool> GetPhoneNumberConfirmedAsync(ApplicationUser user)
//        {
//            throw new NotImplementedException();
//        }

//        /// <summary>
//        /// Sets the phone number asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="phoneNumber">The phone number.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetPhoneNumberAsync(ApplicationUser user, string phoneNumber)
//        {
//            user.Phone = phoneNumber;
//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Sets the phone number confirmed asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="confirmed">if set to <c>true</c> [confirmed].</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetPhoneNumberConfirmedAsync(ApplicationUser user, bool confirmed)
//        {
//            throw new NotImplementedException();
//        }

//        /// <summary>
//        /// Finds the by email asynchronous.
//        /// </summary>
//        /// <param name="email">The email.</param>
//        /// <returns>Task&lt;ApplicationUser&gt;.</returns>
//        public Task<ApplicationUser> FindByEmailAsync(string email)
//        {
//            IDataReader reader = this.provider.RunQuery(this.SelectUserQuery + "u.EMAIL = :p0", email);

//            return Task.FromResult<ApplicationUser>(this.GetFromReader(reader));
//        }

//        /// <summary>
//        /// Gets the email asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.String&gt;.</returns>
//        public Task<string> GetEmailAsync(ApplicationUser user)
//        {
//            return Task.FromResult<string>(user.Email);
//        }

//        /// <summary>
//        /// Gets the email confirmed asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <returns>Task&lt;System.Boolean&gt;.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task<bool> GetEmailConfirmedAsync(ApplicationUser user)
//        {
//            throw new NotImplementedException();
//        }

//        /// <summary>
//        /// Sets the email asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="email">The email.</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetEmailAsync(ApplicationUser user, string email)
//        {
//            user.Email = email;
//            return Task.FromResult(0);
//        }

//        /// <summary>
//        /// Sets the email confirmed asynchronous.
//        /// </summary>
//        /// <param name="user">The user.</param>
//        /// <param name="confirmed">if set to <c>true</c> [confirmed].</param>
//        /// <returns>Task.</returns>
//        /// <exception cref="System.NotImplementedException"></exception>
//        public Task SetEmailConfirmedAsync(ApplicationUser user, bool confirmed)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}