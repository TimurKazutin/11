﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-16-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-16-2014
// ***********************************************************************
// <copyright file="WidgetType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace Lawyers.Common.Enums
{
    using System.Xml.Serialization;

    /// <summary>
    /// Enum WidgetType
    /// </summary>
    public enum WidgetType
    {
        /// <summary>
        /// The array
        /// </summary>
        [XmlEnum(Name = "array")]
        Array,
        [XmlEnum(Name = "attachment")]
        Attachment,
        /// <summary>
        /// The box
        /// </summary>
        [XmlEnum(Name = "box")]
        Box,
        /// <summary>
        /// The container
        /// </summary>
        [XmlEnum(Name = "container")]
        Container,
        /// <summary>
        /// The date
        /// </summary>
        [XmlEnum(Name = "date")]
        Date,
        /// <summary>
        /// The date time
        /// </summary>
        [XmlEnum(Name = "datetime")]
        DateTime,
        /// <summary>
        /// The integer
        /// </summary>
        [XmlEnum(Name = "integer")]
        Integer,
        /// <summary>
        /// The numeric
        /// </summary>
        [XmlEnum(Name = "numeric")]
        Decimal,
        /// <summary>
        /// The text
        /// </summary>
        [XmlEnum(Name = "text")]
        Text,
        /// <summary>
        /// The textgroup
        /// </summary>
        [XmlEnum(Name = "text_group")]
        TextGroup,
        /// <summary>
        /// The single edit
        /// </summary>
        [XmlEnum(Name = "edit")]
        Edit,
        /// <summary>
        /// The hyperlink
        /// </summary>
        [XmlEnum(Name = "hyperlink")]
        Hyperlink,
        /// <summary>
        /// The structure
        /// </summary>
        [XmlEnum(Name = "struct")]
        Struct,
        /// <summary>
        /// The DBComboBox
        /// </summary>
        [XmlEnum(Name = "hdbk")]
        DBComboBox,
        /// <summary>
        /// The list
        /// </summary>
        [XmlEnum(Name = "list")]
        List,
        /// <summary>
        /// The list item
        /// </summary>
        [XmlEnum(Name = "list_item")]
        ListItem,
        /// <summary>
        /// The memo
        /// </summary>
        [XmlEnum(Name = "memo")]
        Memo,
        /// <summary>
        /// The CheckBox
        /// </summary>
        [XmlEnum(Name = "checkbox")]
        CheckBox,
        /// <summary>
        /// The button
        /// </summary>
        [XmlEnum(Name = "button")]
        Button,
        /// <summary>
        /// The check list
        /// </summary>
        [XmlEnum(Name="checklist")]
        CheckList,
        /// <summary>
        /// The data grid
        /// </summary>
        [XmlEnum(Name="DataGrid")]
        DataGrid,
        /// <summary>
        /// The data grid
        /// </summary>
        [XmlEnum(Name = "Form")]
        Form,
        /// <summary>
        /// The tab control
        /// </summary>
        [XmlEnum(Name = "TabControl")]
        TabControl,
        /// <summary>
        /// The tab page
        /// </summary>
        [XmlEnum(Name="tabPage")]
        TabPage,
        /// <summary>
        /// The result
        /// </summary>
        [XmlEnum(Name = "Result")]
        Result,
        /// <summary>
        /// The parameter
        /// </summary>
        [XmlEnum(Name = "param")]
        Parameter
    }
}
