﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Victor Skakun
// Created          : 8-07-2016
//
// Last Modified By : Victor Skakun
// Last Modified On : 8-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Lawyers.Web.App.Resources;

namespace Lawyers.Web.App.Models
{
    public class ContactViewModel
    {
        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [Display(Name="Model_Name", ResourceType =typeof(GlobalStrings))]
        public string Name { get; set; }

        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [Display(Name = "Model_Email", ResourceType = typeof(GlobalStrings))]
        public string Email { get; set; }

        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [Display(Name = "Model_Question", ResourceType = typeof(GlobalStrings))]
        public string Text { get; set; }
    }

    public class HomeLawyer
    {
        public string LawyerName { get; set; }
        public byte[] LawyerPhoto { get; set; }
    }

    public class HomeViewModel
    {
        public List<HomeLawyer> HomeLawyers = new List<HomeLawyer>();
    }
}