﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.SessionState;
using System.Web.Mvc;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using log4net;
    using Newtonsoft.Json;
    using System.Net.Http;

    [SessionState(SessionStateBehavior.Disabled)]
    public class LibraryController : Controller
    {
        private ILog _logger = LogManager.GetLogger("library"); 
        
        private IDataProvider provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

        public class LibModel
        {
            public string display_text { get; set; }
            public string value { get; set; }
            //public HttpPostedFileBase Image { get; set; }    
        }

        // GET: Library
        public JsonResult Index(string type, string query, int qty, string token, string lang )
        { 
            var news = new List<LibModel> ();
            //news.Add(new LibModel { display_text = "Furniture Production", value= "funrinture_production" });
            //news.Add(new LibModel { display_text = "Financial Sector", value = "finance" });
            //news.Add(new LibModel { display_text = "Insurance", value = "insurance_h" });
            /* oked и subj_statuses
             */
            if (type == "status")
            {
                lock (provider.Locker)
                {
                    string ln = "subj_status_name_ru";
                    if (lang.Equals("en")) ln = "subj_status_name_en";
                    string query1 = $"SELECT * FROM subj_statuses WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["subj_status_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;
                        _logger.Error("as");
                        _logger.Info(reader);
                    }
                }
            }
            /*
            if (type == "delivery_term")
            {
                news.Add(new LibModel { display_text = "delivery", value = "delivery" });
            }*/
            if (type == "payment_type")
            {
                string ln = "payment_name";
                if (lang.Equals("en")) ln = "payment_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM attis_payment_types WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["payment_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "company")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM organizations WHERE org_code ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["org_code"].ToString(), display_text = reader["org_name"].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "org_form")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM organization_types WHERE LOWER(org_type_name_ru) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["org_type"].ToString(), display_text = reader["org_type_name_ru"].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "org_type")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM organization_types WHERE LOWER(org_type_name_ru) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["org_type"].ToString(), display_text = reader["org_type_name_ru"].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "code_type")
            {
                string ln = "fm1_oper_kind_name";
                if (lang.Equals("en")) ln = "fm1_oper_kind_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM fm1_oper_kinds WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["fm1_oper_kind_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "code_eknp")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM fm1_knp WHERE LOWER(fm1_knp_name) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["fm1_knp_code"].ToString(), display_text = reader["fm1_knp_name"].ToString() });
                        }
                        reader.Close();
                    }
                }
            }
            if (type == "oper_basis")
            {
                string ln = "fm1_memb_kind_name";
                if (lang.Equals("en")) ln = "fm1_memb_kind_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM fm1_member_kinds WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["fm1_memb_kind_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }
            if (type == "oper_code")
            {
                string ln = "fm1_suspect_oper_name";
                if (lang.Equals("en")) ln = "fm1_suspect_oper_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM fm1_suspect_operations WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["fm1_suspect_oper_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }
            if (type == "fm1_memb_subj_kind")
            {
                string ln = "fm1_subj_kind_name";
                if (lang.Equals("en")) ln = "fm1_subj_kind_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM fm1_subj_kinds WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["fm1_subj_kind_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }
            
            if (type == "currency")
            {
                string ln = "currency_name_ru";
                if (lang.Equals("en")) ln = "currency_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM currencies WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["currency_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "country")
            {
                string ln = "country_name_ru";
                if (lang.Equals("en")) ln = "country_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM countries WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["country_2a_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "customs_office")
            {
                string ln = "custom_name";
                if (lang.Equals("en")) ln = "custom_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM custom_offices WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["custom_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "packaging")
            {
                string ln = "pack_name_ru";
                if (lang.Equals("en")) ln = "pack_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM packagin WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["pack_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "transport_mode_code" || type == "transporttype")
            {
                string ln = "transp_kind_name";
                if (lang.Equals("en")) ln = "transp_kind_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM transport_kinds WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["transp_kind_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }
            
            if (type == "delivery_term")
            {
                string ln = "inkoterms_name_ru";
                if (lang.Equals("en")) ln = "inkoterms_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM inkoterms WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["inkoterms_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "measure")
            {
                string ln = "measure_name_ru";
                if (lang.Equals("en")) ln = "measure_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM measures WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["measure_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "tnved")
            {
                string ln = "shortname";
                if (lang.Equals("en")) ln = "shortname_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM tnved WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["tnvedcode"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
            }

            if (type == "usage_code")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM usage_codes WHERE LOWER(usage_code_name_ru) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["usage_code"].ToString(), display_text = reader["usage_code_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }

            if (type == "declaration_kind")
            {
                string ln = "declaration_kind_name_ru";
                if (lang.Equals("en")) ln = "declaration_kind_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM declaration_kinds WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["declaration_kind_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }

            if (type == "goods_transfer_feature")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM goods_transfer_feature WHERE LOWER(goods_tranfer_feature_name_ru) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["goods_tranfer_feature_code"].ToString(), display_text = reader["goods_tranfer_feature_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }
            
            if (type == "custdoc_kinds")
            {
                string ln = "custdoc_kind_name";
                if (lang.Equals("en")) ln = "custdoc_kind_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM custdoc_kinds WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["custdoc_kind_id"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }

            if (type == "oked")
            {
                string ln = "oked_name_ru";
                if (lang.Equals("en")) ln = "oked_name_en";
                if (lang.Equals("kz")) ln = "oked_name_kz";
                if (lang.Equals("cn")) ln = "oked_name_cn";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM oked_new WHERE LOWER({ln}) ~ LOWER('{query}') OR oked_code ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["oked_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }

            if (type == "kpved")
            {
                string ln = "kpved_name_ru";
                if (lang.Equals("en")) ln = "kpved_name_en";
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM kpved WHERE LOWER({ln}) ~ LOWER('{query}') LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["kpved_subkind"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }

            if (type == "participant_type")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM oked WHERE LOWER(oked_name_ru) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["oked_code"].ToString(), display_text = reader["oked_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }

            if (type == "movement_type")
            {
                //news.Add(new LibModel { display_text = "Furniture Production", value= "funrinture_production" });
                //news.Add(new LibModel { display_text = "Financial Sector", value = "finance" });
                //news.Add(new LibModel { display_text = "Insurance", value = "insurance_h" });
                {
                    string query1 = $"SELECT * FROM oked WHERE LOWER(oked_name_ru) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            //var dt = reader["date"].ToString().Split(' ');
                            news.Add(new LibModel { value = reader["oked_code"].ToString(), display_text = reader["oked_name_ru"].ToString() });
                        }
                        reader.Close();
                        //ViewBag.allUsers = selListMsg;

                    }
                }
            }

            if (type == "pa_document_type")
            {
                lock (provider.Locker)
                {
                    string ln = "pa_doc_type_name_ru";
                    if (lang.Equals("en")) ln = "pa_doc_type_name_en";
                    string query1 = $"SELECT * FROM pa_doc_types WHERE LOWER({ln}) ~ '{query}' LIMIT '{qty}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["pa_doc_type_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();

                    }
                }
            }
            if (type == "bank")
            {
                lock (provider.Locker)
                {
                    string query1 = $"Select * FROM banks WHERE LOWER(bank_name) ~ '{query}' LIMIT '{qty}'";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["bic"].ToString(), display_text = reader["bic"].ToString() + "  " + reader["bank_name"].ToString() });
                        }
                        reader.Close();
                    }
                }
            }
            if (type == "rw_station")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT distinct on (rw_kodstan6) * FROM rw_stations WHERE LOWER(rw_naimstan) ~ '{query}' and rw_kodstan6 is not null  LIMIT '{qty}'";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["rw_kodstan6"].ToString(), display_text = reader["rw_naimstan"].ToString() });
                        }
                        reader.Close();
                    }
                }
            }
            if (type == "twh_doctype")
            {
                string query1 = $"SELECT * FROM twh_doctypes WHERE text_value ~ '{query}' LIMIT '{qty}'";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["code"].ToString(), display_text = reader["text_value"].ToString() });
                    }
                    reader.Close();
                }
            }
            return Json(news, JsonRequestBehavior.AllowGet);
        }

        public JsonResult rw_station(string code)
        {
            var news = new List<LibModel>();
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM rw_stations WHERE rw_kodstan6 = '{code}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        //var dt = reader["date"].ToString().Split(' ');
                        news.Add(new LibModel { value = reader["rw_kodstan6"].ToString(), display_text = reader["rw_naimstan"].ToString() });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;

                }
            }
            return Json(news, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Payment_type(string code, string lang)
        {
            var news = new List<LibModel>();
            string ln = "payment_name";
            if (lang.Equals("en")) ln = "payment_name_en";
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM attis_payment_types WHERE payment_code = '{code}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["payment_code"].ToString(), display_text = reader[ln].ToString() });
                    }
                    reader.Close();
                }
            }
            return Json(news, JsonRequestBehavior.AllowGet); //rw
        }

        public JsonResult Goods_transfer_feature(string code)
        {
            var news = new List<LibModel>();
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM goods_transfer_feature WHERE goods_tranfer_feature_code = '{code}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        //var dt = reader["date"].ToString().Split(' ');
                        news.Add(new LibModel { value = reader["goods_tranfer_feature_code"].ToString(), display_text = reader["goods_tranfer_feature_name_ru"].ToString() });
                    }
                    reader.Close();
                    //ViewBag.allUsers = selListMsg;

                }
            }
            return Json(news, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Customs_office(string code, string lang)
        {
            var news = new List<LibModel>();
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM custom_offices WHERE custom_code = '{code}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["custom_code"].ToString(), display_text = reader["custom_name"].ToString() });
                    }
                    reader.Close();
                }
            }
            return Json(news, JsonRequestBehavior.AllowGet);
        }

        public JsonResult delivery_term(string code, string token)
        {
            var news = new List<LibModel>();
            if (code != "")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM inkoterms WHERE LOWER(inkoterms_code) ~ LOWER('{code}') "; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["inkoterms_code"].ToString(), display_text = reader["inkoterms_name_ru"].ToString() });
                        }
                        reader.Close();
                    }
                }
                return Json(news, JsonRequestBehavior.AllowGet);
            }
            else return Json("empty search");
        }
        public JsonResult tnved(string code, string lang)
        {
            string ln = "shortname";
            if (lang.Equals("en")) ln = "shortname_en";
            var news = new List<LibModel>();
            if (code != "")
            {
                //lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM tnved WHERE LOWER(tnvedcode) ~ '{code}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["tnvedcode"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
                return Json(news, JsonRequestBehavior.AllowGet);
            }            
            else return Json("empty search");
        }

        public JsonResult transporttype(string code, string lang)
        {
            var news = new List<LibModel>();
            if (code != "")
            {
                string ln = "transp_kind_name";
                if (lang.Equals("en")) ln = "transp_kind_name_en";
                {
                    string query1 = $"SELECT * FROM transport_kinds WHERE transp_kind_code = '{code}' LIMIT '1'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["transp_kind_code"].ToString(), display_text = reader[ln].ToString() });
                        }
                        reader.Close();
                    }
                }
                return Json(news, JsonRequestBehavior.AllowGet);
            }
            else return Json("empty search");
        }

        /*
        public JsonResult customs_office(string code, string token)
        {
            var news = new List<LibModel>();
            if (code != "")
            {
                lock (provider.Locker)
                {
                    string query1 = $"SELECT * FROM custom_offices WHERE custom_code ~ '{code}';"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                    var reader = provider.RunQuery(query1);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            news.Add(new LibModel { value = reader["custom_code"].ToString(), display_text = reader["custom_name"].ToString() });
                        }
                        reader.Close();
                    }
                }
                return Json(news, JsonRequestBehavior.AllowGet);
            }
            else return Json("empty search");
        }
        */
        public string kompra(string query)
        {
            string name = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://kompra.kz/api/v2/");
                //var responseTask = client.GetAsync("basic?identifier=150840007789&api-token=aKNmlhwdpKUVOX6WfxZR2MIhf9Xis6Cg"); //110740018327
                var responseTask = client.GetAsync("basic?identifier="+query+"&api-token=aKNmlhwdpKUVOX6WfxZR2MIhf9Xis6Cg");
                responseTask.Wait(); 
                if (responseTask.Result.IsSuccessStatusCode)
                {
                    name = responseTask.Result.Content.ReadAsStringAsync().Result;
                }
                return name;
            }
        }

        public string stat_Committee(string bin, string lang)
        {
            string result = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://stat.gov.kz/api/juridical/counter/api/");
                var responseTask = client.GetAsync("?bin=" + bin + "&lang=" + lang);
                responseTask.Wait();
                if (responseTask.Result.IsSuccessStatusCode)
                {
                    result = responseTask.Result.Content.ReadAsStringAsync().Result;
                }
                return result;
            }
        }

        public string translate(string text, string source, string target)
        {
  
            string name = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://api-free.deepl.com/v2/");
                //var responseTask = client.GetAsync("basic?identifier=150840007789&api-token=aKNmlhwdpKUVOX6WfxZR2MIhf9Xis6Cg"); //110740018327
                var responseTask = client.GetAsync("translate?auth_key=324e45ab-ef56-bf31-1f66-59ba59a92fef:fx&text="+text+"&source_lang="+source+"&target_lang="+target);
                responseTask.Wait();
                if (responseTask.Result.IsSuccessStatusCode)
                {
                    name = responseTask.Result.Content.ReadAsStringAsync().Result;
                }
                return name;
            }
        }

        public string Country(string code, string lang)
        {
            var news = new List<LibModel>();
            string ln = "country_name_ru";
            if (lang.Equals("en")) ln = "country_name_en";
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM countries WHERE country_2a_code = '{code}' LIMIT '{1}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["country_2a_code"].ToString(), display_text = reader[ln].ToString() });
                    }
                    reader.Close();
                }
            }
            return JsonConvert.SerializeObject(news);
        }

        public JsonResult company_status(string code)
        {
            var news = new List<LibModel>();
            
            string query1 = $"SELECT company_status FROM countries WHERE country_2a_code = '{code}' LIMIT '{1}'";
            string status = provider.RunQueryStr(query1);
            news.Add(new LibModel { value = code, display_text = status });
            return Json(news, JsonRequestBehavior.AllowGet);
        }

        public string twh_doctype(string code, string lang)
        {
            
            var news = new List<LibModel>();
            string ln = "country_name_ru";
            if (lang.Equals("en")) ln = "country_name_en";
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM twh_doctypes WHERE code = '{code}' LIMIT 1";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["code"].ToString(), display_text = reader["text_value"].ToString() });
                    }
                    reader.Close();
                }
            }
            return JsonConvert.SerializeObject(news);
        }

        public JsonResult org_type(string code)
        {
            var news = new List<LibModel>();
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM organization_types WHERE org_type = '{code}' LIMIT '1'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["org_type"].ToString(), display_text = reader["org_type_name_ru"].ToString() });
                    }
                    reader.Close();
                }
            }
            return Json(news, JsonRequestBehavior.AllowGet);
        }

        public JsonResult packaging(string code, string lang)
        {
            string ln = "pack_name_ru";
            if (lang.Equals("en")) ln = "pack_name_en";
            var news = new List<LibModel>();
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM packagin WHERE pack_code ~ '{code}' LIMIT '1'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["pack_code"].ToString(), display_text = reader[ln].ToString() });
                    }
                    reader.Close();
                }
            }
            return Json(news, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Oked(string code, string lang)
        {
            var news = new List<LibModel>();
            string ln = "oked_name_ru";
            if (lang.Equals("en")) ln = "oked_name_en";
            if (lang.Equals("kz")) ln = "oked_name_kz";
            if (lang.Equals("cn")) ln = "oked_name_cn";
            lock (provider.Locker)
            {
                string query1 = $"SELECT * FROM oked_new WHERE oked_code = '{code}' LIMIT '11'"; 
                var reader = provider.RunQuery(query1);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        news.Add(new LibModel { value = reader["oked_code"].ToString(), display_text = reader[ln].ToString() });
                    }
                    reader.Close();
                }
            }
            return Json(news, JsonRequestBehavior.AllowGet);
        }

    }
}