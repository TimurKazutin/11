﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 11-08-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 8-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Models namespace.
/// </summary>
namespace Lawyers.Web.App.Models
{
    using Microsoft.AspNet.Identity;
    using System;

    /// <summary>
    /// Class IdentityUser.
    /// </summary>
    public class IdentityUser : IUser
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>The name of the user.</value>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets the password hash.
        /// </summary>
        /// <value>The password hash.</value>
        public string PasswordHash { get; set; }

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>The last name.</value>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the last name in China language.
        /// </summary>
        /// <value>The last name in China language.</value>
        public string LastNameZh { get; set; }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>The first name.</value>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the first name in China language.
        /// </summary>
        /// <value>The first name in China language.</value>
        public string FirstNameZh { get; set; }

        /// <summary>
        /// Gets or sets the name of the middle.
        /// </summary>
        /// <value>The name of the middle.</value>
        public string MiddleName { get; set; }

        /// <summary>
        /// Gets or sets the Person Code.
        /// </summary>
        /// <value>The Person Code.</value>
        public string PersonCode { get; set; }

        /// <summary>
        /// Gets or sets the gender.
        /// </summary>
        /// <value>The gender.</value>
        public string Gender { get; set; }

        /// <summary>
        /// Gets or sets the birthday.
        /// </summary>
        /// <value>The gender.</value>
        public DateTime? Birthday { get; set; }

        /// <summary>
        /// Gets or sets the user roles.
        /// </summary>
        /// <value>The user roles.</value>
        public int UserRoles { get; set; }

        /// <summary>
        /// Gets or sets the residency.
        /// </summary>
        /// <value>The residency.</value>
        public int Residency { get; set; }

        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>The country.</value>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets the phone.
        /// </summary>
        /// <value>The phone.</value>
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="IdentityUser"/> is enable.
        /// </summary>
        /// <value><c>true</c> if enable; otherwise, <c>false</c>.</value>
        public bool Enable { get; set; }

        /// <summary>
        /// Gets or sets the date_registry.
        /// </summary>
        /// <value>The date_registry.</value>
        public DateTime DateRegistry { get; set; }

        /// <summary>
        /// Gets or sets the date_blocked.
        /// </summary>
        /// <value>The date_blocked.</value>
        public DateTime? DateBlocked { get; set; }

        /// <summary>
        /// Gets or sets the date_blocked.
        /// </summary>
        /// <value>The date_blocked.</value>
        public int PersonId { get; set; }
    }
}