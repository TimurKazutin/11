﻿
namespace Lawyers.Common.Metadata
{
	using System.Collections.Generic;
	using System.Xml.Serialization;
	using Model;

	public class MetaDataSource : DataSource
	{
		[XmlArray]
		[XmlArrayItem("Table")]
		public List<MetaTable> Tables { get; set; }

		public MetaDataSource()
		{
			Tables = new List<MetaTable>();
		}
	}
}
