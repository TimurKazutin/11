﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Lawyers.Web.App.Resources;


namespace Lawyers.Web.App.Models
{
    public class ReportsViewModels
    {
        public List<ReportModel> Reports { get; set; }
    }

    public class ReportModel
    {
        public string ReportId { get; set; }
        public string ReportNumber { get; set; }
        public string ReportName { get; set; }
        public DateTime BeginDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime SendDate { get; set; }
        public DateTime ConfirmDate { get; set; }
        public string lawyerFIO { get; set; }
        public int ReportStatus { get; set; }
        public string Comment { get; set; }
        public string ReportPeriod { get; set; }
        public string ReportPeriodName { get; set; }
        public string CollegiumName { get; set; }
    }

    public class Lawyer
    {
        public string LawyerId { get; set; }
        public string LawyerName { get; set; }
        public string LawyerLicenseCode { get; set; }
        public string LawyerMobilePhone { get; set; }
        public string LawyerPhone { get; set; }
        public string LawyerFax { get; set; }
        public string LawyerUserId { get; set; }
        public List<ReportModel> Reports { get; set; }
        public string LawyerOrgFormaName { get; set; }
        public string FIO { get; set; }
    }

    public class LawyersReportsViewModel
    {
        public List<Lawyer> Lawyers { get; set; }
    }

    public class CollegialReportModel
    {
        public string ReportId { get; set; }
        public string ReportNumber { get; set; }
        public string ReportName { get; set; }
        public DateTime BeginDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime SendDate { get; set; }
        public string lawyerFIO { get; set; }
        public int ReportStatus { get; set; }
        public string Comment { get; set; }

        public List<ReportModel> Reports { get; set; }
    }

    public class CollegialReportDBModel
    {
        public string collegium_name { get; set; }
        public string rep_law_state_colleg_id { get; set; }
        public string subj_law_supplier_id { get; set; }
        public string rep_date_begin { get; set; } 
        public string rep_date_end { get; set; }
        public string rep_period { get; set; }
        public string rep_status { get; set; }
        public string rep_send_date { get; set; }
        public string rep_law_state_aid_id { get; set; }
        public string person_id { get; set; }
        public string chief_id { get; set; }
        public string doc_guid { get; set; }
        public string ECP { get; set; }
        public string comment { get; set; }
        public string rep_law_state_sign { get; set; }
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "ReportNumber", ResourceType = typeof(GlobalStrings))]
        public string rep_number { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_5 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_6 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_7 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_8 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_9 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_10 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_11 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_12 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_13 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_14 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_15 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_16 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_17 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_18 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_19 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_20 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_21 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_1_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_2_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_3_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_4_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_5_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_6_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_7_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_8_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_9_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_10_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_11_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_12_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_13_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_14_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_15_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_16_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_17_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_18_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_19_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_20_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_21_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_22_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_22_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_22_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_22_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_23_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_23_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_23_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_23_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_24_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_24_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_24_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_24_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_25_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_25_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_25_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_25_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_26_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_26_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_26_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_26_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_27_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_27_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_27_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_27_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_28_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_28_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_28_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_28_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_29_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_29_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_29_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_29_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_30_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_30_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_30_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_30_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_31_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_31_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_31_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_31_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_32_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_32_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_32_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_32_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_33_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_33_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_33_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_33_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_34_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_34_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_34_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_34_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_35_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_35_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_35_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_35_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_36_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_36_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_36_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_36_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_37_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_37_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_37_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_37_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_38_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_38_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_38_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_38_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_39_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_39_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_39_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_39_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_40_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_40_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_40_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_40_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_41_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_41_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_41_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_41_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_42_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_42_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_42_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_42_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_43_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_43_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_43_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_43_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_44_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_44_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_44_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_44_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_45_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_45_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_45_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_45_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_46_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_46_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_46_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_46_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_47_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_47_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_47_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_47_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_48_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_48_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_48_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_48_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_49_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_49_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_49_3 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public string rep_row_49_4 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_50_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_50_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_51_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_51_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_52_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_52_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_53_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_53_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_54_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_54_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_55_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_55_2 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_56_1 { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? rep_row_56_2 { get; set; }

        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r2_oral_legal_adv_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r2_oral_legal_adv_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r2_oral_legal_adv_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r2_docs_legal_adv_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r2_docs_legal_adv_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r2_docs_legal_adv_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r2_total { get; set; }

        //[RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        //public int r3_law_legal_docs_count { get; set; }
        //[RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        //public int r3_law_legal_docs_hourses { get; set; }
        //[RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        //public int r3_total { get; set; }

        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r41_law_adv_esp_grave_before_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r41_law_adv_esp_grave_before_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r41_law_adv_esp_grave_before_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r41_law_adv_esp_grave_before_total { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r42_law_adv_grave_before_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r42_law_adv_grave_before_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r42_law_adv_grave_before_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r43_law_adv_not_grave_before_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r43_law_adv_not_grave_before_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r43_law_adv_not_grave_before_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r44_law_adv_esp_grave_court_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r44_law_adv_esp_grave_court_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r44_law_adv_esp_grave_court_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r44_law_adv_esp_grave_court_total { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r45_law_adv_grave_court_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r45_law_adv_grave_court_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r45_law_adv_grave_court_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r46_law_adv_not_grave_court_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r46_law_adv_not_grave_court_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r46_law_adv_not_grave_court_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r61_rep_adv_esp_grave_before_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r61_rep_adv_esp_grave_before_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r61_rep_adv_esp_grave_before_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r61_rep_adv_esp_grave_before_total { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r62_rep_adv_grave_before_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r62_rep_adv_grave_before_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r62_rep_adv_grave_before_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r63_rep_adv_not_grave_before_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r63_rep_adv_not_grave_before_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r63_rep_adv_not_grave_before_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r64_rep_adv_esp_grave_court_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r64_rep_adv_esp_grave_court_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r64_rep_adv_esp_grave_court_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r64_rep_adv_esp_grave_court_total { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r65_rep_adv_grave_court_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r65_rep_adv_grave_court_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r65_rep_adv_grave_court_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r66_rep_adv_not_grave_court_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r66_rep_adv_not_grave_court_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r66_rep_adv_not_grave_court_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r7_law_adm_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r7_law_adm_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r7_law_adm_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r7_law_adm_total { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r8_law_civil_112_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r8_law_civil_112_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r8_law_civil_112_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r8_law_civil_total { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r9_law_civil_325_count { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r9_law_civil_325_hourses { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? r9_law_civil_325_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? total_sum { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? total_docs { get; set; }
        [RegularExpression("^[0-9]*$", ErrorMessage = "Только цифры")]
        public int? total_hours { get; set; }
    }

    public class CollegialReportViewModel
    {
        public List<CollegialReportModel> Reports { get; set; }
    }
}