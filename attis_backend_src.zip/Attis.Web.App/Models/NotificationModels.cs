﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 06-11-2018
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 06-30-2018
// ***********************************************************************
// <copyright file="NotificationModels.cs" company="Baddy Inc.">
//     Copyright ©  2018
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace Lawyers.Web.App.Models
{
    using System;
    using System.Collections.Generic;
    using Enums;

    /// <summary>
    /// Class Notification.
    /// </summary>
    public class NotificationsModel
    {
        public List<Notification> Notifications { get; set; }
    }
    public class Notification
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        public NotificationType Type { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Notification"/> is archived.
        /// </summary>
        /// <value><c>true</c> if archived; otherwise, <c>false</c>.</value>
        public bool Archived { get; set; }

        /// <summary>
        /// Gets or sets the creation date.
        /// </summary>
        /// <value>The creation date.</value>
        public DateTime CreationDate { get; set; }
        
        /// <summary>
        /// Gets or sets the read date.
        /// </summary>
        /// <value>The read date.</value>
        public DateTime? ReadDate { get; set; }

        /// <summary>
        /// Gets or sets the creator identifier.
        /// </summary>
        /// <value>The creator identifier.</value>
        public string CreatorId { get; set; }

        /// <summary>
        /// Gets or sets the recipient identifier.
        /// </summary>
        /// <value>The recipient identifier.</value>
        public string RecipientId { get; set; }

        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>The document identifier.</value>
        public string DocumentId { get; set; }

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets the name of the creator.
        /// </summary>
        /// <value>The name of the creator.</value>
        public string CreatorName { get; set; }

        /// <summary>
        /// Gets or sets the creator title.
        /// </summary>
        /// <value>The creator title.</value>
        public string CreatorTitle { get; set; }

        public string CreatorOrgName { get; set; }

        public string CreatorLicense { get; set; }

        public DateTime? CreatorLicenseDate { get; set; }

        /// <summary>
        /// Gets or sets the collegium.
        /// </summary>
        /// <value>The collegium.</value>
        public string Collegium { get; set; }

        /// <summary>
        /// Gets or sets the creator photo.
        /// </summary>
        /// <value>The creator photo.</value>
        public byte[] CreatorPhoto { get; set; }

        /// <summary>
        /// Gets or sets the object identifier.
        /// </summary>
        /// <value>The object identifier.</value>
        public int? ObjectId { get; set; }
        // Gets or sets Recipient full name
        public string RecipientName { get; internal set; }
    }
}