﻿namespace Lawyers.Web.App
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class AuthorizeAttribute : System.Web.Mvc.AuthorizeAttribute
    {
        protected override void HandleUnauthorizedRequest(System.Web.Mvc.AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Request.IsAuthenticated)
            {
                filterContext.Result = new System.Web.Mvc.HttpStatusCodeResult((int)System.Net.HttpStatusCode.Forbidden);
                //filterContext.Result = new RedirectResult("/#/sign-in");
            }
            else
            {
                //base.HandleUnauthorizedRequest(filterContext);
                filterContext.Result = new RedirectResult("/#/sign-in");
            }
        }

        protected override HttpValidationStatus OnCacheAuthorization(HttpContextBase httpContext)
        {
            return base.OnCacheAuthorization(httpContext);
        }

        public override void OnAuthorization(System.Web.Mvc.AuthorizationContext filterContext)
        {
            base.OnAuthorization(filterContext);

            if(filterContext.HttpContext.User.Identity.IsAuthenticated && filterContext.ActionDescriptor.ActionName == "Login")
            {
                this.HandleUnauthorizedRequest(filterContext);
            }
        }
    }
}