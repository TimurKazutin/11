﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lawyers.Web.App.Models
{
    public class XmlModel
    {
    }

    public class ExportData
    {
        public SignedData SignedData { get; set; }
    }

    public class SignedData
    {
        public Data Data { get; set; }
    }

    public class Data
    {
        public Root Root { get; set; }
    }

    public class Root
    {
        public PersonalData PersonalData { get; set; }
        public MessageInformation MessageInformation { get; set; }
        public References References { get; set; }
        public Participants Participants { get; set; }
    }

    public class PersonalData
    {
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string MiddleName { get; set; }
        public string JobName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string OrganisationCode { get; set; }
        public string OrganisationOPF { get; set; }
        public string Organisation { get; set; }
        public string OrganisationArea { get; set; }
        public string OrganisationCity { get; set; }
        //public string OrganisationDistrict { get; set; }
        public string OrganisationStreet { get; set; }
        public string OrganisationHouse{ get; set; }
        public string OrganisationOffice { get; set; }
        public string OrganisationPostalIndex { get; set; }
        public string IINBIN { get; set; }
        public AdditionalAcData AdditionalAcData { get; set; }
    }

    public class AdditionalAcData
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string DocumentIdentity { get; set; }
        public string SeriesDocIdentity { get; set; }
        public string NumberDocIdentity { get; set; }
        public DateTime? DateIssuance { get; set; }
        public string DocumentIssued { get; set; }
    }
    public class MessageInformation
    {
        public string DocumentType { get; set; }
        public string MessageNumber { get; set; }
        public DateTime LastModifyDate { get; set; }
        public DateTime TransactionDate { get; set; }
        public string ViewOperationId { get; set; }
        public string EknpId { get; set; }
        public string OperationNumber { get; set; }

        public DateTime DocOperationDate { get; set; }
        public string DocOperationNumber { get; set; }
        public string CurrencyCodeId { get; set; }
        public float AmountCurrency { get; set; }
        public float AmountCurrencyTenge { get; set; }
        public string OperationStatusId { get; set; }

        public string ParticipantCount { get; set; }
    }

    public class References
    { 
        public Reference Reference { get; set; }
    }

    public class Reference
    {
        public string ReferenceId { get; set; }
        public string ReferenceOperationNumber { get; set; }
        public DateTime? ReferenceDocOperationDate { get; set; }
        public string ReferenceDocOperationNumber { get; set; }
    }
    public class Participants
    {
        public List<Participant> Participant { get; set; }
    }
    public class Participant
    {
        public string MemberId { get; set; }
        public string ParticipantsView { get; set; }
        public string ParticipantsType { get; set; }
        public string IsClientSubject { get; set; }
        public string Residence { get; set; }
        public string ForeignPerson { get; set; }
        public CorrespondentBank CorrespondentBank { get; set; }
        public string OKED { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public Founders Founders { get; set; }
        public AdditionalPersonInfo AdditionalPersonInfo { get; set; }
    }
    public class AdditionalPersonInfo
    {
        public AdditionalInformationAc AdditionalInformationAc { get; set; }
    }
    public class AdditionalInformationAc
    {
        public string URAddress { get; set; }
        public string ACAddress { get; set; }
        public FIO FIO { get; set; }
        public string PlaceBirth { get; set; }
        public DateTime? DateBirth { get; set; }
        public string DocumentIdentity { get; set; }
        public string SeriesDocIdentity { get; set; }
        public string NumberDocIdentity { get; set; }
        public DateTime? DocumentIssued { get; set; }
        public string DateIssuance { get; set; }
    }

    public class FIO
    {
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string MiddleName { get; set; }
        public int IsFioNotSetup { get; set; }
    }
    public class Founder
    {
        public string FounderType { get; set; }
        public string FounderOPF { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string MiddleName { get; set; }
        public string Residence { get; set; }
    }
    public class CorrespondentBank 
    {
        public string AccountNumber { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public BankAddress BankAddress { get; set; }

    }
    public class BankAddress
    {
        public string BankCountry { get; set; }
        public string BankCity { get; set; }
        public string BankOffshoreAddr { get; set; }
    }


    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.iata.org/")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://www.iata.org/", IsNullable = false)]
    public partial class Invoice
    {

        private InvoiceMessageHeaderDocument messageHeaderDocumentField;

        private InvoiceHeaderExchangedDocument headerExchangedDocumentField;

        private InvoiceSpecifiedLogisticsConsignment specifiedLogisticsConsignmentField;

        /// <remarks/>
        public InvoiceMessageHeaderDocument MessageHeaderDocument
        {
            get
            {
                return this.messageHeaderDocumentField;
            }
            set
            {
                this.messageHeaderDocumentField = value;
            }
        }

        /// <remarks/>
        public InvoiceHeaderExchangedDocument HeaderExchangedDocument
        {
            get
            {
                return this.headerExchangedDocumentField;
            }
            set
            {
                this.headerExchangedDocumentField = value;
            }
        }

        /// <remarks/>
        public InvoiceSpecifiedLogisticsConsignment SpecifiedLogisticsConsignment
        {
            get
            {
                return this.specifiedLogisticsConsignmentField;
            }
            set
            {
                this.specifiedLogisticsConsignmentField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.iata.org/")]
    public partial class InvoiceMessageHeaderDocument
    {

        private string idField;

        private string nameField;

        private string typeCodeField;

        private System.DateTime issueDateTimeField;

        private string purposeCodeField;

        private decimal versionIDField;

        private string conversationIDField;

        private SenderParty senderPartyField;

        private RecipientParty recipientPartyField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public System.DateTime IssueDateTime
        {
            get
            {
                return this.issueDateTimeField;
            }
            set
            {
                this.issueDateTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string PurposeCode
        {
            get
            {
                return this.purposeCodeField;
            }
            set
            {
                this.purposeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public decimal VersionID
        {
            get
            {
                return this.versionIDField;
            }
            set
            {
                this.versionIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string ConversationID
        {
            get
            {
                return this.conversationIDField;
            }
            set
            {
                this.conversationIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public SenderParty SenderParty
        {
            get
            {
                return this.senderPartyField;
            }
            set
            {
                this.senderPartyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public RecipientParty RecipientParty
        {
            get
            {
                return this.recipientPartyField;
            }
            set
            {
                this.recipientPartyField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2", IsNullable = false)]
    public partial class SenderParty
    {

        private SenderPartyPrimaryID primaryIDField;

        /// <remarks/>
        public SenderPartyPrimaryID PrimaryID
        {
            get
            {
                return this.primaryIDField;
            }
            set
            {
                this.primaryIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class SenderPartyPrimaryID
    {

        private byte schemeIDField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte schemeID
        {
            get
            {
                return this.schemeIDField;
            }
            set
            {
                this.schemeIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2", IsNullable = false)]
    public partial class RecipientParty
    {

        private RecipientPartyPrimaryID primaryIDField;

        /// <remarks/>
        public RecipientPartyPrimaryID PrimaryID
        {
            get
            {
                return this.primaryIDField;
            }
            set
            {
                this.primaryIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class RecipientPartyPrimaryID
    {

        private byte schemeIDField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte schemeID
        {
            get
            {
                return this.schemeIDField;
            }
            set
            {
                this.schemeIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.iata.org/")]
    public partial class InvoiceHeaderExchangedDocument
    {

        private string idField;

        private string typeCodeField;

        private System.DateTime issueDateTimeField;

        private bool copyIndicatorField;

        private string customsIDField;

        private string headerInformationField;

        private string summaryInformationField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public System.DateTime IssueDateTime
        {
            get
            {
                return this.issueDateTimeField;
            }
            set
            {
                this.issueDateTimeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public bool CopyIndicator
        {
            get
            {
                return this.copyIndicatorField;
            }
            set
            {
                this.copyIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string CustomsID
        {
            get
            {
                return this.customsIDField;
            }
            set
            {
                this.customsIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string HeaderInformation
        {
            get
            {
                return this.headerInformationField;
            }
            set
            {
                this.headerInformationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public string SummaryInformation
        {
            get
            {
                return this.summaryInformationField;
            }
            set
            {
                this.summaryInformationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://www.iata.org/")]
    public partial class InvoiceSpecifiedLogisticsConsignment
    {

        private IncludedSupplyChainConsignment includedSupplyChainConsignmentField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
        public IncludedSupplyChainConsignment IncludedSupplyChainConsignment
        {
            get
            {
                return this.includedSupplyChainConsignmentField;
            }
            set
            {
                this.includedSupplyChainConsignmentField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2", IsNullable = false)]
    public partial class IncludedSupplyChainConsignment
    {

        private IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovement borderCrossingLogisticsTransportMovementField;

        private IncludedSupplyChainConsignmentApplicableLogisticsServiceCharge applicableLogisticsServiceChargeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransaction relatedSupplyChainTradeTransactionField;

        private IncludedSupplyChainConsignmentAssociatedTradeParty associatedTradePartyField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovement BorderCrossingLogisticsTransportMovement
        {
            get
            {
                return this.borderCrossingLogisticsTransportMovementField;
            }
            set
            {
                this.borderCrossingLogisticsTransportMovementField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentApplicableLogisticsServiceCharge ApplicableLogisticsServiceCharge
        {
            get
            {
                return this.applicableLogisticsServiceChargeField;
            }
            set
            {
                this.applicableLogisticsServiceChargeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransaction RelatedSupplyChainTradeTransaction
        {
            get
            {
                return this.relatedSupplyChainTradeTransactionField;
            }
            set
            {
                this.relatedSupplyChainTradeTransactionField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradeParty AssociatedTradeParty
        {
            get
            {
                return this.associatedTradePartyField;
            }
            set
            {
                this.associatedTradePartyField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovement
    {

        private string modeCodeField;

        private string modeField;

        private string idField;

        private IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementLoadingTransportEvent loadingTransportEventField;

        private IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEvent unloadingTransportEventField;

        /// <remarks/>
        public string ModeCode
        {
            get
            {
                return this.modeCodeField;
            }
            set
            {
                this.modeCodeField = value;
            }
        }

        /// <remarks/>
        public string Mode
        {
            get
            {
                return this.modeField;
            }
            set
            {
                this.modeField = value;
            }
        }

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementLoadingTransportEvent LoadingTransportEvent
        {
            get
            {
                return this.loadingTransportEventField;
            }
            set
            {
                this.loadingTransportEventField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEvent UnloadingTransportEvent
        {
            get
            {
                return this.unloadingTransportEventField;
            }
            set
            {
                this.unloadingTransportEventField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementLoadingTransportEvent
    {

        private System.DateTime actualOccurrenceDateTimeField;

        private IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementLoadingTransportEventOccurrenceLogisticsLocation occurrenceLogisticsLocationField;

        /// <remarks/>
        public System.DateTime ActualOccurrenceDateTime
        {
            get
            {
                return this.actualOccurrenceDateTimeField;
            }
            set
            {
                this.actualOccurrenceDateTimeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementLoadingTransportEventOccurrenceLogisticsLocation OccurrenceLogisticsLocation
        {
            get
            {
                return this.occurrenceLogisticsLocationField;
            }
            set
            {
                this.occurrenceLogisticsLocationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementLoadingTransportEventOccurrenceLogisticsLocation
    {

        private string idField;

        private string nameField;

        private string typeCodeField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEvent
    {

        private System.DateTime actualOccurrenceDateTimeField;

        private IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEventOccurrenceLogisticsLocation occurrenceLogisticsLocationField;

        /// <remarks/>
        public System.DateTime ActualOccurrenceDateTime
        {
            get
            {
                return this.actualOccurrenceDateTimeField;
            }
            set
            {
                this.actualOccurrenceDateTimeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEventOccurrenceLogisticsLocation OccurrenceLogisticsLocation
        {
            get
            {
                return this.occurrenceLogisticsLocationField;
            }
            set
            {
                this.occurrenceLogisticsLocationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEventOccurrenceLogisticsLocation
    {

        private IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEventOccurrenceLogisticsLocationID idField;

        private string nameField;

        private string typeCodeField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEventOccurrenceLogisticsLocationID ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentBorderCrossingLogisticsTransportMovementUnloadingTransportEventOccurrenceLogisticsLocationID
    {

        private byte schemeAgencyIDField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte schemeAgencyID
        {
            get
            {
                return this.schemeAgencyIDField;
            }
            set
            {
                this.schemeAgencyIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentApplicableLogisticsServiceCharge
    {

        private string idField;

        private string descriptionField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransaction
    {

        private byte lineItemQuantityField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItem includedSupplyChainTradeLineItemField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreement applicableSupplyChainTradeAgreementField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDelivery applicableSupplyChainTradeDeliveryField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlement applicableSupplyChainTradeSettlementField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackage[] specifiedLogisticsPackageField;

        /// <remarks/>
        public byte LineItemQuantity
        {
            get
            {
                return this.lineItemQuantityField;
            }
            set
            {
                this.lineItemQuantityField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItem IncludedSupplyChainTradeLineItem
        {
            get
            {
                return this.includedSupplyChainTradeLineItemField;
            }
            set
            {
                this.includedSupplyChainTradeLineItemField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreement ApplicableSupplyChainTradeAgreement
        {
            get
            {
                return this.applicableSupplyChainTradeAgreementField;
            }
            set
            {
                this.applicableSupplyChainTradeAgreementField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDelivery ApplicableSupplyChainTradeDelivery
        {
            get
            {
                return this.applicableSupplyChainTradeDeliveryField;
            }
            set
            {
                this.applicableSupplyChainTradeDeliveryField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlement ApplicableSupplyChainTradeSettlement
        {
            get
            {
                return this.applicableSupplyChainTradeSettlementField;
            }
            set
            {
                this.applicableSupplyChainTradeSettlementField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SpecifiedLogisticsPackage")]
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackage[] SpecifiedLogisticsPackage
        {
            get
            {
                return this.specifiedLogisticsPackageField;
            }
            set
            {
                this.specifiedLogisticsPackageField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItem
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocument associatedDocumentLineDocumentField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreement specifiedSupplyChainTradeAgreementField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDelivery specifiedSupplyChainTradeDeliveryField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlement specifiedSupplyChainTradeSettlementField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProduct specifiedTradeProductField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocument AssociatedDocumentLineDocument
        {
            get
            {
                return this.associatedDocumentLineDocumentField;
            }
            set
            {
                this.associatedDocumentLineDocumentField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreement SpecifiedSupplyChainTradeAgreement
        {
            get
            {
                return this.specifiedSupplyChainTradeAgreementField;
            }
            set
            {
                this.specifiedSupplyChainTradeAgreementField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDelivery SpecifiedSupplyChainTradeDelivery
        {
            get
            {
                return this.specifiedSupplyChainTradeDeliveryField;
            }
            set
            {
                this.specifiedSupplyChainTradeDeliveryField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlement SpecifiedSupplyChainTradeSettlement
        {
            get
            {
                return this.specifiedSupplyChainTradeSettlementField;
            }
            set
            {
                this.specifiedSupplyChainTradeSettlementField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProduct SpecifiedTradeProduct
        {
            get
            {
                return this.specifiedTradeProductField;
            }
            set
            {
                this.specifiedTradeProductField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocument
    {

        private string lineIDField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocumentIncludedNote includedNoteField;

        /// <remarks/>
        public string LineID
        {
            get
            {
                return this.lineIDField;
            }
            set
            {
                this.lineIDField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocumentIncludedNote IncludedNote
        {
            get
            {
                return this.includedNoteField;
            }
            set
            {
                this.includedNoteField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocumentIncludedNote
    {

        private string contentField;

        /// <remarks/>
        public string Content
        {
            get
            {
                return this.contentField;
            }
            set
            {
                this.contentField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreement
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementAdditionalReferencedDocument additionalReferencedDocumentField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePrice[] netPriceProductTradePriceField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementAdditionalReferencedDocument AdditionalReferencedDocument
        {
            get
            {
                return this.additionalReferencedDocumentField;
            }
            set
            {
                this.additionalReferencedDocumentField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePrice[] NetPriceProductTradePrice
        {
            get
            {
                return this.netPriceProductTradePriceField;
            }
            set
            {
                this.netPriceProductTradePriceField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementAdditionalReferencedDocument
    {

        private string issuerAssignedIDField;

        private System.DateTime issueDateTimeField;

        private string typeCodeField;

        private string nameField;

        private string itemIdentificationIDField;

        /// <remarks/>
        public string IssuerAssignedID
        {
            get
            {
                return this.issuerAssignedIDField;
            }
            set
            {
                this.issuerAssignedIDField = value;
            }
        }

        /// <remarks/>
        public System.DateTime IssueDateTime
        {
            get
            {
                return this.issueDateTimeField;
            }
            set
            {
                this.issueDateTimeField = value;
            }
        }

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public string ItemIdentificationID
        {
            get
            {
                return this.itemIdentificationIDField;
            }
            set
            {
                this.itemIdentificationIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePrice
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceChargeAmount chargeAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceBasisQuantity basisQuantityField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceChargeAmount ChargeAmount
        {
            get
            {
                return this.chargeAmountField;
            }
            set
            {
                this.chargeAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceBasisQuantity BasisQuantity
        {
            get
            {
                return this.basisQuantityField;
            }
            set
            {
                this.basisQuantityField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceChargeAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public float Value { get; set; }

    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeAgreementNetPriceProductTradePriceBasisQuantity
    {

        private byte unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public float Value { get; set; }        
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDelivery
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliveryBilledQuantity billedQuantityField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliveryFinalDestinationTradeCountry finalDestinationTradeCountryField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliverySpecifiedLogisticsRegulatedGoods specifiedLogisticsRegulatedGoodsField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliveryBilledQuantity BilledQuantity
        {
            get
            {
                return this.billedQuantityField;
            }
            set
            {
                this.billedQuantityField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliveryFinalDestinationTradeCountry FinalDestinationTradeCountry
        {
            get
            {
                return this.finalDestinationTradeCountryField;
            }
            set
            {
                this.finalDestinationTradeCountryField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliverySpecifiedLogisticsRegulatedGoods SpecifiedLogisticsRegulatedGoods
        {
            get
            {
                return this.specifiedLogisticsRegulatedGoodsField;
            }
            set
            {
                this.specifiedLogisticsRegulatedGoodsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliveryBilledQuantity
    {

        private byte unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliveryFinalDestinationTradeCountry
    {

        private string idField;

        private string nameField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliverySpecifiedLogisticsRegulatedGoods
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliverySpecifiedLogisticsRegulatedGoodsApplicableTransportDangerousGoods applicableTransportDangerousGoodsField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliverySpecifiedLogisticsRegulatedGoodsApplicableTransportDangerousGoods ApplicableTransportDangerousGoods
        {
            get
            {
                return this.applicableTransportDangerousGoodsField;
            }
            set
            {
                this.applicableTransportDangerousGoodsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeDeliverySpecifiedLogisticsRegulatedGoodsApplicableTransportDangerousGoods
    {

        private string uNDGIdentificationCodeField;

        /// <remarks/>
        public string UNDGIdentificationCode
        {
            get
            {
                return this.uNDGIdentificationCodeField;
            }
            set
            {
                this.uNDGIdentificationCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlement
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTax applicableTradeTaxField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceCharge specifiedTradeAllowanceChargeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation specifiedTradeSettlementMonetarySummationField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTax ApplicableTradeTax
        {
            get
            {
                return this.applicableTradeTaxField;
            }
            set
            {
                this.applicableTradeTaxField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceCharge SpecifiedTradeAllowanceCharge
        {
            get
            {
                return this.specifiedTradeAllowanceChargeField;
            }
            set
            {
                this.specifiedTradeAllowanceChargeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation SpecifiedTradeSettlementMonetarySummation
        {
            get
            {
                return this.specifiedTradeSettlementMonetarySummationField;
            }
            set
            {
                this.specifiedTradeSettlementMonetarySummationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTax
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTaxCalculatedAmount calculatedAmountField;

        private string typeCodeField;

        private byte calculatedRateField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTaxBasisAmount basisAmountField;

        private string categoryCodeField;

        private string exemptionReasonCodeField;

        private string descriptionField;

        private string functionCodeField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTaxCalculatedAmount CalculatedAmount
        {
            get
            {
                return this.calculatedAmountField;
            }
            set
            {
                this.calculatedAmountField = value;
            }
        }

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        public byte CalculatedRate
        {
            get
            {
                return this.calculatedRateField;
            }
            set
            {
                this.calculatedRateField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTaxBasisAmount BasisAmount
        {
            get
            {
                return this.basisAmountField;
            }
            set
            {
                this.basisAmountField = value;
            }
        }

        /// <remarks/>
        public string CategoryCode
        {
            get
            {
                return this.categoryCodeField;
            }
            set
            {
                this.categoryCodeField = value;
            }
        }

        /// <remarks/>
        public string ExemptionReasonCode
        {
            get
            {
                return this.exemptionReasonCodeField;
            }
            set
            {
                this.exemptionReasonCodeField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string FunctionCode
        {
            get
            {
                return this.functionCodeField;
            }
            set
            {
                this.functionCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTaxCalculatedAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementApplicableTradeTaxBasisAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceCharge
    {

        private byte calculationPercentField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeBasisAmount basisAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeActualAmount actualAmountField;

        private string reasonCodeField;

        private string reasonField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeDeductionAmount deductionAmountField;

        /// <remarks/>
        public byte CalculationPercent
        {
            get
            {
                return this.calculationPercentField;
            }
            set
            {
                this.calculationPercentField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeBasisAmount BasisAmount
        {
            get
            {
                return this.basisAmountField;
            }
            set
            {
                this.basisAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeActualAmount ActualAmount
        {
            get
            {
                return this.actualAmountField;
            }
            set
            {
                this.actualAmountField = value;
            }
        }

        /// <remarks/>
        public string ReasonCode
        {
            get
            {
                return this.reasonCodeField;
            }
            set
            {
                this.reasonCodeField = value;
            }
        }

        /// <remarks/>
        public string Reason
        {
            get
            {
                return this.reasonField;
            }
            set
            {
                this.reasonField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeDeductionAmount DeductionAmount
        {
            get
            {
                return this.deductionAmountField;
            }
            set
            {
                this.deductionAmountField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeBasisAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeActualAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeDeductionAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationLineTotalAmount lineTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationAllowanceTotalAmount allowanceTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationTaxTotalAmount taxTotalAmountField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationLineTotalAmount LineTotalAmount
        {
            get
            {
                return this.lineTotalAmountField;
            }
            set
            {
                this.lineTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationAllowanceTotalAmount AllowanceTotalAmount
        {
            get
            {
                return this.allowanceTotalAmountField;
            }
            set
            {
                this.allowanceTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationTaxTotalAmount TaxTotalAmount
        {
            get
            {
                return this.taxTotalAmountField;
            }
            set
            {
                this.taxTotalAmountField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationLineTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public decimal Value { get; set; }        
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationAllowanceTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationTaxTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProduct
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductGlobalID globalIDField;

        private string sellerAssignedIDField;

        private string buyerAssignedIDField;

        private string descriptionField;

        private string globalExtensionIDField;

        private string sellerAssignedExtensionIDField;

        private string buyerAssignedExtensionIDField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductApplicableProductCharacteristic applicableProductCharacteristicField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductDesignatedProductClassification designatedProductClassificationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductOriginTradeCountry originTradeCountryField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductGlobalID GlobalID
        {
            get
            {
                return this.globalIDField;
            }
            set
            {
                this.globalIDField = value;
            }
        }

        /// <remarks/>
        public string SellerAssignedID
        {
            get
            {
                return this.sellerAssignedIDField;
            }
            set
            {
                this.sellerAssignedIDField = value;
            }
        }

        /// <remarks/>
        public string BuyerAssignedID
        {
            get
            {
                return this.buyerAssignedIDField;
            }
            set
            {
                this.buyerAssignedIDField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string GlobalExtensionID
        {
            get
            {
                return this.globalExtensionIDField;
            }
            set
            {
                this.globalExtensionIDField = value;
            }
        }

        /// <remarks/>
        public string SellerAssignedExtensionID
        {
            get
            {
                return this.sellerAssignedExtensionIDField;
            }
            set
            {
                this.sellerAssignedExtensionIDField = value;
            }
        }

        /// <remarks/>
        public string BuyerAssignedExtensionID
        {
            get
            {
                return this.buyerAssignedExtensionIDField;
            }
            set
            {
                this.buyerAssignedExtensionIDField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductApplicableProductCharacteristic ApplicableProductCharacteristic
        {
            get
            {
                return this.applicableProductCharacteristicField;
            }
            set
            {
                this.applicableProductCharacteristicField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductDesignatedProductClassification DesignatedProductClassification
        {
            get
            {
                return this.designatedProductClassificationField;
            }
            set
            {
                this.designatedProductClassificationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductOriginTradeCountry OriginTradeCountry
        {
            get
            {
                return this.originTradeCountryField;
            }
            set
            {
                this.originTradeCountryField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductGlobalID
    {

        private byte schemeAgencyIDField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte schemeAgencyID
        {
            get
            {
                return this.schemeAgencyIDField;
            }
            set
            {
                this.schemeAgencyIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductApplicableProductCharacteristic
    {

        private string typeCodeField;

        private string descriptionField;

        private string valueField;

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductDesignatedProductClassification
    {

        private string systemIDField;

        private string classCodeField;

        /// <remarks/>
        public string SystemID
        {
            get
            {
                return this.systemIDField;
            }
            set
            {
                this.systemIDField = value;
            }
        }

        /// <remarks/>
        public string ClassCode
        {
            get
            {
                return this.classCodeField;
            }
            set
            {
                this.classCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionIncludedSupplyChainTradeLineItemSpecifiedTradeProductOriginTradeCountry
    {

        private string idField;

        private string nameField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreement
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradeParty sellerTradePartyField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradeParty buyerTradePartyField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradeDeliveryTerms applicableTradeDeliveryTermsField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTerms applicableTradePaymentTermsField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradeParty SellerTradeParty
        {
            get
            {
                return this.sellerTradePartyField;
            }
            set
            {
                this.sellerTradePartyField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradeParty BuyerTradeParty
        {
            get
            {
                return this.buyerTradePartyField;
            }
            set
            {
                this.buyerTradePartyField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradeDeliveryTerms ApplicableTradeDeliveryTerms
        {
            get
            {
                return this.applicableTradeDeliveryTermsField;
            }
            set
            {
                this.applicableTradeDeliveryTermsField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTerms ApplicableTradePaymentTerms
        {
            get
            {
                return this.applicableTradePaymentTermsField;
            }
            set
            {
                this.applicableTradePaymentTermsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradeParty
    {

        private string idField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyGlobalID globalIDField;

        private string nameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedLegalOrganization specifiedLegalOrganizationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContact definedTradeContactField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddress postalTradeAddressField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedTaxRegistration specifiedTaxRegistrationField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyGlobalID GlobalID
        {
            get
            {
                return this.globalIDField;
            }
            set
            {
                this.globalIDField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedLegalOrganization SpecifiedLegalOrganization
        {
            get
            {
                return this.specifiedLegalOrganizationField;
            }
            set
            {
                this.specifiedLegalOrganizationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContact DefinedTradeContact
        {
            get
            {
                return this.definedTradeContactField;
            }
            set
            {
                this.definedTradeContactField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddress PostalTradeAddress
        {
            get
            {
                return this.postalTradeAddressField;
            }
            set
            {
                this.postalTradeAddressField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedTaxRegistration SpecifiedTaxRegistration
        {
            get
            {
                return this.specifiedTaxRegistrationField;
            }
            set
            {
                this.specifiedTaxRegistrationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyGlobalID
    {

        private byte schemeAgencyIDField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte schemeAgencyID
        {
            get
            {
                return this.schemeAgencyIDField;
            }
            set
            {
                this.schemeAgencyIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedLegalOrganization
    {

        private string idField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContact
    {

        private string personNameField;

        private string departmentNameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication directTelephoneUniversalCommunicationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactFaxUniversalCommunication faxUniversalCommunicationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactEmailURIUniversalCommunication emailURIUniversalCommunicationField;

        /// <remarks/>
        public string PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
        public string DepartmentName
        {
            get
            {
                return this.departmentNameField;
            }
            set
            {
                this.departmentNameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication DirectTelephoneUniversalCommunication
        {
            get
            {
                return this.directTelephoneUniversalCommunicationField;
            }
            set
            {
                this.directTelephoneUniversalCommunicationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactFaxUniversalCommunication FaxUniversalCommunication
        {
            get
            {
                return this.faxUniversalCommunicationField;
            }
            set
            {
                this.faxUniversalCommunicationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactEmailURIUniversalCommunication EmailURIUniversalCommunication
        {
            get
            {
                return this.emailURIUniversalCommunicationField;
            }
            set
            {
                this.emailURIUniversalCommunicationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication
    {

        private string completeNumberField;

        /// <remarks/>
        public string CompleteNumber
        {
            get
            {
                return this.completeNumberField;
            }
            set
            {
                this.completeNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactFaxUniversalCommunication
    {

        private string completeNumberField;

        /// <remarks/>
        public string CompleteNumber
        {
            get
            {
                return this.completeNumberField;
            }
            set
            {
                this.completeNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyDefinedTradeContactEmailURIUniversalCommunication
    {

        private string uRIIDField;

        /// <remarks/>
        public string URIID
        {
            get
            {
                return this.uRIIDField;
            }
            set
            {
                this.uRIIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddress
    {

        private string idField;

        private string postcodeCodeField;

        private string postOfficeBoxField;

        private string streetNameField;

        private string cityNameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddressCountryIdentificationTradeCountry countryIdentificationTradeCountryField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string PostcodeCode
        {
            get
            {
                return this.postcodeCodeField;
            }
            set
            {
                this.postcodeCodeField = value;
            }
        }

        /// <remarks/>
        public string PostOfficeBox
        {
            get
            {
                return this.postOfficeBoxField;
            }
            set
            {
                this.postOfficeBoxField = value;
            }
        }

        /// <remarks/>
        public string StreetName
        {
            get
            {
                return this.streetNameField;
            }
            set
            {
                this.streetNameField = value;
            }
        }

        /// <remarks/>
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddressCountryIdentificationTradeCountry CountryIdentificationTradeCountry
        {
            get
            {
                return this.countryIdentificationTradeCountryField;
            }
            set
            {
                this.countryIdentificationTradeCountryField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddressCountryIdentificationTradeCountry
    {

        private string idField;

        private string nameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision subordinateTradeCountrySubDivisionField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision SubordinateTradeCountrySubDivision
        {
            get
            {
                return this.subordinateTradeCountrySubDivisionField;
            }
            set
            {
                this.subordinateTradeCountrySubDivisionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision
    {

        private string idField;

        private string nameField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedTaxRegistration
    {

        private string idField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax associatedRegisteredTaxField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax AssociatedRegisteredTax
        {
            get
            {
                return this.associatedRegisteredTaxField;
            }
            set
            {
                this.associatedRegisteredTaxField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementSellerTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax
    {

        private string typeCodeField;

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradeParty
    {

        private string idField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyGlobalID globalIDField;

        private string nameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedLegalOrganization specifiedLegalOrganizationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContact definedTradeContactField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddress postalTradeAddressField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedTaxRegistration specifiedTaxRegistrationField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyGlobalID GlobalID
        {
            get
            {
                return this.globalIDField;
            }
            set
            {
                this.globalIDField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedLegalOrganization SpecifiedLegalOrganization
        {
            get
            {
                return this.specifiedLegalOrganizationField;
            }
            set
            {
                this.specifiedLegalOrganizationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContact DefinedTradeContact
        {
            get
            {
                return this.definedTradeContactField;
            }
            set
            {
                this.definedTradeContactField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddress PostalTradeAddress
        {
            get
            {
                return this.postalTradeAddressField;
            }
            set
            {
                this.postalTradeAddressField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedTaxRegistration SpecifiedTaxRegistration
        {
            get
            {
                return this.specifiedTaxRegistrationField;
            }
            set
            {
                this.specifiedTaxRegistrationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyGlobalID
    {

        private byte schemeAgencyIDField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte schemeAgencyID
        {
            get
            {
                return this.schemeAgencyIDField;
            }
            set
            {
                this.schemeAgencyIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedLegalOrganization
    {

        private string idField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContact
    {

        private string personNameField;

        private string departmentNameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication directTelephoneUniversalCommunicationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactFaxUniversalCommunication faxUniversalCommunicationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactEmailURIUniversalCommunication emailURIUniversalCommunicationField;

        /// <remarks/>
        public string PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
        public string DepartmentName
        {
            get
            {
                return this.departmentNameField;
            }
            set
            {
                this.departmentNameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication DirectTelephoneUniversalCommunication
        {
            get
            {
                return this.directTelephoneUniversalCommunicationField;
            }
            set
            {
                this.directTelephoneUniversalCommunicationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactFaxUniversalCommunication FaxUniversalCommunication
        {
            get
            {
                return this.faxUniversalCommunicationField;
            }
            set
            {
                this.faxUniversalCommunicationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactEmailURIUniversalCommunication EmailURIUniversalCommunication
        {
            get
            {
                return this.emailURIUniversalCommunicationField;
            }
            set
            {
                this.emailURIUniversalCommunicationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication
    {

        private string completeNumberField;

        /// <remarks/>
        public string CompleteNumber
        {
            get
            {
                return this.completeNumberField;
            }
            set
            {
                this.completeNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactFaxUniversalCommunication
    {

        private string completeNumberField;

        /// <remarks/>
        public string CompleteNumber
        {
            get
            {
                return this.completeNumberField;
            }
            set
            {
                this.completeNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyDefinedTradeContactEmailURIUniversalCommunication
    {

        private string uRIIDField;

        /// <remarks/>
        public string URIID
        {
            get
            {
                return this.uRIIDField;
            }
            set
            {
                this.uRIIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddress
    {

        private string idField;

        private string postcodeCodeField;

        private string postOfficeBoxField;

        private string streetNameField;

        private string cityNameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddressCountryIdentificationTradeCountry countryIdentificationTradeCountryField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string PostcodeCode
        {
            get
            {
                return this.postcodeCodeField;
            }
            set
            {
                this.postcodeCodeField = value;
            }
        }

        /// <remarks/>
        public string PostOfficeBox
        {
            get
            {
                return this.postOfficeBoxField;
            }
            set
            {
                this.postOfficeBoxField = value;
            }
        }

        /// <remarks/>
        public string StreetName
        {
            get
            {
                return this.streetNameField;
            }
            set
            {
                this.streetNameField = value;
            }
        }

        /// <remarks/>
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddressCountryIdentificationTradeCountry CountryIdentificationTradeCountry
        {
            get
            {
                return this.countryIdentificationTradeCountryField;
            }
            set
            {
                this.countryIdentificationTradeCountryField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddressCountryIdentificationTradeCountry
    {

        private string idField;

        private string nameField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision subordinateTradeCountrySubDivisionField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision SubordinateTradeCountrySubDivision
        {
            get
            {
                return this.subordinateTradeCountrySubDivisionField;
            }
            set
            {
                this.subordinateTradeCountrySubDivisionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision
    {

        private string idField;

        private string nameField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedTaxRegistration
    {

        private string idField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax associatedRegisteredTaxField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax AssociatedRegisteredTax
        {
            get
            {
                return this.associatedRegisteredTaxField;
            }
            set
            {
                this.associatedRegisteredTaxField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementBuyerTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax
    {

        private string typeCodeField;

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradeDeliveryTerms
    {

        private string deliveryTypeCodeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradeDeliveryTermsRelevantTradeLocation relevantTradeLocationField;

        /// <remarks/>
        public string DeliveryTypeCode
        {
            get
            {
                return this.deliveryTypeCodeField;
            }
            set
            {
                this.deliveryTypeCodeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradeDeliveryTermsRelevantTradeLocation RelevantTradeLocation
        {
            get
            {
                return this.relevantTradeLocationField;
            }
            set
            {
                this.relevantTradeLocationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradeDeliveryTermsRelevantTradeLocation
    {

        private string idField;

        private string nameField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTerms
    {

        private string idField;

        private string descriptionField;

        private System.DateTime dueDateDateTimeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTermsApplicableTradePaymentDiscountTerms applicableTradePaymentDiscountTermsField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public System.DateTime DueDateDateTime
        {
            get
            {
                return this.dueDateDateTimeField;
            }
            set
            {
                this.dueDateDateTimeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTermsApplicableTradePaymentDiscountTerms ApplicableTradePaymentDiscountTerms
        {
            get
            {
                return this.applicableTradePaymentDiscountTermsField;
            }
            set
            {
                this.applicableTradePaymentDiscountTermsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTermsApplicableTradePaymentDiscountTerms
    {

        private System.DateTime basisDateTimeField;

        private byte basisPeriodMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTermsApplicableTradePaymentDiscountTermsBasisAmount basisAmountField;

        private byte calculationPercentField;

        /// <remarks/>
        public System.DateTime BasisDateTime
        {
            get
            {
                return this.basisDateTimeField;
            }
            set
            {
                this.basisDateTimeField = value;
            }
        }

        /// <remarks/>
        public byte BasisPeriodMeasure
        {
            get
            {
                return this.basisPeriodMeasureField;
            }
            set
            {
                this.basisPeriodMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTermsApplicableTradePaymentDiscountTermsBasisAmount BasisAmount
        {
            get
            {
                return this.basisAmountField;
            }
            set
            {
                this.basisAmountField = value;
            }
        }

        /// <remarks/>
        public byte CalculationPercent
        {
            get
            {
                return this.calculationPercentField;
            }
            set
            {
                this.calculationPercentField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeAgreementApplicableTradePaymentTermsApplicableTradePaymentDiscountTermsBasisAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDelivery
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryNetWeightMeasure netWeightMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryGrossWeightMeasure grossWeightMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryGrossVolumeMeasure grossVolumeMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryPlannedDeliverySupplyChainEvent plannedDeliverySupplyChainEventField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryNetWeightMeasure NetWeightMeasure
        {
            get
            {
                return this.netWeightMeasureField;
            }
            set
            {
                this.netWeightMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryGrossWeightMeasure GrossWeightMeasure
        {
            get
            {
                return this.grossWeightMeasureField;
            }
            set
            {
                this.grossWeightMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryGrossVolumeMeasure GrossVolumeMeasure
        {
            get
            {
                return this.grossVolumeMeasureField;
            }
            set
            {
                this.grossVolumeMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryPlannedDeliverySupplyChainEvent PlannedDeliverySupplyChainEvent
        {
            get
            {
                return this.plannedDeliverySupplyChainEventField;
            }
            set
            {
                this.plannedDeliverySupplyChainEventField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryNetWeightMeasure
    {

        private byte unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryGrossWeightMeasure
    {

        private byte unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryGrossVolumeMeasure
    {

        private byte unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeDeliveryPlannedDeliverySupplyChainEvent
    {

        private System.DateTime occurrenceDateTimeField;

        /// <remarks/>
        public System.DateTime OccurrenceDateTime
        {
            get
            {
                return this.occurrenceDateTimeField;
            }
            set
            {
                this.occurrenceDateTimeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlement
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementInvoiceApplicableTradeCurrencyExchange invoiceApplicableTradeCurrencyExchangeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeans specifiedTradeSettlementPaymentMeansField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTax applicableTradeTaxField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementBillingSpecifiedPeriod billingSpecifiedPeriodField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceCharge specifiedTradeAllowanceChargeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedLogisticsServiceCharge specifiedLogisticsServiceChargeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation specifiedTradeSettlementMonetarySummationField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementInvoiceApplicableTradeCurrencyExchange InvoiceApplicableTradeCurrencyExchange
        {
            get
            {
                return this.invoiceApplicableTradeCurrencyExchangeField;
            }
            set
            {
                this.invoiceApplicableTradeCurrencyExchangeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeans SpecifiedTradeSettlementPaymentMeans
        {
            get
            {
                return this.specifiedTradeSettlementPaymentMeansField;
            }
            set
            {
                this.specifiedTradeSettlementPaymentMeansField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTax ApplicableTradeTax
        {
            get
            {
                return this.applicableTradeTaxField;
            }
            set
            {
                this.applicableTradeTaxField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementBillingSpecifiedPeriod BillingSpecifiedPeriod
        {
            get
            {
                return this.billingSpecifiedPeriodField;
            }
            set
            {
                this.billingSpecifiedPeriodField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceCharge SpecifiedTradeAllowanceCharge
        {
            get
            {
                return this.specifiedTradeAllowanceChargeField;
            }
            set
            {
                this.specifiedTradeAllowanceChargeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedLogisticsServiceCharge SpecifiedLogisticsServiceCharge
        {
            get
            {
                return this.specifiedLogisticsServiceChargeField;
            }
            set
            {
                this.specifiedLogisticsServiceChargeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation SpecifiedTradeSettlementMonetarySummation
        {
            get
            {
                return this.specifiedTradeSettlementMonetarySummationField;
            }
            set
            {
                this.specifiedTradeSettlementMonetarySummationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementInvoiceApplicableTradeCurrencyExchange
    {

        private string sourceCurrencyCodeField;

        private string targetCurrencyCodeField;

        private byte conversionRateField;

        private System.DateTime conversionRateDateTimeField;

        /// <remarks/>
        public string SourceCurrencyCode
        {
            get
            {
                return this.sourceCurrencyCodeField;
            }
            set
            {
                this.sourceCurrencyCodeField = value;
            }
        }

        /// <remarks/>
        public string TargetCurrencyCode
        {
            get
            {
                return this.targetCurrencyCodeField;
            }
            set
            {
                this.targetCurrencyCodeField = value;
            }
        }

        /// <remarks/>
        public byte ConversionRate
        {
            get
            {
                return this.conversionRateField;
            }
            set
            {
                this.conversionRateField = value;
            }
        }

        /// <remarks/>
        public System.DateTime ConversionRateDateTime
        {
            get
            {
                return this.conversionRateDateTimeField;
            }
            set
            {
                this.conversionRateDateTimeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeans
    {

        private string typeCodeField;

        private string typeField;

        private string informationField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeePartyCreditorFinancialAccount payeePartyCreditorFinancialAccountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeeSpecifiedCreditorFinancialInstitution payeeSpecifiedCreditorFinancialInstitutionField;

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        public string Type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        public string Information
        {
            get
            {
                return this.informationField;
            }
            set
            {
                this.informationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeePartyCreditorFinancialAccount PayeePartyCreditorFinancialAccount
        {
            get
            {
                return this.payeePartyCreditorFinancialAccountField;
            }
            set
            {
                this.payeePartyCreditorFinancialAccountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeeSpecifiedCreditorFinancialInstitution PayeeSpecifiedCreditorFinancialInstitution
        {
            get
            {
                return this.payeeSpecifiedCreditorFinancialInstitutionField;
            }
            set
            {
                this.payeeSpecifiedCreditorFinancialInstitutionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeePartyCreditorFinancialAccount
    {

        private string iBANIDField;

        private string bBANIDField;

        private string accountNameField;

        /// <remarks/>
        public string IBANID
        {
            get
            {
                return this.iBANIDField;
            }
            set
            {
                this.iBANIDField = value;
            }
        }

        /// <remarks/>
        public string BBANID
        {
            get
            {
                return this.bBANIDField;
            }
            set
            {
                this.bBANIDField = value;
            }
        }

        /// <remarks/>
        public string AccountName
        {
            get
            {
                return this.accountNameField;
            }
            set
            {
                this.accountNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeeSpecifiedCreditorFinancialInstitution
    {

        private string bICIDField;

        private string nameField;

        private string sortCodeIDField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeeSpecifiedCreditorFinancialInstitutionLocationFinancialInstitutionAddress locationFinancialInstitutionAddressField;

        /// <remarks/>
        public string BICID
        {
            get
            {
                return this.bICIDField;
            }
            set
            {
                this.bICIDField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public string SortCodeID
        {
            get
            {
                return this.sortCodeIDField;
            }
            set
            {
                this.sortCodeIDField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeeSpecifiedCreditorFinancialInstitutionLocationFinancialInstitutionAddress LocationFinancialInstitutionAddress
        {
            get
            {
                return this.locationFinancialInstitutionAddressField;
            }
            set
            {
                this.locationFinancialInstitutionAddressField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementPaymentMeansPayeeSpecifiedCreditorFinancialInstitutionLocationFinancialInstitutionAddress
    {

        private string postcodeCodeField;

        private string streetNameField;

        private string cityNameField;

        private string countrySubDivisionIDField;

        private string countryIDField;

        private string departmentNameField;

        private string postOfficeBoxField;

        private string cityIDField;

        private string countrySubDivisionNameField;

        private string countryNameField;

        /// <remarks/>
        public string PostcodeCode
        {
            get
            {
                return this.postcodeCodeField;
            }
            set
            {
                this.postcodeCodeField = value;
            }
        }

        /// <remarks/>
        public string StreetName
        {
            get
            {
                return this.streetNameField;
            }
            set
            {
                this.streetNameField = value;
            }
        }

        /// <remarks/>
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        public string CountrySubDivisionID
        {
            get
            {
                return this.countrySubDivisionIDField;
            }
            set
            {
                this.countrySubDivisionIDField = value;
            }
        }

        /// <remarks/>
        public string CountryID
        {
            get
            {
                return this.countryIDField;
            }
            set
            {
                this.countryIDField = value;
            }
        }

        /// <remarks/>
        public string DepartmentName
        {
            get
            {
                return this.departmentNameField;
            }
            set
            {
                this.departmentNameField = value;
            }
        }

        /// <remarks/>
        public string PostOfficeBox
        {
            get
            {
                return this.postOfficeBoxField;
            }
            set
            {
                this.postOfficeBoxField = value;
            }
        }

        /// <remarks/>
        public string CityID
        {
            get
            {
                return this.cityIDField;
            }
            set
            {
                this.cityIDField = value;
            }
        }

        /// <remarks/>
        public string CountrySubDivisionName
        {
            get
            {
                return this.countrySubDivisionNameField;
            }
            set
            {
                this.countrySubDivisionNameField = value;
            }
        }

        /// <remarks/>
        public string CountryName
        {
            get
            {
                return this.countryNameField;
            }
            set
            {
                this.countryNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTax
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTaxCalculatedAmount calculatedAmountField;

        private string typeCodeField;

        private byte calculatedRateField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTaxBasisAmount basisAmountField;

        private string categoryCodeField;

        private string exemptionReasonCodeField;

        private string descriptionField;

        private string functionCodeField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTaxCalculatedAmount CalculatedAmount
        {
            get
            {
                return this.calculatedAmountField;
            }
            set
            {
                this.calculatedAmountField = value;
            }
        }

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        public byte CalculatedRate
        {
            get
            {
                return this.calculatedRateField;
            }
            set
            {
                this.calculatedRateField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTaxBasisAmount BasisAmount
        {
            get
            {
                return this.basisAmountField;
            }
            set
            {
                this.basisAmountField = value;
            }
        }

        /// <remarks/>
        public string CategoryCode
        {
            get
            {
                return this.categoryCodeField;
            }
            set
            {
                this.categoryCodeField = value;
            }
        }

        /// <remarks/>
        public string ExemptionReasonCode
        {
            get
            {
                return this.exemptionReasonCodeField;
            }
            set
            {
                this.exemptionReasonCodeField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string FunctionCode
        {
            get
            {
                return this.functionCodeField;
            }
            set
            {
                this.functionCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTaxCalculatedAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementApplicableTradeTaxBasisAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementBillingSpecifiedPeriod
    {

        private System.DateTime startDateTimeField;

        private System.DateTime endDateTimeField;

        /// <remarks/>
        public System.DateTime StartDateTime
        {
            get
            {
                return this.startDateTimeField;
            }
            set
            {
                this.startDateTimeField = value;
            }
        }

        /// <remarks/>
        public System.DateTime EndDateTime
        {
            get
            {
                return this.endDateTimeField;
            }
            set
            {
                this.endDateTimeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceCharge
    {

        private byte calculationPercentField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeBasisAmount basisAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeActualAmount actualAmountField;

        private string reasonCodeField;

        private string reasonField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeDeductionAmount deductionAmountField;

        /// <remarks/>
        public byte CalculationPercent
        {
            get
            {
                return this.calculationPercentField;
            }
            set
            {
                this.calculationPercentField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeBasisAmount BasisAmount
        {
            get
            {
                return this.basisAmountField;
            }
            set
            {
                this.basisAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeActualAmount ActualAmount
        {
            get
            {
                return this.actualAmountField;
            }
            set
            {
                this.actualAmountField = value;
            }
        }

        /// <remarks/>
        public string ReasonCode
        {
            get
            {
                return this.reasonCodeField;
            }
            set
            {
                this.reasonCodeField = value;
            }
        }

        /// <remarks/>
        public string Reason
        {
            get
            {
                return this.reasonField;
            }
            set
            {
                this.reasonField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeDeductionAmount DeductionAmount
        {
            get
            {
                return this.deductionAmountField;
            }
            set
            {
                this.deductionAmountField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeBasisAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeActualAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeAllowanceChargeDeductionAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedLogisticsServiceCharge
    {

        private string idField;

        private byte appliedAmountField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public byte AppliedAmount
        {
            get
            {
                return this.appliedAmountField;
            }
            set
            {
                this.appliedAmountField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummation
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationChargeTotalAmount chargeTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationAllowanceTotalAmount allowanceTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationTaxTotalAmount taxTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationGrandTotalAmount grandTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationPackingChargeTotalAmount packingChargeTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationFreightChargeTotalAmount freightChargeTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationInsuranceChargeTotalAmount insuranceChargeTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationExcludingTaxesLineTotalAmount excludingTaxesLineTotalAmountField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationIncludingTaxesLineTotalAmount includingTaxesLineTotalAmountField;

        private string grandTotalField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationChargeTotalAmount ChargeTotalAmount
        {
            get
            {
                return this.chargeTotalAmountField;
            }
            set
            {
                this.chargeTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationAllowanceTotalAmount AllowanceTotalAmount
        {
            get
            {
                return this.allowanceTotalAmountField;
            }
            set
            {
                this.allowanceTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationTaxTotalAmount TaxTotalAmount
        {
            get
            {
                return this.taxTotalAmountField;
            }
            set
            {
                this.taxTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationGrandTotalAmount GrandTotalAmount
        {
            get
            {
                return this.grandTotalAmountField;
            }
            set
            {
                this.grandTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationPackingChargeTotalAmount PackingChargeTotalAmount
        {
            get
            {
                return this.packingChargeTotalAmountField;
            }
            set
            {
                this.packingChargeTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationFreightChargeTotalAmount FreightChargeTotalAmount
        {
            get
            {
                return this.freightChargeTotalAmountField;
            }
            set
            {
                this.freightChargeTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationInsuranceChargeTotalAmount InsuranceChargeTotalAmount
        {
            get
            {
                return this.insuranceChargeTotalAmountField;
            }
            set
            {
                this.insuranceChargeTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationExcludingTaxesLineTotalAmount ExcludingTaxesLineTotalAmount
        {
            get
            {
                return this.excludingTaxesLineTotalAmountField;
            }
            set
            {
                this.excludingTaxesLineTotalAmountField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationIncludingTaxesLineTotalAmount IncludingTaxesLineTotalAmount
        {
            get
            {
                return this.includingTaxesLineTotalAmountField;
            }
            set
            {
                this.includingTaxesLineTotalAmountField = value;
            }
        }

        /// <remarks/>
        public string GrandTotal
        {
            get
            {
                return this.grandTotalField;
            }
            set
            {
                this.grandTotalField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationChargeTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationAllowanceTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationTaxTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationGrandTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationPackingChargeTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationFreightChargeTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationInsuranceChargeTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationExcludingTaxesLineTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionApplicableSupplyChainTradeSettlementSpecifiedTradeSettlementMonetarySummationIncludingTaxesLineTotalAmount
    {

        private string currencyCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackage
    {

        private byte itemQuantityField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageGrossWeightMeasure grossWeightMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageNetWeightMeasure netWeightMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageGrossVolumeMeasure grossVolumeMeasureField;

        private byte levelCodeField;

        private byte sequenceNumericField;

        private string descriptionField;

        private string seriesStartIDField;

        private string seriesEndIDField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackagePhysicalLogisticsShippingMarks physicalLogisticsShippingMarksField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItem includedSupplyChainTradeLineItemField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimension linearSpatialDimensionField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageUsedSupplyChainPackaging usedSupplyChainPackagingField;

        /// <remarks/>
        public float ItemQuantity { get; set; }


        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageGrossWeightMeasure GrossWeightMeasure
        {
            get
            {
                return this.grossWeightMeasureField;
            }
            set
            {
                this.grossWeightMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageNetWeightMeasure NetWeightMeasure
        {
            get
            {
                return this.netWeightMeasureField;
            }
            set
            {
                this.netWeightMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageGrossVolumeMeasure GrossVolumeMeasure
        {
            get
            {
                return this.grossVolumeMeasureField;
            }
            set
            {
                this.grossVolumeMeasureField = value;
            }
        }

        /// <remarks/>
        public byte LevelCode
        {
            get
            {
                return this.levelCodeField;
            }
            set
            {
                this.levelCodeField = value;
            }
        }

        /// <remarks/>
        public byte SequenceNumeric
        {
            get
            {
                return this.sequenceNumericField;
            }
            set
            {
                this.sequenceNumericField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string SeriesStartID
        {
            get
            {
                return this.seriesStartIDField;
            }
            set
            {
                this.seriesStartIDField = value;
            }
        }

        /// <remarks/>
        public string SeriesEndID
        {
            get
            {
                return this.seriesEndIDField;
            }
            set
            {
                this.seriesEndIDField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackagePhysicalLogisticsShippingMarks PhysicalLogisticsShippingMarks
        {
            get
            {
                return this.physicalLogisticsShippingMarksField;
            }
            set
            {
                this.physicalLogisticsShippingMarksField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItem IncludedSupplyChainTradeLineItem
        {
            get
            {
                return this.includedSupplyChainTradeLineItemField;
            }
            set
            {
                this.includedSupplyChainTradeLineItemField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimension LinearSpatialDimension
        {
            get
            {
                return this.linearSpatialDimensionField;
            }
            set
            {
                this.linearSpatialDimensionField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageUsedSupplyChainPackaging UsedSupplyChainPackaging
        {
            get
            {
                return this.usedSupplyChainPackagingField;
            }
            set
            {
                this.usedSupplyChainPackagingField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageGrossWeightMeasure
    {

        private string unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public float Value { get; set; }

    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageNetWeightMeasure
    {

        private string unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public float Value { get; set; }

    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageGrossVolumeMeasure
    {

        private string unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackagePhysicalLogisticsShippingMarks
    {

        private string markingField;

        private string markingInstructionCodeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackagePhysicalLogisticsShippingMarksBarcodeLogisticsLabel barcodeLogisticsLabelField;

        /// <remarks/>
        public string Marking
        {
            get
            {
                return this.markingField;
            }
            set
            {
                this.markingField = value;
            }
        }

        /// <remarks/>
        public string MarkingInstructionCode
        {
            get
            {
                return this.markingInstructionCodeField;
            }
            set
            {
                this.markingInstructionCodeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackagePhysicalLogisticsShippingMarksBarcodeLogisticsLabel BarcodeLogisticsLabel
        {
            get
            {
                return this.barcodeLogisticsLabelField;
            }
            set
            {
                this.barcodeLogisticsLabelField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackagePhysicalLogisticsShippingMarksBarcodeLogisticsLabel
    {

        private string idField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItem
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocument associatedDocumentLineDocumentField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProduct specifiedTradeProductField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocument AssociatedDocumentLineDocument
        {
            get
            {
                return this.associatedDocumentLineDocumentField;
            }
            set
            {
                this.associatedDocumentLineDocumentField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProduct SpecifiedTradeProduct
        {
            get
            {
                return this.specifiedTradeProductField;
            }
            set
            {
                this.specifiedTradeProductField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemAssociatedDocumentLineDocument
    {

        private string lineIDField;

        /// <remarks/>
        public string LineID
        {
            get
            {
                return this.lineIDField;
            }
            set
            {
                this.lineIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProduct
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProductIndividualTradeProductInstance individualTradeProductInstanceField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProductIndividualTradeProductInstance IndividualTradeProductInstance
        {
            get
            {
                return this.individualTradeProductInstanceField;
            }
            set
            {
                this.individualTradeProductInstanceField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProductIndividualTradeProductInstance
    {

        private string batchIDField;

        private string lotIDField;

        private System.DateTime expiryDateTimeField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProductIndividualTradeProductInstanceProductionSupplyChainEvent productionSupplyChainEventField;

        /// <remarks/>
        public string BatchID
        {
            get
            {
                return this.batchIDField;
            }
            set
            {
                this.batchIDField = value;
            }
        }

        /// <remarks/>
        public string LotID
        {
            get
            {
                return this.lotIDField;
            }
            set
            {
                this.lotIDField = value;
            }
        }

        /// <remarks/>
        public System.DateTime ExpiryDateTime
        {
            get
            {
                return this.expiryDateTimeField;
            }
            set
            {
                this.expiryDateTimeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProductIndividualTradeProductInstanceProductionSupplyChainEvent ProductionSupplyChainEvent
        {
            get
            {
                return this.productionSupplyChainEventField;
            }
            set
            {
                this.productionSupplyChainEventField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageIncludedSupplyChainTradeLineItemSpecifiedTradeProductIndividualTradeProductInstanceProductionSupplyChainEvent
    {

        private System.DateTime occurrenceDateTimeField;

        /// <remarks/>
        public System.DateTime OccurrenceDateTime
        {
            get
            {
                return this.occurrenceDateTimeField;
            }
            set
            {
                this.occurrenceDateTimeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimension
    {

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionWidthMeasure widthMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionLengthMeasure lengthMeasureField;

        private IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionHeightMeasure heightMeasureField;

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionWidthMeasure WidthMeasure
        {
            get
            {
                return this.widthMeasureField;
            }
            set
            {
                this.widthMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionLengthMeasure LengthMeasure
        {
            get
            {
                return this.lengthMeasureField;
            }
            set
            {
                this.lengthMeasureField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionHeightMeasure HeightMeasure
        {
            get
            {
                return this.heightMeasureField;
            }
            set
            {
                this.heightMeasureField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionWidthMeasure
    {

        private string unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionLengthMeasure
    {

        private string unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageLinearSpatialDimensionHeightMeasure
    {

        private string unitCodeField;

        private byte valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string unitCode
        {
            get
            {
                return this.unitCodeField;
            }
            set
            {
                this.unitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public byte Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentRelatedSupplyChainTradeTransactionSpecifiedLogisticsPackageUsedSupplyChainPackaging
    {

        private string typeCodeField;

        private string typeField;

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }

        /// <remarks/>
        public string Type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradeParty
    {

        private string idField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyGlobalID globalIDField;

        private string nameField;

        private string roleCodeField;

        private IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedLegalOrganization specifiedLegalOrganizationField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContact definedTradeContactField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddress postalTradeAddressField;

        private IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedTaxRegistration specifiedTaxRegistrationField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyGlobalID GlobalID
        {
            get
            {
                return this.globalIDField;
            }
            set
            {
                this.globalIDField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public string RoleCode
        {
            get
            {
                return this.roleCodeField;
            }
            set
            {
                this.roleCodeField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedLegalOrganization SpecifiedLegalOrganization
        {
            get
            {
                return this.specifiedLegalOrganizationField;
            }
            set
            {
                this.specifiedLegalOrganizationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContact DefinedTradeContact
        {
            get
            {
                return this.definedTradeContactField;
            }
            set
            {
                this.definedTradeContactField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddress PostalTradeAddress
        {
            get
            {
                return this.postalTradeAddressField;
            }
            set
            {
                this.postalTradeAddressField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedTaxRegistration SpecifiedTaxRegistration
        {
            get
            {
                return this.specifiedTaxRegistrationField;
            }
            set
            {
                this.specifiedTaxRegistrationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyGlobalID
    {

        private byte schemeAgencyIDField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte schemeAgencyID
        {
            get
            {
                return this.schemeAgencyIDField;
            }
            set
            {
                this.schemeAgencyIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedLegalOrganization
    {

        private string idField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContact
    {

        private string personNameField;

        private string departmentNameField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication directTelephoneUniversalCommunicationField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactFaxUniversalCommunication faxUniversalCommunicationField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactEmailURIUniversalCommunication emailURIUniversalCommunicationField;

        /// <remarks/>
        public string PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
        public string DepartmentName
        {
            get
            {
                return this.departmentNameField;
            }
            set
            {
                this.departmentNameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication DirectTelephoneUniversalCommunication
        {
            get
            {
                return this.directTelephoneUniversalCommunicationField;
            }
            set
            {
                this.directTelephoneUniversalCommunicationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactFaxUniversalCommunication FaxUniversalCommunication
        {
            get
            {
                return this.faxUniversalCommunicationField;
            }
            set
            {
                this.faxUniversalCommunicationField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactEmailURIUniversalCommunication EmailURIUniversalCommunication
        {
            get
            {
                return this.emailURIUniversalCommunicationField;
            }
            set
            {
                this.emailURIUniversalCommunicationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactDirectTelephoneUniversalCommunication
    {

        private string completeNumberField;

        /// <remarks/>
        public string CompleteNumber
        {
            get
            {
                return this.completeNumberField;
            }
            set
            {
                this.completeNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactFaxUniversalCommunication
    {

        private string completeNumberField;

        /// <remarks/>
        public string CompleteNumber
        {
            get
            {
                return this.completeNumberField;
            }
            set
            {
                this.completeNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyDefinedTradeContactEmailURIUniversalCommunication
    {

        private string uRIIDField;

        /// <remarks/>
        public string URIID
        {
            get
            {
                return this.uRIIDField;
            }
            set
            {
                this.uRIIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddress
    {

        private string idField;

        private string postcodeCodeField;

        private string postOfficeBoxField;

        private string streetNameField;

        private string cityNameField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddressCountryIdentificationTradeCountry countryIdentificationTradeCountryField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string PostcodeCode
        {
            get
            {
                return this.postcodeCodeField;
            }
            set
            {
                this.postcodeCodeField = value;
            }
        }

        /// <remarks/>
        public string PostOfficeBox
        {
            get
            {
                return this.postOfficeBoxField;
            }
            set
            {
                this.postOfficeBoxField = value;
            }
        }

        /// <remarks/>
        public string StreetName
        {
            get
            {
                return this.streetNameField;
            }
            set
            {
                this.streetNameField = value;
            }
        }

        /// <remarks/>
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddressCountryIdentificationTradeCountry CountryIdentificationTradeCountry
        {
            get
            {
                return this.countryIdentificationTradeCountryField;
            }
            set
            {
                this.countryIdentificationTradeCountryField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddressCountryIdentificationTradeCountry
    {

        private string idField;

        private string nameField;

        private IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision subordinateTradeCountrySubDivisionField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision SubordinateTradeCountrySubDivision
        {
            get
            {
                return this.subordinateTradeCountrySubDivisionField;
            }
            set
            {
                this.subordinateTradeCountrySubDivisionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartyPostalTradeAddressCountryIdentificationTradeCountrySubordinateTradeCountrySubDivision
    {

        private string idField;

        private string nameField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedTaxRegistration
    {

        private string idField;

        private IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax associatedRegisteredTaxField;

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax AssociatedRegisteredTax
        {
            get
            {
                return this.associatedRegisteredTaxField;
            }
            set
            {
                this.associatedRegisteredTaxField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:2")]
    public partial class IncludedSupplyChainConsignmentAssociatedTradePartySpecifiedTaxRegistrationAssociatedRegisteredTax
    {

        private string typeCodeField;

        /// <remarks/>
        public string TypeCode
        {
            get
            {
                return this.typeCodeField;
            }
            set
            {
                this.typeCodeField = value;
            }
        }
    }


}