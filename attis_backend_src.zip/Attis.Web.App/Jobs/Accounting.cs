﻿//using Quartz;
//using System.IO;
//using System.Net;
//using System.Net.Mail;
//using System.Threading.Tasks;
//using System.Xml;

//namespace QuartzApp.Jobs
//{
//    public class Accounting : IJob
//    {
//        public await Task Execute(IJobExecutionContext context)
//        {
//            string = "asdasd";
//        }
//    }
//}