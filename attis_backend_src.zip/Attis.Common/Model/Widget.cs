﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-17-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 05-04-2015
// ***********************************************************************
// <copyright file="Widget.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Controls namespace.
/// </summary>
namespace Lawyers.Common.Model 
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Threading;
    using System.Xml.Serialization;
    using Lawyers.Common.Classes;
    using Lawyers.Common.Enums;
    using Microsoft.AspNet.Identity;

    /// <summary>
    /// Class Widget.
    /// </summary>
    [XmlType]
    public class Widget
    {
        /// <summary>
        /// The data type
        /// </summary>
        [XmlIgnore]
        private Lawyers.Common.Enums.DataType? _dataType;

        /// <summary>
        /// The mandatory
        /// </summary>
        [XmlAttribute(AttributeName = "mandatory")]
        public string _mandatory;

        /// <summary>
        /// The read only
        /// </summary>
        [XmlAttribute(AttributeName = "read_only")]
        public string _readOnly;

        /// <summary>
        /// The visible
        /// </summary>
        [XmlAttribute(AttributeName = "visible")]
        public string _visible;

        /// <summary>
        /// The logged
        /// </summary>
        [XmlAttribute(AttributeName = "logged")]
        public string _logged;

        /// <summary>
        /// The length
        /// </summary>
        [XmlIgnore]
        private int? _length;

        /// <summary>
        /// The relative width in grids
        /// </summary>
        [XmlIgnore]
        private int? _col_width;

        /// <summary>
        /// The width in percents in forms
        /// </summary>
        [XmlIgnore]
        private int? _control_width;

        /// <summary>
        /// The data source identifier
        /// </summary>
        [XmlIgnore]
        private int? _dataSourceID;

        /// <summary>
        /// Gets or sets the children.
        /// </summary>
        /// <value>The children.</value>
        [XmlElement(ElementName = "widget")]
        public List<Widget> Children { get; set; }

        /// <summary>
        /// Gets or sets the primary keys.
        /// </summary>
        /// <value>The primary keys.</value>
        [XmlElement(ElementName = "field_pk")]
        public List<FieldPrimaryKey> PrimaryKeys { get; set; }

        /// <summary>
        /// Gets or sets the foreign keys.
        /// </summary>
        /// <value>The foreign keys.</value>
        [XmlElement(ElementName = "field_fk")]
        public List<FieldForeignKey> ForeignKeys { get; set; }

        /// <summary>
        /// Gets or sets the filters.
        /// </summary>
        /// <value>The filters.</value>
        [XmlElement(ElementName = "filter")]
        public List<FieldFilter> Filters { get; set; }

        /// <summary>
        /// Gets or sets the type of the data.
        /// </summary>
        /// <value>The type of the data.</value>
        [XmlAttribute(AttributeName = "data_type")]
        public Lawyers.Common.Enums.DataType DataType
        {
            get { return this._dataType ?? Lawyers.Common.Enums.DataType.None; }
            set { this._dataType = value; }
        }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        [XmlAttribute(AttributeName = "type")]
        public Lawyers.Common.Enums.WidgetType Type { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="IWidget" /> is mandatory.
        /// </summary>
        /// <value><c>true</c> if mandatory; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool Mandatory
        {
            get { return this._mandatory == "1"; }
            set { this._mandatory = value ? "1" : "0"; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [read only].
        /// </summary>
        /// <value><c>true</c> if [read only]; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool ReadOnly
        {
            get { return this._readOnly == "1"; }
            set { this._readOnly = value ? "1" : "0"; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="IWidget" /> is visible.
        /// </summary>
        /// <value><c>true</c> if visible; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool Visible
        {
            get { return this._visible == "1" || string.IsNullOrEmpty(this._visible); }
            set { this._visible = value ? "1" : "0"; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="IWidget" /> is logged.
        /// </summary>
        /// <value><c>true</c> if visible; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool Logged
        {
            get { return this._logged == "1"; }
            set { this._logged = value ? "1" : "0"; }
        }

        /// <summary>
        /// Gets or sets the length.
        /// </summary>
        /// <value>The length.</value>
        [XmlAttribute(AttributeName = "length")]
        public int Length
        {
            get { return this._length ?? 0; }
            set { this._length = value; }
        }

        /// <summary>
        /// Gets or sets the relative_width.
        /// </summary>
        /// <value>The relative_width.
        /// It is used also for separation of the struct widget on top and bottom. 0 - no separation, 1- top, 2 - bottom, 3 - both 
        /// It is used also for customization of DataGrid. 0 - ordinary, 1 - simple without pagination, filtering, sorting </value>
        [XmlAttribute(AttributeName = "col_width")]
        public int ColumnWidth
        {
            get { return this._col_width ?? 0; }
            set { this._col_width = value; }
        }

        /// <summary>
        /// Gets or sets the control_width.
        /// </summary>
        /// <value>The control width in forms.</value>
        [XmlAttribute(AttributeName = "ctrl_width")]
        public int ControlWidth
        {
            get { return this._control_width ?? 0; }
            set { this._control_width = value; }
        }
       
        /// <summary>
        /// Gets or sets the data source identifier.
        /// </summary>
        /// <value>The data source identifier.</value>
        [XmlAttribute(AttributeName = "datasource_id")]
        public int DataSourceID
        {
            get { return this._dataSourceID ?? 0; }
            set { this._dataSourceID = value; }
        }

        /// <summary>
        /// Gets or sets the caption.
        /// </summary>
        /// <value>The caption.</value>
        public string Caption
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(CaptionRu))
                    return CaptionRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(CaptionKk))
                    return CaptionKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(CaptionEn))
                    return CaptionEn;
                return CaptionRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    CaptionRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    CaptionKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    CaptionEn = value;
                    return;
                }
                CaptionRu = value;
            }
        }

        /// <summary>
        /// Gets or sets the caption en.
        /// </summary>
        /// <value>The caption en.</value>
        [XmlAttribute(AttributeName = "caption_en")]
        public string CaptionEn { get; set; }

        /// <summary>
        /// Kazakh language Caption.
        /// <value>The caption Kazakhstan.</value>
        [XmlAttribute(AttributeName = "caption_kz")]
        public string CaptionKk { get; set; }

        /// <summary>
        /// Chinese language Caption.
        /// <value>The caption Chinese.</value>
        [XmlAttribute(AttributeName = "caption_ru")]
        public string CaptionRu { get; set; }

        /// <summary>
        /// Gets or sets the tool tip.
        /// <value>The tooltip.</value>/// 
        //public string ToolTip { get; set; }
        public string ToolTip
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(ToolTipRu))
                    return ToolTipRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(ToolTipKk))
                    return ToolTipKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(ToolTipEn))
                    return ToolTipEn;
                return ToolTipRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    ToolTipRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    ToolTipKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    ToolTipEn = value;
                    return;
                }
                ToolTipRu = value;
            }
        }
        [XmlAttribute(AttributeName = "tooltip_en")]
        public string ToolTipEn { get; set; }
        [XmlAttribute(AttributeName = "tooltip_kz")]
        public string ToolTipKk { get; set; }
        [XmlAttribute(AttributeName = "tooltip_ru")]
        public string ToolTipRu { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        [XmlAttribute(AttributeName = "code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the default value. For document, it is also used for setting the name of the table for logging of update events.
        /// </summary>
        /// <value>The default value.</value>
        public string DefaultValue
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(DefaultValueRu))
                    return DefaultValueRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(DefaultValueKk))
                    return DefaultValueKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(DefaultValueEn))
                    return DefaultValueEn;
                return DefaultValueRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    DefaultValueRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    DefaultValueKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    DefaultValueEn = value;
                    return;
                }
                DefaultValueRu = value;
            }
        }
        [XmlAttribute(AttributeName = "default_value_en")]
        public string DefaultValueEn { get; set; }
        [XmlAttribute(AttributeName = "default_value_kz")]
        public string DefaultValueKk { get; set; }
        [XmlAttribute(AttributeName = "default_value_ru")]
        public string DefaultValueRu { get; set; }

        /// <summary>
        /// Gets or sets the field.
        /// </summary>
        /// <value>The field.</value>
        public string Field
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(FieldRu))
                    return FieldRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(FieldKk))
                    return FieldKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(FieldEn))
                    return FieldEn;
                return FieldRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    FieldRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    FieldKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    FieldEn = value;
                    return;
                }
                FieldRu = value;
            }
        }
        [XmlAttribute(AttributeName = "field_en")]
        public string FieldEn { get; set; }
        [XmlAttribute(AttributeName = "field_kz")]
        public string FieldKk { get; set; }
        [XmlAttribute(AttributeName = "field_ru")]
        public string FieldRu { get; set; }

        /// <summary>
        /// Gets or sets the field view.
        /// </summary>
        /// <value>The field view.</value>
        //[XmlAttribute(AttributeName = "field_view")] 
        public string FieldView
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(FieldViewRu))
                    return FieldViewRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(FieldViewKk))
                    return FieldViewKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(FieldViewEn))
                    return FieldViewEn;
                return FieldViewRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    FieldViewRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    FieldViewKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    FieldViewEn = value;
                    return;
                }
                FieldViewRu = value;
            }
        }
        [XmlAttribute(AttributeName = "field_view_en")]
        public string FieldViewEn { get; set; }
        [XmlAttribute(AttributeName = "field_view_kz")]
        public string FieldViewKk { get; set; }
        [XmlAttribute(AttributeName = "field_view_ru")]
        public string FieldViewRu { get; set; }

        /// <summary>
        /// Gets or sets the name of the filter field.
        /// </summary>
        /// <value>The name of the filter field.</value>
        [XmlAttribute(AttributeName = "filter_fn")]
        public string FilterFieldName { get; set; }

        /// <summary>
        /// Gets or sets the filter field value.
        /// </summary>
        /// <value>The filter field value.</value>
        [XmlAttribute(AttributeName = "filter_fv")]
        public string FilterFieldValue { get; set; }

        /// <summary>
        /// Gets or sets the key.
        /// </summary>
        /// <value>The key.</value>
        [XmlAttribute(AttributeName = "key")]
        public string Key { get; set; }

        /// <summary>
        /// Gets or sets the mask.
        /// </summary>
        /// <value>The mask.</value>
        [XmlAttribute(AttributeName = "mask")]
        public string Mask { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the name of the table.
        /// </summary>
        /// <value>The name of the table.</value>
        [XmlAttribute(AttributeName = "table")]
        public string TableName { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        [XmlIgnore]
        public virtual object Value { get; set; }

        /// <summary>
        /// Gets the parent.
        /// </summary>
        /// <value>The parent.</value>
        [XmlIgnore]
        public Widget Parent { get; private set; }

        /// <summary>
        /// Widget is displayed as in a form view.
        /// </summary>
        /// <value>is a form view</value>
        [XmlIgnore]
        public bool IsForm { get; set; }

        /// <summary>
        /// Gets or sets the custom editing form of the complex widget (DataGrid or Form).
        /// </summary>
        /// <value>The custom editing form.</value>
        [XmlAttribute(AttributeName = "custom_form")]
        public string CustomForm { get; set; }

        /// <summary>
        /// Gets the type of the MVC.
        /// </summary>
        /// <value>The type of the MVC.</value>
        [XmlIgnore]
        public string MvcType
        {
            get
            {
                string mvctype = string.Empty;
                if (this.Parent != null && this.Parent.Type == WidgetType.TextGroup && (this.Type == WidgetType.Integer || this.Type == WidgetType.Decimal))
                    mvctype = "Edit";
                else
                {
                    switch (this.Type)
                    {
                        case WidgetType.Integer:   // TODO; Check if required
                        case WidgetType.Decimal:
                            mvctype = "Text";
                            break;
                        //case WidgetType.Struct: // TODO; Implement struct
                            //mvctype = "Container";
                            //break;
                        default:
                            mvctype = this.Type.ToString();
                            break;
                    }
                }

                mvctype += "View";
                return mvctype;
            }
        }

        /// <summary>
        /// Gets or sets the items.
        /// </summary>
        /// <value>The items.</value>
        [XmlIgnore]
        public List<KeyValueData> Items { get; set; }

        /// <summary>
        /// Gets or sets the data fields.
        /// </summary>
        /// <value>The data fields.</value>
        [XmlIgnore]
        public List<Field> DataFields { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Widget" /> is checked.
        /// </summary>
        /// <value><c>true</c> if checked; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool Checked { get; set; }

        /// <summary>
        /// Sets the parent.
        /// </summary>
        /// <param name="parent">The parent.</param>
        public void SetParent(Widget parent)
        {
            this.Parent = parent;

            foreach (Widget child in this.Children)
            {
                child.SetParent(this);
            }
        }

        /// <summary>
        /// Gets the checks.
        /// </summary>
        /// <value>The checks.</value>
        [XmlIgnore]
        public List<Check> LocalChecks { get; private set; }

        /// <summary>
        /// Sets the checks.
        /// </summary>
        /// <param name="document">The document.</param>
        public void SetChecks(Document document)
        {
            if (document.Checks != null && document.Checks.Count > 0)
            {
                foreach (Check check in document.Checks.Where(c => c.ContainsWidget(this.Name)))
                {
                    foreach (Action action in check.Actions)
                    {
                        Widget widget = document.FindChildByName(action.WidgetName ?? this.Name);
                        action.MvcName = widget.MvcType + "_" + widget.Name;
                        if (!string.IsNullOrEmpty(action.WidgetDestination))
                        {
                            Widget destWidget = document.FindChildByName(action.WidgetDestination);
                            action.DestMvcName = destWidget.MvcType + "_" + destWidget.Name;
                        }
                    }

                    this.LocalChecks.Add(check);
                }

                foreach (Widget child in Children) child.SetChecks(document);
            }
        }

        /// <summary>
        /// Finds the name of the child by.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>Widget.</returns>
        public Widget FindChildByName(string name)
        {
            Widget child = null;
            if (this.Name == name)
                child = this;
            else
            {
                foreach (Widget w in this.Children)
                {
                    Widget res = w.FindChildByName(name);
                    if (res != null)
                    {
                        child = res;
                        break;
                    }
                }
            }

            return child;
        }

        /// <summary>
        /// Finds the child by field.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <param name="field">The field.</param>
        /// <returns>Widget.</returns>
        public Widget FindChildByField(string table, string field)
        {
            Widget child = null;

            if (this.TableName == table && this.Field == field && this.Visible)
                child = this;
            else
            {
                foreach (Widget w in this.Children)
                {
                    Widget res = w.FindChildByField(table, field);
                    if (res != null)
                    {
                        child = res;
                        break;
                    }
                }
            }

            return child;
        }

        /// <summary>
        /// Finds the child by table.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <returns>Widget.</returns>
        public Widget FindChildByTable(string table)
        {
            Widget child = null;

            if (this.TableName == table)
                child = this;
            else
            {
                foreach (Widget w in this.Children)
                {
                    Widget res = w.FindChildByTable(table);
                    if (res != null)
                    {
                        child = res;
                        break;
                    }
                }
            }

            return child;
        }

        /// <summary>
        /// Firsts the child with data table.
        /// </summary>
        /// <returns>Widget.</returns>
        public Widget FirstChildWithDataTable()
        {
            Widget child = null;

            if (!string.IsNullOrEmpty(this.TableName))
                child = this;
            else
            {
                foreach (Widget w in this.Children)
                {
                    Widget res = w.FirstChildWithDataTable();
                    if (res != null)
                    {
                        child = res;
                        break;
                    }
                }
            }

            return child;
        }

        /// <summary>
        /// Finds the type of the children by.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>List&lt;Widget&gt;.</returns>
        public List<Widget> FindChildrenByType(WidgetType type)
        {
            List<Widget> children = new List<Widget>();

            if (this.Type == type)
                children.Add(this);
            else
            {
                foreach (Widget w in this.Children)
                {
                    List<Widget> res = w.FindChildrenByType(type);
                    if (res.Count > 0)
                    {
                        children.AddRange(res);
                    }
                }
            }

            return children;
        }

        /// <summary>
        /// Finds the type of the parent by MVC.
        /// </summary>
        /// <param name="mvcType">Type of the MVC.</param>
        /// <returns>Widget.</returns>
        public Widget FindParentByMvcType(string mvcType)
        {
            if (this.Parent == null) return null;

            Widget parent = null;

            if (this.Parent.MvcType == mvcType)
            {
                parent = this.Parent;
            }
            else
            {
                parent = this.Parent.FindParentByMvcType(mvcType);
            }

            return parent;
        }

        /// <summary>
        /// Finds the type of the parent by.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>Widget.</returns>
        public Widget FindParentByType(Lawyers.Common.Enums.WidgetType type)
        {
            if (this.Parent == null) return null;

            Widget parent = null;
            if (this.Parent.Type == type)
            {
                parent = this.Parent;
            }
            else
            {
                parent = this.Parent.FindParentByType(type);
            }

            return parent;
        }

        /// <summary>
        /// Finds the base parent of the widget (either DataGrid or Form).
        /// </summary>
        /// <param name="type"></param>
        /// <returns>Widget.</returns>
        public Widget FindBaseParent()
        {
            if (this.Parent == null) return null;

            Widget parent = null;
            if (this.Parent.Type == Lawyers.Common.Enums.WidgetType.DataGrid || this.Parent.Type == Lawyers.Common.Enums.WidgetType.Form)
            {
                parent = this.Parent;
            }
            else
            {
                parent = this.Parent.FindBaseParent();
            }

            return parent;

            //Widget w = FindParentByType(Lawyers.Common.Enums.WidgetType.DataGrid);
            //if(w == null)
            //    w = FindParentByType(Lawyers.Common.Enums.WidgetType.Form);
            //return w;
        }

        /// <summary>
        /// Gets a value indicating whether this <see cref="Widget"/> is simple.
        /// </summary>
        /// <value><c>true</c> if simple; otherwise, <c>false</c>.</value>
        public bool Simple
        {
            get
            {
                return this.Type == Common.Enums.WidgetType.DBComboBox
                    || this.Type == Common.Enums.WidgetType.CheckBox
                    || this.Type == Common.Enums.WidgetType.CheckList
                    || this.Type == Common.Enums.WidgetType.Date
                    || this.Type == Common.Enums.WidgetType.DateTime
                    || this.Type == Common.Enums.WidgetType.List
                    || this.Type == Common.Enums.WidgetType.Memo
                    || this.Type == Common.Enums.WidgetType.Integer
                    || this.Type == Common.Enums.WidgetType.Decimal
                    || this.Type == Common.Enums.WidgetType.Text
                    || this.Type == Common.Enums.WidgetType.Edit
                    || this.Type == Common.Enums.WidgetType.Attachment;
            }
        }

        /// <summary>
        /// Gets the simple children.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <returns>List&lt;Widget&gt;.</returns>
        public List<Widget> GetSimpleChildren(string table)
        {
            List<Widget> result = new List<Widget>();

            foreach (Widget child in this.Children)
            {
                if ((child.Simple && child.TableName == table) || child.Type == Lawyers.Common.Enums.WidgetType.DataGrid || child.Type == Lawyers.Common.Enums.WidgetType.Form || child.Type == Common.Enums.WidgetType.Button || child.Type == Common.Enums.WidgetType.Hyperlink)
                {
                    result.Add(child);
                }
                else
                {
                    if (child.Type != Lawyers.Common.Enums.WidgetType.Array)
                    {
                        result.AddRange(child.GetSimpleChildren(table));
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Replaces the fields.
        /// </summary>
        /// <param name="jsUrl">The js URL.</param>
        /// <param name="predicate">The predicate.</param>
        /// <returns>System.String.</returns>
        public string ReplaceFields(string jsUrl, string predicate)
        {
            string url = "'";
            jsUrl = jsUrl.Trim();

            while (jsUrl.Contains('['))
            {
                url += jsUrl.Substring(0, jsUrl.IndexOf('['));
                url += "' + " + predicate + jsUrl.Substring(jsUrl.IndexOf('[') + 1, jsUrl.IndexOf(']') - jsUrl.IndexOf('[') - 1);

                if (jsUrl.IndexOf(']') != jsUrl.Length - 1)
                {
                    url += " + '";
                }

                jsUrl = jsUrl.Remove(jsUrl.IndexOf('['), 1);
                jsUrl = jsUrl.Remove(jsUrl.IndexOf(']'), 1);
            }

            return url;
        }

        /// <summary>
        /// Gets the root.
        /// </summary>
        /// <returns>Widget.</returns>
        internal Widget GetRoot()
        {
            Widget root = null;
            if (this.Parent == null)
                root = this;
            else
                root = this.Parent.GetRoot();

            return root;
        }

        /// <summary>
        /// Gets the filter value.
        /// </summary>
        /// <param name="p">The p.</param>
        /// <param name="record">The record.</param>
        /// <param name="ds">The ds.</param>
        /// <returns>System.String.</returns>
        public string GetFilterValue(string p, object[] record, SortedDictionary<string, int> fieldIndexes, ClaimsIdentity identity)
         {
            string result = p;

            if (p.StartsWith("widget:"))
            {
                Widget widget = this.GetRoot().FindChildByName(p.Substring(7));

                if (record != null && !string.IsNullOrEmpty(widget.TableName))
                {
                    result = record[fieldIndexes[widget.Field]] != null ? record[fieldIndexes[widget.Field]].ToString() : null;
                }
                else
                {
                    result = widget == null ? string.Empty : widget.Value == null ? string.Empty : widget.Value.ToString();
                }
            }

            if (p.StartsWith("w:"))
            {
                Widget widget = this.GetRoot().FindChildByName(p.Substring(2));

                if (record != null && !string.IsNullOrEmpty(widget.TableName))
                {
                    result = record[fieldIndexes[widget.Field]].ToString();
                }
                else
                {
                    result = widget == null ? string.Empty : widget.Value == null ? string.Empty : widget.Value.ToString();
                }
            }

            if (p == "function:auth()")
            {
                result = "'" + identity.Claims.Where(c => c.Type == System.Security.Claims.ClaimTypes.NameIdentifier).First().Value + "'";
            }

            if (p == "function:subj_id()")
            {
                result = identity.Claims.Where(c => c.Type == "subj_id").First().Value;
            }

            if (p == "function:law_id()")
            {
                result = identity.Claims.Where(c => c.Type == "subj_law_supplier_id").First().Value;
            }

            if (p == "function:authFilter()")
            {
                result = identity.Claims.Where(c => c.Type == System.Security.Claims.ClaimTypes.NameIdentifier).First().Value;
            }

            if (p == "function:auth_company()")
            {
                result = identity.Claims.Where(c => c.Type == System.Security.Claims.ClaimTypes.PrimarySid).First().Value;
            }

            if (p == "function:auth_role()")
            {
                result = identity.Claims.Where(c => c.Type == "user_role").First().Value;
            }

            return result;
        }

        /// <summary>
        /// Gest the preferred width of the grid.
        /// </summary>
        //public string GetPreferedGridWidth()
        //{
        //    string grid_width;
        //    if (ControlWidth > 0)
        //        grid_width = ControlWidth + "%";
        //    else if (DataFields.Count < 4)
        //        grid_width = "906px";
        //    else if (DataFields.Count * 150 < 1154)
        //        grid_width = "1154px";
        //    else
        //        grid_width = DataFields.Count * 150 + "px";
        //    return grid_width;
        //}
        public int GetPreferedGridWidth()
        {
            int grid_width;
            if (DataFields.Count < 4)
                grid_width = 906;
            else if (DataFields.Count * 150 < 1154)
                grid_width = 1154;
            else
                grid_width = DataFields.Count * 150;
            return grid_width;
        }

        /// <summary>
        /// Gest the preferred width of the grid.
        /// </summary>
        //public string GetGridStyles(string width)
        //{
        //    if (width.EndsWith("px") && width != "906px")
        //        return "overflow:scroll";
        //    else
        //        return "";
        //}
        public string GetGridStyles(int width)
        {
            //return (width > 1154? "overflow:scroll" : "");
            return (width > 906 ? "overflow:scroll" : "");
        }

        /// <summary>
        /// Gest the preferred width of the grid.
        /// </summary>
        public string getJTablePreferredWidth(int width)
        {
            string grid_width;
            if (ControlWidth > 0)  //takes into account width explicitly set on in the template 
                grid_width = ControlWidth + "%";
            else
                grid_width = width + "px";
            return grid_width;
        }

        /// <summary>
        /// checks if type is isNumericType.
        /// </summary>
        public bool isNumericDataType(DataType type)
        {
            switch (type)
            {
                case DataType.Integer:
                case DataType.Int4:
                case DataType.Int2:
                case DataType.Decimal:
                case DataType.Numeric:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// checks if type is isIntegerType..
        /// </summary>
        public bool isIntegerDateType(DataType type)
        {
            switch (type)
            {
                case DataType.Integer:
                case DataType.Int4:
                case DataType.Int2:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// get primary widget name
        /// </summary>
        public string WidgetName
        {
            get { return (IsForm ? "" : "") + MvcType + "_" + Name; }
        }


        /// <summary>
        /// get additional widget name with language suffice
        /// </summary>
        public string AdditionalWidgetName
        {
            get
            {
                if (!string.IsNullOrEmpty(FieldRu) && Field != FieldRu)
                {
                    return WidgetName + "_ru";
                }
                if (!string.IsNullOrEmpty(FieldKk) && Field != FieldKk)
                {
                    return WidgetName + "_kz";
                }
                if (!string.IsNullOrEmpty(FieldEn) && Field != FieldEn)
                {
                    return WidgetName + "_en";
                }
                else
                {
                    return WidgetName;
                }
            }
        }

        /// <summary>
        /// get additional widget name
        /// </summary>
        public string AdditionalWidgetField
        {
            get
            {
                if (!string.IsNullOrEmpty(FieldRu) && Field != FieldRu)
                {
                    return FieldRu;
                }
                if (!string.IsNullOrEmpty(FieldKk) && Field != FieldKk)
                {
                    return FieldKk;
                }
                if (!string.IsNullOrEmpty(FieldEn) && Field != FieldEn)
                {
                    return FieldEn;
                }
                else
                {
                    return Field;
                }
            }
        }

        /// <summary>
        /// get additional widget tool tip
        /// </summary>
        public string AdditionalWidgetToolTip
        {
            get
            {
                if (!string.IsNullOrEmpty(FieldRu) && Field != FieldRu)
                {
                    return ToolTipRu;
                }
                if (!string.IsNullOrEmpty(FieldKk) && Field != FieldKk)
                {
                    return ToolTipKk;
                }
                if (!string.IsNullOrEmpty(FieldEn) && Field != FieldEn)
                {
                    return ToolTipEn;
                }
                else
                {
                    return ToolTip;
                }
            }
        }

        /// <summary>
        /// get additional widget default value
        /// </summary>
        public string AdditionalwidgetDefaultValue
        {
            get
            {
                if (!string.IsNullOrEmpty(FieldRu) && Field != FieldRu)
                {
                    return DefaultValueRu;
                }
                if (!string.IsNullOrEmpty(FieldKk) && Field != FieldKk)
                {
                    return DefaultValueKk;
                }
                if (!string.IsNullOrEmpty(FieldEn) && Field != FieldEn)
                {
                    return DefaultValueEn;
                }
                else
                {
                    return DefaultValue;
                }
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Widget"/> class.
        /// </summary>
        public Widget()
        {
            IsForm = false;
            this.LocalChecks = new List<Check>();
        }
    }
}
