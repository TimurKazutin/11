﻿using Lawyers.Web.App.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lawyers.Web.App.Models
{
    public class OrdersViewModel
    {
        public List<OrderModel> Orders { get; set; }
    }

    public class DocsViewModel
    {
        public List<Inv> Invoice { get; set; }
    }

    public class Sellers
    {
        public int attis_contract_id { get; set; }
        public string attis_contract_owner { get; set; }
        public string attis_contract_status { get; set; }
        public string attis_contract_kpveds { get; set; }
        public bool attis_contract_type { get; set; }
        public bool attis_contract_case { get; set; }
        public string attis_contract_subject { get; set; }
        public string attis_contract_desc { get; set; }
        public string attis_contract_currency { get; set; }
        public string conditions { get; set; }
        public string attis_contract_delivery_term { get; set; }
        public string attis_contract_delivery_place { get; set; }
        public DateTime? attis_contract_date { get; set; }
        public string attis_contract_payment_type { get; set; }
        public string attis_contract_contragent { get; set; }
        public DateTime? attis_contract_deadline { get; set; }
        public DateTime attis_contract_create_date { get; set; }
        public List<Product> product { get; set; }
        public List<Kfiles> files { get; set; }
        public string language { get; set; }
        public int attis_contract_is_public { get; set; }
        public int? grace_period { get; set; }
        public DateTime? payment_date { get; set; }
        public float? advance_payment { get; set; }
        public int? delay_days { get; set; }
        public float? overdue { get; set; }
        public int? packaging_transport_fees_included { get; set; }
        public string goods_origin_country { get; set; }
        public string point_of_departure { get; set; }
        public string destination_point { get; set; }
        public int? days_to_change_price { get; set; }
        public float? prepayment_percent { get; set; }
        public int? number_of_days_for_prepayment { get; set; }
        public int? number_of_days_for_fullpayment { get; set; }
        public int? overdue_term { get; set; }
        public int? shipping_term { get; set; }
        public int? total_delivery_time { get; set; }
        public int? days_to_receive_goods { get; set; }
        public int? days_to_quality_receive_goods { get; set; }
        public int? transfer_of_ownership { get; set; }
        public int? guaranty_term { get; set; }
        public int? exceeding_guaranty_term { get; set; }
        public float? payment_overdue { get; set; }
        public float? shipping_overdue { get; set; }
        public float? decline_due_to_overdue { get; set; }
        public string legal_country { get; set; }
        public string arbitrage_country { get; set; }
        public string contract_language { get; set; }
        public DateTime? contract_term { get; set; }
        public int? notification_term { get; set; }
        public bool is_signed_by_owner { get; set; }
        public bool is_signed_by_counterparty { get; set; }
        public string how_is_signed_by_owner { get; set; }
        public string how_is_signed_by_counterparty { get; set; }
        public string when_is_signed_by_owner { get; set; }
        public string when_is_signed_by_counterparty { get; set; }
        public int? cancel_term { get; set; }
        public int? consent_term { get; set; }
        public int? inform_term { get; set; }
        public int? location_term { get; set; }
        public string name_of_signature_owner { get; set; }
        public string name_of_signature_counterparty { get; set; }

    }

    public class Product
    {
        public string attis_cg_good_name { get; set; }
        public string attis_cg_TNVED { get; set; }
        public string attis_cg_quantity { get; set; }
        public string attis_cg_measures { get; set; }
        public string attis_cg_price { get; set; }
        public string origin_country { get; set; }
    }
    public class Prod
    {
        public string attis_cg_good_name { get; set; }
        public string attis_cg_TNVED { get; set; }
        public int attis_cg_quantity { get; set; }
        public string attis_cg_measures { get; set; }
        public float attis_cg_price { get; set; }
    }

    public class Ktgres
    {
        public int status { get; set; }
        public string message { get; set; }
        public List<Kfiles> files { get; set; }
    }

    public class Contr
    {
        public int id { get; set; }
        public string attis_contract_currency { get; set; }
        public string attis_contract_status { get; set; }
        public string attis_contract_subject { get; set; }
        public string attis_contract_desc { get; set; }
        public string attis_contract_number { get; set; }
        public string attis_contract_date { get; set; }
        public string attis_contract_owner { get; set; }
        public string owner_org { get; set; }
        public string owner_org_name { get; set; }
        public string attis_contract_contragent { get; set; }
        public string attis_contract_contragent_name { get; set; }
        public float attis_contract_amount { get; set; }
    }

    public class Orders
    {
        public string title { get; set; }
        public List<Contr> contracts { get; set; }
    }
    public class Inv
    {
        public int Id { get; set; }
        public string Num { get; set; }
        public string Debt { get; set; }
        public decimal dDebt { get; set; }
        public string Reg { get; set; }
        public string Deb { get; set; }
        public DateTime Date { get; set; }
        public bool Payd { get; set; }
        public string DocType { get; set; }
        public string DocNo { get; set; }
    }

    public class Deal
    {
        public int Id { get; set; }
        public int? state { get; set; }
        public string User { get; set; }
        public string Debt { get; set; }
        public string additional_agreement { get; set; }
        public string Deb { get; set; }
        public DateTime Date { get; set; }
        public bool Agree { get; set; }
    }

    public class Light
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string condition { get; set; }
        public string value { get; set; }
        public string color { get; set; }
        public string logic { get; set; }
        public string dest { get; set; }
        public bool is_active { get; set; }
    }

    public class OrderModel
    {
        public OrderModel()
        {
        }
        //    public string Name { get; set; }

        public string Id { get; set; }
        public string subj_id { get; set; }
        [Required(ErrorMessage = "Требуется значение")]
        public string FirmName { get; set; }
        [Required(ErrorMessage = "Требуется значение")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Требуется значение")]
        public string Contacts { get; set; }

        [Required(ErrorMessage = "Требуется значение")]
        //[RegularExpression("[0-9]+(.[0-9][0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.99")]
        public decimal Debt { get; set; }
        public string Debtstr { get; set; }
        public string DocNo { get; set; }
        public string Creditor_name { get; set; }
        [Required(ErrorMessage = "Требуется значение")]
        public string Agreement { get; set; }
        //[Required(ErrorMessage = "Требуется значение")]
        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public DateTime DebtDate { get; set; }
        //[Required(ErrorMessage = "Требуется значение")]
        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public DateTime AgreementDate { get; set; }

        public string Reg { get; set; }
        public int Quant { get; set; }

        //public bool Remember { get; set; }
        public bool proof { get; set; }
        public bool late { get; set; }
        public bool late_or_problems { get; set; }
        public bool typic { get; set; }
        public string corr { get; set; }
        public bool regrs { get; set; }
        public bool revrs { get; set; }
        public bool opn { get; set; }
        public bool payed { get; set; }

        public string fact_id { get; set; }
        public string kred_id { get; set; }
        public string dbtr_id { get; set; }
        //[Required(ErrorMessage = "Требуется значение")]
        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public DateTime ratedt { get; set; }

        [Required(ErrorMessage = "Требуется значение")]
        [RegularExpression("[0-9]+(.[0-9]?[0-9]?[0-9]?[0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.9999")]
        public decimal K1 { get; set; }

        [Required(ErrorMessage = "Требуется значение")]
        [RegularExpression("[0-9]+(.[0-9][0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.99")]
        public decimal K2 { get; set; }

        [Required(ErrorMessage = "Требуется значение")]
        [RegularExpression("[0-9]+(.[0-9][0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.99")]
        public decimal K3 { get; set; }

        [Required(ErrorMessage = "Требуется значение")]
        [RegularExpression("[0-9]+(.[0-9][0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.99")]
        public decimal K4 { get; set; }

        [Required(ErrorMessage = "Требуется значение")]
        [RegularExpression("[0-9]+(.[0-9][0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.99")]
        public decimal fund { get; set; }

        //[Required(ErrorMessage = "Требуется значение")]
        //[RegularExpression("[0-9]+(.[0-9][0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.99")]
        public decimal first { get; set; }

        [Required(ErrorMessage = "Требуется значение")]
        [RegularExpression("[0-9]+(.[0-9][0-9]?)?", ErrorMessage = "должен содержать цифры до 999999.99")]
        public int free { get; set; }
        //[Required(ErrorMessage = "Требуется значение")]
        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public DateTime regrsdt { get; set; }

        public bool tx { get; set; }
        public bool cmp { get; set; }
        public string status { get; set; }
        public string debit_confirm { get; set; }
        public string color { get; set; }

        //[Required(ErrorMessage = "Ведите фамилию")]

        //[Display(Name = "Bin", ResourceType = typeof(GlobalStrings))]
        //[Required(ErrorMessage = "Поле БИН.Требуется значение")]
        //[MinLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        //[MaxLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        //[RegularExpression("^[0-9]*$", ErrorMessage = "БИН должен содержать 12 цифр")]
        public string Bin { get; set; }

    }
    public class OrderDet
    {
        public List<OrderModel> OrderDetails { get; set; }
    }
}