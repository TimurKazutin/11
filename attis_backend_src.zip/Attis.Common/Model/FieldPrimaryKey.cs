﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-17-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-18-2014
// ***********************************************************************
// <copyright file="FieldPrimaryKey.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Controls namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Xml.Serialization;
    using Lawyers.Common.Interfaces;

    /// <summary>
    /// Class FieldPrimaryKey.
    /// </summary>
    [XmlType]
    public class FieldPrimaryKey
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        [XmlAttribute(AttributeName = "position")]
        public int Position { get; set; }

        /// <summary>
        /// Gets or sets the parameter.
        /// </summary>
        /// <value>The parameter.</value>
        [XmlAttribute(AttributeName = "param")]
        public string Parameter { get; set; }
    }
}
