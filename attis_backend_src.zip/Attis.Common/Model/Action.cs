﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-19-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-19-2014
// ***********************************************************************
// <copyright file="Action.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Collections.Generic;
    using System.Threading;
    using System.Xml.Serialization;
    using Lawyers.Common.Classes;
    using Lawyers.Common.Enums;

    /// <summary>
    /// Class Action.
    /// </summary>
    [XmlType]
    public class Action
    {
        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        [XmlAttribute(AttributeName = "type")]
        public ActionType Type { get; set; }

        /// <summary>
        /// Gets or sets the name of the widget.
        /// </summary>
        /// <value>The name of the widget.</value>
        [XmlAttribute(AttributeName = "widget")]
        public string WidgetName { get; set; }

        /// <summary>
        /// Gets or sets the widget source.
        /// </summary>
        /// <value>The widget source.</value>
        [XmlAttribute(AttributeName = "widget_src")]
        public string WidgetSource { get; set; }

        /// <summary>
        /// Gets or sets the widget destination.
        /// </summary>
        /// <value>The widget destination.</value>
        [XmlAttribute(AttributeName = "widget_dest")]
        public string WidgetDestination { get; set; }

        /// <summary>
        /// Gets or sets the name of the field filter.
        /// </summary>
        /// <value>The name of the field filter.</value>
        [XmlAttribute(AttributeName = "field_fn")]
        public string FieldFilterName { get; set; }

        /// <summary>
        /// Gets or sets the default value.
        /// </summary>
        /// <value>The default value.</value>
        public string DefaultValue
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(DefaultValueRu))
                    return DefaultValueRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(DefaultValueKk))
                    return DefaultValueKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(DefaultValueEn))
                    return DefaultValueEn;
                return DefaultValueRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    DefaultValueRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    DefaultValueKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    DefaultValueEn = value;
                    return;
                }
                DefaultValueRu = value;
            }
        }
        [XmlAttribute(AttributeName = "default_value_en")]
        public string DefaultValueEn { get; set; }
        [XmlAttribute(AttributeName = "default_value_kz")]
        public string DefaultValueKk { get; set; }
        [XmlAttribute(AttributeName = "default_value_ru")]
        public string DefaultValueRu { get; set; }

        /// <summary>
        /// Gets or sets the mask.
        /// </summary>
        /// <value>The mask.</value>
        [XmlAttribute(AttributeName = "mask")]
        public string Mask { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        [XmlAttribute(AttributeName = "msg")]
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the name of the stored procedure.
        /// </summary>
        /// <value>The name of the stored procedure.</value>
        [XmlAttribute(AttributeName = "stored_procedure")]
        public string StoredProcedureName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Action"/> is apply.
        /// </summary>
        /// <value><c>true</c> if apply; otherwise, <c>false</c>.</value>
        [XmlIgnore]
        public bool Apply { get; set; }

        /// <summary>
        /// Gets or sets the type string.
        /// </summary>
        /// <value>The type string.</value>
        [XmlIgnore]
        public string TypeString { get { return Type.ToString(); } set { } }

        /// <summary>
        /// Gets or sets the name of the MVC.
        /// </summary>
        /// <value>The name of the MVC.</value>
        [XmlIgnore]
        public string MvcName { get; set; }

        /// <summary>
        /// Gets or sets the name of the dest MVC.
        /// </summary>
        /// <value>The name of the dest MVC.</value>
        [XmlIgnore]
        public string DestMvcName { get; set; }

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>The data.</value>
        [XmlIgnore]
        public List<KeyValueData> Data { get; set; }
    }
}
