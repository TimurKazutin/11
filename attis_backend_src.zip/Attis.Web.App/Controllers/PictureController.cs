﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 11-25-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 12-10-2014
// ***********************************************************************
// <copyright file="PictureController.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Web.Mvc;
    using Common;
    using Common.Classes;
    using Common.Interfaces;
    using Microsoft.AspNet.Identity;

    /// <summary>
    /// Class PictureController.
    /// </summary>
    public class PictureController : Controller
    {
        /// <summary>
        /// Gets or sets the doc_guid.
        /// </summary>
        /// <value>The doc_guid.</value>
        private Guid DocGuid
        {
            get => (Guid)HttpContext.Session["doc_guid"];
            set => HttpContext.Session["doc_guid"] = value;
        }

		/// <summary>
		/// Gets the provider.
		/// </summary>
		/// <value>The provider.</value>
		private IDataProvider Provider => GlobalContainer.Instance.Get<Configuration>().DataProvider;

        /// <summary>
		/// Gets the list images.
		/// </summary>
		/// <value>The list images.</value>
		private List<ImageFile> ListImages
        {
            get
            {
                var result = ListFiles.Where(i => i.IsPicture).ToList();
                return result;
            }
        }

        private List<ImageFile> ListFiles
        {
            get
            {
                var result = HttpContext.Session["ListFiles"] as List<ImageFile>;
                return result;
            }
        }

        // GET: Picture
        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns>ActionResult.</returns>
        [ChildActionOnly]
        public ActionResult Index()
        {
            return PartialView();
        }

        /// <summary>
        /// Loads the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>JsonResult.</returns>
        [HttpPost]
        public JsonResult LoadImages(string id)
        {
            if (!String.IsNullOrEmpty(id)) {
            DocGuid = Guid.Parse(id);
            GetFiles();
            return Json(new { ListImages = ListImages.Select(li => new {li.ID, li.Name, li.IconPath, li.WidgetId }).ToArray() });
            }
            else
                return Json("");
        }

        [HttpPost]
        public JsonResult LoadLogo(string id)
        {
            if (!String.IsNullOrEmpty(id)) {
                DocGuid = Guid.Parse(id);
                GetFiles();
                return Json(new { ListImages = ListImages.Select(li => new { li.ID, li.Name, li.IconPath, li.WidgetId }).Where(li => li.WidgetId == "logo").ToArray() });
            }
            else 
                return Json("");
        }

        [HttpPost]
        public JsonResult LoadFiles(string id)
        {
            if (id != null)
            {
                DocGuid = Guid.Parse(id);
            }
            GetFiles();
            return Json(new { ListFiles = ListFiles.Select(li => new { li.ID, li.Name, li.IconPath, li.WidgetId }).ToArray() });
        }

        [HttpPost]
        public JsonResult LoadFilesWithTableName(string widgetId, string ID)
        {
            string id = Request.QueryString["id"];

            HttpContext.Session["ListFiles"] = Provider.GetFiles(id, ID);
            return Json(new { ListFiles = ListFiles.Select(li => new { li.ID, li.Name, li.IconPath, li.WidgetId }).ToArray() });
        }

        //[HttpPost]
        public string DeleteFile(string id)
        {
            var result = "Ok";

            try
            {
                Provider.DeleteFile(int.Parse(id));
            }
            catch (Exception ex)
            {
                result = "Error" + ex;
            }

            return result;
        }

        [HttpPost]
        public JsonResult UploadFilesWithTableName(string widgetId, string id)
        {
            widgetId = Request.QueryString[0];
            var r = new List<ImageFile>();

            foreach (string file in Request.Files)
            {
                var hpf = Request.Files[file];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = widgetId,
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = id
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }

            return Json(new { r[0].ID, r[0].Name, r[0].Type, size = r[0].Length, r[0].IconPath, r[0].WidgetId });
        }

        [HttpPost]
        public JsonResult UploadFiles(string id)
        {
            var r = new List<ImageFile>();

            foreach (string file in Request.Files)
            {
                var hpf = Request.Files[file];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    DocGuid = DocGuid,
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = id
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }

            return Json(new { r[0].ID, r[0].Name, r[0].Type, size = r[0].Length, r[0].IconPath, r[0].WidgetId });
        }

        [HttpPost]
        public JsonResult UploadLogo(string id)
        {
            var r = new List<ImageFile>();

            foreach (string file in Request.Files)
            {
                var hpf = Request.Files[file];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    DocGuid = DocGuid,
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "logo"
                };

                hpf.InputStream.CopyTo(imgFile.Image);
                if (id != "defaultLogo") {
                    Provider.DeleteFile(Int32.Parse(id));
                }                
                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }

            return Json(new { r[0].ID, r[0].Name, r[0].Type, size = r[0].Length, r[0].IconPath, r[0].WidgetId });
        }

        private void GetFiles()
        {
            HttpContext.Session["ListFiles"] = Provider.GetFiles(DocGuid);
        }

        /// <summary>
        /// Gets the image.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>ActionResult.</returns>
        public ActionResult GetImage(int id)
        {
            var file = ListFiles.First(img => img.ID == id);
            return File(file.Image.ToArray(), file.ContentType, file.Name);
        }

        public ActionResult GetFile(int id)
        {
            var file = Provider.GetFileByID(id);
            if (file != null)
            {
                Response.AppendHeader("content-disposition", "inline; filename=" + file.Name);
                Response.AppendHeader("Content-Length", file.Image.Length.ToString());
                return new FileStreamResult(file.Image, file.ContentType);
            }
            else return null;
        }

        public ActionResult GetTxtFile(int id)
        {
            var file = Provider.GetFileByID(id);
            Response.AppendHeader("content-disposition", "inline; filename=" + file.Name);
            Response.AppendHeader("Content-Length", file.Image.Length.ToString());
            return new FileStreamResult(file.Image, "application/vnd.ms-excel");
        }

        public ActionResult GetFileByGuid(Guid id)
        {
            var file = Provider.GetFileByGuid(id);
            Response.AppendHeader("content-disposition", "inline; filename=" + file.Name);
            Response.AppendHeader("Content-Length", file.Image.Length.ToString());
            return new FileStreamResult(file.Image, file.ContentType);
        }

        [HttpPost]
        public string avatar_upload(string token)
        {
            var r = new List<ImageFile>();
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = "user",
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "avatar"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }
            var user = User.Identity.GetUserId();
            string adr= "/picture/getfile/"+r[0].ID.ToString();
            string query = $"UPDATE persons SET avatar='{adr}' WHERE user_id='{user}'";
            Provider.RunNonQuery(query);
            return "{\"url\":\"" + adr + "\"}";
        }

        [HttpPost]
        public string logo_upload(string token)
        {
            var r = new List<ImageFile>();
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = "org",
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "logo"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }
            var user = User.Identity.GetUserId();
            string query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
            int oid = Provider.RunScalar(query);
            string adr = "/picture/getfile/" + r[0].ID.ToString();
            query = $"UPDATE organizations SET logo='{adr}' WHERE org_id={oid}"; 
            Provider.RunNonQuery(query);
            return "{\"url\":\"" + adr + "\"}";
        }
    }
}