﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Lawyers.Web.App.Models
{
    public class NewsModel
    {
        [Key]
        public int NewsID { get; set; }
        //public int CollegID { get; set; }

        [DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/mm/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }
        public string Title { get; set; }
        public string Purpos { get; set; }
        public string Priv { get; set; }
        [AllowHtml]
        public string Content { get; set; }
        //public HttpPostedFileBase Image { get; set; }

        public NewsModel()
        {
            this.Date = DateTime.Now;
        }
    }

    public class NewsModel1
    {
        [Key]
        public int id { get; set; }
        public string date { get; set; }
        public string title { get; set; }
        public string text { get; set; }
        //public HttpPostedFileBase Image { get; set; }    
    }
}