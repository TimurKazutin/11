﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-30-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-08-2014
// ***********************************************************************
// <copyright file="GlobalContainer.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace Lawyers.Common
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class GlobalContainer.
    /// </summary>
    public class GlobalContainer
    {
        /// <summary>
        /// The instance
        /// </summary>
        private static volatile GlobalContainer instance;
        /// <summary>
        /// The synchronize root
        /// </summary>
        private static readonly object SyncRoot = new object();

        /// <summary>
        /// The dictionary
        /// </summary>
        private readonly Dictionary<Type, object> _dictionary;

        /// <summary>
        /// Gets the instance.
        /// </summary>
        /// <value>The instance.</value>
        public static GlobalContainer Instance
        {
            get
            {
                if (instance != null)
                {
                    return instance;
                }

                lock (SyncRoot)
                {
                    if (instance == null)
                        instance = new GlobalContainer();
                }

                return instance;
            }
        }

        /// <summary>
        /// Prevents a default instance of the <see cref="GlobalContainer"/> class from being created.
        /// </summary>
        private GlobalContainer()
        {
            this._dictionary = new Dictionary<Type, object>();
        }

        /// <summary>
        /// Sets the specified object.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="o">The object.</param>
        public void Set<T>(T o)
        {
            if (this._dictionary.ContainsKey(typeof(T)))
            {
                this._dictionary[typeof(T)] = o;
            }
            else
            {
                _dictionary.Add(typeof(T), o);
            }
        }

        /// <summary>
        /// Gets this instance.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>T.</returns>
        public T Get<T>() where T : new()
        {
            T result = default(T);

            if (this._dictionary.ContainsKey(typeof(T)))
            {
                result = (T)this._dictionary[typeof(T)];
            }
            else
            {
                result = new T();
                _dictionary.Add(typeof(T), result);
            }

            return result;
        }
    }
}
