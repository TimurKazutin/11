﻿namespace Lawyers.Web.App.Models
{
    public class CheckUniqueModel
    {
        public string FieldName { get; set; }

        public string FieldValue { get; set; }
    }
}