﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 18-07-2016
// ***********************************************************************
// <copyright file="IdentityConfig.cs" company="A&S">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The App namespace.
/// </summary>

using Lawyers.Web.App.IdentityExtensions;

namespace Lawyers.Web.App
{
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.Owin;
    using Microsoft.Owin;
    using Microsoft.Owin.Security;
    using Resources;
    using System;
    using System.Net;
    using System.Net.Mail;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using Lawyers.Web.App.Models;
    using PostgreSQL.AspNet.Identity.EntityFramework;
    using Twilio;
    using Twilio.Rest.Api.V2010.Account;
    using Twilio.Types;
    using Twilio.Clients;
    using System.Configuration;

    /// <summary>
    /// Class EmailService.
    /// </summary>
    public class EmailService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            // адрес и порт smtp-сервера, с которого мы и будем отправлять письмо
            SmtpClient client = new SmtpClient(System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"], Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]));

            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential(System.Configuration.ConfigurationManager.AppSettings["EmailSender"], System.Configuration.ConfigurationManager.AppSettings["EmailSenderPass"]);
            client.EnableSsl = false;

            // создаем письмо: message.Destination - адрес получателя
            var mail = new MailMessage(System.Configuration.ConfigurationManager.AppSettings["EmailSender"], message.Destination);
            mail.Subject = message.Subject;
            mail.Body = message.Body;
            mail.IsBodyHtml = true;
            try
            {
                client.Send(mail);
                return Task.FromResult<object>(true);
            }
            catch (Exception ex)
            { return Task.FromResult<object>(false); }
        }
    }

    public static class Keys
    {
        public static string SMSAccountIdentification = "My Idenfitication";
        public static string SMSAccountPassword = "My Password";
        public static string SMSAccountFrom = "+15555551234";
    }
    /// <summary>
    /// Class SmsService.
    /// </summary>
    public class SmsService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            //TwilioClient.Init(System.Configuration.ConfigurationManager.AppSettings["SMSAccountSid"], System.Configuration.ConfigurationManager.AppSettings["SMSAccountAuthToken"]);

            /*var result = MessageResource.Create(message.Destination,
                                              from: new PhoneNumber(System.Configuration.ConfigurationManager.AppSettings["SMSAccountFrom"]),
                                              body: message.Body);
                                              */
            //return Task.FromResult(0);
            // Twilio Begin
            var accountSid = ConfigurationManager.AppSettings["SMSAccountSid"];
            var authToken = ConfigurationManager.AppSettings["SMSAccountAuthToken"];
            var fromNumber = ConfigurationManager.AppSettings["SMSAccountFrom"];

            TwilioClient.Init(accountSid, authToken);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                                                | SecurityProtocolType.Tls11
                                                | SecurityProtocolType.Tls12
                                                | SecurityProtocolType.Ssl3;
            MessageResource result = MessageResource.Create(
            new PhoneNumber(message.Destination),
            from: new PhoneNumber(fromNumber),
            body: message.Body
            );

            ////Status is one of Queued, Sending, Sent, Failed or null if the number is not valid
            //Trace.TraceInformation(result.Status.ToString());
            ////Twilio doesn't currently have an async API, so return success.
            return Task.FromResult(0);    
            // Twilio End

        }
    }

    // Configure the application user manager used in this application. UserManager is defined in ASP.NET Identity and is used by the application.
    /// <summary>
    /// Class ApplicationUserManager.
    /// </summary>
    public class ApplicationUserManager : UserManager<ApplicationUser>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationUserManager"/> class.
        /// </summary>
        /// <param name="store">The store.</param>
        public ApplicationUserManager(IUserStore<ApplicationUser> store)
            : base(store)
        {
        }

        /// <summary>
        /// Creates the specified options.
        /// </summary>
        /// <param name="options">The options.</param>
        /// <param name="context">The context.</param>
        /// <returns>ApplicationUserManager.</returns>
        //    public static ApplicationUserManager Create(IdentityFactoryOptions<ApplicationUserManager> options, IOwinContext context) 
        //    {
        //        var userStore = new UserStore();
        //        var manager = new ApplicationUserManager(userStore as IUserStore<ApplicationUser>);
        //        // Configure validation logic for usernames
        //        manager.UserValidator = new UserValidator<ApplicationUser>(manager)
        //        {
        //            AllowOnlyAlphanumericUserNames = false,
        //            RequireUniqueEmail = true
        //        };

        //        // Configure validation logic for passwords
        //        manager.PasswordValidator = new PasswordValidator
        //        {
        //            RequiredLength = 8,
        //            RequireNonLetterOrDigit = false,
        //            RequireDigit = true,
        //            RequireLowercase = true,
        //            RequireUppercase = true,
        //        };

        //        // Configure user lockout defaults
        //        manager.UserLockoutEnabledByDefault = true;
        //        manager.DefaultAccountLockoutTimeSpan = TimeSpan.FromMinutes(5); //duration of log on
        //        manager.MaxFailedAccessAttemptsBeforeLockout = 5;

        //        // Register two factor authentication providers. This application uses Phone and Emails as a step of receiving a code for verifying the user
        //        // You can write your own provider and plug it in here.
        //        manager.RegisterTwoFactorProvider(GlobalStrings.IdentityConfig_PhoneCode, new PhoneNumberTokenProvider<ApplicationUser>
        //        {
        //            MessageFormat = GlobalStrings.IdentityConfig_YourSecurityCode
        //        });
        //        manager.RegisterTwoFactorProvider(GlobalStrings.IdentityConfig_EmailCode, new EmailTokenProvider<ApplicationUser>
        //        {
        //            Subject = GlobalStrings.IdentityConfig_SecurityCode,
        //            BodyFormat = GlobalStrings.IdentityConfig_YourSecurityCode
        //        });
        //        manager.EmailService = new EmailService();
        //        manager.SmsService = new SmsService();
        //        var dataProtectionProvider = options.DataProtectionProvider;
        //        if (dataProtectionProvider != null)
        //        {
        //            manager.UserTokenProvider = 
        //                new DataProtectorTokenProvider<ApplicationUser>(dataProtectionProvider.Create("ASP.NET Identity"));
        //        }
        //        return manager;
        //    }
        //}

        public static ApplicationUserManager Create(IdentityFactoryOptions<ApplicationUserManager> options, IOwinContext context)
        {
            var manager = new ApplicationUserManager(new UserStore<ApplicationUser>(context.Get<ApplicationDbContext>()));
            // Configure validation logic for usernames
            manager.UserValidator = new UserValidator<ApplicationUser>(manager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true
            };

            // Configure validation logic for passwords
            manager.PasswordValidator = new CustomPasswordValidator(8);


            // Configure user lockout defaults
            manager.UserLockoutEnabledByDefault = true;
            manager.DefaultAccountLockoutTimeSpan = TimeSpan.FromMinutes(5);
            manager.MaxFailedAccessAttemptsBeforeLockout = 5;

            manager.RegisterTwoFactorProvider(GlobalStrings.Account_VerifyCode_Phone, new PhoneNumberTokenProvider<ApplicationUser>
            {
                MessageFormat = "Ваш секретный код для портала Attis: {0}"
            });
            manager.RegisterTwoFactorProvider(GlobalStrings.Account_VerifyCode_Email, new EmailTokenProvider<ApplicationUser>
            {
                Subject = "Секретный код",
                BodyFormat = "Ваш секретный код для портала Attis: {0}"
            });
            manager.EmailService = new EmailService();
            manager.SmsService = new SmsService();
            var dataProtectionProvider = options.DataProtectionProvider;
            if (dataProtectionProvider != null)
            {
                manager.UserTokenProvider =
                    new DataProtectorTokenProvider<ApplicationUser>(dataProtectionProvider.Create("ASP.NET Identity"));
            }
            return manager;
        }
    }

    // Configure the application sign-in manager which is used in this application.
    /// <summary>
    /// Class ApplicationSignInManager.
    /// </summary>
    public class ApplicationSignInManager : SignInManager<ApplicationUser, string>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationSignInManager"/> class.
        /// </summary>
        /// <param name="userManager">The user manager.</param>
        /// <param name="authenticationManager">The authentication manager.</param>
        public ApplicationSignInManager(ApplicationUserManager userManager, IAuthenticationManager authenticationManager)
            : base(userManager, authenticationManager)
        {
        }

        /// <summary>
        /// Creates the user identity asynchronous.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>Task&lt;ClaimsIdentity&gt;.</returns>
        public override Task<ClaimsIdentity> CreateUserIdentityAsync(ApplicationUser user)
        {
            return user.GenerateUserIdentityAsync((ApplicationUserManager)UserManager);
        }

        /// <summary>
        /// Creates the specified options.
        /// </summary>
        /// <param name="options">The options.</param>
        /// <param name="context">The context.</param>
        /// <returns>ApplicationSignInManager.</returns>
        public static ApplicationSignInManager Create(IdentityFactoryOptions<ApplicationSignInManager> options, IOwinContext context)
        {
            return new ApplicationSignInManager(context.GetUserManager<ApplicationUserManager>(), context.Authentication);
        }
    }
}
