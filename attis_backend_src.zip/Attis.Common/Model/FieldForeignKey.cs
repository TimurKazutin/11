﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-17-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-18-2014
// ***********************************************************************
// <copyright file="FieldForeignKey.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Controls namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Xml.Serialization;
    using Lawyers.Common.Interfaces;

    /// <summary>
    /// Class FieldForeignKey.
    /// </summary>
    [XmlType]
    public class FieldForeignKey : FieldPrimaryKey
    {
        /// <summary>
        /// Gets or sets the name of the table.
        /// </summary>
        /// <value>The name of the table.</value>
        [XmlAttribute(AttributeName = "baseTable")]
        public string TableName { get; set; }

        /// <summary>
        /// Gets or sets the name of the field.
        /// </summary>
        /// <value>The name of the field.</value>
        [XmlAttribute(AttributeName = "baseField")]
        public string FieldName { get; set; }
    }
}
