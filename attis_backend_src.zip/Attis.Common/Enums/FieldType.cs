﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 11-02-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-02-2014
// ***********************************************************************
// <copyright file="FieldType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    /// <summary>
    /// Enum FieldType
    /// </summary>
    public enum FieldType
    {
        /// <summary>
        /// The none
        /// </summary>
        None,
        /// <summary>
        /// The primary key
        /// </summary>
        PrimaryKey,
        /// <summary>
        /// The foreign key
        /// </summary>
        ForeignKey
    }
}
