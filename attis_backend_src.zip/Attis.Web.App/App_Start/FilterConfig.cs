﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 03-10-2015
// ***********************************************************************
// <copyright file="FilterConfig.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The App namespace.
/// </summary>
namespace Lawyers.Web.App
{
    using System.Net;
    using System.Web;
    using System.Web.Mvc;

    /// <summary>
    /// Class FilterConfig.
    /// </summary>
    public class FilterConfig
    {
        /// <summary>
        /// Registers the global filters.
        /// </summary>
        /// <param name="filters">The filters.</param>
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            //filters.Add(new CheckForDownPage());    //enable maintenance
        }
    }
    public class CheckForDownPage : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var path = System.Web.Hosting.HostingEnvironment.MapPath("~/down.htm");
            string ip = HttpContext.Current.Request.UserHostAddress;

            if (System.IO.File.Exists(path) && (!(ip == "::1" || ip == "178.16.35.231")))
            {
                filterContext.HttpContext.Response.Clear();
                filterContext.HttpContext.Response.Redirect("~/down.htm");
                return;
            }

            base.OnActionExecuting(filterContext);
        }
    }
}
