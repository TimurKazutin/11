﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-16-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-16-2014
// ***********************************************************************
// <copyright file="IFieldForeignKey.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Interfaces namespace.
/// </summary>
namespace Lawyers.Common.Interfaces
{
    /// <summary>
    /// Interface IFieldForeignKey
    /// </summary>
    public interface IFieldForeignKey : IFieldPrimaryKey
    {
        /// <summary>
        /// Gets or sets the name of the table.
        /// </summary>
        /// <value>The name of the table.</value>
        string TableName { get; set; }

        /// <summary>
        /// Gets or sets the name of the field.
        /// </summary>
        /// <value>The name of the field.</value>
        string FieldName { get; set; }
    }
}
