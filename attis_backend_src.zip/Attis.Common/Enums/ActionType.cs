﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-16-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-16-2014
// ***********************************************************************
// <copyright file="ActionType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    using System.Xml.Serialization;

    /// <summary>
    /// Enum ActionType
    /// </summary>
    public enum ActionType
    {
        /// <summary>
        /// The read only
        /// </summary>
        [XmlEnum("read_only")]
        ReadOnly,
        /// <summary>
        /// The mandatory
        /// </summary>
        [XmlEnum("mandatory")]
        Mandatory,
        /// <summary>
        /// The visible
        /// </summary>
        [XmlEnum("visible")]
        Visible,
        /// <summary>
        /// The mask
        /// </summary>
        [XmlEnum("set_mask")]
        Mask,
        /// <summary>
        /// The list
        /// </summary>
        [XmlEnum("set_list")]
        List,
        /// <summary>
        /// The value
        /// </summary>
        [XmlEnum("set_value")]
        Value,
        /// <summary>
        /// The message
        /// </summary>
        [XmlEnum("show_msg")]
        Message,
        /// <summary>
        /// The link
        /// </summary>
        [XmlEnum("link")]
        Link,
        /// <summary>
        /// The link stored procedure
        /// </summary>
        [XmlEnum("link_storedProcedure")]
        LinkStoredProcedure,
        /// <summary>
        /// The filter
        /// </summary>
        [XmlEnum("filter")]
        Filter,
        /// <summary>
        /// The database check
        /// </summary>
        [XmlEnum("check_db")]
        DbCheck,
        /// <summary>
        /// The result
        /// </summary>
        [XmlEnum(Name = "result")]
        Result
    }
}
