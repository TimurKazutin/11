﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 05-07-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 05-12-2015
// ***********************************************************************
// <copyright file="TableFilters.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Data namespace.
/// </summary>
namespace Lawyers.Engine.Data
{
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Class TableFilters.
    /// </summary>
    public class TableFilters : List<TableFilter>
    {
        /// <summary>
        /// Gets the filter string.
        /// </summary>
        /// <value>The filter string.</value>
        public string FilterString
        {
            get
            {
                return string.Join(" and ", this.Select(i => i.FilterString));
            }
        }
    }
}
