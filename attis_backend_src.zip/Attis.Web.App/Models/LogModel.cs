﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lawyers.Web.App.Models
{
    public class LogModel
    {
        public int LogId { get; set; }
        public string LogText { get; set; }
        public DateTime? LogDate { get; set; }
        public string LogDateString { get; set; }
        public string LogSection { get; set; }
        public string LogSourceUserId { get; set; }
        public string LogTargetUserId { get; set; }
        public string LogDocId { get; set; }
        public string LogDocTable { get; set; }
    }
}