﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-23-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-18-2014
// ***********************************************************************
// <copyright file="Field.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Data namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using Lawyers.Common.Enums;

    /// <summary>
    /// Class Field.
    /// </summary>
    public class Field
    {
        /// <summary>
        /// Gets the type of the data.
        /// </summary>
        /// <value>The type of the data.</value>
        public DataType DataType { get; private set; }

        /// <summary>
        /// Gets the type.
        /// </summary>
        /// <value>The type.</value>
        public FieldType Type { get; private set; }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; private set; }

        /// <summary>
        /// Gets the size.
        /// </summary>
        /// <value>The size.</value>
        public int Size { get; private set; }

        /// <summary>
        /// Gets the default value.
        /// </summary>
        /// <value>The default value.</value>
        public string DefaultValue { get; private set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Field"/> is editable.
        /// </summary>
        /// <value><c>true</c> if editable; otherwise, <c>false</c>.</value>
        public bool Editable { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Field"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="type">The type.</param>
        /// <param name="fieldType">Type of the field.</param>
        /// <param name="size">The size.</param>
        /// <param name="defaultValue">The default value.</param>
        public Field(string name, DataType type, FieldType fieldType, int size, string defaultValue)
        {
            this.Name = name;
            this.DataType = type;
            this.Type = fieldType;
            this.Size = size;
            this.DefaultValue = defaultValue;
            this.Editable = this.Type != FieldType.PrimaryKey;
        }
    }
}
