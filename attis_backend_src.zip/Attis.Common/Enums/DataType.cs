﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-16-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-16-2014
// ***********************************************************************
// <copyright file="DataType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    using System.Xml.Serialization;

    /// <summary>
    /// Enum DataType
    /// </summary>
    public enum DataType
    {
        /// <summary>
        /// The none
        /// </summary>
        [XmlIgnore]
        None,
        /// <summary>
        /// The number
        /// </summary>
        [XmlEnum(Name = "NUMBER")]
        Numeric,
        /// <summary>
        /// The integer
        /// </summary>
        [XmlEnum(Name = "integer")]
        Integer,
        /// <summary>
        /// The integer
        /// </summary>
        [XmlEnum(Name = "int4")]
        Int4,
        /// <summary>
        /// The integer
        /// </summary>
        [XmlEnum(Name = "int2")]
        Int2,
        /// <summary>
        /// The number
        /// </summary>
        [XmlEnum(Name = "numeric")]
        Decimal,

        /// <summary>
        /// The character
        /// </summary>
        [XmlEnum(Name = "CHAR")]
        Char,
        /// <summary>
        /// The table
        /// </summary>
        [XmlEnum(Name = "TABLE")]
        Table,
        /// <summary>
        /// The date
        /// </summary>
        [XmlEnum(Name = "DATE")]
        Date,
        /// <summary>
        /// The varchar
        /// </summary>
        [XmlEnum(Name = "VARCHAR2")]
        Varchar,
        /// <summary>
        /// The nvarchar
        /// </summary>
        [XmlEnum(Name = "NVARCHAR2")]
        NVarchar,
        /// <summary>
        /// The character
        /// </summary>
        [XmlEnum(Name = "bpchar")]
        Char_,
        /// <summary>
        /// The date
        /// </summary>
        [XmlEnum(Name = "date")]
        Date_,
        /// <summary>
        /// The date
        /// </summary>
        [XmlEnum(Name = "timestamp")]
        DateTime,
        /// <summary>
        /// The varchar
        /// </summary>
        [XmlEnum(Name = "varchar")]
        Varchar_
    }
}
