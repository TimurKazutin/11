﻿
namespace Lawyers.Common.Metadata
{
	using System.Xml.Serialization;

	public class MetaPrimaryKey
	{
		[XmlAttribute]
		public string Name { get; set; }
	}
}
