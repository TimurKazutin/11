﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 03-10-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 03-10-2015
// ***********************************************************************
// <copyright file="ErrorController.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Controllers namespace.
/// </summary>
namespace Lawyers.Web.App.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;

    /// <summary>
    /// Class ErrorController.
    /// </summary>
    public class ErrorController : Controller
    {

        /// <summary>
        /// Indexes the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>ActionResult.</returns>
        public ActionResult Index(int id)
        {
            return View(id);
        }

        /// <summary>
        /// Releases unmanaged resources and optionally releases managed resources.
        /// </summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources.</param>
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }
    }
}