﻿using System.ComponentModel;

namespace Lawyers.Web.App.Models.Enums
{
    public enum NotificationType
    {
        [Description("Запрос на согласование документа клиента")]
        RequestApprovalReportGgup,
        [Description("Запрос на корректировку документа клиента")]
        RequestEditReportGgup,
        [Description("Запрос на согласование ранее отклоненного документа клиента")]
        RequestApprovalPreviouslyRejectedReportGgup,
        [Description("Заявка на согласование профиля клиента")]
        RequestApprovalProfile,
        [Description("Заявка на внесение изменений данных в профиле клиента")]
        RequestEditProfile,
        [Description("Ваша учетная запись заблокирована Торговой площадкой")]
        AccountLockedTka,
        [Description("Ваша учетная запись разблокирован Торговой площадкой")]
        AccountUnlockedTka,
        [Description("Ваша учетная запись заблокированна администрацией веб-портала &laquo;Е-адвокатура&raquo;")]
        AccountLockedWeb,
        [Description("Ваша учетная запись разблокирована администрацией веб-портала &laquo;Е-адвокатура&raquo;")]
        AccountUnlockedWeb,
        [Description("Запрос на согласование Заявки согласован")]
        RequestApprovalReportGgupAccepted,
        [Description("Запрос на согласование Заявки отказано")]
        RequestApprovalReportGgupRejected,
        [Description("Запрос на корректировку Заявки согласован")]
        RequestEditReportGgupAccepted,
        [Description("Запрос на корректировку Заявки отклонен")]
        RequestEditReportGgupRejected,
        [Description("Запрос на согласование откорректированного Заявки")]
        RequestApprovalAdjustedReportGgup,
        [Description("Запрос на согласование откорректированного Заявки согласован")]
        RequestApprovalAdjustedReportGgupAccepted,
        [Description("Запрос на согласование откорректированного Заявки отклонен")]
        RequestApprovalAdjustedReportGgupRejected,
        [Description("Запрос на согласование ранее отклоненного Заявки согласован")]
        RequestApprovalPreviouslyRejectedReportGgupAccepted,
        [Description("Запрос на согласование ранее отклоненного Заявки отклонен")]
        RequestApprovalPreviouslyRejectedReportGgupRejected,
        
        [Description("Заявка на согласование профиля клиента утверждена")]
        RequestApprovalProfileAccepted,
        [Description("Заявка на согласование профиля клиента отказано")]
        RequestApprovalProfileRejected,
        [Description("Заявка на внесение изменений данных в профиле клиента утверждена")]
        RequestEditProfileAccepted,
        [Description("Заявка на внесение изменений данных в профиле клиента отказано")]
        RequestEditProfileRejected,
        
        [Description("Пользователь заблокирован администрацией веб-портала &laquo;Торговая площадка&raquo;")]
        AccountUserLocked,
        [Description("Заявка Забронированa")]
        DebtReserved,
        [Description("Заявка ok")]
        DebtFinal,
        [Description("Пользователь разблокирован администрацией веб-портала &laquo;Торговая площадка&raquo;")]
        AccountUserUnlocked,

        [Description("Ответ на предложение")]
        NewBid,

        [Description("Уведомление о новом предложении")]
        NewOffer = 1,

        [Description("Уведомление о принятии предложения")]
        AcceptOffer,

        [Description("Уведомление об отклонении предложения")]
        DeclineOffer,

        [Description("новая валидацийя")]
        NewValid,
        [Description("Новая Уведомление о Заявке на перевозку")]
        NewCourierOffer = 6,
        [Description("Принятие перевозки")]
        CourierAccept = 7,
        [Description("Отказ от перевозки")]
        CourierDecline = 8,
        [Description("Выбор перевозчика")]
        CourierSelect = 9,
        NewBrokerOffer = 10,
        [Description("Принятие перевозки")]
        BrokerAccept = 12,
        [Description("Отказ от перевозки")]
        BrokerDecline = 13,
        [Description("Выбор перевозчика")]
        BrokerSelect = 14,
        [Description("Выбор перевозчика")]
        SignContract = 15,
        [Description("New user")]
        NewUser = 16,
        [Description("insurance request")]
        insuranceRequest = 20,
        [Description("insurance approved")]
        insuranceApproved = 21,
        [Description("Insurance Document Request")]
        insuranceDocRequest = 22,
        [Description("insurance signed")]
        insuranceSigned = 23,
    }
}