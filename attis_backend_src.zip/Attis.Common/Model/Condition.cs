﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-19-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 04-27-2015
// ***********************************************************************
// <copyright file="Condition.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Security.Claims;
	using System.Xml.Serialization;
	using Lawyers.Common.Enums;

    /// <summary>
    /// Class Condition.
    /// </summary>
    [XmlType]
	public class Condition
	{
		/// <summary>
		/// The _condition type
		/// </summary>
		private ConditionItemType? _conditionType;

		/// <summary>
		/// The _operation type
		/// </summary>
		private ConditionOperationType? _operationType;

		/// <summary>
		/// Gets or sets the type of the condition.
		/// </summary>
		/// <value>The type of the condition.</value>
		[XmlAttribute(AttributeName = "condition")]
		public ConditionItemType ConditionType
		{
			get { return this._conditionType ?? ConditionItemType.None; }
			set { this._conditionType = value; }
		}

		/// <summary>
		/// Gets or sets the type.
		/// </summary>
		/// <value>The type.</value>
		[XmlAttribute(AttributeName = "type")]
		public ConditionType Type { get; set; }

		/// <summary>
		/// Gets or sets the type of the operation.
		/// </summary>
		/// <value>The type of the operation.</value>
		[XmlAttribute(AttributeName = "operation")]
		public ConditionOperationType OperationType
		{
			get { return this._operationType ?? ConditionOperationType.None; }
			set { this._operationType = value; }
		}

		/// <summary>
		/// Gets or sets the widget.
		/// </summary>
		/// <value>The widget.</value>
		[XmlAttribute(AttributeName = "widget")]
		public string Widget { get; set; }

		/// <summary>
		/// Gets or sets the widget destination.
		/// </summary>
		/// <value>The widget destination.</value>
		[XmlAttribute(AttributeName = "widget_dest")]
		public string WidgetDestination { get; set; }

		/// <summary>
		/// Gets or sets the value.
		/// </summary>
		/// <value>The value.</value>
		[XmlAttribute(AttributeName = "value")]
		public string Value { get; set; }

		/// <summary>
		/// Gets or sets the name of the procedure.
		/// </summary>
		/// <value>The name of the procedure.</value>
		[XmlAttribute(AttributeName = "proc_name")]
		public string ProcedureName { get; set; }

		/// <summary>
		/// Gets or sets the widget value.
		/// </summary>
		/// <value>The widget value.</value>
		[XmlAttribute(AttributeName = "widget_value")]
		public string WidgetValue { get; set; }

		/// <summary>
		/// Gets or sets the name of the array table.
		/// </summary>
		/// <value>The name of the array table.</value>
		[XmlAttribute(AttributeName = "array_TableName")]
		public string ArrayTableName { get; set; }

		/// <summary>
		/// Gets or sets the array row count.
		/// </summary>
		/// <value>The array row count.</value>
		[XmlAttribute(AttributeName = "array_RowCount")]
		public string ArrayRowCount { get; set; }

		/// <summary>
		/// Gets or sets the children.
		/// </summary>
		/// <value>The children.</value>
		[XmlElement(ElementName = "condition")]
		public List<Condition> Children { get; set; }

		/// <summary>
		/// Determines whether the specified widget name contains widget.
		/// </summary>
		/// <param name="widgetName">Name of the widget.</param>
		/// <returns><c>true</c> if the specified widget name contains widget; otherwise, <c>false</c>.</returns>
		public bool ContainsWidget(string widgetName)
		{
			bool result = false;

			if ((!string.IsNullOrEmpty(Widget) && Widget == widgetName)
				|| (!string.IsNullOrEmpty(WidgetValue) && WidgetValue == widgetName)) /// TODO: check all possible situations
			{
				result = true;
			}
			else
			{
				foreach (Condition child in Children)
				{
					if (child.ContainsWidget(widgetName))
					{
						result = true;
						break;
					}
				}
			}

			return result;
		}

		// Maximka code
		/// <summary>
		/// Checks the specified document.
		/// </summary>
		/// <param name="document">The document.</param>
		/// <param name="dataSet">The data set.</param>
		/// <param name="widget">The widget.</param>
		/// <param name="record">The record.</param>
		/// <param name="value">The value.</param>
		/// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
		public bool Check(Document document, ClaimsIdentity identity, SortedDictionary<string, int> FieldIndexes, Widget widget, object[] record, object value)
		{
			if (Type == Lawyers.Common.Enums.ConditionType.Brackets || Type == Lawyers.Common.Enums.ConditionType.Root)
			{
				if (ConditionType == ConditionItemType.Or)
				{
					foreach (var c in Children)
					{
						if (c.Check(document, identity, FieldIndexes, widget, record, value))
							return true;
					}
					return false;
				}
				else
				{
					foreach (var c in Children)
					{
						if (!c.Check(document, identity, FieldIndexes, widget, record, value))
							return false;
					}
					return true;
				}
			}
			else
			{
				object valueToCompare = null;
				switch (Type)
				{
					case Common.Enums.ConditionType.Condition:
						valueToCompare = this.Value;

						if (this.Widget == "function:auth_role()")
						{
							value = identity.Claims.Where(c => c.Type == "user_role").First().Value;
                        }
						else
						{
							if (this.Widget != widget.Name)
							{
								Widget wgtValue = document.FindChildByName(this.Widget);
								value = wgtValue.Value ?? wgtValue.DefaultValue;
							}
						}

						if (valueToCompare == null && !string.IsNullOrEmpty(this.Widget))
						{
							Widget wgtValue = document.FindChildByName(this.Widget);

							if (!string.IsNullOrEmpty(wgtValue.TableName))
							{
								valueToCompare = record != null && wgtValue.Field != null && FieldIndexes.ContainsKey(wgtValue.Field) ? record[FieldIndexes[wgtValue.Field]] ?? wgtValue.Value : wgtValue.Value ?? wgtValue.DefaultValue;
							}
							else
							{
								valueToCompare = wgtValue.Value ?? wgtValue.DefaultValue;
							}
						}
						break;
					case Common.Enums.ConditionType.Condition_widget:
						Widget widgetValue = document.FindChildByName(this.WidgetValue);

						if (!string.IsNullOrEmpty(widgetValue.TableName))
						{
							valueToCompare = record != null && widgetValue.Field != null ? record[FieldIndexes[widgetValue.Field]] : widgetValue.Value ?? widgetValue.DefaultValue;
						}
						else
						{
							valueToCompare = widgetValue.Value ?? widgetValue.DefaultValue;
						}

						Widget widgetSrc = document.FindChildByName(this.Widget);
						object valueSrc = null;

						if (!string.IsNullOrEmpty(widgetSrc.TableName))
						{
							valueSrc = record != null && widgetSrc.Field != null ? record[FieldIndexes[widgetSrc.Field]] : widgetSrc.Value ?? widgetSrc.DefaultValue;
						}
						else
						{
							valueSrc = widgetSrc.Value ?? widgetSrc.DefaultValue;
						}

						return this.Operation(valueSrc, valueToCompare);
					default:
						break;
				}

				return this.Operation(value, valueToCompare);
			}
		}

		/// <summary>
		/// Operations the specified value.
		/// </summary>
		/// <param name="value">The value.</param>
		/// <param name="valueToCompare">The value to compare.</param>
		/// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
		private bool Operation(object value, object valueToCompare)
		{
			switch (OperationType)
			{
				case ConditionOperationType.Equal:
					return Convert.ToString(valueToCompare) == Convert.ToString(value);
				case ConditionOperationType.NotEqual:
					return Convert.ToString(valueToCompare) != Convert.ToString(value);
				case ConditionOperationType.Blank:
					return String.IsNullOrWhiteSpace(Convert.ToString(valueToCompare));
				case ConditionOperationType.NotBlank:
					return !String.IsNullOrWhiteSpace(Convert.ToString(valueToCompare));
				case ConditionOperationType.Greater:
					{
						if (valueToCompare == null || value == null)
							return false;
						else
						{
							if (valueToCompare.GetType() == typeof(DateTime))
							{
								return Convert.ToDateTime(value) > Convert.ToDateTime(valueToCompare);
							}
							else
							{
								if (valueToCompare.GetType() == typeof(Decimal))
								{
									return Convert.ToDecimal(value) > Convert.ToDecimal(valueToCompare);
								}
                                else if (valueToCompare.GetType() == typeof(Int16) || valueToCompare.GetType() == typeof(Int32))
                                {
                                    return Convert.ToInt32(value) > Convert.ToInt32(valueToCompare);
                                }
                                else
								{
									// something else
								}
							}
						}
						return true;
					}
				case ConditionOperationType.GreaterOrEqual:
					{
						if (valueToCompare == null || value == null)
							return false;
						else
						{
							if (valueToCompare.GetType() == typeof(DateTime))
							{
								return Convert.ToDateTime(value) >= Convert.ToDateTime(valueToCompare);
							}
							else
							{
								if (valueToCompare.GetType() == typeof(Decimal))
								{
									return Convert.ToDecimal(value) >= Convert.ToDecimal(valueToCompare);
								}
                                else if (valueToCompare.GetType() == typeof(Int16) || valueToCompare.GetType() == typeof(Int32))
                                {
                                    return Convert.ToInt32(value) >= Convert.ToInt32(valueToCompare);
                                }
                                else
								{
									// something else
								}
							}
						}
						return true;
					}
				case ConditionOperationType.Less:
					{
						if (valueToCompare == null || value == null)
							return false;
						else
						{
							if (valueToCompare.GetType() == typeof(DateTime))
							{
								return Convert.ToDateTime(value) < Convert.ToDateTime(valueToCompare);
							}
							else
							{
								if (valueToCompare.GetType() == typeof(Decimal))
								{
									return Convert.ToDecimal(value) < Convert.ToDecimal(valueToCompare);
								}
                                else if (valueToCompare.GetType() == typeof(Int16) || valueToCompare.GetType() == typeof(Int32))
                                {
                                    return Convert.ToInt32(value) < Convert.ToInt32(valueToCompare);
                                }
                                else
								{
									// something else
								}
							}
						}
						return true;
					}
				case ConditionOperationType.LessOrEqual:
					{
						if (valueToCompare == null || value == null)
							return false;
						else
						{
							if (valueToCompare.GetType() == typeof(DateTime))
							{
								return Convert.ToDateTime(value) <= Convert.ToDateTime(valueToCompare);
							}
							else
							{
								if (valueToCompare.GetType() == typeof(Decimal))
								{
									return Convert.ToDecimal(value) <= Convert.ToDecimal(valueToCompare);
								}
                                else if (valueToCompare.GetType() == typeof(Int16) || valueToCompare.GetType() == typeof(Int32))
                                {
                                    return Convert.ToInt32(value) <= Convert.ToInt32(valueToCompare);
                                }
                                else
								{
									// something else
								}
							}
						}
						return true;
					}
				default:
					return false;
			}
		}
	}
}
