﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-11-2014
// ***********************************************************************
// <copyright file="Startup.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Web.Mvc;
using Microsoft.Owin;
using Owin;
using Lawyers.Common.Model;
using Microsoft.AspNet.SignalR;

[assembly: OwinStartupAttribute(typeof(Lawyers.Web.App.Startup))]
namespace Lawyers.Web.App
{
    /// <summary>
    /// Class Startup.
    /// </summary>
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);

            //var idProvider = new CustomUserIdProvider();
            //GlobalHost.DependencyResolver.Register(typeof(IUserIdProvider), () => idProvider);
        }
    }
}
