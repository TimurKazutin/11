﻿namespace Lawyers.Database.Postgres
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;
    using Common.Classes;
    using Common.Enums;
    using Common.Interfaces;
    using Common.Metadata;
    using Common.Model;
    using Npgsql;
    using NpgsqlTypes;

    public class PG_DataProvider : IDataProvider
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly NpgsqlConnection _connection;

        public bool IsDeveloper { get; private set; }

        public string lastError { get; private set; }

        private static readonly object SyncRoot = new object();

        public object Locker
        {
            get { return SyncRoot; }
        }

        public ImageFile GetFileByGuid(Guid id)
        {
            ImageFile imgFile = null;
            lock (Locker)
            {
                var cmd = _connection.CreateCommand();
                cmd.CommandText =
                    string.Format(
                        @"select id, doc_guid, img_file_name, doc_img_date, doc_img_scan from DOCIMAGES where doc_img_status=1 and doc_guid='{0}'",
                        id);
                var reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    imgFile = new ImageFile()
                    {
                        ID = reader.GetInt32(0),
                        //DocGuid = Guid.Parse(reader.GetString(1)),
                        Name = reader.GetString(2),
                        Date = reader.GetDateTime(3)
                    };

                    var blob = reader.GetStream(4);
                    imgFile.Image = new MemoryStream();
                    blob.CopyTo(imgFile.Image);
                    imgFile.Image.Position = 0;
                }

                reader.Close();
            }
            return imgFile;
        }

        public PG_DataProvider(string connStr)
        {
            IsDeveloper = false;
            //_connection = new PgSqlConnection(connStr);

            //for developer version
            connStr = "host=localhost;Port=5432;database=attis;user id=postgres;password=HA;Client Encoding=utf8";
            //connStr = "host=localhost;Port=5433;database=attis;user id=postgres;password=WRm4mg;Client Encoding=utf8";
            //IsDeveloper = true;
            lastError = "";
            _connection = new NpgsqlConnection(connStr);
            _connection.Open();
        }

        public void clearError()
        {
            lastError = "";
        }

        public IDataReader RunQuery(string query, params object[] parameters)
        {
            lock (Locker) { 
                var pgCommand = new NpgsqlCommand(query) { Connection = _connection };
            lastError = "";

            for (var i = 0; i < parameters.Length; i++)
            {
                var param = new NpgsqlParameter("p" + i.ToString(), parameters[i]);
                pgCommand.Parameters.Add(param);
            }

            IDataReader r = null;

            try
            {
                r = pgCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                log.Error(ex+ query);
            }

            return r;
            }
        }

        public int RunNonQuery(string query, params object[] parameters)
        {
            lock (Locker)
            {
                var cmd = _connection.CreateCommand();
                cmd.CommandText = query;
                lastError = "";

                for (var i = 0; i < parameters.Length; i++)
                {
                    var param = new NpgsqlParameter("p" + i.ToString(), parameters[i]);
                    cmd.Parameters.Add(param);
                }

                var r = -3;
                try
                {
                    r = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                    log.Error(ex + query);
                }

                return r;
            }
        }

        public int RunNonQuery(string query, object[] values, int[] paramIndexes, int[] pkIndexes, Field[] fields, out object paramOut)
        {
            query += " as pOut";
            lock (Locker)
            {
                var cmd = _connection.CreateCommand();
                cmd.CommandText = query;
                lastError = "";

                for (var i = 0; i < paramIndexes.Length; i++)
                {
                    var dtype = fields[paramIndexes[i]].DataType;
                    var param = new NpgsqlParameter("p" + paramIndexes[i].ToString(), GetPostgresDbType(dtype));

                    if (dtype == DataType.NVarchar || dtype == DataType.Varchar || dtype == DataType.Varchar_)
                    {
                        param.Size = fields[paramIndexes[i]].Size;
                    }

                    param.Value = values[paramIndexes[i]] ?? DBNull.Value;
                    cmd.Parameters.Add(param);
                }

                if (pkIndexes != null)
                {
                    for (var k = 0; k < pkIndexes.Length; k++)
                    {
                        var param = new NpgsqlParameter("pk" + pkIndexes[k], NpgsqlDbType.Integer)
                        {
                            Value = values[pkIndexes[k]]
                        };

                        cmd.Parameters.Add(param);
                    }
                }

                var pOut = new NpgsqlParameter("pOut", NpgsqlDbType.Integer) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(pOut);

                var res = -3;
                try
                {
                    res = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                    log.Error(ex + query);
                }

                paramOut = pOut.Value;

                if (res == -1 && lastError == "")
                {
                    res = 1;
                }

                return res;
            }
        }

        public int RunNonQuery(string query, object[] values, int[] paramIndexes, int[] pkIndexes, Field[] fields)
        {
            lock (Locker)
            {
                var cmd = _connection.CreateCommand();
                cmd.CommandText = query;
                lastError = "";

                for (var i = 0; i < paramIndexes.Length; i++)
                {
                    var dtype = fields[paramIndexes[i]].DataType;
                    var param = new NpgsqlParameter("p" + paramIndexes[i].ToString(), GetPostgresDbType(dtype));

                    if (dtype == DataType.NVarchar || dtype == DataType.Varchar || dtype == DataType.Varchar_)
                    {
                        param.Size = fields[paramIndexes[i]].Size;
                    }

                    if (values[paramIndexes[i]] == null)
                    {
                        param.Value = DBNull.Value;
                    }
                    else
                    {
                        param.Value = values[paramIndexes[i]];
                    }

                    cmd.Parameters.Add(param);
                }

                if (pkIndexes != null)
                {
                    for (var k = 0; k < pkIndexes.Length; k++)
                    {
                        var param = new NpgsqlParameter("pk" + pkIndexes[k].ToString(), NpgsqlDbType.Integer);

                        param.Value = values[pkIndexes[k]];
                        cmd.Parameters.Add(param);
                    }
                }

                var res = -3;

                try
                {
                    res = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                    log.Error(ex + query);
                }

                if (res == -1 && lastError == "")
                {
                    res = 1;
                }

                return res;
            }
        }

        public int RunScalarStoredProcedure(string query, params object[] parameters)
        {
            var cmd = new NpgsqlCommand(query)
            {
                Connection = _connection,
                CommandType = CommandType.StoredProcedure
            };

            lastError = "";

            for (var i = 0; i < parameters.Length; i++)
            {
                parameters[i] = parameters[i] ?? string.Empty;

                if (parameters[i] is string)
                {
                    cmd.Parameters.AddWithValue(parameters[i]).NpgsqlDbType = NpgsqlDbType.Varchar;
                    continue;
                }

                cmd.Parameters.AddWithValue(parameters[i]);
            }

            int r;

            try
            {
                var res = cmd.ExecuteScalar();
                r = (int)(res is DBNull ? 1 : (res ?? 1));
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("violates"))
                    r = -21;
                else
                    r = -10;
                lastError = ex.Message;
                log.Error(ex);
            }

            if (r == -1 && lastError == "")
                r = 1;

            return r;
        }

        public int RunScalar(string query)
        {
            lock (Locker)
            {
                var cmd = new NpgsqlCommand(query)
                {
                    Connection = _connection,
                    CommandType = CommandType.Text
                };

                lastError = "";

                int r;

                try
                {
                    var res = cmd.ExecuteScalar();
                    r = Convert.ToInt32(res ?? -3);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("violates"))
                        r = -21;
                    else
                        r = -10;
                    lastError = ex.Message;
                    log.Error(ex);
                }

                if (r == -1 && lastError == "")
                    r = 1;

                return r;
            }
        }

        public string RunQueryStr(string query)
        {
            lock (Locker)
            {
                var cmd = new NpgsqlCommand(query)
                {
                    Connection = _connection,
                    CommandType = CommandType.Text
                };

                lastError = "";

                string r;
                lock (Locker)
                    try
                    {
                        var res = cmd.ExecuteScalar();
                        r = res.ToString();
                    }
                    catch (Exception ex)
                    {
                        if (ex.Message.Contains("violates"))
                            r = "-21";
                        else
                            r = "-10";
                        lastError = ex.Message;
                        log.Error(ex);
                    }
                return r;
            }
        }

        public string RunNoStr(string query, params object[] parameters)
        {
            var cmd = new NpgsqlCommand(query)
            {
                Connection = _connection,
                CommandType = CommandType.Text
            };

            if (parameters.Length > 0)
            {
                var parm = new NpgsqlParameter("p0", parameters[0]);
                cmd.Parameters.Add(parm);
            }
            lastError = "";

            string r;

            try
            {
                var res = cmd.ExecuteScalar();
                r = res.ToString();
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("violates"))
                    r = "-21";
                else
                    r = "-10";
                lastError = ex.Message;
                log.Error(ex);
            }
            return r;
        }
        private NpgsqlDbType GetPostgresDbType(DataType dataType)
        {
            var result = NpgsqlDbType.Varchar;
            switch (dataType)
            {
                case DataType.Char:
                case DataType.Char_:
                    result = NpgsqlDbType.Char;
                    break;
                case DataType.Date:
                case DataType.Date_:
                case DataType.DateTime:
                    result = NpgsqlDbType.Date;
                    break;
                case DataType.Int2:
                case DataType.Int4:
                case DataType.Integer:
                    result = NpgsqlDbType.Integer;
                    break;
                case DataType.Decimal:
                case DataType.Numeric:
                    result = NpgsqlDbType.Numeric;
                    break;
                case DataType.Varchar:
                case DataType.Varchar_:
                case DataType.NVarchar:
                    result = NpgsqlDbType.Varchar;
                    break;
            }
            return result;
        }

        public TemplateDictionary GetTemplates()
        {
            var dictionary = new TemplateDictionary();
            var cmd = _connection.CreateCommand();
            cmd.CommandText = @"select t.id, t.template_xml, t.user_role from TEMPLATES t";
            var reader = cmd.ExecuteReader();

            var serializer = new XmlSerializer(typeof(Template));

            while (reader.Read())
            {
                var xml = reader["template_xml"].ToString();
                Template template;

                using (TextReader sr = new StringReader(xml))
                {
                    template = (Template)serializer.Deserialize(sr);
                }

                template.Document.SetParent(null);
                template.Document.SetChecks(template.Document);
                template.Roles = reader.GetInt32(2);
                dictionary.Add(template.Guid, template);
            }

            reader.Close();

            return dictionary;
        }

        /// <summary>
        /// Saves the picture.
        /// </summary>
        /// <param name="imgFile">The img file.</param>
        public void SaveFile(ImageFile imgFile)
        {
            lock (Locker)
            {
                lastError = "";
                var cmd = _connection.CreateCommand();
                cmd.CommandText =
                    @"insert into DOCIMAGES(DOC_GUID, IMG_FILE_NAME, DOC_IMG_STATUS, DOC_IMG_DATE, DOC_IMG_SCAN, DOC_WIDGET_ID) values(:pDocGuid, :pImgName, 1, :pDate, :pImgScan, :pDocWidgetId) returning ID as pOutID";

                if (imgFile.EntityId != null)
                {
                    var pDocGuid = new NpgsqlParameter("pDocGuid", imgFile.EntityId);
                    cmd.Parameters.Add(pDocGuid);
                }
                else
                {
                    var pDocGuid = new NpgsqlParameter("pDocGuid", imgFile.DocGuid.ToString("N"));
                    cmd.Parameters.Add(pDocGuid);
                }


                var pImgName = new NpgsqlParameter("pImgName", imgFile.Name);
                cmd.Parameters.Add(pImgName);

                var pDate = new NpgsqlParameter("pDate", imgFile.Date);
                cmd.Parameters.Add(pDate);

                var pImgScan = new NpgsqlParameter("pImgScan", NpgsqlDbType.Bytea) { Value = imgFile.Image.ToArray() };
                cmd.Parameters.Add(pImgScan);

                //var pImgScan = new NpgsqlParameter("pImgScan", NpgsqlDbType.Array | NpgsqlDbType.Text).Value = new[] { imgFile.Image.ToArray() };
                //cmd.Parameters.Add(pImgScan);

                var pDocWidgetId = new NpgsqlParameter("pDocWidgetId", imgFile.WidgetId);
                cmd.Parameters.Add(pDocWidgetId);

                var pOutID =
                    new NpgsqlParameter("pOutID", NpgsqlDbType.Integer) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(pOutID);

                var res = cmd.ExecuteNonQuery();

                imgFile.ID = res >= 0 ? Convert.ToInt32(pOutID.Value) : 0;
            }
        }

        public void UploadBlockDoc(ImageFile imgFile)
        {
            lastError = "";
            var cmd = _connection.CreateCommand();
            cmd.CommandText = @"update subjects_law_suppliers SET law_block_doc_base = :pFile WHERE subj_law_supplier_id = :pWhereValue returning subj_law_supplier_id as pOutID";

            var pFile = new NpgsqlParameter("pFile", NpgsqlDbType.Bytea) { Value = imgFile.Image.ToArray() };
            cmd.Parameters.Add(pFile);

            var pWhereValue = new NpgsqlParameter("pWhereValue", imgFile.ID);
            cmd.Parameters.Add(pWhereValue);

            var pOutID = new NpgsqlParameter("pOutID", NpgsqlDbType.Integer) { Direction = ParameterDirection.Output };
            cmd.Parameters.Add(pOutID);

            if (pOutID.Value != null)
            {
                imgFile.ID = cmd.ExecuteNonQuery() >= 0 ? Convert.ToInt32(pOutID.Value.ToString()) : 0;
            }
        }

        /// <summary>
        /// Gets the pictures.
        /// </summary>
        /// <param name="guid">The unique identifier.</param>
        /// <returns>List&lt;ImageFile&gt;.</returns>
        public List<ImageFile> GetFiles(Guid guid)
        {
            var result = new List<ImageFile>();

            lock (Locker)
            {
                var cmd = _connection.CreateCommand();
                cmd.CommandText = @"select id, doc_guid, img_file_name, doc_img_date, doc_widget_id from DOCIMAGES where doc_img_status=1 and doc_guid='" + guid.ToString("N") + "'";

                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var imgFile = new ImageFile()
                    {
                        ID = reader.GetInt32(0),
                        DocGuid = Guid.Parse(reader.GetString(1)),
                        Name = reader.GetString(2),
                        Date = reader.GetDateTime(3),
                        WidgetId = reader.GetString(4)
                    };

                    result.Add(imgFile);
                }

                reader.Close();
            }

            return result;
        }

        public List<ImageFile> GetFiles(string id, string widgetId)
        {
            var result = new List<ImageFile>();
            lock (Locker)
            {
                var cmd = _connection.CreateCommand();
                cmd.CommandText = @"select id, doc_guid, img_file_name, doc_img_date, doc_widget_id from DOCIMAGES where doc_img_status=1 and doc_guid='" + id + "' and doc_widget_id = '" + widgetId + "';";

                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var imgFile = new ImageFile()
                    {
                        ID = reader.GetInt32(0),
                        Name = reader.GetString(2),
                        Date = reader.GetDateTime(3),
                        WidgetId = reader.GetString(4)
                    };

                    result.Add(imgFile);
                }
                reader.Close();
            }
            return result;
        }

        public ImageFile GetFileByID(int id)
        {
            ImageFile imgFile = null;
            lock (Locker)
            {
                var cmd = _connection.CreateCommand();
                cmd.CommandText = @"select id, doc_guid, img_file_name, doc_img_date, doc_img_scan from DOCIMAGES where doc_img_status=1 and id=" + id.ToString();
                try
                {
                    var reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        imgFile = new ImageFile()
                        {
                            ID = reader.GetInt32(0),
                            //DocGuid = Guid.Parse(reader.GetString(1)),
                            Name = reader.GetString(2),
                            Date = reader.GetDateTime(3)
                        };

                        var blob = reader.GetStream(4);
                        imgFile.Image = new MemoryStream();
                        blob.CopyTo(imgFile.Image);
                        imgFile.Image.Position = 0;
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                    log.Error(ex);
                }
            }
            return imgFile;
        }

        public void DeleteFile(int id)
        {
            var cmd = _connection.CreateCommand();
            cmd.CommandText = @"delete from DOCIMAGES where id=" + id.ToString();
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Gets the reports.
        /// </summary>
        /// <returns>ReportDictionary.</returns>
        public ReportDictionary GetReports()
        {
            var dictionary = new ReportDictionary();
            var cmd = _connection.CreateCommand();
            cmd.CommandText = @"select t.id, t.Name, t.Template from REPORTS t";
            var reader = cmd.ExecuteReader();

            var serializer = new XmlSerializer(typeof(Report));

            while (reader.Read())
            {
                var xml = reader["template"].ToString();
                Report template;

                using (TextReader sr = new StringReader(xml))
                {
                    template = (Report)serializer.Deserialize(sr);
                }

                template.Name = reader.GetString(1);
                dictionary.Add(reader.GetInt32(0), template);
            }

            reader.Close();
            return dictionary;
        }


        /// <summary>
        /// Gets the database metadata.
        /// </summary>
        /// <returns>XDocument.</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public List<MetaTable> GetDatabaseMetadata()
        {
            var result = new List<MetaTable>();

            // get tables with comments
            var cmd = _connection.CreateCommand();
            cmd.CommandText = @"select ut.TABLE_NAME, utco.COMMENTS from user_tables ut left outer join user_tab_comments utco on utco.table_name = ut.TABLE_NAME union all
            select VIEW_NAME as TABLE_NAME, null AS COMMENTS from user_views order by TABLE_NAME";

            using (var reader = cmd.ExecuteReader())
                while (reader.Read())
                {
                    var table = new MetaTable() { Name = reader[0].ToString() };

                    if (!reader.IsDBNull(1))
                    {
                        table.Comment = reader[1].ToString();
                    }

                    result.Add(table);
                }

            // get table columns with comments
            cmd.CommandText = @"SELECT
               tc.TABLE_NAME,
               tc.COLUMN_NAME,
               tc.COLUMN_ID AS ID,
               tc.DATA_TYPE AS DataType,
               tc.DATA_LENGTH AS Length,
               tc.DATA_PRECISION AS Precision,
               tc.DATA_SCALE AS Scale,
               tc.NULLABLE AS Nullable,
               tc.CHAR_USED,
               tc.CHAR_LENGTH AS LengthInChars,
               cc.comments
            from   user_col_comments cc
            join   user_tab_columns  tc on  cc.column_name = tc.column_name and cc.table_name  = tc.table_name
            ORDER BY TABLE_NAME, ID";

            using (var reader = cmd.ExecuteReader())
                while (reader.Read())
                {
                    var table = result.First(t => t.Name == reader[0].ToString());
                    var column = new MetaColumn() { Name = reader[1].ToString(), DataType = reader[3].ToString(), Nullable = reader[7].ToString() == "Y" };

                    if (reader.GetInt32(9) > 0)
                    {
                        column.Size = reader[9].ToString();
                    }

                    if (!reader.IsDBNull(10))
                    {
                        column.Comment = reader[10].ToString();
                    }

                    table.Columns.Add(column);
                }

            // get table primary keys
            cmd.CommandText = @"select ucc.table_name, ucc.column_name, ucc.position from user_cons_columns ucc
            join user_constraints uc on uc.table_name = ucc.table_name and uc.constraint_name = ucc.constraint_name
            where uc.table_name not like 'BIN$%' and uc.constraint_type = 'P'";

            using (var reader = cmd.ExecuteReader())
                while (reader.Read())
                {
                    var table = result.First(t => t.Name == reader[0].ToString());
                    var pk = new MetaPrimaryKey() { Name = reader[1].ToString() };
                    table.PrimaryKeys.Add(pk);
                }

            cmd.CommandText = @"SELECT a.table_name, a.column_name, c_pk.table_name r_table_name, a_pk.column_name r_column_name
            FROM user_cons_columns a
            JOIN user_constraints c ON a.owner = c.owner AND a.constraint_name = c.constraint_name
            JOIN user_constraints c_pk ON c.r_owner = c_pk.owner AND c.r_constraint_name = c_pk.constraint_name
            join user_cons_columns a_pk ON a_pk.owner = c_pk.owner AND a_pk.constraint_name = c_pk.constraint_name
            WHERE c.constraint_type = 'R'
            order by table_name, column_name";

            using (var reader = cmd.ExecuteReader())
                while (reader.Read())
                {
                    var table = result.First(t => t.Name == reader[0].ToString());
                    var fk = new MetaForeignKey() { Name = reader[1].ToString(), Table = reader[2].ToString(), Column = reader[3].ToString() };
                    table.ForeignKeys.Add(fk);
                    reader.Close(); //roma
                }

            return result;
        }

        public string AddNewReport(string subjLawSupplId, string userId, string collegiumId, string beginDate, string endDate, string reportNumber)
        {

            lock (Locker)
            {
                lastError = "";

                var cmd = _connection.CreateCommand();

                //var month = DateTime.Now.Month.ToString();
                //var year = DateTime.Now.Year.ToString();
                //var daysInMonth = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);

                //cmd.CommandText = @"insert into rep_law_state_aid(law_collegium_id, rep_status, person_id, user_id, subj_law_supplier_id, rep_date_begin, rep_date_end)
                //    values(:pLawCollegiumId , 1, :pUserId, :pUserId, :pSubjLawSupplId, 
                //    '01." + month + "." + year + "'," +
                //    "'" + daysInMonth + "." + month + "." + year + "') returning rep_law_state_aid_id as pOutID";

                cmd.CommandText = "insert into rep_law_state_aid(law_collegium_id, rep_status, person_id, user_id, subj_law_supplier_id, rep_date_begin, rep_date_end, rep_number) values(:pLawCollegiumId , 1, :pUserId, :pUserId, :pSubjLawSupplId, :pBeginDate, :pEndDate, :pReportNumber) returning rep_law_state_aid_id as pOutID";

                var pUserId = new NpgsqlParameter("pUserId", NpgsqlDbType.Varchar) { Value = userId };
                cmd.Parameters.Add(pUserId);

                var pLawCollegiumId = new NpgsqlParameter("pLawCollegiumId", NpgsqlDbType.Integer) { Value = int.Parse(collegiumId) };
                cmd.Parameters.Add(pLawCollegiumId);

                var pSubjLawSupplId = new NpgsqlParameter("pSubjLawSupplId", NpgsqlDbType.Integer) { Value = int.Parse(subjLawSupplId) };
                cmd.Parameters.Add(pSubjLawSupplId);

                var pBeginDate = new NpgsqlParameter("pBeginDate", DateTime.Parse(beginDate));
                cmd.Parameters.Add(pBeginDate);

                var pEndDate = new NpgsqlParameter("pEndDate", DateTime.Parse(endDate));
                cmd.Parameters.Add(pEndDate);

                var pReportNumber = new NpgsqlParameter("pReportNumber", NpgsqlDbType.Varchar) { Value = reportNumber };
                cmd.Parameters.Add(pReportNumber);

                var pOutID = new NpgsqlParameter("pOutID", NpgsqlDbType.Integer);
                pOutID.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(pOutID);

                cmd.ExecuteNonQuery();

                return pOutID.Value != null ? pOutID.Value.ToString() : string.Empty;
            }
        }

        public DataTable RunQueryDataTable(string query, params object[] parameters)
        {
            var pgCommand = new NpgsqlCommand(query) { Connection = _connection };
            lastError = "";

            //var cmd = _connection.CreateCommand();
            //cmd.CommandText = query;
            //myDataAdapter.SelectCommand.Parameters.Add("DName", PgSqlType.VarChar, 15).Value = "DEVELOPMENT";
            //myDataAdapter.SelectCommand.Parameters.Add("DeptNo", NpgsqlDbType.Integer).Value = 50;

            for (var i = 0; i < parameters.Length; i++)
            {
                var param = new NpgsqlParameter("p" + i.ToString(), parameters[i]);
                pgCommand.Parameters.Add(param);
            }

            var sqlAdapter = new NpgsqlDataAdapter { SelectCommand = pgCommand };
            var dt = new DataTable();

            try
            {
                sqlAdapter.Fill(dt);
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                log.Error(ex);
            }

            return dt;
        }
    }
}
