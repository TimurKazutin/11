﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 11-05-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-07-2014
// ***********************************************************************
// <copyright file="TemplateDictionary.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class TemplateDictionary.
    /// </summary>
    public class TemplateDictionary : SortedDictionary<Guid, Template>
    {
    }
}
