﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 03-05-2015
// ***********************************************************************
// <copyright file="RouteConfig.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The App namespace.
/// </summary>
namespace Lawyers.Web.App
{
    using Common;
    using Helpers;
    using System;
    using System.Web.Mvc;
    using System.Web.Routing;

    /// <summary>
    /// Class RouteConfig.
    /// </summary>
    public class RouteConfig
    {
        /// <summary>
        /// Registers the routes.
        /// </summary>
        /// <param name="routes">The routes.</param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            //const string en = Cultures.EnglishCultureName;
            const string ru = Cultures.RussianCultureName;
            const string cultureConstraints = @"([a-z]{2}|[a-z]{2}-[A-Z]{2})";
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "HomeActions", "OfferPdf",
                new { controller = "Home", action = "OfferPdf" }
            );

            routes.MapRoute(
                name: "ReportCulture",
                url: "{culture}/Report/{action}/{id}/{*parameters}",
                defaults: new { culture = ru, controller = "Report", action = "Index", id = UrlParameter.Optional, parameters = UrlParameter.Optional },
                constraints: new { culture = cultureConstraints }
            );
            routes.MapRoute(
                name: "Report",
                url: "Report/{action}/{id}/{*parameters}",
                defaults: new { controller = "Report", action = "Index", id = UrlParameter.Optional, parameters = UrlParameter.Optional }
            );

            routes.MapRoute(
                name: "External",
                url: "{culture}/Template/External/{guid}/{*getParams}",
                defaults: new { culture = ru, controller = "Template", action = "External", guid = UrlParameter.Optional, getParams = UrlParameter.Optional },
                constraints: new { culture = cultureConstraints }
            );

            routes.MapRoute(
                name: "HomeCulture",
                url: "{culture}",
                defaults: new { culture = ru, controller = "Home", action = "Index" },
                constraints: new { culture = cultureConstraints }
            );

            routes.MapRoute(
                name: "DefaultCulture",
                url: "{culture}/{controller}/{action}/{id}/{key}",
                defaults: new { culture = ru, controller = "Home", action = "Index", id = UrlParameter.Optional, key = UrlParameter.Optional },
                constraints: new { culture = cultureConstraints }
            );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}/{key}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional, key = UrlParameter.Optional });
        }
    }
}
