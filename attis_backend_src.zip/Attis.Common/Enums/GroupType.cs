﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-16-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-16-2014
// ***********************************************************************
// <copyright file="GroupType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    using System.Xml.Serialization;

    /// <summary>
    /// Enum GroupType
    /// </summary>
    public enum GroupType
    {
        /// <summary>
        /// The none
        /// </summary>
        [XmlIgnore]
        None,
        /// <summary>
        /// The expander
        /// </summary>
        [XmlEnum(Name = "expander")]
        Expander,
        /// <summary>
        /// The tab page
        /// </summary>
        [XmlEnum(Name = "tabPage")]
        TabPage
    }
}
