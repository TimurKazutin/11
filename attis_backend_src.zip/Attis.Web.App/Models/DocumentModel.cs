﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using static Lawyers.Web.App.Controllers.ContractController;

namespace Lawyers.Web.App.Models
{
    public class DocModel
    {
        public string DocumentID { get; set; }
        public string DocumentNumber { get; set; }
        public DateTime DocumentDate { get; set; }
        public string CurrencyCode { get; set; }
        public string DocType { get; set; }
        public string DocTypeTitle { get; set; }
        public string FileType { get; set; }
        public int PlacesQuantity { get; set; }
        public string PlacesDescription { get; set; }
        public float GrossWeightQuantity { get; set; }
        public float NetWeightQuantity { get; set; }
        public float GCost { get; set; }
        public float Discount { get; set; }
        public float TransportCharges { get; set; }
        public float InsuranceCharges { get; set; }
        public float OtherCharges { get; set; }
        public float TotalCost { get; set; }
        public int PaymentPeriod { get; set; }
        public string InvoiceByer { get; set; }
        public string InvoiceSeller { get; set; }
        public string SellerName { get; set; }
        public string DocGuid { get; set; }
        public List<GoodsModel> product { get; set; }
    }
    public class CMRModel
    {
        public string DocumentID { get; set; }
        public string PrDocumentName { get; set; }
        public string PrDocumentNumber { get; set; }
        public string cmr_number { get; set; }
        public DateTime PrDocumentDate { get; set; }
        public DateTime cmr_date { get; set; }
        public string CurrencyCode { get; set; }
        public string cmr_sender { get; set; }
        public comp sender { get; set; }
        public string cmr_recipient { get; set; }
        public comp recipient { get; set; }
        public string CountryCode { get; set; }
        public string City { get; set; }
        public string StreetHouse { get; set; }
        public string PostalCode { get; set; }
        public string DeliveryPlace { get; set; }
        public string TermsDescription { get; set; }
        public string WarehouseName { get; set; }
        public string cmr_courier { get; set; }
        public comp courier { get; set; }
        public string cmr_courier_next { get; set; }
        public comp courier_next { get; set; }
        public DateTime TakingCargoDate { get; set; }
        public string cmr_track { get; set; }
        public string cmr_trailer { get; set; }
        public string DocType { get; set; }
        public string FileType { get; set; }
        public string DocGuid { get; set; }
        public string DeliveryTermsStringCode { get; set; }
        public string custom_code { get; set; }
        public string courier_notes { get; set; }
        public float? GoodsCost { get; set; }
        public List<CMRGoodsModel> product { get; set; }
        public List<cmr_doc> docs { get; set; }
        public customs customs_office { get; set; }
        public string cmr_track_reg_country { get; set; }
        public LibModel cmr_track_reg_country_name { get; set; }
    }

    public class GoodsModel
    {
        public string GoodMarking { get; set; }
        public string GoodsCode { get; set; }
        public string GoodsDescription { get; set; }
        public float GoodsQuantity { get; set; }
        public string SupplementaryQualifierName { get; set; }
        public float GrossWeightQuantity { get; set; }
        public float NetWeightQuantity { get; set; }
        public float Price { get; set; }
        public float Discount { get; set; }
        public float DiscountPercentage { get; set; }
        public string OriginCountryCode { get; set; }
        public float ServiceCharges { get; set; }
        public float TransportCharges { get; set; }
        public float OtherCharges { get; set; }
    }

    public class CMRGoodsModel
    {
        public string Id { get; set; }
        public string GoodMarking { get; set; }
        public string GoodsNomenclatureCode { get; set; }
        public string GoodsDescription { get; set; }
        public float GoodsQuantity { get; set; }
        public float GrossWeightQuantity { get; set; }
        public float VolumeQuantity { get; set; }
        public float? GoodsPrice { get; set; }

        public List<CMRPlacesModel> places { get; set; }
    }
    public class CMRPlacesModel
    {
        public string PlacesCount { get; set; }
        public string Description { get; set; }
        public string PlacesPartCount { get; set; }
        public string PackagingTypeCode { get; set; }
        public LibModel PackagingType { get; set; }
        public string CmrId { get; set; }
        public string GoodId { get; set; }
    }

    public class Fm1Model
    {
        //fm1_main.
        public string fm1_main_number { get; set; }
        public string fm1_main_related_number { get; set; }
        public DateTime fm1_main_related_date { get; set; }
        public DateTime fm1_main_date { get; set; }
        public string fm1_main_doc_kind { get; set; }
        public string fm1_main_form_state { get; set; }
        public string fm1_main_reason { get; set; }
        public string fm1_main_subreason { get; set; }
        //fm1_subject.
        public string fm1_subj_code { get; set; }
        public string fm1_subj_org_form { get; set; }
        public string fm1_subj_name { get; set; }
        public string fm1_subj_pers_second_name { get; set; }
        public string fm1_subj_pers_name { get; set; }
        public string fm1_subj_pers_middle_name { get; set; }
        public string fm1_subj_rnn { get; set; }
        public string fm1_subj_iin_bin { get; set; }

        //fm1_addrr.
        public string state_kaz_1 { get; set; }
        public string region_kaz_1 { get; set; }
        public string sity_kaz_1 { get; set; }
        public string street_1 { get; set; }
        public string house_num_1 { get; set; }
        public string flat_num_1 { get; set; }
        public string post_index_1 { get; set; }

        //fm1_docs.
        public string doc_num { get; set; }
        public string doc_series { get; set; }
        public string goverm_office { get; set; }
        public DateTime doc_date { get; set; }
        public string doc_type { get; set; }

        //fm1_subject.
        public string fm1_subj_manager_second_name { get; set; }
        public string fm1_subj_manager_name { get; set; }
        public string fm1_subj_manager_patronymic { get; set; }
        public string fm1_subj_position { get; set; }
        public string fm1_subj_phone { get; set; }
        public string fm1_subj_email { get; set; }

        //fm1_oper.
        public string fm1_oper_number { get; set; }
        public string fm1_oper_code_type { get; set; }
        public string fm1_oper_eknp { get; set; }
        public string fm1_oper_members_quant { get; set; }
        public float fm1_oper_curr_code { get; set; }
        public string fm1_oper_currency { get; set; }
        public float fm1_oper_tenge_sum { get; set; }
        public string fm1_oper_basis { get; set; }
        public DateTime fm1_oper_basis_doc_date { get; set; }
        public string fm1_oper_basis_doc_num { get; set; }
        public string fm1_oper_1code { get; set; }
        public string fm1_oper_2code { get; set; }
        public string fm1_oper_3code { get; set; }
        public string fm1_oper_trouble_desc { get; set; }
        public string fm1_oper_add_info { get; set; }

        //fm1_members.
        public string fm1_member { get; set; }
        public string fm1_memb_is_subj { get; set; }
        public string fm1_memb_subj_kind { get; set; }
        public string fm1_memb_country { get; set; }
        public string fm1_memb_country_2 { get; set; }
        public string fm1_memb_type { get; set; }
        public string fm1_memb_foreign { get; set; }
        public string fm1_memb_bank_branch_place { get; set; }
        public string fm1_memb_bank_branch { get; set; }
        public string fm1_memb_sdp { get; set; }
        public string fm1_memb_branch_code { get; set; }
        public string fm1_memb_acc { get; set; }
        public string fm1_memb_bank_place { get; set; }
        public string fm1_memb_bank_name { get; set; }
        public string fm1_memb_org_form { get; set; }
        public string fm1_memb_company_name { get; set; }
        public string fm1_memb_noname { get; set; }
        public string fm1_memb_founder_org_form { get; set; }
        public string fm1_memb_founder_secondname { get; set; }
        public string fm1_memb_founder_ { get; set; }
        public string fm1_memb_founder_name { get; set; }
        public string fm1_memb_founder_patronymic { get; set; }
        public string fm1_memb_memb_add_info { get; set; }

        //fm1_persons.
        public string fm1_person_secondname { get; set; }
        public string fm1_person_name { get; set; }
        public string fm1_person_midle_name { get; set; }
        public string fm1_person_secondname_2 { get; set; }
        public string fm1_person_name_2 { get; set; }
        public string fm1_person_middle_name_2 { get; set; }
        public string oked { get; set; }
        public string iin_bin { get; set; }
        public DateTime? fm1_person_birth_date { get; set; }
        public string fm1_person_birth_place { get; set; }

        public string doc_type_2 { get; set; }
        public string doc_num_2 { get; set; }
        public string doc_series_2 { get; set; }
        public string goverm_office_2 { get; set; }
        public DateTime doc_date_2 { get; set; }
        public string state_kaz_2 { get; set; }
        public string region_kaz_2 { get; set; }
        public string sity_kaz_2 { get; set; }
        public string street_2 { get; set; }
        public string house_num_2 { get; set; }
        public string flat_num_2 { get; set; }
        public string post_index_2 { get; set; }
        public string fm1_memb_contact_phone_2 { get; set; }
        public string fm1_memb_email_2 { get; set; }
        public string state_kaz_3 { get; set; }
        public string region_kaz_3 { get; set; }
        public string sity_kaz_3 { get; set; }
        public string street_3 { get; set; }
        public string house_num_3 { get; set; }
        public string flat_num_3 { get; set; }
        public string post_index_3 { get; set; }
        public string fm1_memb_memb_add_info_3 { get; set; }
        public List<fmembers> members { get; set; }

    }

    public class fmembers
    {
        public string fm1_member { get; set; }
        public string fm1_memb_is_subj { get; set; }
        public string fm1_memb_subj_kind { get; set; }
        public string fm1_memb_country { get; set; }
        public string fm1_memb_country_2 { get; set; }
        public string fm1_memb_type { get; set; }
        public string fm1_memb_foreign { get; set; }
        public string fm1_memb_bank_branch_place { get; set; }
        public string fm1_memb_bank_branch { get; set; }
        public string fm1_memb_sdp { get; set; }
        public string fm1_memb_branch_code { get; set; }
        public string fm1_memb_acc { get; set; }
        public string fm1_memb_bank_place { get; set; }
        public string fm1_memb_bank_name { get; set; }
        public string fm1_memb_org_form { get; set; }
        public string fm1_memb_company_name { get; set; }
        public string fm1_memb_noname { get; set; }
        public string fm1_memb_founder_org_form { get; set; }
        public string fm1_memb_founder_secondname { get; set; }
        public string fm1_memb_founder_ { get; set; }
        public string fm1_memb_founder_name { get; set; }
        public string fm1_memb_founder_patronymic { get; set; }
        public string fm1_memb_memb_add_info { get; set; }
        public string fm1_memb_member_addrr { get; set; }
        public string fm1_memb_member_fact_addrr { get; set; }
        public string fm1_member_name { get; set; }
        public string fm1_member_middle_name { get; set; }
        public string fm1_member_secondname { get; set; }
        public string fm1_member_birth_place { get; set; }
        public DateTime? fm1_member_birth_date { get; set; }



        public string fm1_person_secondname { get; set; }
        public string fm1_person_name { get; set; }
        public string fm1_person_midle_name { get; set; }
        public string fm1_person_secondname_2 { get; set; }
        public string fm1_person_name_2 { get; set; }
        public string fm1_person_middle_name_2 { get; set; }
        public string oked { get; set; }
        public string iin_bin { get; set; }
        public DateTime? fm1_person_birth_date { get; set; }
        public string fm1_person_birth_place { get; set; }

        public string doc_type_2 { get; set; }
        public string doc_num_2 { get; set; }
        public string doc_series_2 { get; set; }
        public string goverm_office_2 { get; set; }
        public DateTime doc_date_2 { get; set; }
        public string state_kaz_2 { get; set; }
        public string region_kaz_2 { get; set; }
        public string sity_kaz_2 { get; set; }
        public string street_2 { get; set; }
        public string house_num_2 { get; set; }
        public string flat_num_2 { get; set; }
        public string post_index_2 { get; set; }
        public string fm1_memb_contact_phone_2 { get; set; }
        public string fm1_memb_email_2 { get; set; }
        public string state_kaz_3 { get; set; }
        public string region_kaz_3 { get; set; }
        public string sity_kaz_3 { get; set; }
        public string street_3 { get; set; }
        public string house_num_3 { get; set; }
        public string flat_num_3 { get; set; }
        public string post_index_3 { get; set; }
        public string fm1_memb_memb_add_info_3 { get; set; }
    }
    public class resid
    {
        public string value { get; set; }
        public string display_text { get; set; }
    }

    public class Firm
    {
        public string org_name { get; set; }
        public string org_code { get; set; }
    }

    public class Ceos
    {
        public string org_name { get; set; }
        public string org_code { get; set; }
        public string company_address { get; set; }
        public string company_ceo { get; set; }
    }

    public class Orgs
    {
        public string org_name { get; set; }
        public string org_code { get; set; }
        public string org_type { get; set; }
        public string org_reg_date { get; set; }
        public string company_region { get; set; }
        public string org_oked { get; set; }
        public string company_contacts { get; set; }
        public string company_main_sphere { get; set; }
        public string company_additional_sphere { get; set; }
        public string company_ceo { get; set; }
        public string company_founder { get; set; }
        public string company_website { get; set; }
        public string company_email { get; set; }
        public resid org_residency { get; set; }
        public string person_code { get; set; }
        public string given_name { get; set; }
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public string gender { get; set; }
        public DateTime? date_of_birth { get; set; }
        public string residency { get; set; }
        public string user_id { get; set; }
        public person persons { get; set; }
    }
    public class fullComp
    {
        public comp organizations { get; set; }
        public resid org_residency { get; set; }
        public person persons { get; set; }
        public social socials { get; set; }
        public social person_socials { get; set; }
        public List<OrgAdress> addresses { get; set; }
        public List<BankModel> banks { get; set; }
        public List<Founders> founders { get; set; }
        public List<PADocument> person_documents { get; set; }
    }

    public class EpGoods
    {
        public string ap_good_data_goods_numeric { get; set; }
        public string ap_good_data_list_numeric { get; set; }
        public string ap_good_data_goods_description { get; set; }
        public float? ap_good_data_gross_weight_quantity { get; set; }
        public float? ap_good_data_net_weight_quantity { get; set; }
        public float? ap_good_data_invoiced_cost { get; set; }
        public float? ap_good_data_customs_cost { get; set; }
        public float? ap_good_data_statistical_cost { get; set; }
        public string ap_good_data_goods_tnved_code { get; set; }
        public string ap_good_data_origin_country_code { get; set; }
        public LibModel ap_good_data_origin_country { get; set; }
        public string ap_good_data_delivery_terms_string_code { get; set; }
        public float? ap_good_data_quant { get; set; }
        public string ap_good_data_ext_measure { get; set; }
        public string ap_good_data_container_num { get; set; }
        public string ap_good_data_places_name { get; set; }
        public float? ap_good_data_places { get; set; }
        public int? ap_good_data_packet { get; set; }
    }
    public class EpiModel
    {
        public string ap_memb_organization_name_1 { get; set; }
        public string ap_memb_short_name_1 { get; set; }
        public string ap_memb_bin_1 { get; set; }
        public string ap_memb_itn_1 { get; set; }
        public string ap_member_postal_code_1 { get; set; }
        public string ap_member_country_name_1 { get; set; }
        public string ap_member_region_1 { get; set; }
        public string ap_member_city_1 { get; set; }
        public string ap_member_street_house_1 { get; set; }
        public string ap_memb_organization_name_4 { get; set; }
        public string ap_memb_short_name_4 { get; set; }
        public string ap_memb_bin_4 { get; set; }
        public string ap_memb_itn_4 { get; set; }
        public string ap_member_postal_code_4 { get; set; }
        public string ap_member_country_name_4 { get; set; }
        public string ap_member_region_4 { get; set; }
        public string ap_member_city_4 { get; set; }
        public string ap_member_street_house_4 { get; set; }
        public string ap_memb_organization_name_5 { get; set; }
        public string ap_memb_short_name_5 { get; set; }
        public string ap_memb_bin_5 { get; set; }
        public string ap_memb_itn_5 { get; set; }
        public string ap_member_postal_code_5 { get; set; }
        public string ap_member_country_name_5 { get; set; }
        public string ap_member_region_5 { get; set; }
        public string ap_member_city_5 { get; set; }
        public string ap_member_street_house_5 { get; set; }
        public string ap_memb_organization_name_2 { get; set; }
        public string ap_memb_short_name_2 { get; set; }
        public string ap_memb_bin_2 { get; set; }
        public string ap_memb_itn_2 { get; set; }
        public string ap_member_postal_code_2 { get; set; }
        public string ap_member_country_name_2 { get; set; }
        public string ap_member_region_2 { get; set; }
        public string ap_member_city_2 { get; set; }
        public string ap_member_street_house_2 { get; set; }
        public string ap_memb_organization_name_3 { get; set; }
        public string ap_memb_short_name_3 { get; set; }
        public string ap_memb_bin_3 { get; set; }
        public string ap_memb_itn_3 { get; set; }
        public string ap_member_postal_code_3 { get; set; }
        public string ap_member_country_name_3 { get; set; }
        public LibModel ap_member_country_3 { get; set; }
        public string ap_member_region_3 { get; set; }
        public string ap_member_city_3 { get; set; }
        public string ap_member_street_house_3 { get; set; }
        public string ap_person_person_surname_1 { get; set; }
        public string ap_person_person_name_1 { get; set; }
        public string ap_person_person_middle_name_1 { get; set; }
        public string ap_person_person_post_1 { get; set; }
        public string ap_person_contact_phone_1 { get; set; }
        public string ap_person_person_surname_2 { get; set; }
        public string ap_person_person_name_2 { get; set; }
        public string ap_person_person_middle_name_2 { get; set; }
        public string ap_person_person_post_2 { get; set; }
        public string ap_person_reg_country_code_2 { get; set; }
        public LibModel ap_person_reg_country_2 { get; set; }
        public string ap_send_rec_identity_card_code { get; set; }
        public string ap_send_rec_identity_card_series { get; set; }
        public string ap_send_rec_identity_card_number { get; set; }
        public DateTime? ap_send_rec_identity_card_date { get; set; }
        public string ap_send_rec_organization_name { get; set; }
        public string ap_good_origin_country_name { get; set; }
        public LibModel ap_good_origin_country { get; set; }
        public string ap_good_specification_number { get; set; }
        public string ap_good_specification_list_number { get; set; }
        public string ap_good_total_goods_number { get; set; }
        public string ap_good_total_package_number { get; set; }
        public string ap_good_total_sheet_number { get; set; }
        public float? ap_good_total_cust_cost { get; set; }
        public string ap_good_cust_cost_currency_code { get; set; }
        public string ap_main_reg_num { get; set; }
        public string ap_main_country_code { get; set; }
        public DateTime ap_main_reg_date { get; set; }
        public string ap_main_trans_kind_code { get; set; }
        public string ap_main_transit_direction_code { get; set; }
        public string ap_main_electronic_document_sign { get; set; }
        public string ap_main_declaration_kind { get; set; }
        public string ap_main_subsoil_sign { get; set; }
        public string ap_main_seal_number { get; set; }
        public string ap_main_seal_quantity { get; set; }
        public string ap_main_language_cuesad { get; set; }
        public string ap_main_recipient_country_code { get; set; }
        public LibModel ap_main_recipient_country { get; set; }
        public string ap_main_movement_code { get; set; }
        public string ap_main_decl_num { get; set; }
        public DateTime? ap_main_decl_date { get; set; }
        public int? ap_main_carnet { get; set; }
        public string ap_transp_information_type_code { get; set; }
        public string ap_transp_customs_office { get; set; }
        public string ap_transp_customs_country_code { get; set; }
        public LibModel ap_transp_customs_country { get; set; }
        public string ap_transp_container_indicator { get; set; }
        public string ap_transp_dispatch_country_code { get; set; }
        public LibModel ap_transp_dispatch_country { get; set; }
        public string ap_transp_destination_country_code { get; set; }
        public LibModel ap_transp_destination_country { get; set; }
        public string ap_transp_customs_office_inout { get; set; }
        public string ap_transp_customs_country_code_io { get; set; }
        public LibModel ap_transp_customs_country_io { get; set; }
        public DateTime? ap_transp_date_expected_arrival { get; set; }
        public string ap_transp_transport_mode_code { get; set; }
        public string ap_transp_transport_nationality_code { get; set; }
        public LibModel ap_transp_transport_nationality { get; set; }
        public string ap_transp_vin { get; set; }
        public string ap_transp_transport_identifier { get; set; }
        public string ap_transp_active_transport_identifier { get; set; }
        public string ap_transp_date_expected_arrival_time { get; set; }
        public List<EpGoods> product { get; set; }
        public List<prev_doc> prev_docs { get; set; }
        public List<Kfiles> files { get; set; }
    }

    public class Kfiles
    {
        public string id { get; set; }
        public string name { get; set; }
        public string date { get; set; }
    }

    public class prev_doc
    {
        public DateTime? ap_prev_doc_preceding_document_date { get; set; }
        public string ap_prev_doc_preceding_document_number { get; set; }
        public string PrecedingDocumentName { get; set; }
        public string ap_prev_doc_kind { get; set; }
    }

    public class cmr_doc
    {
        public DateTime? document_date { get; set; }
        public string document_number { get; set; }
        //public string PrecedingDocumentName { get; set; }
        public string document_kind { get; set; }
    }

    public class customs
    {
        public string custom_code { get; set; }
        public string custom_name { get; set; }
        public LibModel custom_country { get; set; }
        public string custom_addr { get; set; }
        public string custom_email { get; set; }
        public string custom_phone { get; set; }
        public string custom_fax { get; set; }
        public string custom_id { get; set; }
        public string custom_cust_code { get; set; }
        public string custom_sovam { get; set; }
    }

    public class AwbModel
    {
        public string awb_id { get; set; }
        public string awb_guid { get; set; }
        public string awb_imp_date { get; set; }
        public string awb_inp_time { get; set; }
        public string user_id { get; set; }
        public string airport_code { get; set; }
        public string acompany_code { get; set; }
        public string serial_num { get; set; }
        public string acomp_name_addr { get; set; }
        public string sender_name_addr { get; set; }
        public string recipient_name_addr { get; set; }
        public string agent_name_addr { get; set; }
        public string agent_iata_code { get; set; }
        public string agent_acc { get; set; }
        public string dest_airport { get; set; }
        public string payment_data { get; set; }
        public string first_carrier_dest_point { get; set; }
        public string fist_carrier_name { get; set; }
        public string second_carrier_dest_point { get; set; }
        public string second_carrier_name { get; set; }
        public string third_carrier_dest_point { get; set; }
        public string third_carrier_name { get; set; }
        public string curr_code { get; set; }
        public string pr_o { get; set; }
        public string col_l { get; set; }
        public string pr_d { get; set; }
        public string col_l1 { get; set; }
        public string decl_value_carr { get; set; }
        public string decl_value_cust { get; set; }
        public string dest_airport1 { get; set; }
        public string flight_date { get; set; }
        public string insuranse_amount { get; set; }
        public string handling_info { get; set; }
        public string custom_status { get; set; }
        public string pieses_no { get; set; }
        public string brutto { get; set; }
        public string measure { get; set; }
        public string rate_class { get; set; }
        public string commodity_item { get; set; }
        public string chargeable_weight { get; set; }
        public string rate_charge { get; set; }
        public string total { get; set; }
        public string nature_quant { get; set; }
        public string total_pieses { get; set; }
        public string total_sum_rev { get; set; }
        public string total_brutto { get; set; }
        public string other_charges { get; set; }
        public string weight_charge_sum { get; set; }
        public string valuation_sum { get; set; }
        public string tax_sum { get; set; }
        public string total_other_charges { get; set; }
        public string carrier_total_other_charges { get; set; }
        public string total_prepaid_collect { get; set; }
        public string awb_create_date { get; set; }
        public string awb_place { get; set; }
        public string signature { get; set; }
    }

    public class GR11
    {
        public string NAME { get; set; }
        public string T2 { get; set; } //T2 = улица; Т3 = дом, в качестве разделительного знака между Т2 и Т3 использовать «,» - запятую;
        public string T3 { get; set; }
        public string T4 { get; set; }
        public string T5 { get; set; }
        public string T6 { get; set; }
    }

    public class GR12
    {
        public string phone { get; set; }
        public string fax { get; set; }
        public string email { get; set; }
    }

    public class GR13
    {
        public string kod { get; set; } //DOC+KOD:::NAIM_DOC + продолжение NAIM_DOC:N: DATE,№,SZD++1+T’
        public string fax { get; set; }
        public string email { get; set; }
    }

    public class GR18
    {
        public string X { get; set; }
        public string NE { get; set; } //Код рода упаковки указывается в соответствии с Рекомендацией ООН №21.
        public string pkg_name { get; set; }
        public string pkg_no { get; set; }
        public string pkg_count { get; set; }
        public string same_count { get; set; }
        public string sender_country { get; set; }
        public string receiver_country { get; set; }
        public string Name { get; set; }
    }

    public class PackingList
    {
        public int list_id { get; set; }
        public string DocumentID { get; set; }
        public string ref_document_id { get; set; }
        public float? gross_weight_quantity { get; set; }
        public float? net_weight_quantity { get; set; }
        public string comp1 { get; set; }
        public string comp2 { get; set; }
        public comp consignor { get; set; }
        public comp consignee { get; set; }
        public LibModel delivery_terms { get; set; }
        public string terms_description { get; set; }
        public string contract_pr_document_name { get; set; }
        public string contract_pr_document_number { get; set; }
        public DateTime? contract_pr_document_date { get; set; }
        public string invoice_pr_document_name { get; set; }
        public string invoice_pr_document_number { get; set; }
        public DateTime? invoice_pr_document_date { get; set; }
        public string registration_pr_document_name { get; set; }
        public string registration_pr_document_number { get; set; }
        public DateTime? registration_pr_document_date { get; set; }
        public List<string> DeliveryPlace { get; set; }
        public DocModel invoice { get; set; }
        public List<pkglist_goods> goods { get; set; }
        public List<pkglist_transportmeans> transports { get; set; }
        public List<pkglist_totalplacesquantity> places { get; set; }
    }

    public class LibModel
    {
        public string display_text { get; set; }
        public string value { get; set; }
    }
    public class pkglist_goods
    {
        public int? id { get; set; }
        public string goodsdescription { get; set; }
        public string goodscode { get; set; }
        public float? goodsquantity { get; set; }
        public float? placegoodsquantity { get; set; }
        public string measureunitqualifiername { get; set; }
        public string measureunitqualifiercode { get; set; }
        public LibModel measureunitqualifier { get; set; }
        public float? grossweightquantity { get; set; }
        public float? netweightquantity { get; set; }
        public string dimensions { get; set; }
        public float? goodsvolume { get; set; }
        public LibModel volumeunitqualifier { get; set; }
        public string goodmarking { get; set; }
        public List<pkglist_goods_placesquantity> packagings { get; set; }
    }

    public class rwb_initial_data
    {
        public List<DocModel> invoice_list { get; set; }
        public List<PackingList> packing_lists { get; set; }
        public List<CSVModel> ktzh_resp { get; set; }
        public comp consignor { get; set; }

        public comp consignee { get; set; }

        public DateTime? when_signed_by_owner { get; set; }
        public string contrac_carrier_name { get; set; }

    }
    public class fm1_initial_data
    {
        public fullComp seller { get; set; }
        public fullComp buyer { get; set; }

    }
    public class insurance_initial_data
    {
        public List<Product> products { get; set; }
        public fullComp contract_owner { get; set; }
        public List<PackingList> packing_lists { get; set; }
        public CMRModel cmr { get; set; }
    }


    public class pkglist_goods_placesquantity
    {
        public int goods_id { get; set; }
        public int? packging_placescount { get; set; }
        public string packaging_placesdescription { get; set; }
        public LibModel packaging_packagingtypecode { get; set; }
        public string packaging_partialplacescount { get; set; }
    }


    public class pkglist_goods_packinginfo
    {
        public int goods_id { get; set; }
        public LibModel packingcode { get; set; }
        public string placesquantity { get; set; }
        public string placesdescription { get; set; }
    }
    public class pkglist_transportmeans
    {
        public string packaging_transport_number { get; set; }
        public LibModel packaging_transporttypecode { get; set; }
        public LibModel packaging_transportcountrycode { get; set; }
        public int? packaging_transportleading { get; set; }
    }

    public class pkglist_totalplacesquantity
    {
        public string packging_placescount { get; set; }
        public string packaging_placesdescription { get; set; }
        public LibModel packaging_packagingtypecode { get; set; }
    }

    public class PADocument
    {
        public string id { get; set; }
        public string document_type { get; set; }
        public string document_number { get; set; }
        public string document_serial { get; set; }
        public DateTime? document_date { get; set; }
        public string document_issued_by { get; set; }
        public string is_active { get; set; }
        public DateTime? document_exp_date { get; set; }
        public Kfiles file { get; set; }
    }

    public class rw_bill
    {
        public int? id { get; set; }
        public int? doc_id { get; set; }
        public int? refdocid { get; set; }
        public string consignor_notice { get; set; }
        public int? places_quantity { get; set; }
        public float? gross_weight_quantity { get; set; }
        public string departure_mode_description { get; set; }
        public string loader_mode_description { get; set; }
        public int? additional_sheet_quantity { get; set; }
        public float? cargo_value { get; set; }
        public string customs_notice { get; set; }
        public string weight_definition_mode_description { get; set; }
        public string carrier_notice { get; set; }
        public string commerce_akt { get; set; }
        public string prolongation { get; set; }
        public string issue_marks { get; set; }
        public float? amount60 { get; set; }
        public float? amount61 { get; set; }
        public float? amount62 { get; set; }
        public float? amount63 { get; set; }
        public string calculation_notice { get; set; }
        public string addition_payment { get; set; }
        public string consignor_option_notice { get; set; }
        public string consignor { get; set; }
        public string consignee { get; set; }
        public string departure_station_code { get; set; }
        public string departure_station_name { get; set; }
        public string departure_rwcode { get; set; }
        public string departure_rwname { get; set; }
        public string departure_country { get; set; }
        public string destination_rwcode { get; set; }
        public string destination_station_code { get; set; }
        public string destination_rwand_station_name { get; set; }
        public string border_station_code { get; set; }
        public string border_station_name { get; set; }
        public string border_rwcode { get; set; }
        public string border_rwname { get; set; }
        public string border_country { get; set; }
        public string contract_name { get; set; }
        public string contract_number { get; set; }
        public DateTime? contract_date { get; set; }
        public float? flat_pallet_quantity { get; set; }
        public float? box_pallet_quantity { get; set; }
        public string pallet_exchange_mode { get; set; }
        public string work_tool_id { get; set; }
        public string work_tool_container_description { get; set; }
        public string work_tool_railway_code { get; set; }
        public int? mark_sing { get; set; }
        public string mark_kind { get; set; }
        public string mark_result_control { get; set; }
        public string contract_carrier_name { get; set; }
        public string contract_carrier_time { get; set; }
        public string contract_carrier_date { get; set; }
        public string contract_carrier_date_time_moscow { get; set; }
        public string contract_carrier_station_code { get; set; }
        public string contract_carrier_station_name { get; set; }
        public string contract_carrier_rw_name { get; set; }
        public string contract_carrier_country { get; set; }
        public string arrival_carrier_name { get; set; }
        public string arrival_date { get; set; }
        public string arrival_time { get; set; }
        public string arrival_date_time_moscow { get; set; }
        public string arrival_station_code { get; set; }
        public string arrival_station_name { get; set; }
        public string arrival_rw_name { get; set; }
        public string arrival_rw_code { get; set; }
        public string arrival_country { get; set; }
        public List<rwb_goods> goods { get; set; }
        public List<rwb_carrier> carrier { get; set; }
        public List<rwb_container> container { get; set; }
        public List<rwb_auto> auto { get; set; }
        public List<rwb_carriage> carriage { get; set; }
        public List<rwb_seal> seal { get; set; }
        public List<rwb_stamp> stamp33 { get; set; }
        public List<rwb_stamp> stamp34 { get; set; }
        public rwb_stamp stamp35 { get; set; }
        public List<rwb_carrier_charge> carrier_charge { get; set; }
        public List<paid_rw_cod> paid_rw_code { get; set; }
        public List<rwb_doc> consignor_doc { get; set; }
    }

    public class rwb_goods {
        public int? container_indicator { get; set; }
        public string work_tool_description { get; set; }
        public string conductor_description { get; set; }
        public double? place_goods_quantity { get; set; }
        public double? places_quantity { get; set; }
        public double? gross_weight_quantity { get; set; }
        public string places_description { get; set; }
        public int? harmonized_range_goods { get; set; }
        public string packing { get; set; }
        public string marking { get; set; }
        public string carriage_number { get; set; }
        public string container_number { get; set; }
        public int? goods_numeric { get; set; }
        public string customs_code { get; set; }
        public int? gtd_number { get; set; }
        public double gcost { get; set; }
        public string currency { get; set; }
        public string mrn { get; set; }
    }

    public class rwb_carrier {
        public int id { get; set; }
        public string carrier_name { get; set; }
        public string carrier_code { get; set; }
        public string from_station_code { get; set; }
        public string from_station_name { get; set; }
        public string from_rw_name { get; set; }
        public string from_country { get; set; }
        public string to_station_code { get; set; }
        public string to_station_name { get; set; }
        public string to_rw_name { get; set; }
        public string to_country { get; set; }
        public List<rw_tech_station> tech_station { get; set; }
    }
    public class rwb_doc {
        public string doc_name { get; set; }
        public string doc_number { get; set; }
        public DateTime? doc_date { get; set; }
        public string mode_code { get; set; }
        public DateTime? expiration_date { get; set; }
        public string release_customs { get; set; }
    }
    public class paid_rw_cod {
        public string paid_rw_name { get; set; }
        public string paid_rw_code { get; set; }
        public string paid_rw_short { get; set; }
        public string payer_code { get; set; }
        public string payer_name { get; set; }
        public string from_rw_name { get; set; }
        public string from_country { get; set; }
    }
    public class rwb_container {
        public string container_id { get; set; }
        public string rw_code { get; set; }
        public string container_kind { get; set; }
        public string container_mode_desc { get; set; }
        public float? container_capacity { get; set; }
        public string container_capacity_unit_code { get; set; }
        public double? tare { get; set; }
        public double? goods_weight { get; set; }
        public double? places_quentity { get; set; }
        public double? pocket_quentity { get; set; }
        public double? container_length { get; set; }
    }
    public class rwb_auto {
        public string vin { get; set; }
        public string transport_kind { get; set; }
        public string transport_mark { get; set; }
        public string transport_identifier { get; set; }
        public string transport_nationality { get; set; }
        public string active_transport_identifier { get; set; }
        public string transport_regnumber { get; set; }
        public int? wagon_number { get; set; }
        public double? tare { get; set; }
        public double? goods_weight { get; set; }
        public double? places_quentity { get; set; }
        public double? pocket_quentity { get; set; }
        public double? container_length { get; set; }
    }

    public class rwb_carriage {
        public string carriage_id { get; set; }
        public string rw_name { get; set; }
        public string owner_name { get; set; }
        public string owner_type { get; set; }
        public double? rw_power { get; set; }
        public double? axis_quentity { get; set; }
        public double? tare { get; set; }
        public double? goods_weight { get; set; }
        public string caliber { get; set; }
    }
    public class rwb_stamp {
        public string carrier_name { get; set; }
        public string date { get; set; }
        public string time { get; set; }
        public string date_time_moscow { get; set; }
        public string station_code { get; set; }
        public string station_name { get; set; }
        public string rw_name { get; set; }
        public string rw_code { get; set; }
        public string country { get; set; }
    }
    public class rw_tech_station {
        public int? order_number { get; set; }
        public string tech_signs { get; set; }
        public string station_code { get; set; }
        public string station_name { get; set; }
        public string rw_name { get; set; }
        public string country { get; set; }
    }
    public class rwb_seal {
        public string seal_id { get; set; }
        public float? seal_quentity { get; set; }
        public float? ident_kind { get; set; }
        public string ident_desc { get; set; }
    }
    public class rwb_carrier_charge {
        public float? order_no { get; set; }
        public string carrier_code { get; set; }
        public string from_station_code { get; set; }
        public string from_station_name { get; set; }
        public string from_rw_name { get; set; }
        public string from_country { get; set; }
        public string to_station_code { get; set; }
        public string to_station_name { get; set; }
        public string to_rw_name { get; set; }
        public string to_country { get; set; }
        public float? distance { get; set; }
        public double? calc_weight { get; set; }
        public string extra_charge_code { get; set; }
        public string extra_charge_name { get; set; }
        public double? extra_charge_amount { get; set; }
        public string tarif_code { get; set; }
        public string calc_cargo_code { get; set; }
        public float? currency_rate { get; set; }
        public string snd_tarif_currency_code { get; set; }
        public string snd_payment_currency { get; set; }
        public string rcv_tarif_currency_code { get; set; }
        public string rcv_payment_currency { get; set; }
        public double? amount48 { get; set; }
        public double? amount49 { get; set; }
        public double? amount50 { get; set; }
        public double? amount51 { get; set; }
        public double? amount52 { get; set; }
        public double? amount53 { get; set; }
        public double? amount54 { get; set; }
        public double? amount55 { get; set; }
        public double? amount56 { get; set; }
        public double? amount57 { get; set; }
        public double? amount58 { get; set; }
        public double? amount59 { get; set; }
    }

    public class cargo_insurance
    {
        int id { get; set; }
        public string doc_id { get; set; }
        public string policy_holder_name { get; set; }
        public string represented_by { get; set; }
        public string legal_address { get; set; }
        public string actual_address { get; set; }
        public int? is_public_person { get; set; }
        public string insured_details { get; set; }
        public string insured_activity { get; set; }
        public string beneficiary { get; set; }
        public string beneficiary_details { get; set; }
        public string shipping_name { get; set; }
        public string package_info { get; set; }
        public float? cargo_cost { get; set; }
        public int? package_count { get; set; }
        public float? total_cost { get; set; }
        public DateTime? release_date { get; set; }
        public int? containerization { get; set; }
        public string cargo_placing { get; set; }
        public string route { get; set; }
        public string security_measures { get; set; }
        public string transport_means { get; set; }
        public string transfer_points { get; set; }
        public string shipping_details { get; set; }
        public int? risk_a { get; set; }
        public int? risk_b1 { get; set; }
        public int? risk_b2 { get; set; }
        public string additional_conditions { get; set; }
        public float? max_value_a { get; set; }
        public float? max_value_b { get; set; }
        public float? max_value_c { get; set; }
        public float? max_value_d { get; set; }
        public float? max_value_e { get; set; }
        public float? max_value_f { get; set; }
        public int? insured_transport { get; set; }
        public float? insured_transport_amount { get; set; }
        public string franchise { get; set; }
        public DateTime? shipment_date { get; set; }
        public string shipment_duration { get; set; }
        public string insurance_stats { get; set; }
        public string relevant_info { get; set; }
        public string other { get; set; }
        public List<Kfiles> files { get; set; }
    }


    public class liability_insurance
    {
        int id { get; set; }
        public string doc_id { get; set; }
        public string policy_holder_name { get; set; }
        public string policy_holder_address { get; set; }
        public string policy_holder_phone { get; set; }
        public string policy_holder_email { get; set; }
        public string policy_holder_bank { get; set; }
        public string policy_holder_bin { get; set; }
        public string policy_holder_bik { get; set; }
        public int? is_resident { get; set; }
        public string license_no { get; set; }
        public string economy_sector { get; set; }
        public string activity_type { get; set; }
        public string object_teritory { get; set; }
        public string insured_details { get; set; }
        public float? life_insured_sum { get; set; }
        public float? property_insured_sum { get; set; }
        public float? cargo_insured_sum { get; set; }
        public float? total_insured_sum { get; set; }
        public string insurance_term { get; set; }
        public string insurance_teritory { get; set; }
        public string transport_type { get; set; }
        public string transport_model { get; set; }
        public string transport_name { get; set; }
        public string transport_reg_number { get; set; }
        public string transport_body_number { get; set; }
        public string transport_release_date { get; set; }
        public int? vehicles_number { get; set; }
        public string previous_insurance_info { get; set; }
        public string valid_contracts_info { get; set; }
        public string insurer_name { get; set; }
        public string insurer_address { get; set; }
        public string insurer_phone { get; set; }
        public DateTime? insurance_date { get; set; }
        public List<Kfiles> files { get; set; }
    }

    public class docNotification
    {
        public int? docid { get; set; }
        public int? notifnumint { get; set; }
        public string blankinnum { get; set; }
        public string cbxnum { get; set; }
        public string transtype { get; set; }
        public string regcountry { get; set; }
        public string transportmark { get; set; }
        public string transportnum { get; set; }
        public string trailernum { get; set; }
        public string carriername { get; set; }
        public string carrierrnn { get; set; }
        public string drivername { get; set; }
        public string driverpasspnum { get; set; }
        public DateTime? driverpasspdate { get; set; }
        public string driverpasspplace { get; set; }
        public int? goodsforbidden { get; set; }
        public DateTime? placedate { get; set; }
        public DateTime? noticedate { get; set; }
        public string custmark { get; set; }
        public string regnum { get; set; }
        public string custofficerstampnum { get; set; }
        public string custofficername { get; set; }
        public string specialist { get; set; }
        public string shassi { get; set; }
        public string driverdocname { get; set; }
        public string dcodepto { get; set; }
        public string namepto { get; set; }
        public string carrieraddress { get; set; }
        public string regcountrycode { get; set; }
        public string purpose { get; set; }
        public string notifnum { get; set; }
        public int? createyear { get; set; }
        public int? trisleave { get; set; }
        public string carrierstamp1 { get; set; }
        public string carrierstamp2 { get; set; }
        public string placename { get; set; }
        public DateTime? dateout { get; set; }
        public int? damage { get; set; }
        public int? breachiden { get; set; }
        public int? removeiden { get; set; }
        public int? imposiden { get; set; }
        public int? bi_amount { get; set; }
        public string bi_num { get; set; }
        public int? ri_amount { get; set; }
        public string ri_num { get; set; }
        public int? ii_amount { get; set; }
        public string ii_num { get; set; }
        public string driveroffice { get; set; }
        public string damcomment { get; set; }
        public int? newdoc { get; set; }
        public int? isnew { get; set; }
        public string drivertype { get; set; }
        public string docscurrencycode { get; set; }
        public string transcategorycode { get; set; }
        public string twhplace { get; set; }
        public int? notifcuststatus { get; set; }
        public DateTime? notifcuststatusdate { get; set; }
        public string pr_vygr { get; set; }
        public List<docnotificationcustdocs> docnotificationcustdocs { get; set; }
        public List<docnotificationdocs> docnotificationdocs { get; set; }
        public List<docnotificationpermdocs> docnotificationpermdocs { get; set; }
        public List<docnotificationrecipients> docnotificationrecipients { get; set; }
        public List <documents> documents { get; set; }
        public List<cwcardinmain> cwcardinmain { get; set; }
        public List<cwcardoutmain> cwcardoutmain { get; set; }
    }

    public class docnotificationcustdocs
    {
        public int? recordid {get;set;} 
        public int? linenum { get; set; }
        public string doctype { get; set; }
        public string docnum { get; set; }
        public DateTime? docdate { get; set; }
        public string addpermfirm { get; set; }
        public string custofficerstampnum { get; set; }
        public string custofficername { get; set; }
        public int? ny { get; set; }
        public int? nj { get; set; }
        public int? nn { get; set; }
        public string docdkd { get; set; }
    }

    public class docnotificationdocs
    {
        public int? recordid { get; set; }
        public int? linenum { get; set; }
        public string doctype { get; set; }
        public string docnum { get; set; }
        public DateTime? docdate { get; set; }
        public string doccomment { get; set; }
        public string docfirm { get; set; }
        public int? indv { get; set; }
        public float? docnetto { get; set; }
        public float? docbrutto { get; set; }
        public string doccurrencycode { get; set; }
        public float? docprice { get; set; }
        public string sendername { get; set; }
        public DateTime? docdatecreate { get; set; }
    }

    public class docnotificationpermdocs
    {
        public int? recordid { get; set; }
        public int? linenum { get; set; }
        public string doctype { get; set; }
        public string docnum { get; set; }
        public DateTime? docdate { get; set; }
        public string addpermfirm { get; set; }
        public string custofficerstampnum { get; set; }
        public float? docnetto { get; set; }
        public float? docbrutto { get; set; }
        public string doccurrencycode { get; set; }
        public float? docprice { get; set; }
    }

    public class docnotificationrecipients
    {
        public int? recordid { get; set; }
        public int? linenum { get; set; }
        public string recipientrnn { get; set; }
        public string recipientname { get; set; }
        public string recipientaddress { get; set; }
        public string indf { get; set; }

    }

    public class documents
    { 
        public int? doctypecode { get; set; }
        public int? docstatus { get; set; }
    }

    public class cwpassport
    {
        public string id { get; set; }
        public string countryid { get; set; }
        public string currencyid { get; set; }
        public string city { get; set; }
        public string cbxnum { get; set; }
        public string cbxname { get; set; }
        public string addresscbx { get; set; }
        public string codepto { get; set; }
        public string ptofullname { get; set; }
        public string ownerrnn { get; set; }
        public string ownername { get; set; }
        public string owneraddress { get; set; }
        public string ownerbank { get; set; }
        public string owneracc { get; set; }
        public string cbxnamealt { get; set; }
        public string beglettersf { get; set; }
        public string codeofficesf { get; set; }
        public DateTime? cbxdate { get; set; }
        public string cbxlic { get; set; }
        public string cbxbank { get; set; }
        public string cbxacc { get; set; }
        public string cbxbankaddress { get; set; }
        public string ownerbankaddress { get; set; }
        public string cbxrnn { get; set; }
        public string ownerokpo { get; set; }
        public string cbxokpo { get; set; }
        public string cbxbankcode { get; set; }
        public string ownerbankcode { get; set; }
        public int? maxdayskeep { get; set; }
        public int? roundsf { get; set; }
    }

    public class cwcardinmain
    {
        public int? id { get; set; }
        public int? notifnumint { get; set; }
        public string docnum { get; set; }
        public DateTime? docdate { get; set; }
        public DateTime? enddate { get; set; }
        public string description { get; set; }
        public string companyname { get; set; }
        public string companycode { get; set; }
        public string personname { get; set; }
        public string officername { get; set; }
        public string recipientname { get; set; }
        public string recipientcode { get; set; }
        public DateTime? enddatekd { get; set; }
        public string isclosed { get; set; }
        public string kdnum { get; set; }
        public string docidnotif { get; set; }
        public List<cwcardingoods> cwcardingoods { get; set; }
    }

    public class cwcardingoods
    {
        public int? id { get; set; }
        public int linenum { get; set; }
        public string goodscode { get; set; }
        public string goodsname { get; set; }
        public string goodsplacemarks { get; set; }
        public int? goodsplacequantity { get; set; }
        public string goodsplacetype { get; set; }
        public float? goodsquantity { get; set; }
        public string goodsmeasure { get; set; }
        public float? goodsweight { get; set; }
        public float? goodsvolume { get; set; }
        public float? goodsprice { get; set; }
        public string goodscurrency { get; set; }
        public string goodscountry { get; set; }
        public string goodsnumber { get; set; }
    }

    public class cwcardoutmain
    {
        public int? id { get; set; }
        public string docnum { get; set; }
        public DateTime? docdate { get; set; }
        public string description { get; set; }
        public string cause { get; set; }
        public string officername { get; set; }
        public string recipientname { get; set; }
        public string recipientcode { get; set; }
        public string personname { get; set; }
        public string cardinnumber { get; set; }
        public List<cwcardoutgoods> cwcardoutgoods { get; set; }
    }

    public class cwcardoutgoods
    {
        public int? id { get; set; }
        public int linenum { get; set; }
        public string cardingoodsid { get; set; }
        public string goodsname { get; set; }
        public float? goodsoutquantity { get; set; }
        public float? goodsoutplacequantity { get; set; }
        public float? goodsoutprice { get; set; }
        public float? goodsoutweight { get; set; }
        public string isblank { get; set; }
        public string checkowner { get; set; }
    }

    public class gtd
    {
        public int? gtd_id { get; set; }
        public string gtd_guid { get; set; }
        public string ga { get; set; }
        public string g011 { get; set; }
        public string g012 { get; set; }
        public string g013 { get; set; }
        public string g012_1 { get; set; }
        public string g542 { get; set; }
        public string gk_7 { get; set; }
        public string g021 { get; set; }
        public string g022i { get; set; }
        public string g023i { get; set; }
        public int? g031 { get; set; }
        public int? g032 { get; set; }
        public int? g041 { get; set; }
        public int? g042 { get; set; }
        public string g081 { get; set; }
        public string g082 { get; set; }
        public string g083 { get; set; }
        public string g0141 { get; set; }
        public string g0142 { get; set; }
        public string g0143 { get; set; }
        public string g091 { get; set; }
        public string g092 { get; set; }
        public string g093 { get; set; }
        public string g11 { get; set; }
        public string g11_1 { get; set; }
        public string g15a { get; set; }
        public string g16a { get; set; }
        public string g17a { get; set; }
        public int? g19 { get; set; }
        public int? g20 { get; set; }
        public float? g23 { get; set; }
        public string g22_curr { get; set; }
        public float? g22_total_price { get; set; }
        public int? g241 { get; set; }
        public int? g242 { get; set; }
        public int? g30_place { get; set; }

    }
    /*
    private float myVar; // GR20 Масса груза брутто (включая упаковку) для каждого груза в одной строке с наименованием груза
    public float pkg_mass
    { 
        get { return myVar; }
        set { myVar = value; }
    }

    private string other_opt; //A:B:C = Знаки, марки и номера, нанесенные на груз
    public string pkg_info
    {
        get { return other_opt; }
        set { other_opt = value; }
    }
    */

    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    /*[System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0", IsNullable = false)]
    public partial class AutoPreliminary0
    {

        private string documentIDField;

        private object refDocumentIDField;

        private AutoPreliminaryEECEDocHeaderAddInfo eECEDocHeaderAddInfoField;

        private string electronicDocumentSignField;

        private AutoPreliminaryRegNumber regNumberField;

        private AutoPreliminaryRefRegNumber refRegNumberField;

        private string usageCodeField;

        private AutoPreliminaryEntryCheckPointDetails entryCheckPointDetailsField;

        private AutoPreliminaryDeclarantDetails declarantDetailsField;

        private AutoPreliminaryBorderTransportDetails borderTransportDetailsField;

        private AutoPreliminaryMainConsignmentDetails mainConsignmentDetailsField;

        private AutoPreliminaryCarrierDetails carrierDetailsField;

        private AutoPreliminarySparePartsInfo sparePartsInfoField;

        private string documentModeIDField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string DocumentID
        {
            get
            {
                return this.documentIDField;
            }
            set
            {
                this.documentIDField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public object RefDocumentID
        {
            get
            {
                return this.refDocumentIDField;
            }
            set
            {
                this.refDocumentIDField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryEECEDocHeaderAddInfo EECEDocHeaderAddInfo
        {
            get
            {
                return this.eECEDocHeaderAddInfoField;
            }
            set
            {
                this.eECEDocHeaderAddInfoField = value;
            }
        }

        /// <remarks/>
        public string ElectronicDocumentSign
        {
            get
            {
                return this.electronicDocumentSignField;
            }
            set
            {
                this.electronicDocumentSignField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryRegNumber RegNumber
        {
            get
            {
                return this.regNumberField;
            }
            set
            {
                this.regNumberField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryRefRegNumber RefRegNumber
        {
            get
            {
                return this.refRegNumberField;
            }
            set
            {
                this.refRegNumberField = value;
            }
        }

        /// <remarks/>
        public string UsageCode
        {
            get
            {
                return this.usageCodeField;
            }
            set
            {
                this.usageCodeField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryEntryCheckPointDetails EntryCheckPointDetails
        {
            get
            {
                return this.entryCheckPointDetailsField;
            }
            set
            {
                this.entryCheckPointDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryDeclarantDetails DeclarantDetails
        {
            get
            {
                return this.declarantDetailsField;
            }
            set
            {
                this.declarantDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryBorderTransportDetails BorderTransportDetails
        {
            get
            {
                return this.borderTransportDetailsField;
            }
            set
            {
                this.borderTransportDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetails MainConsignmentDetails
        {
            get
            {
                return this.mainConsignmentDetailsField;
            }
            set
            {
                this.mainConsignmentDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryCarrierDetails CarrierDetails
        {
            get
            {
                return this.carrierDetailsField;
            }
            set
            {
                this.carrierDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminarySparePartsInfo SparePartsInfo
        {
            get
            {
                return this.sparePartsInfoField;
            }
            set
            {
                this.sparePartsInfoField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlAttributeAttribute()]
        public string DocumentModeID
        {
            get
            {
                return this.documentModeIDField;
            }
            set
            {
                this.documentModeIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryEECEDocHeaderAddInfo
    {

        private string infEnvelopeCodeField;

        private string eDocCodeField;

        private string eDocDateTimeField;

        private string languageCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string InfEnvelopeCode
        {
            get
            {
                return this.infEnvelopeCodeField;
            }
            set
            {
                this.infEnvelopeCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string EDocCode
        {
            get
            {
                return this.eDocCodeField;
            }
            set
            {
                this.eDocCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string EDocDateTime
        {
            get
            {
                return this.eDocDateTimeField;
            }
            set
            {
                this.eDocDateTimeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string LanguageCode
        {
            get
            {
                return this.languageCodeField;
            }
            set
            {
                this.languageCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryRegNumber
    {

        private string countryCodeField;

        private string dateField;

        private string pINumberField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string Date
        {
            get
            {
                return this.dateField;
            }
            set
            {
                this.dateField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string PINumber
        {
            get
            {
                return this.pINumberField;
            }
            set
            {
                this.pINumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryRefRegNumber
    {

        private string countryCodeField;

        private string dateField;

        private string pINumberField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string Date
        {
            get
            {
                return this.dateField;
            }
            set
            {
                this.dateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string PINumber
        {
            get
            {
                return this.pINumberField;
            }
            set
            {
                this.pINumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryEntryCheckPointDetails
    {

        private string customsOfficeCodeField;

        private string borderCheckpointCodeField;

        private string borderCheckpointNameField;

        /// <remarks/>
        public string CustomsOfficeCode
        {
            get
            {
                return this.customsOfficeCodeField;
            }
            set
            {
                this.customsOfficeCodeField = value;
            }
        }

        /// <remarks/>
        public string BorderCheckpointCode
        {
            get
            {
                return this.borderCheckpointCodeField;
            }
            set
            {
                this.borderCheckpointCodeField = value;
            }
        }

        /// <remarks/>
        public string BorderCheckpointName
        {
            get
            {
                return this.borderCheckpointNameField;
            }
            set
            {
                this.borderCheckpointNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryDeclarantDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RKOrganizationFeatures rKOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        private RegisterDocumentIdDetails registerDocumentIdDetailsField;

        private bool equalIndicatorField;

        private string[] textField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RKOrganizationFeatures RKOrganizationFeatures
        {
            get
            {
                return this.rKOrganizationFeaturesField;
            }
            set
            {
                this.rKOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public RegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public bool EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string[] Text
        {
            get
            {
                return this.textField;
            }
            set
            {
                this.textField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", IsNullable = false)]
    public partial class RKOrganizationFeatures
    {

        private string bINField;

        private string iINField;

        private string iTNField;

        /// <remarks/>
        public string BIN
        {
            get
            {
                return this.bINField;
            }
            set
            {
                this.bINField = value;
            }
        }

        /// <remarks/>
        public string IIN
        {
            get
            {
                return this.iINField;
            }
            set
            {
                this.iINField = value;
            }
        }

        /// <remarks/>
        public string ITN
        {
            get
            {
                return this.iTNField;
            }
            set
            {
                this.iTNField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class BusinessEntityTypeCode
    {

        private string unifiedCodeField;

        private string codeListIdField;

        /// <remarks/>
        public string UnifiedCode
        {
            get
            {
                return this.unifiedCodeField;
            }
            set
            {
                this.unifiedCodeField = value;
            }
        }

        /// <remarks/>
        public string CodeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class UITN
    {

        private string uITNCodeField;

        private string countryCodeField;

        /// <remarks/>
        public string UITNCode
        {
            get
            {
                return this.uITNCodeField;
            }
            set
            {
                this.uITNCodeField = value;
            }
        }

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class IdentityCard
    {

        private byte identityCardCodeField;

        private string identityCardNameField;

        private string fullIdentityCardNameField;

        private string identityCardSeriesField;

        private string identityCardNumberField;

        private System.DateTime identityCardDateField;

        private System.DateTime docValidityDateField;

        private string organizationNameField;

        private string issuerCodeField;

        private string authorityIdField;

        private string countryCodeField;

        /// <remarks/>
        public byte IdentityCardCode
        {
            get
            {
                return this.identityCardCodeField;
            }
            set
            {
                this.identityCardCodeField = value;
            }
        }

        /// <remarks/>
        public string IdentityCardName
        {
            get
            {
                return this.identityCardNameField;
            }
            set
            {
                this.identityCardNameField = value;
            }
        }

        /// <remarks/>
        public string FullIdentityCardName
        {
            get
            {
                return this.fullIdentityCardNameField;
            }
            set
            {
                this.fullIdentityCardNameField = value;
            }
        }

        /// <remarks/>
        public string IdentityCardSeries
        {
            get
            {
                return this.identityCardSeriesField;
            }
            set
            {
                this.identityCardSeriesField = value;
            }
        }

        /// <remarks/>
        public string IdentityCardNumber
        {
            get
            {
                return this.identityCardNumberField;
            }
            set
            {
                this.identityCardNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime IdentityCardDate
        {
            get
            {
                return this.identityCardDateField;
            }
            set
            {
                this.identityCardDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }

        /// <remarks/>
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        public string IssuerCode
        {
            get
            {
                return this.issuerCodeField;
            }
            set
            {
                this.issuerCodeField = value;
            }
        }

        /// <remarks/>
        public string AuthorityId
        {
            get
            {
                return this.authorityIdField;
            }
            set
            {
                this.authorityIdField = value;
            }
        }

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class SubjectAddressDetails
    {

        private string addressKindCodeField;

        private string postalCodeField;

        private string countryCodeField;

        private string counryNameField;

        private string regionField;

        private string districtField;

        private string townField;

        private string cityField;

        private string streetHouseField;

        private string houseField;

        private string roomField;

        private string addressTextField;

        private string oKTMOField;

        private byte oKATOField;

        private string kLADRField;

        private string aOGUIDField;

        private string aOIDField;

        private string territoryCodeField;

        private string postOfficeBoxIdField;

        /// <remarks/>
        public string AddressKindCode
        {
            get
            {
                return this.addressKindCodeField;
            }
            set
            {
                this.addressKindCodeField = value;
            }
        }

        /// <remarks/>
        public string PostalCode
        {
            get
            {
                return this.postalCodeField;
            }
            set
            {
                this.postalCodeField = value;
            }
        }

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string CounryName
        {
            get
            {
                return this.counryNameField;
            }
            set
            {
                this.counryNameField = value;
            }
        }

        /// <remarks/>
        public string Region
        {
            get
            {
                return this.regionField;
            }
            set
            {
                this.regionField = value;
            }
        }

        /// <remarks/>
        public string District
        {
            get
            {
                return this.districtField;
            }
            set
            {
                this.districtField = value;
            }
        }

        /// <remarks/>
        public string Town
        {
            get
            {
                return this.townField;
            }
            set
            {
                this.townField = value;
            }
        }

        /// <remarks/>
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <remarks/>
        public string StreetHouse
        {
            get
            {
                return this.streetHouseField;
            }
            set
            {
                this.streetHouseField = value;
            }
        }

        /// <remarks/>
        public string House
        {
            get
            {
                return this.houseField;
            }
            set
            {
                this.houseField = value;
            }
        }

        /// <remarks/>
        public string Room
        {
            get
            {
                return this.roomField;
            }
            set
            {
                this.roomField = value;
            }
        }

        /// <remarks/>
        public string AddressText
        {
            get
            {
                return this.addressTextField;
            }
            set
            {
                this.addressTextField = value;
            }
        }

        /// <remarks/>
        public string OKTMO
        {
            get
            {
                return this.oKTMOField;
            }
            set
            {
                this.oKTMOField = value;
            }
        }

        /// <remarks/>
        public byte OKATO
        {
            get
            {
                return this.oKATOField;
            }
            set
            {
                this.oKATOField = value;
            }
        }

        /// <remarks/>
        public string KLADR
        {
            get
            {
                return this.kLADRField;
            }
            set
            {
                this.kLADRField = value;
            }
        }

        /// <remarks/>
        public string AOGUID
        {
            get
            {
                return this.aOGUIDField;
            }
            set
            {
                this.aOGUIDField = value;
            }
        }

        /// <remarks/>
        public string AOID
        {
            get
            {
                return this.aOIDField;
            }
            set
            {
                this.aOIDField = value;
            }
        }

        /// <remarks/>
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }

        /// <remarks/>
        public string PostOfficeBoxId
        {
            get
            {
                return this.postOfficeBoxIdField;
            }
            set
            {
                this.postOfficeBoxIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class CommunicationDetails
    {

        private string[] phoneField;

        private string faxField;

        private string telexField;

        private string[] e_mailField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Phone", Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string[] Phone
        {
            get
            {
                return this.phoneField;
            }
            set
            {
                this.phoneField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string Fax
        {
            get
            {
                return this.faxField;
            }
            set
            {
                this.faxField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string Telex
        {
            get
            {
                return this.telexField;
            }
            set
            {
                this.telexField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("E_mail", Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string[] E_mail
        {
            get
            {
                return this.e_mailField;
            }
            set
            {
                this.e_mailField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class RegisterDocumentIdDetails
    {

        private string[] itemsField;

        private ItemsChoiceType[] itemsElementNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("AEORegistryKindCode", typeof(string), Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        [System.Xml.Serialization.XmlElementAttribute("CountryA2Code", typeof(string), Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        [System.Xml.Serialization.XmlElementAttribute("DocId", typeof(string), Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        [System.Xml.Serialization.XmlElementAttribute("RegistrationNumberId", typeof(string), Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        [System.Xml.Serialization.XmlElementAttribute("RegistryOwnerCode", typeof(string), Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        [System.Xml.Serialization.XmlElementAttribute("ReregistrationCode", typeof(string), Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        [System.Xml.Serialization.XmlChoiceIdentifierAttribute("ItemsElementName")]
        public string[] Items
        {
            get
            {
                return this.itemsField;
            }
            set
            {
                this.itemsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ItemsElementName")]
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public ItemsChoiceType[] ItemsElementName
        {
            get
            {
                return this.itemsElementNameField;
            }
            set
            {
                this.itemsElementNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IncludeInSchema = false)]
    public enum ItemsChoiceType
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("urn:customs.ru:RUSCommonAggregateTypes:5.15.0:AEORegistryKindCode")]
        AEORegistryKindCode,

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("urn:customs.ru:RUSCommonAggregateTypes:5.15.0:CountryA2Code")]
        CountryA2Code,

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("urn:customs.ru:RUSCommonAggregateTypes:5.15.0:DocId")]
        DocId,

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("urn:customs.ru:RUSCommonAggregateTypes:5.15.0:RegistrationNumberId")]
        RegistrationNumberId,

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("urn:customs.ru:RUSCommonAggregateTypes:5.15.0:RegistryOwnerCode")]
        RegistryOwnerCode,

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("urn:customs.ru:RUSCommonAggregateTypes:5.15.0:ReregistrationCode")]
        ReregistrationCode,
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryBorderTransportDetails
    {

        private byte transportModeCodeField;

        private byte transportMeansQuantityField;

        private string containerIndicatorField;

        private string transportMeansRegIdField;

        private string transportMeansCountryCodeField;

        private string vINIDField;

        private string chassisIDField;

        private string bodyIDField;

        private string transportKindCodeField;

        private string markCodeField;

        private AutoPreliminaryBorderTransportDetailsTrailerDetails[] trailerDetailsField;

        private AutoPreliminaryBorderTransportDetailsTransportMeansGrossMass transportMeansGrossMassField;

        private AutoPreliminaryBorderTransportDetailsRouteDetails[] routeDetailsField;

        private string purposeField;

        private AutoPreliminaryBorderTransportDetailsPermitTranspornationDocDetails[] permitTranspornationDocDetailsField;

        /// <remarks/>
        public byte TransportModeCode
        {
            get
            {
                return this.transportModeCodeField;
            }
            set
            {
                this.transportModeCodeField = value;
            }
        }

        /// <remarks/>
        public byte TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        public string ContainerIndicator
        {
            get
            {
                return this.containerIndicatorField;
            }
            set
            {
                this.containerIndicatorField = value;
            }
        }

        /// <remarks/>
        public string TransportMeansRegId
        {
            get
            {
                return this.transportMeansRegIdField;
            }
            set
            {
                this.transportMeansRegIdField = value;
            }
        }

        /// <remarks/>
        public string TransportMeansCountryCode
        {
            get
            {
                return this.transportMeansCountryCodeField;
            }
            set
            {
                this.transportMeansCountryCodeField = value;
            }
        }

        /// <remarks/>
        public string VINID
        {
            get
            {
                return this.vINIDField;
            }
            set
            {
                this.vINIDField = value;
            }
        }

        /// <remarks/>
        public string ChassisID
        {
            get
            {
                return this.chassisIDField;
            }
            set
            {
                this.chassisIDField = value;
            }
        }

        /// <remarks/>
        public string BodyID
        {
            get
            {
                return this.bodyIDField;
            }
            set
            {
                this.bodyIDField = value;
            }
        }

        /// <remarks/>
        public string TransportKindCode
        {
            get
            {
                return this.transportKindCodeField;
            }
            set
            {
                this.transportKindCodeField = value;
            }
        }

        /// <remarks/>
        public string MarkCode
        {
            get
            {
                return this.markCodeField;
            }
            set
            {
                this.markCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("TrailerDetails")]
        public AutoPreliminaryBorderTransportDetailsTrailerDetails[] TrailerDetails
        {
            get
            {
                return this.trailerDetailsField;
            }
            set
            {
                this.trailerDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryBorderTransportDetailsTransportMeansGrossMass TransportMeansGrossMass
        {
            get
            {
                return this.transportMeansGrossMassField;
            }
            set
            {
                this.transportMeansGrossMassField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("RouteDetails")]
        public AutoPreliminaryBorderTransportDetailsRouteDetails[] RouteDetails
        {
            get
            {
                return this.routeDetailsField;
            }
            set
            {
                this.routeDetailsField = value;
            }
        }

        /// <remarks/>
        public string Purpose
        {
            get
            {
                return this.purposeField;
            }
            set
            {
                this.purposeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PermitTranspornationDocDetails")]
        public AutoPreliminaryBorderTransportDetailsPermitTranspornationDocDetails[] PermitTranspornationDocDetails
        {
            get
            {
                return this.permitTranspornationDocDetailsField;
            }
            set
            {
                this.permitTranspornationDocDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryBorderTransportDetailsTrailerDetails
    {

        private string transportMeansRegIdField;

        private string transportMeansCountryCodeField;

        private string vINIDField;

        private string chassisIDField;

        private string bodyIDField;

        private string transportKindCodeField;

        private string markCodeField;

        /// <remarks/>
        public string TransportMeansRegId
        {
            get
            {
                return this.transportMeansRegIdField;
            }
            set
            {
                this.transportMeansRegIdField = value;
            }
        }

        /// <remarks/>
        public string TransportMeansCountryCode
        {
            get
            {
                return this.transportMeansCountryCodeField;
            }
            set
            {
                this.transportMeansCountryCodeField = value;
            }
        }

        /// <remarks/>
        public string VINID
        {
            get
            {
                return this.vINIDField;
            }
            set
            {
                this.vINIDField = value;
            }
        }

        /// <remarks/>
        public string ChassisID
        {
            get
            {
                return this.chassisIDField;
            }
            set
            {
                this.chassisIDField = value;
            }
        }

        /// <remarks/>
        public string BodyID
        {
            get
            {
                return this.bodyIDField;
            }
            set
            {
                this.bodyIDField = value;
            }
        }

        /// <remarks/>
        public string TransportKindCode
        {
            get
            {
                return this.transportKindCodeField;
            }
            set
            {
                this.transportKindCodeField = value;
            }
        }

        /// <remarks/>
        public string MarkCode
        {
            get
            {
                return this.markCodeField;
            }
            set
            {
                this.markCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryBorderTransportDetailsTransportMeansGrossMass
    {

        private decimal measuredAmountField;

        private string measureUnitQualifierNameField;

        private string measureUnitQualifierCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public decimal MeasuredAmount
        {
            get
            {
                return this.measuredAmountField;
            }
            set
            {
                this.measuredAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryBorderTransportDetailsRouteDetails
    {

        private string countryCodeField;

        private string placeNameField;

        private byte objectOrdinalField;

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        public byte ObjectOrdinal
        {
            get
            {
                return this.objectOrdinalField;
            }
            set
            {
                this.objectOrdinalField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryBorderTransportDetailsPermitTranspornationDocDetails
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private string prDocumentDateField;

        private System.DateTime docStartDateField;

        private System.DateTime docValidityDateField;

        private string docKindCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetails
    {

        private bool tIRCarnetIndicatorField;

        private AutoPreliminaryMainConsignmentDetailsTIRCarnetIdDetails tIRCarnetIdDetailsField;

        private string declarationKindCodeField;

        private string transitProcedureCodeField;

        private string transitFeatureCodeField;

        private string loadingListsQuantityField;

        private string loadingListsPageQuantityField;

        private string goodsQuantityField;

        private string cargoQuantityField;

        private AutoPreliminaryMainConsignmentDetailsSealDetails sealDetailsField;

        private AutoPreliminaryMainConsignmentDetailsPITransitTransportMeansDetails pITransitTransportMeansDetailsField;

        private AutoPreliminaryMainConsignmentDetailsTransitTerminationDetails transitTerminationDetailsField;

        private AutoPreliminaryMainConsignmentDetailsPITranshipmentDetails[] pITranshipmentDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetails[] consignmentDetailsField;

        private AutoPreliminaryMainConsignmentDetailsTransitGuaranteeDetails[] transitGuaranteeDetailsField;

        private AutoPreliminaryMainConsignmentDetailsTransitDeclarantDetails transitDeclarantDetailsField;

        private AutoPreliminaryMainConsignmentDetailsUnionCarrierDetails unionCarrierDetailsField;

        private AutoPreliminaryMainConsignmentDetailsRailwayStampDetails railwayStampDetailsField;

        /// <remarks/>
        public bool TIRCarnetIndicator
        {
            get
            {
                return this.tIRCarnetIndicatorField;
            }
            set
            {
                this.tIRCarnetIndicatorField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsTIRCarnetIdDetails TIRCarnetIdDetails
        {
            get
            {
                return this.tIRCarnetIdDetailsField;
            }
            set
            {
                this.tIRCarnetIdDetailsField = value;
            }
        }

        /// <remarks/>
        public string DeclarationKindCode
        {
            get
            {
                return this.declarationKindCodeField;
            }
            set
            {
                this.declarationKindCodeField = value;
            }
        }

        /// <remarks/>
        public string TransitProcedureCode
        {
            get
            {
                return this.transitProcedureCodeField;
            }
            set
            {
                this.transitProcedureCodeField = value;
            }
        }

        /// <remarks/>
        public string TransitFeatureCode
        {
            get
            {
                return this.transitFeatureCodeField;
            }
            set
            {
                this.transitFeatureCodeField = value;
            }
        }

        /// <remarks/>
        public string LoadingListsQuantity
        {
            get
            {
                return this.loadingListsQuantityField;
            }
            set
            {
                this.loadingListsQuantityField = value;
            }
        }

        /// <remarks/>
        public string LoadingListsPageQuantity
        {
            get
            {
                return this.loadingListsPageQuantityField;
            }
            set
            {
                this.loadingListsPageQuantityField = value;
            }
        }

        /// <remarks/>
        public string GoodsQuantity
        {
            get
            {
                return this.goodsQuantityField;
            }
            set
            {
                this.goodsQuantityField = value;
            }
        }

        /// <remarks/>
        public string CargoQuantity
        {
            get
            {
                return this.cargoQuantityField;
            }
            set
            {
                this.cargoQuantityField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsSealDetails SealDetails
        {
            get
            {
                return this.sealDetailsField;
            }
            set
            {
                this.sealDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsPITransitTransportMeansDetails PITransitTransportMeansDetails
        {
            get
            {
                return this.pITransitTransportMeansDetailsField;
            }
            set
            {
                this.pITransitTransportMeansDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsTransitTerminationDetails TransitTerminationDetails
        {
            get
            {
                return this.transitTerminationDetailsField;
            }
            set
            {
                this.transitTerminationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PITranshipmentDetails")]
        public AutoPreliminaryMainConsignmentDetailsPITranshipmentDetails[] PITranshipmentDetails
        {
            get
            {
                return this.pITranshipmentDetailsField;
            }
            set
            {
                this.pITranshipmentDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ConsignmentDetails")]
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetails[] ConsignmentDetails
        {
            get
            {
                return this.consignmentDetailsField;
            }
            set
            {
                this.consignmentDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("TransitGuaranteeDetails")]
        public AutoPreliminaryMainConsignmentDetailsTransitGuaranteeDetails[] TransitGuaranteeDetails
        {
            get
            {
                return this.transitGuaranteeDetailsField;
            }
            set
            {
                this.transitGuaranteeDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsTransitDeclarantDetails TransitDeclarantDetails
        {
            get
            {
                return this.transitDeclarantDetailsField;
            }
            set
            {
                this.transitDeclarantDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsUnionCarrierDetails UnionCarrierDetails
        {
            get
            {
                return this.unionCarrierDetailsField;
            }
            set
            {
                this.unionCarrierDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsRailwayStampDetails RailwayStampDetails
        {
            get
            {
                return this.railwayStampDetailsField;
            }
            set
            {
                this.railwayStampDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsTIRCarnetIdDetails
    {

        private string tIRSeriesField;

        private string tIRIDField;

        private byte tIRPageOrdinalField;

        private string tIRHolderIDField;

        /// <remarks/>
        public string TIRSeries
        {
            get
            {
                return this.tIRSeriesField;
            }
            set
            {
                this.tIRSeriesField = value;
            }
        }

        /// <remarks/>
        public string TIRID
        {
            get
            {
                return this.tIRIDField;
            }
            set
            {
                this.tIRIDField = value;
            }
        }

        /// <remarks/>
        public byte TIRPageOrdinal
        {
            get
            {
                return this.tIRPageOrdinalField;
            }
            set
            {
                this.tIRPageOrdinalField = value;
            }
        }

        /// <remarks/>
        public string TIRHolderID
        {
            get
            {
                return this.tIRHolderIDField;
            }
            set
            {
                this.tIRHolderIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsSealDetails
    {

        private string sealQuantityField;

        private string[] sealNumberField;

        private string[] sealIdField;

        private string[] sealDescriptionTextField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string SealQuantity
        {
            get
            {
                return this.sealQuantityField;
            }
            set
            {
                this.sealQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SealNumber", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string[] SealNumber
        {
            get
            {
                return this.sealNumberField;
            }
            set
            {
                this.sealNumberField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SealId", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string[] SealId
        {
            get
            {
                return this.sealIdField;
            }
            set
            {
                this.sealIdField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SealDescriptionText", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string[] SealDescriptionText
        {
            get
            {
                return this.sealDescriptionTextField;
            }
            set
            {
                this.sealDescriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsPITransitTransportMeansDetails
    {

        private bool equalIndicatorField;

        private string transporKindField;

        private byte transportMeansQuantityField;

        private TransportMeansRegistrationId[] transportMeansRegistrationIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public bool EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string TransporKind
        {
            get
            {
                return this.transporKindField;
            }
            set
            {
                this.transporKindField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public byte TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("TransportMeansRegistrationId", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public TransportMeansRegistrationId[] TransportMeansRegistrationId
        {
            get
            {
                return this.transportMeansRegistrationIdField;
            }
            set
            {
                this.transportMeansRegistrationIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class TransportMeansRegistrationId
    {

        private string transportIdentifierField;

        private string trailerIdentifierField;

        private string secondTrailerIdentifierField;

        private string transportMeansNationalityCodeField;

        private string vINIDField;

        private string transportModeCodeField;

        private string transportMarkCodeField;

        private string docIDField;

        /// <remarks/>
        public string TransportIdentifier
        {
            get
            {
                return this.transportIdentifierField;
            }
            set
            {
                this.transportIdentifierField = value;
            }
        }

        /// <remarks/>
        public string TrailerIdentifier
        {
            get
            {
                return this.trailerIdentifierField;
            }
            set
            {
                this.trailerIdentifierField = value;
            }
        }

        /// <remarks/>
        public string SecondTrailerIdentifier
        {
            get
            {
                return this.secondTrailerIdentifierField;
            }
            set
            {
                this.secondTrailerIdentifierField = value;
            }
        }

        /// <remarks/>
        public string TransportMeansNationalityCode
        {
            get
            {
                return this.transportMeansNationalityCodeField;
            }
            set
            {
                this.transportMeansNationalityCodeField = value;
            }
        }

        /// <remarks/>
        public string VINID
        {
            get
            {
                return this.vINIDField;
            }
            set
            {
                this.vINIDField = value;
            }
        }

        /// <remarks/>
        public string TransportModeCode
        {
            get
            {
                return this.transportModeCodeField;
            }
            set
            {
                this.transportModeCodeField = value;
            }
        }

        /// <remarks/>
        public string TransportMarkCode
        {
            get
            {
                return this.transportMarkCodeField;
            }
            set
            {
                this.transportMarkCodeField = value;
            }
        }

        /// <remarks/>
        public string DocID
        {
            get
            {
                return this.docIDField;
            }
            set
            {
                this.docIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsTransitTerminationDetails
    {

        private CustomsOfficeDetails customsOfficeDetailsField;

        private string customsControlZoneIdField;

        private RegisterDocumentIdDetails registerDocumentIdDetailsField;

        private SubjectAddressDetails1 subjectAddressDetailsField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public CustomsOfficeDetails CustomsOfficeDetails
        {
            get
            {
                return this.customsOfficeDetailsField;
            }
            set
            {
                this.customsOfficeDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string CustomsControlZoneId
        {
            get
            {
                return this.customsControlZoneIdField;
            }
            set
            {
                this.customsControlZoneIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public RegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails1 SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class CustomsOfficeDetails
    {

        private string codeField;

        private string officeNameField;

        private string countryCodeField;

        private string countryCode1Field;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OfficeName
        {
            get
            {
                return this.officeNameField;
            }
            set
            {
                this.officeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urnx")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("CountryCode")]
        public string CountryCode1
        {
            get
            {
                return this.countryCode1Field;
            }
            set
            {
                this.countryCode1Field = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class SubjectAddressDetails1
    {

        private string addressKindCodeField;

        private string postalCodeField;

        private string countryCodeField;

        private string counryNameField;

        private string regionField;

        private string districtField;

        private string townField;

        private string cityField;

        private string streetHouseField;

        private string houseField;

        private string roomField;

        private string addressTextField;

        private string oKTMOField;

        private byte oKATOField;

        private string kLADRField;

        private string aOGUIDField;

        private string aOIDField;

        private string territoryCodeField;

        private string postOfficeBoxIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AddressKindCode
        {
            get
            {
                return this.addressKindCodeField;
            }
            set
            {
                this.addressKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PostalCode
        {
            get
            {
                return this.postalCodeField;
            }
            set
            {
                this.postalCodeField = value;
            }
        }

        /// <remarks/> nestas
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "vzt")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "vzt")]
        public string CounryName
        {
            get
            {
                return this.counryNameField;
            }
            set
            {
                this.counryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "vzt")]
        public string Region
        {
            get
            {
                return this.regionField;
            }
            set
            {
                this.regionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "vzt")]
        public string District
        {
            get
            {
                return this.districtField;
            }
            set
            {
                this.districtField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Town
        {
            get
            {
                return this.townField;
            }
            set
            {
                this.townField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string StreetHouse
        {
            get
            {
                return this.streetHouseField;
            }
            set
            {
                this.streetHouseField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string House
        {
            get
            {
                return this.houseField;
            }
            set
            {
                this.houseField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Room
        {
            get
            {
                return this.roomField;
            }
            set
            {
                this.roomField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AddressText
        {
            get
            {
                return this.addressTextField;
            }
            set
            {
                this.addressTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string OKTMO
        {
            get
            {
                return this.oKTMOField;
            }
            set
            {
                this.oKTMOField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public byte OKATO
        {
            get
            {
                return this.oKATOField;
            }
            set
            {
                this.oKATOField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string KLADR
        {
            get
            {
                return this.kLADRField;
            }
            set
            {
                this.kLADRField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AOGUID
        {
            get
            {
                return this.aOGUIDField;
            }
            set
            {
                this.aOGUIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AOID
        {
            get
            {
                return this.aOIDField;
            }
            set
            {
                this.aOIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PostOfficeBoxId
        {
            get
            {
                return this.postOfficeBoxIdField;
            }
            set
            {
                this.postOfficeBoxIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsPITranshipmentDetails
    {

        private string cargoOperationKindCodeField;

        private bool containerIndicatorField;

        private string countryCodeField;

        private string countryNameField;

        private string placeNameField;

        private CustomsOfficeDetails customsOfficeDetailsField;

        private TranshipmentTransportDetails transhipmentTransportDetailsField;

        private string[] containerNumberField;

        private string descriptionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string CargoOperationKindCode
        {
            get
            {
                return this.cargoOperationKindCodeField;
            }
            set
            {
                this.cargoOperationKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public bool ContainerIndicator
        {
            get
            {
                return this.containerIndicatorField;
            }
            set
            {
                this.containerIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string CountryName
        {
            get
            {
                return this.countryNameField;
            }
            set
            {
                this.countryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public CustomsOfficeDetails CustomsOfficeDetails
        {
            get
            {
                return this.customsOfficeDetailsField;
            }
            set
            {
                this.customsOfficeDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public TranshipmentTransportDetails TranshipmentTransportDetails
        {
            get
            {
                return this.transhipmentTransportDetailsField;
            }
            set
            {
                this.transhipmentTransportDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ContainerNumber", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string[] ContainerNumber
        {
            get
            {
                return this.containerNumberField;
            }
            set
            {
                this.containerNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class TranshipmentTransportDetails
    {

        private string transporKindField;

        private string countryCodeField;

        private byte transportMeansQuantityField;

        private TranshipmentTransportDetailsTransportMeansRegistrationId[] transportMeansRegistrationIdField;

        /// <remarks/>
        public string TransporKind
        {
            get
            {
                return this.transporKindField;
            }
            set
            {
                this.transporKindField = value;
            }
        }

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public byte TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("TransportMeansRegistrationId")]
        public TranshipmentTransportDetailsTransportMeansRegistrationId[] TransportMeansRegistrationId
        {
            get
            {
                return this.transportMeansRegistrationIdField;
            }
            set
            {
                this.transportMeansRegistrationIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class TranshipmentTransportDetailsTransportMeansRegistrationId
    {

        private string transportIdentifierField;

        private string trailerIdentifierField;

        private string secondTrailerIdentifierField;

        private string transportMeansNationalityCodeField;

        private string vINIDField;

        private string transportModeCodeField;

        private string transportMarkCodeField;

        private string docIDField;

        /// <remarks/>
        public string TransportIdentifier
        {
            get
            {
                return this.transportIdentifierField;
            }
            set
            {
                this.transportIdentifierField = value;
            }
        }

        /// <remarks/>
        public string TrailerIdentifier
        {
            get
            {
                return this.trailerIdentifierField;
            }
            set
            {
                this.trailerIdentifierField = value;
            }
        }

        /// <remarks/>
        public string SecondTrailerIdentifier
        {
            get
            {
                return this.secondTrailerIdentifierField;
            }
            set
            {
                this.secondTrailerIdentifierField = value;
            }
        }

        /// <remarks/>
        public string TransportMeansNationalityCode
        {
            get
            {
                return this.transportMeansNationalityCodeField;
            }
            set
            {
                this.transportMeansNationalityCodeField = value;
            }
        }

        /// <remarks/>
        public string VINID
        {
            get
            {
                return this.vINIDField;
            }
            set
            {
                this.vINIDField = value;
            }
        }

        /// <remarks/>
        public string TransportModeCode
        {
            get
            {
                return this.transportModeCodeField;
            }
            set
            {
                this.transportModeCodeField = value;
            }
        }

        /// <remarks/>
        public string TransportMarkCode
        {
            get
            {
                return this.transportMarkCodeField;
            }
            set
            {
                this.transportMarkCodeField = value;
            }
        }

        /// <remarks/>
        public string DocID
        {
            get
            {
                return this.docIDField;
            }
            set
            {
                this.docIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetails
    {

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsTransportDocumentDetails transportDocumentDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsCustomsDocIdDetails customsDocIdDetailsField;

        private string cargoQuantityField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDispatchCountry dispatchCountryField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationCountry destinationCountryField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsCAInvoiceValueAmount cAInvoiceValueAmountField;

        private string grossWeightQuantityField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsConsignorDetails consignorDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsConsigneeDetails consigneeDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsSellerDetails sellerDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsBuyerDetails buyerDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsLoadingLocationDetails loadingLocationDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsUnloadingLocationDetails unloadingLocationDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationDetails destinationDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsContainerDetails[] containerDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsUnloadWarehouseDetails unloadWarehouseDetailsField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsGoodsItem[] goodsItemField;

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsTransportDocumentDetails TransportDocumentDetails
        {
            get
            {
                return this.transportDocumentDetailsField;
            }
            set
            {
                this.transportDocumentDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsCustomsDocIdDetails CustomsDocIdDetails
        {
            get
            {
                return this.customsDocIdDetailsField;
            }
            set
            {
                this.customsDocIdDetailsField = value;
            }
        }

        /// <remarks/>
        public string CargoQuantity
        {
            get
            {
                return this.cargoQuantityField;
            }
            set
            {
                this.cargoQuantityField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDispatchCountry DispatchCountry
        {
            get
            {
                return this.dispatchCountryField;
            }
            set
            {
                this.dispatchCountryField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationCountry DestinationCountry
        {
            get
            {
                return this.destinationCountryField;
            }
            set
            {
                this.destinationCountryField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsCAInvoiceValueAmount CAInvoiceValueAmount
        {
            get
            {
                return this.cAInvoiceValueAmountField;
            }
            set
            {
                this.cAInvoiceValueAmountField = value;
            }
        }

        /// <remarks/>
        public string GrossWeightQuantity
        {
            get
            {
                return this.grossWeightQuantityField;
            }
            set
            {
                this.grossWeightQuantityField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsConsignorDetails ConsignorDetails
        {
            get
            {
                return this.consignorDetailsField;
            }
            set
            {
                this.consignorDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsConsigneeDetails ConsigneeDetails
        {
            get
            {
                return this.consigneeDetailsField;
            }
            set
            {
                this.consigneeDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsSellerDetails SellerDetails
        {
            get
            {
                return this.sellerDetailsField;
            }
            set
            {
                this.sellerDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsBuyerDetails BuyerDetails
        {
            get
            {
                return this.buyerDetailsField;
            }
            set
            {
                this.buyerDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsLoadingLocationDetails LoadingLocationDetails
        {
            get
            {
                return this.loadingLocationDetailsField;
            }
            set
            {
                this.loadingLocationDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsUnloadingLocationDetails UnloadingLocationDetails
        {
            get
            {
                return this.unloadingLocationDetailsField;
            }
            set
            {
                this.unloadingLocationDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationDetails DestinationDetails
        {
            get
            {
                return this.destinationDetailsField;
            }
            set
            {
                this.destinationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ContainerDetails")]
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsContainerDetails[] ContainerDetails
        {
            get
            {
                return this.containerDetailsField;
            }
            set
            {
                this.containerDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsUnloadWarehouseDetails UnloadWarehouseDetails
        {
            get
            {
                return this.unloadWarehouseDetailsField;
            }
            set
            {
                this.unloadWarehouseDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("GoodsItem")]
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsGoodsItem[] GoodsItem
        {
            get
            {
                return this.goodsItemField;
            }
            set
            {
                this.goodsItemField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsTransportDocumentDetails
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private string prDocumentDateField;

        private string docKindCodeField;

        private string placeNameField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsCustomsDocIdDetails
    {

        private byte customsCodeField;

        private System.DateTime registrationDateField;

        private string gTDNumberField;

        private string codeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public byte CustomsCode
        {
            get
            {
                return this.customsCodeField;
            }
            set
            {
                this.customsCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime RegistrationDate
        {
            get
            {
                return this.registrationDateField;
            }
            set
            {
                this.registrationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string GTDNumber
        {
            get
            {
                return this.gTDNumberField;
            }
            set
            {
                this.gTDNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDispatchCountry
    {

        private string countryCodeField;

        private string countryNameField;

        private string territoryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "dsp")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "dsp")]
        public string CountryName
        {
            get
            {
                return this.countryNameField;
            }
            set
            {
                this.countryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "dsp")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationCountry
    {

        private string countryCodeField;

        private string countryNameField;

        private string territoryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "ddc")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "ddc")]
        public string CountryName
        {
            get
            {
                return this.countryNameField;
            }
            set
            {
                this.countryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "ddc")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsCAInvoiceValueAmount
    {

        private string amountField;

        private string currencyCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CurrencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsConsignorDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private RKOrganizationFeatures rKOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        private bool equalIndicatorField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RKOrganizationFeatures RKOrganizationFeatures
        {
            get
            {
                return this.rKOrganizationFeaturesField;
            }
            set
            {
                this.rKOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        public bool EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", IsNullable = false)]
    public partial class RFOrganizationFeatures
    {

        private byte oGRNField;

        private string iNNField;

        private byte kPPField;

        /// <remarks/>
        public byte OGRN
        {
            get
            {
                return this.oGRNField;
            }
            set
            {
                this.oGRNField = value;
            }
        }

        /// <remarks/>
        public string INN
        {
            get
            {
                return this.iNNField;
            }
            set
            {
                this.iNNField = value;
            }
        }

        /// <remarks/>
        public byte KPP
        {
            get
            {
                return this.kPPField;
            }
            set
            {
                this.kPPField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsConsigneeDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private RKOrganizationFeatures rKOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        private bool equalIndicatorField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RKOrganizationFeatures RKOrganizationFeatures
        {
            get
            {
                return this.rKOrganizationFeaturesField;
            }
            set
            {
                this.rKOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        public bool EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsSellerDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsBuyerDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsLoadingLocationDetails
    {

        private string countryCodeField;

        private string placeNameField;

        private string eventDateField;

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsUnloadingLocationDetails
    {

        private string countryCodeField;

        private string placeNameField;

        private string eventDateField;

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationDetails
    {

        private string countryCodeField;

        private string placeNameField;

        private AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationDetailsAddress addressField;

        private byte customsCodeField;

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationDetailsAddress Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <remarks/>
        public byte CustomsCode
        {
            get
            {
                return this.customsCodeField;
            }
            set
            {
                this.customsCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsDestinationDetailsAddress
    {

        private string addressKindCodeField;

        private string postalCodeField;

        private string countryCodeField;

        private string counryNameField;

        private string regionField;

        private string districtField;

        private string townField;

        private string cityField;

        private string streetHouseField;

        private string houseField;

        private string roomField;

        private string addressTextField;

        private string oKTMOField;

        private byte oKATOField;

        private string kLADRField;

        private string aOGUIDField;

        private string aOIDField;

        private string territoryCodeField;

        private string postOfficeBoxIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AddressKindCode
        {
            get
            {
                return this.addressKindCodeField;
            }
            set
            {
                this.addressKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PostalCode
        {
            get
            {
                return this.postalCodeField;
            }
            set
            {
                this.postalCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CounryName
        {
            get
            {
                return this.counryNameField;
            }
            set
            {
                this.counryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Region
        {
            get
            {
                return this.regionField;
            }
            set
            {
                this.regionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string District
        {
            get
            {
                return this.districtField;
            }
            set
            {
                this.districtField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Town
        {
            get
            {
                return this.townField;
            }
            set
            {
                this.townField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string StreetHouse
        {
            get
            {
                return this.streetHouseField;
            }
            set
            {
                this.streetHouseField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string House
        {
            get
            {
                return this.houseField;
            }
            set
            {
                this.houseField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Room
        {
            get
            {
                return this.roomField;
            }
            set
            {
                this.roomField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AddressText
        {
            get
            {
                return this.addressTextField;
            }
            set
            {
                this.addressTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string OKTMO
        {
            get
            {
                return this.oKTMOField;
            }
            set
            {
                this.oKTMOField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public byte OKATO
        {
            get
            {
                return this.oKATOField;
            }
            set
            {
                this.oKATOField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string KLADR
        {
            get
            {
                return this.kLADRField;
            }
            set
            {
                this.kLADRField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AOGUID
        {
            get
            {
                return this.aOGUIDField;
            }
            set
            {
                this.aOGUIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AOID
        {
            get
            {
                return this.aOIDField;
            }
            set
            {
                this.aOIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PostOfficeBoxId
        {
            get
            {
                return this.postOfficeBoxIdField;
            }
            set
            {
                this.postOfficeBoxIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsContainerDetails
    {

        private string containerNumberField;

        private string countryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string ContainerNumber
        {
            get
            {
                return this.containerNumberField;
            }
            set
            {
                this.containerNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsUnloadWarehouseDetails
    {

        private string informationTypeCodeField;

        private string placeNameField;

        private GoodsLocationDocDetails goodsLocationDocDetailsField;

        private RegisterDocumentIdDetails registerDocumentIdDetailsField;

        private System.DateTime warehouseDateField;

        private StorageRequirementDetails storageRequirementDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string InformationTypeCode
        {
            get
            {
                return this.informationTypeCodeField;
            }
            set
            {
                this.informationTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public GoodsLocationDocDetails GoodsLocationDocDetails
        {
            get
            {
                return this.goodsLocationDocDetailsField;
            }
            set
            {
                this.goodsLocationDocDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public RegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime WarehouseDate
        {
            get
            {
                return this.warehouseDateField;
            }
            set
            {
                this.warehouseDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public StorageRequirementDetails StorageRequirementDetails
        {
            get
            {
                return this.storageRequirementDetailsField;
            }
            set
            {
                this.storageRequirementDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class GoodsLocationDocDetails
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private string prDocumentDateField;

        private System.DateTime docStartDateField;

        private System.DateTime docValidityDateField;

        private string docKindCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class StorageRequirementDetails
    {

        private bool specialStorageRequirementIndicatorField;

        private string descriptionField;

        /// <remarks/>
        public bool SpecialStorageRequirementIndicator
        {
            get
            {
                return this.specialStorageRequirementIndicatorField;
            }
            set
            {
                this.specialStorageRequirementIndicatorField = value;
            }
        }

        /// <remarks/>
        public string Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsConsignmentDetailsGoodsItem
    {

        private string goodsNumericField;

        private string goodsTNVEDCodeField;

        private string[] goodsDescriptionField;

        private string grossWeightQuantityField;

        private string netWeightQuantityField;

        private GoodsMeasureQuantity goodsMeasureQuantityField;

        private byte[] dTConsignmentItemOrdinalField;

        private bool militaryProductsField;

        private AddGoodsMeasureQuantity[] addGoodsMeasureQuantityField;

        private string[] productionPlaceNameField;

        private string goodsLabelDescriptionField;

        private string goodsUsageDescriptionField;

        private Manufacturer[] manufacturerField;

        private VetReleaseOrganizationDetails[] vetReleaseOrganizationDetailsField;

        private CargoPackagePalletDetails[] cargoPackagePalletDetailsField;

        private PIContainerDetails[] pIContainerDetailsField;

        private OriginCountryDetails originCountryDetailsField;

        private CAValueAmount cAValueAmountField;

        private PIPrecedingDocDetails[] pIPrecedingDocDetailsField;

        private PIGoodsDocDetails[] pIGoodsDocDetailsField;

        private PIShipmentLocationDetails[] pIShipmentLocationDetailsField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string GoodsNumeric
        {
            get
            {
                return this.goodsNumericField;
            }
            set
            {
                this.goodsNumericField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string GoodsTNVEDCode
        {
            get
            {
                return this.goodsTNVEDCodeField;
            }
            set
            {
                this.goodsTNVEDCodeField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("GoodsDescription", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string[] GoodsDescription
        {
            get
            {
                return this.goodsDescriptionField;
            }
            set
            {
                this.goodsDescriptionField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string GrossWeightQuantity
        {
            get
            {
                return this.grossWeightQuantityField;
            }
            set
            {
                this.grossWeightQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string NetWeightQuantity
        {
            get
            {
                return this.netWeightQuantityField;
            }
            set
            {
                this.netWeightQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public GoodsMeasureQuantity GoodsMeasureQuantity
        {
            get
            {
                return this.goodsMeasureQuantityField;
            }
            set
            {
                this.goodsMeasureQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("DTConsignmentItemOrdinal", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public byte[] DTConsignmentItemOrdinal
        {
            get
            {
                return this.dTConsignmentItemOrdinalField;
            }
            set
            {
                this.dTConsignmentItemOrdinalField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public bool MilitaryProducts
        {
            get
            {
                return this.militaryProductsField;
            }
            set
            {
                this.militaryProductsField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("AddGoodsMeasureQuantity", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public AddGoodsMeasureQuantity[] AddGoodsMeasureQuantity
        {
            get
            {
                return this.addGoodsMeasureQuantityField;
            }
            set
            {
                this.addGoodsMeasureQuantityField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("ProductionPlaceName", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string[] ProductionPlaceName
        {
            get
            {
                return this.productionPlaceNameField;
            }
            set
            {
                this.productionPlaceNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string GoodsLabelDescription
        {
            get
            {
                return this.goodsLabelDescriptionField;
            }
            set
            {
                this.goodsLabelDescriptionField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string GoodsUsageDescription
        {
            get
            {
                return this.goodsUsageDescriptionField;
            }
            set
            {
                this.goodsUsageDescriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Manufacturer", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public Manufacturer[] Manufacturer
        {
            get
            {
                return this.manufacturerField;
            }
            set
            {
                this.manufacturerField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("VetReleaseOrganizationDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public VetReleaseOrganizationDetails[] VetReleaseOrganizationDetails
        {
            get
            {
                return this.vetReleaseOrganizationDetailsField;
            }
            set
            {
                this.vetReleaseOrganizationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("CargoPackagePalletDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public CargoPackagePalletDetails[] CargoPackagePalletDetails
        {
            get
            {
                return this.cargoPackagePalletDetailsField;
            }
            set
            {
                this.cargoPackagePalletDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PIContainerDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public PIContainerDetails[] PIContainerDetails
        {
            get
            {
                return this.pIContainerDetailsField;
            }
            set
            {
                this.pIContainerDetailsField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public OriginCountryDetails OriginCountryDetails
        {
            get
            {
                return this.originCountryDetailsField;
            }
            set
            {
                this.originCountryDetailsField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public CAValueAmount CAValueAmount
        {
            get
            {
                return this.cAValueAmountField;
            }
            set
            {
                this.cAValueAmountField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("PIPrecedingDocDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public PIPrecedingDocDetails[] PIPrecedingDocDetails
        {
            get
            {
                return this.pIPrecedingDocDetailsField;
            }
            set
            {
                this.pIPrecedingDocDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PIGoodsDocDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public PIGoodsDocDetails[] PIGoodsDocDetails
        {
            get
            {
                return this.pIGoodsDocDetailsField;
            }
            set
            {
                this.pIGoodsDocDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PIShipmentLocationDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public PIShipmentLocationDetails[] PIShipmentLocationDetails
        {
            get
            {
                return this.pIShipmentLocationDetailsField;
            }
            set
            {
                this.pIShipmentLocationDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class GoodsMeasureQuantity
    {

        private byte goodsQuantityField;

        private string measureUnitQualifierNameField;

        private string measureUnitQualifierCodeField;

        /// <remarks/>
        public byte GoodsQuantity
        {
            get
            {
                return this.goodsQuantityField;
            }
            set
            {
                this.goodsQuantityField = value;
            }
        }

        /// <remarks/>
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        public string MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class AddGoodsMeasureQuantity
    {

        private byte goodsQuantityField;

        private string measureUnitQualifierNameField;

        private string measureUnitQualifierCodeField;

        /// <remarks/>
        public byte GoodsQuantity
        {
            get
            {
                return this.goodsQuantityField;
            }
            set
            {
                this.goodsQuantityField = value;
            }
        }

        /// <remarks/>
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        public string MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class Manufacturer
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class VetReleaseOrganizationDetails
    {

        private string subjectNameField;

        private string veterinaryOrganizationIdField;

        /// <remarks/>
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        public string VeterinaryOrganizationId
        {
            get
            {
                return this.veterinaryOrganizationIdField;
            }
            set
            {
                this.veterinaryOrganizationIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class CargoPackagePalletDetails
    {

        private byte pakageQuantityField;

        private string pakageTypeCodeField;

        private byte pakagePartQuantityField;

        private string pakageKindNameField;

        private CargoPackagePalletDetailsPackagePalleteInformation[] packagePalleteInformationField;

        /// <remarks/>
        public byte PakageQuantity
        {
            get
            {
                return this.pakageQuantityField;
            }
            set
            {
                this.pakageQuantityField = value;
            }
        }

        /// <remarks/>
        public string PakageTypeCode
        {
            get
            {
                return this.pakageTypeCodeField;
            }
            set
            {
                this.pakageTypeCodeField = value;
            }
        }

        /// <remarks/>
        public byte PakagePartQuantity
        {
            get
            {
                return this.pakagePartQuantityField;
            }
            set
            {
                this.pakagePartQuantityField = value;
            }
        }

        /// <remarks/>
        public string PakageKindName
        {
            get
            {
                return this.pakageKindNameField;
            }
            set
            {
                this.pakageKindNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PackagePalleteInformation")]
        public CargoPackagePalletDetailsPackagePalleteInformation[] PackagePalleteInformation
        {
            get
            {
                return this.packagePalleteInformationField;
            }
            set
            {
                this.packagePalleteInformationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class CargoPackagePalletDetailsPackagePalleteInformation
    {

        private string infoKindCodeField;

        private string palleteCodeField;

        private byte palleteQuantityField;

        private string[] cargoDescriptionTextField;

        /// <remarks/>
        public string InfoKindCode
        {
            get
            {
                return this.infoKindCodeField;
            }
            set
            {
                this.infoKindCodeField = value;
            }
        }

        /// <remarks/>
        public string PalleteCode
        {
            get
            {
                return this.palleteCodeField;
            }
            set
            {
                this.palleteCodeField = value;
            }
        }

        /// <remarks/>
        public byte PalleteQuantity
        {
            get
            {
                return this.palleteQuantityField;
            }
            set
            {
                this.palleteQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("CargoDescriptionText")]
        public string[] CargoDescriptionText
        {
            get
            {
                return this.cargoDescriptionTextField;
            }
            set
            {
                this.cargoDescriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class PIContainerDetails
    {

        private string containerNumberField;

        private string countryCodeField;

        /// <remarks/>
        public string ContainerNumber
        {
            get
            {
                return this.containerNumberField;
            }
            set
            {
                this.containerNumberField = value;
            }
        }

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class OriginCountryDetails
    {

        private string countryCodeField;

        private string countryNameField;

        private string territoryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "ocd")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "ocd")]
        public string CountryName
        {
            get
            {
                return this.countryNameField;
            }
            set
            {
                this.countryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class CAValueAmount
    {

        private string amountField;

        private string currencyCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "cav")]
        public string Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "cav")]
        public string CurrencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class PIPrecedingDocDetails
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private string prDocumentDateField;

        private string docKindCodeField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class PIGoodsDocDetails
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private string prDocumentDateField;

        private System.DateTime docStartDateField;

        private System.DateTime docValidityDateField;

        private string countryCodeField;

        private string docKindCodeField;

        private string authorityNameField;

        private string authorityIdField;

        private string formNumberIdField;

        private string registrationSeriesIdField;

        private byte tnvedCodeField;

        private string[] goodsDescriptionField;

        private string goodsLabelDescriptionField;

        private PIGoodsDocDetailsManufacturer manufacturerField;

        private PIGoodsDocDetailsGoodsDisinfectionDetails goodsDisinfectionDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        public string AuthorityName
        {
            get
            {
                return this.authorityNameField;
            }
            set
            {
                this.authorityNameField = value;
            }
        }

        /// <remarks/>
        public string AuthorityId
        {
            get
            {
                return this.authorityIdField;
            }
            set
            {
                this.authorityIdField = value;
            }
        }

        /// <remarks/>
        public string FormNumberId
        {
            get
            {
                return this.formNumberIdField;
            }
            set
            {
                this.formNumberIdField = value;
            }
        }

        /// <remarks/>
        public string RegistrationSeriesId
        {
            get
            {
                return this.registrationSeriesIdField;
            }
            set
            {
                this.registrationSeriesIdField = value;
            }
        }

        /// <remarks/>
        public byte TnvedCode
        {
            get
            {
                return this.tnvedCodeField;
            }
            set
            {
                this.tnvedCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("GoodsDescription")]
        public string[] GoodsDescription
        {
            get
            {
                return this.goodsDescriptionField;
            }
            set
            {
                this.goodsDescriptionField = value;
            }
        }

        /// <remarks/>
        public string GoodsLabelDescription
        {
            get
            {
                return this.goodsLabelDescriptionField;
            }
            set
            {
                this.goodsLabelDescriptionField = value;
            }
        }

        /// <remarks/>
        public PIGoodsDocDetailsManufacturer Manufacturer
        {
            get
            {
                return this.manufacturerField;
            }
            set
            {
                this.manufacturerField = value;
            }
        }

        /// <remarks/>
        public PIGoodsDocDetailsGoodsDisinfectionDetails GoodsDisinfectionDetails
        {
            get
            {
                return this.goodsDisinfectionDetailsField;
            }
            set
            {
                this.goodsDisinfectionDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class PIGoodsDocDetailsManufacturer
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class PIGoodsDocDetailsGoodsDisinfectionDetails
    {

        private bool disinfectionIndicatorField;

        private PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetails disinfectionDetailsField;

        /// <remarks/>
        public bool DisinfectionIndicator
        {
            get
            {
                return this.disinfectionIndicatorField;
            }
            set
            {
                this.disinfectionIndicatorField = value;
            }
        }

        /// <remarks/>
        public PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetails DisinfectionDetails
        {
            get
            {
                return this.disinfectionDetailsField;
            }
            set
            {
                this.disinfectionDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetails
    {

        private System.DateTime eventDateField;

        private string expositionDurationField;

        private string disinfectionMethodNameField;

        private string chemicalNameField;

        private decimal temperatureMeasureField;

        private PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetailsConcentrationMeasure concentrationMeasureField;

        private PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetailsDoseMeasure doseMeasureField;

        private string descriptionTextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "duration")]
        public string ExpositionDuration
        {
            get
            {
                return this.expositionDurationField;
            }
            set
            {
                this.expositionDurationField = value;
            }
        }

        /// <remarks/>
        public string DisinfectionMethodName
        {
            get
            {
                return this.disinfectionMethodNameField;
            }
            set
            {
                this.disinfectionMethodNameField = value;
            }
        }

        /// <remarks/>
        public string ChemicalName
        {
            get
            {
                return this.chemicalNameField;
            }
            set
            {
                this.chemicalNameField = value;
            }
        }

        /// <remarks/>
        public decimal TemperatureMeasure
        {
            get
            {
                return this.temperatureMeasureField;
            }
            set
            {
                this.temperatureMeasureField = value;
            }
        }

        /// <remarks/>
        public PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetailsConcentrationMeasure ConcentrationMeasure
        {
            get
            {
                return this.concentrationMeasureField;
            }
            set
            {
                this.concentrationMeasureField = value;
            }
        }

        /// <remarks/>
        public PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetailsDoseMeasure DoseMeasure
        {
            get
            {
                return this.doseMeasureField;
            }
            set
            {
                this.doseMeasureField = value;
            }
        }

        /// <remarks/>
        public string DescriptionText
        {
            get
            {
                return this.descriptionTextField;
            }
            set
            {
                this.descriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetailsConcentrationMeasure
    {

        private decimal measuredAmountField;

        private string measureUnitQualifierNameField;

        private string measureUnitQualifierCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public decimal MeasuredAmount
        {
            get
            {
                return this.measuredAmountField;
            }
            set
            {
                this.measuredAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class PIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetailsDoseMeasure
    {

        private decimal measuredAmountField;

        private string measureUnitQualifierNameField;

        private string measureUnitQualifierCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public decimal MeasuredAmount
        {
            get
            {
                return this.measuredAmountField;
            }
            set
            {
                this.measuredAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class PIShipmentLocationDetails
    {

        private string countryCodeField;

        private string locationCodeField;

        private string regionField;

        private string districtField;

        private string townField;

        private string cityField;

        private System.DateTime eventDateField;

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string LocationCode
        {
            get
            {
                return this.locationCodeField;
            }
            set
            {
                this.locationCodeField = value;
            }
        }

        /// <remarks/>
        public string Region
        {
            get
            {
                return this.regionField;
            }
            set
            {
                this.regionField = value;
            }
        }

        /// <remarks/>
        public string District
        {
            get
            {
                return this.districtField;
            }
            set
            {
                this.districtField = value;
            }
        }

        /// <remarks/>
        public string Town
        {
            get
            {
                return this.townField;
            }
            set
            {
                this.townField = value;
            }
        }

        /// <remarks/>
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsTransitGuaranteeDetails
    {

        private byte measureCodeField;

        private GuaranteeAmount guaranteeAmountField;

        private GuaranteeCertificateIdDetails guaranteeCertificateIdDetailsField;

        private TransitGuaranteeDocDetails transitGuaranteeDocDetailsField;

        private string nationalGuaranteeCodeField;

        private string[] nonGuaranteeCountryCodeField;

        private RegisterDocumentIdDetails registerDocumentIdDetailsField;

        private string guaranteeNameField;

        private byte uNPField;

        private byte bICField;

        private GuaranteeTD guaranteeTDField;

        private GuaranteeAddress guaranteeAddressField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public byte MeasureCode
        {
            get
            {
                return this.measureCodeField;
            }
            set
            {
                this.measureCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public GuaranteeAmount GuaranteeAmount
        {
            get
            {
                return this.guaranteeAmountField;
            }
            set
            {
                this.guaranteeAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public GuaranteeCertificateIdDetails GuaranteeCertificateIdDetails
        {
            get
            {
                return this.guaranteeCertificateIdDetailsField;
            }
            set
            {
                this.guaranteeCertificateIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public TransitGuaranteeDocDetails TransitGuaranteeDocDetails
        {
            get
            {
                return this.transitGuaranteeDocDetailsField;
            }
            set
            {
                this.transitGuaranteeDocDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string NationalGuaranteeCode
        {
            get
            {
                return this.nationalGuaranteeCodeField;
            }
            set
            {
                this.nationalGuaranteeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("NonGuaranteeCountryCode", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string[] NonGuaranteeCountryCode
        {
            get
            {
                return this.nonGuaranteeCountryCodeField;
            }
            set
            {
                this.nonGuaranteeCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public RegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public string GuaranteeName
        {
            get
            {
                return this.guaranteeNameField;
            }
            set
            {
                this.guaranteeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public byte UNP
        {
            get
            {
                return this.uNPField;
            }
            set
            {
                this.uNPField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public byte BIC
        {
            get
            {
                return this.bICField;
            }
            set
            {
                this.bICField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public GuaranteeTD GuaranteeTD
        {
            get
            {
                return this.guaranteeTDField;
            }
            set
            {
                this.guaranteeTDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public GuaranteeAddress GuaranteeAddress
        {
            get
            {
                return this.guaranteeAddressField;
            }
            set
            {
                this.guaranteeAddressField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class GuaranteeAmount
    {

        private string amountField;

        private string currencyCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CurrencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class GuaranteeCertificateIdDetails
    {

        private byte customsCodeField;

        private System.DateTime registrationDateField;

        private string gTDNumberField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public byte CustomsCode
        {
            get
            {
                return this.customsCodeField;
            }
            set
            {
                this.customsCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0", DataType = "date")]
        public System.DateTime RegistrationDate
        {
            get
            {
                return this.registrationDateField;
            }
            set
            {
                this.registrationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string GTDNumber
        {
            get
            {
                return this.gTDNumberField;
            }
            set
            {
                this.gTDNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class TransitGuaranteeDocDetails
    {

        private string prDocumentNameField;

        private string prDocumentNumberField;

        private string prDocumentDateField;

        private System.DateTime docStartDateField;

        private System.DateTime docValidityDateField;

        private string countryCodeField;

        private string docKindCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentName
        {
            get
            {
                return this.prDocumentNameField;
            }
            set
            {
                this.prDocumentNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentNumber
        {
            get
            {
                return this.prDocumentNumberField;
            }
            set
            {
                this.prDocumentNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PrDocumentDate
        {
            get
            {
                return this.prDocumentDateField;
            }
            set
            {
                this.prDocumentDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }

        /// <remarks/>
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        public string DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class GuaranteeTD
    {

        private string generalDocNameField;

        private string generalNumberField;

        private System.DateTime generalDateField;

        private string generalKindCodeField;

        private string guaranteeDocNameField;

        private string guaranteeNumberField;

        private System.DateTime guaranteeDateField;

        private string guaranteeKindCodeField;

        private string addGuaranteeDocNameField;

        private string addGuaranteeNumberField;

        private System.DateTime addGuaranteeDateField;

        private string addGuaranteeKindCodeField;

        /// <remarks/>
        public string GeneralDocName
        {
            get
            {
                return this.generalDocNameField;
            }
            set
            {
                this.generalDocNameField = value;
            }
        }

        /// <remarks/>
        public string GeneralNumber
        {
            get
            {
                return this.generalNumberField;
            }
            set
            {
                this.generalNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime GeneralDate
        {
            get
            {
                return this.generalDateField;
            }
            set
            {
                this.generalDateField = value;
            }
        }

        /// <remarks/>
        public string GeneralKindCode
        {
            get
            {
                return this.generalKindCodeField;
            }
            set
            {
                this.generalKindCodeField = value;
            }
        }

        /// <remarks/>
        public string GuaranteeDocName
        {
            get
            {
                return this.guaranteeDocNameField;
            }
            set
            {
                this.guaranteeDocNameField = value;
            }
        }

        /// <remarks/>
        public string GuaranteeNumber
        {
            get
            {
                return this.guaranteeNumberField;
            }
            set
            {
                this.guaranteeNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime GuaranteeDate
        {
            get
            {
                return this.guaranteeDateField;
            }
            set
            {
                this.guaranteeDateField = value;
            }
        }

        /// <remarks/>
        public string GuaranteeKindCode
        {
            get
            {
                return this.guaranteeKindCodeField;
            }
            set
            {
                this.guaranteeKindCodeField = value;
            }
        }

        /// <remarks/>
        public string AddGuaranteeDocName
        {
            get
            {
                return this.addGuaranteeDocNameField;
            }
            set
            {
                this.addGuaranteeDocNameField = value;
            }
        }

        /// <remarks/>
        public string AddGuaranteeNumber
        {
            get
            {
                return this.addGuaranteeNumberField;
            }
            set
            {
                this.addGuaranteeNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
        public System.DateTime AddGuaranteeDate
        {
            get
            {
                return this.addGuaranteeDateField;
            }
            set
            {
                this.addGuaranteeDateField = value;
            }
        }

        /// <remarks/>
        public string AddGuaranteeKindCode
        {
            get
            {
                return this.addGuaranteeKindCodeField;
            }
            set
            {
                this.addGuaranteeKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class GuaranteeAddress
    {

        private string addressKindCodeField;

        private string postalCodeField;

        private string countryCodeField;

        private string counryNameField;

        private string regionField;

        private string districtField;

        private string townField;

        private string cityField;

        private string streetHouseField;

        private string houseField;

        private string roomField;

        private string addressTextField;

        private string oKTMOField;

        private byte oKATOField;

        private string kLADRField;

        private string aOGUIDField;

        private string aOIDField;

        private string territoryCodeField;

        private string postOfficeBoxIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AddressKindCode
        {
            get
            {
                return this.addressKindCodeField;
            }
            set
            {
                this.addressKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PostalCode
        {
            get
            {
                return this.postalCodeField;
            }
            set
            {
                this.postalCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CounryName
        {
            get
            {
                return this.counryNameField;
            }
            set
            {
                this.counryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Region
        {
            get
            {
                return this.regionField;
            }
            set
            {
                this.regionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string District
        {
            get
            {
                return this.districtField;
            }
            set
            {
                this.districtField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Town
        {
            get
            {
                return this.townField;
            }
            set
            {
                this.townField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string StreetHouse
        {
            get
            {
                return this.streetHouseField;
            }
            set
            {
                this.streetHouseField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string House
        {
            get
            {
                return this.houseField;
            }
            set
            {
                this.houseField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string Room
        {
            get
            {
                return this.roomField;
            }
            set
            {
                this.roomField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AddressText
        {
            get
            {
                return this.addressTextField;
            }
            set
            {
                this.addressTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string OKTMO
        {
            get
            {
                return this.oKTMOField;
            }
            set
            {
                this.oKTMOField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public byte OKATO
        {
            get
            {
                return this.oKATOField;
            }
            set
            {
                this.oKATOField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string KLADR
        {
            get
            {
                return this.kLADRField;
            }
            set
            {
                this.kLADRField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AOGUID
        {
            get
            {
                return this.aOGUIDField;
            }
            set
            {
                this.aOGUIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string AOID
        {
            get
            {
                return this.aOIDField;
            }
            set
            {
                this.aOIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PostOfficeBoxId
        {
            get
            {
                return this.postOfficeBoxIdField;
            }
            set
            {
                this.postOfficeBoxIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsTransitDeclarantDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        private bool equalIndicatorField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public bool EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsUnionCarrierDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        private CarrierRepresentativeDetails carrierRepresentativeDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public CarrierRepresentativeDetails CarrierRepresentativeDetails
        {
            get
            {
                return this.carrierRepresentativeDetailsField;
            }
            set
            {
                this.carrierRepresentativeDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class CarrierRepresentativeDetails
    {

        private string personSurnameField;

        private string personNameField;

        private string personMiddleNameField;

        private string personPostField;

        private CommunicationDetails communicationDetailsField;

        private IdentityCard identityCardField;

        private string roleCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonSurname
        {
            get
            {
                return this.personSurnameField;
            }
            set
            {
                this.personSurnameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonMiddleName
        {
            get
            {
                return this.personMiddleNameField;
            }
            set
            {
                this.personMiddleNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonPost
        {
            get
            {
                return this.personPostField;
            }
            set
            {
                this.personPostField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string RoleCode
        {
            get
            {
                return this.roleCodeField;
            }
            set
            {
                this.roleCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryMainConsignmentDetailsRailwayStampDetails
    {

        private byte railwayStationCodeField;

        private System.DateTime eventDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public byte RailwayStationCode
        {
            get
            {
                return this.railwayStationCodeField;
            }
            set
            {
                this.railwayStationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", DataType = "date")]
        public System.DateTime EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryCarrierDetails
    {

        private string organizationNameField;

        private string shortNameField;

        private string organizationLanguageField;

        private RFOrganizationFeatures rFOrganizationFeaturesField;

        private string countryA2CodeField;

        private BusinessEntityTypeCode businessEntityTypeCodeField;

        private string businessEntityTypeNameField;

        private UITN uITNField;

        private string personIdField;

        private IdentityCard identityCardField;

        private SubjectAddressDetails[] subjectAddressDetailsField;

        private CommunicationDetails communicationDetailsField;

        private AutoPreliminaryCarrierDetailsCarrierRepresentativeDetails carrierRepresentativeDetailsField;

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationName
        {
            get
            {
                return this.organizationNameField;
            }
            set
            {
                this.organizationNameField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string ShortName
        {
            get
            {
                return this.shortNameField;
            }
            set
            {
                this.shortNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string OrganizationLanguage
        {
            get
            {
                return this.organizationLanguageField;
            }
            set
            {
                this.organizationLanguageField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public RFOrganizationFeatures RFOrganizationFeatures
        {
            get
            {
                return this.rFOrganizationFeaturesField;
            }
            set
            {
                this.rFOrganizationFeaturesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string CountryA2Code
        {
            get
            {
                return this.countryA2CodeField;
            }
            set
            {
                this.countryA2CodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public BusinessEntityTypeCode BusinessEntityTypeCode
        {
            get
            {
                return this.businessEntityTypeCodeField;
            }
            set
            {
                this.businessEntityTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string BusinessEntityTypeName
        {
            get
            {
                return this.businessEntityTypeNameField;
            }
            set
            {
                this.businessEntityTypeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public UITN UITN
        {
            get
            {
                return this.uITNField;
            }
            set
            {
                this.uITNField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        //[System.Xml.Serialization.XmlElementAttribute("SubjectAddressDetails", Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public SubjectAddressDetails[] SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        public AutoPreliminaryCarrierDetailsCarrierRepresentativeDetails CarrierRepresentativeDetails
        {
            get
            {
                return this.carrierRepresentativeDetailsField;
            }
            set
            {
                this.carrierRepresentativeDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminaryCarrierDetailsCarrierRepresentativeDetails
    {

        private string personSurnameField;

        private string personNameField;

        private string personMiddleNameField;

        private string personPostField;

        private CommunicationDetails communicationDetailsField;

        private IdentityCard identityCardField;

        private string roleCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonSurname
        {
            get
            {
                return this.personSurnameField;
            }
            set
            {
                this.personSurnameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonName
        {
            get
            {
                return this.personNameField;
            }
            set
            {
                this.personNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonMiddleName
        {
            get
            {
                return this.personMiddleNameField;
            }
            set
            {
                this.personMiddleNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string PersonPost
        {
            get
            {
                return this.personPostField;
            }
            set
            {
                this.personPostField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public IdentityCard IdentityCard
        {
            get
            {
                return this.identityCardField;
            }
            set
            {
                this.identityCardField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:RUSCommonAggregateTypes:5.15.0")]
        public string RoleCode
        {
            get
            {
                return this.roleCodeField;
            }
            set
            {
                this.roleCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:CustomsDocuments:AutoPreliminary:5.15.0")]
    public partial class AutoPreliminarySparePartsInfo
    {

        private bool storeIndicatorField;

        private SparePartsItemDetails[] sparePartsItemDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public bool StoreIndicator
        {
            get
            {
                return this.storeIndicatorField;
            }
            set
            {
                this.storeIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SparePartsItemDetails", Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
        public SparePartsItemDetails[] SparePartsItemDetails
        {
            get
            {
                return this.sparePartsItemDetailsField;
            }
            set
            {
                this.sparePartsItemDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0", IsNullable = false)]
    public partial class SparePartsItemDetails
    {

        private string[] goodsDescriptionField;

        private SparePartsItemDetailsQuantity quantityField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("GoodsDescription")]
        public string[] GoodsDescription
        {
            get
            {
                return this.goodsDescriptionField;
            }
            set
            {
                this.goodsDescriptionField = value;
            }
        }

        /// <remarks/>
        public SparePartsItemDetailsQuantity Quantity
        {
            get
            {
                return this.quantityField;
            }
            set
            {
                this.quantityField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:customs.ru:Information:PriorInformation:PriorCommonAggregateTypes:5.15.0")]
    public partial class SparePartsItemDetailsQuantity
    {

        private byte goodsQuantityField;

        private string measureUnitQualifierNameField;

        private string measureUnitQualifierCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public byte GoodsQuantity
        {
            get
            {
                return this.goodsQuantityField;
            }
            set
            {
                this.goodsQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string MeasureUnitQualifierName
        {
            get
            {
                return this.measureUnitQualifierNameField;
            }
            set
            {
                this.measureUnitQualifierNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:customs.ru:CommonAggregateTypes:5.10.0")]
        public string MeasureUnitQualifierCode
        {
            get
            {
                return this.measureUnitQualifierCodeField;
            }
            set
            {
                this.measureUnitQualifierCodeField = value;
            }
        }
    }
    */
    public class SelectedBroker
    {
        public string given_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string position { get; set; }
        public string phone_number { get; set; }

        public string organization_name { get; set; }
        public string short_name { get; set; }
        public string org_code { get; set; }
        public string org_itn { get; set; }
    }


    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://schemas.xmlsoap.org/soap/envelope/", IsNullable = false)]
    public partial class Envelope
    {

        private object headerField;

        private EnvelopeBody bodyField;

        /// <remarks/>
        public object Header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
            }
        }

        /// <remarks/>
        public EnvelopeBody Body
        {
            get
            {
                return this.bodyField;
            }
            set
            {
                this.bodyField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    public partial class EnvelopeBody
    {

        private registerAutoPreliminaryInformation registerAutoPreliminaryInformationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "http://ws.open.astana1.kgd.gov.kz/")]
        public registerAutoPreliminaryInformation registerAutoPreliminaryInformation
        {
            get
            {
                return this.registerAutoPreliminaryInformationField;
            }
            set
            {
                this.registerAutoPreliminaryInformationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://ws.open.astana1.kgd.gov.kz/")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://ws.open.astana1.kgd.gov.kz/", IsNullable = false)]
    public partial class registerAutoPreliminaryInformation
    {

        private AutoPreliminaryInformation autoPreliminaryInformationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:R:042:AutoPreliminaryInformation:v1.0.0")]
        public AutoPreliminaryInformation AutoPreliminaryInformation
        {
            get
            {
                return this.autoPreliminaryInformationField;
            }
            set
            {
                this.autoPreliminaryInformationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:R:042:AutoPreliminaryInformation:v1.0.0")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:R:042:AutoPreliminaryInformation:v1.0.0", IsNullable = false)]
    public partial class AutoPreliminaryInformation
    {

        private string eDocCodeField;

        private string eDocIdField;

        private string eDocRefIdField;

        private string eDocDateTimeField;

        private string eDocIndicatorCodeField;

        private PreliminaryInformationIdDetails preliminaryInformationIdDetailsField;

        private RefPreliminaryInformationIdDetails refPreliminaryInformationIdDetailsField;

        private string preliminaryInformationUsageCodeField;

        private PIATEntryCheckPointDetails pIATEntryCheckPointDetailsField;

        private PIDeclarantDetails pIDeclarantDetailsField;

        private PIATBorderTransportDetails pIATBorderTransportDetailsField;

        private PIATMainConsignmentDetails pIATMainConsignmentDetailsField;

        private PIATCarrierDetails pIATCarrierDetailsField;

        private SparePartsDetails sparePartsDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EDocCode
        {
            get
            {
                return this.eDocCodeField;
            }
            set
            {
                this.eDocCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EDocId
        {
            get
            {
                return this.eDocIdField;
            }
            set
            {
                this.eDocIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EDocRefId
        {
            get
            {
                return this.eDocRefIdField;
            }
            set
            {
                this.eDocRefIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EDocDateTime
        {
            get
            {
                return this.eDocDateTimeField;
            }
            set
            {
                this.eDocDateTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string EDocIndicatorCode
        {
            get
            {
                return this.eDocIndicatorCodeField;
            }
            set
            {
                this.eDocIndicatorCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public PreliminaryInformationIdDetails PreliminaryInformationIdDetails
        {
            get
            {
                return this.preliminaryInformationIdDetailsField;
            }
            set
            {
                this.preliminaryInformationIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public RefPreliminaryInformationIdDetails RefPreliminaryInformationIdDetails
        {
            get
            {
                return this.refPreliminaryInformationIdDetailsField;
            }
            set
            {
                this.refPreliminaryInformationIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PreliminaryInformationUsageCode
        {
            get
            {
                return this.preliminaryInformationUsageCodeField;
            }
            set
            {
                this.preliminaryInformationUsageCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public PIATEntryCheckPointDetails PIATEntryCheckPointDetails
        {
            get
            {
                return this.pIATEntryCheckPointDetailsField;
            }
            set
            {
                this.pIATEntryCheckPointDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public PIDeclarantDetails PIDeclarantDetails
        {
            get
            {
                return this.pIDeclarantDetailsField;
            }
            set
            {
                this.pIDeclarantDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public PIATBorderTransportDetails PIATBorderTransportDetails
        {
            get
            {
                return this.pIATBorderTransportDetailsField;
            }
            set
            {
                this.pIATBorderTransportDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public PIATMainConsignmentDetails PIATMainConsignmentDetails
        {
            get
            {
                return this.pIATMainConsignmentDetailsField;
            }
            set
            {
                this.pIATMainConsignmentDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public PIATCarrierDetails PIATCarrierDetails
        {
            get
            {
                return this.pIATCarrierDetailsField;
            }
            set
            {
                this.pIATCarrierDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
        public SparePartsDetails SparePartsDetails
        {
            get
            {
                return this.sparePartsDetailsField;
            }
            set
            {
                this.sparePartsDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class PreliminaryInformationIdDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string eventDateField;

        private string preliminaryInformationSeqIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PreliminaryInformationSeqId
        {
            get
            {
                return this.preliminaryInformationSeqIdField;
            }
            set
            {
                this.preliminaryInformationSeqIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class UnifiedCountryCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class RefPreliminaryInformationIdDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string eventDateField;

        private string preliminaryInformationSeqIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PreliminaryInformationSeqId
        {
            get
            {
                return this.preliminaryInformationSeqIdField;
            }
            set
            {
                this.preliminaryInformationSeqIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class PIATEntryCheckPointDetails
    {

        private string customsOfficeCodeField;

        private string borderCheckpointCodeField;

        private string borderCheckpointNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CustomsOfficeCode
        {
            get
            {
                return this.customsOfficeCodeField;
            }
            set
            {
                this.customsOfficeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string BorderCheckpointCode
        {
            get
            {
                return this.borderCheckpointCodeField;
            }
            set
            {
                this.borderCheckpointCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string BorderCheckpointName
        {
            get
            {
                return this.borderCheckpointNameField;
            }
            set
            {
                this.borderCheckpointNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class PIDeclarantDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        private PIDeclarantDetailsRegisterDocumentIdDetails registerDocumentIdDetailsField;

        private string equalIndicatorField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        public PIDeclarantDetailsRegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class CAUniqueCustomsNumberId
    {

        private string countryCodeField;

        private string countryCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCodeListId
        {
            get
            {
                return this.countryCodeListIdField;
            }
            set
            {
                this.countryCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8", IsNullable = false)]
    public partial class SubjectAddressDetails
    {

        private string addressKindCodeField;

        private UnifiedCountryCode unifiedCountryCodeField;

        private string territoryCodeField;

        private string regionNameField;

        private string districtNameField;

        private string cityNameField;

        private string settlementNameField;

        private string streetNameField;

        private string buildingNumberIdField;

        private string roomNumberIdField;

        private string postCodeField;

        private string postOfficeBoxIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string AddressKindCode
        {
            get
            {
                return this.addressKindCodeField;
            }
            set
            {
                this.addressKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string RegionName
        {
            get
            {
                return this.regionNameField;
            }
            set
            {
                this.regionNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DistrictName
        {
            get
            {
                return this.districtNameField;
            }
            set
            {
                this.districtNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SettlementName
        {
            get
            {
                return this.settlementNameField;
            }
            set
            {
                this.settlementNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string StreetName
        {
            get
            {
                return this.streetNameField;
            }
            set
            {
                this.streetNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string BuildingNumberId
        {
            get
            {
                return this.buildingNumberIdField;
            }
            set
            {
                this.buildingNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string RoomNumberId
        {
            get
            {
                return this.roomNumberIdField;
            }
            set
            {
                this.roomNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string PostCode
        {
            get
            {
                return this.postCodeField;
            }
            set
            {
                this.postCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string PostOfficeBoxId
        {
            get
            {
                return this.postOfficeBoxIdField;
            }
            set
            {
                this.postOfficeBoxIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIDeclarantDetailsRegisterDocumentIdDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string registrationNumberIdField;

        private string reregistrationCodeField;

        private string aEORegistryKindCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RegistrationNumberId
        {
            get
            {
                return this.registrationNumberIdField;
            }
            set
            {
                this.registrationNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ReregistrationCode
        {
            get
            {
                return this.reregistrationCodeField;
            }
            set
            {
                this.reregistrationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string AEORegistryKindCode
        {
            get
            {
                return this.aEORegistryKindCodeField;
            }
            set
            {
                this.aEORegistryKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class PIATBorderTransportDetails
    {

        private UnifiedTransportModeCode unifiedTransportModeCodeField;

        private string transportMeansQuantityField;

        private string containerIndicatorField;

        private TransportMeansRegId transportMeansRegIdField;

        private string vehicleIdField;

        private string vehicleChassisIdField;

        private string vehicleBodyIdField;

        private TransportTypeCode transportTypeCodeField;

        private VehicleMakeCode vehicleMakeCodeField;

        private PIATBorderTransportDetailsTrailerDetails trailerDetailsField;

        private TransportMeansGrossMass transportMeansGrossMassField;

        private PIATBorderTransportDetailsPIATItineraryPointDetails pIATItineraryPointDetailsField;

        private string transportMeansEntryPurposeCodeField;

        private PIATBorderTransportDetailsPermitTranspornationDocDetails permitTranspornationDocDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedTransportModeCode UnifiedTransportModeCode
        {
            get
            {
                return this.unifiedTransportModeCodeField;
            }
            set
            {
                this.unifiedTransportModeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ContainerIndicator
        {
            get
            {
                return this.containerIndicatorField;
            }
            set
            {
                this.containerIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public TransportMeansRegId TransportMeansRegId
        {
            get
            {
                return this.transportMeansRegIdField;
            }
            set
            {
                this.transportMeansRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleId
        {
            get
            {
                return this.vehicleIdField;
            }
            set
            {
                this.vehicleIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleChassisId
        {
            get
            {
                return this.vehicleChassisIdField;
            }
            set
            {
                this.vehicleChassisIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleBodyId
        {
            get
            {
                return this.vehicleBodyIdField;
            }
            set
            {
                this.vehicleBodyIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public TransportTypeCode TransportTypeCode
        {
            get
            {
                return this.transportTypeCodeField;
            }
            set
            {
                this.transportTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public VehicleMakeCode VehicleMakeCode
        {
            get
            {
                return this.vehicleMakeCodeField;
            }
            set
            {
                this.vehicleMakeCodeField = value;
            }
        }

        /// <remarks/>
        public PIATBorderTransportDetailsTrailerDetails TrailerDetails
        {
            get
            {
                return this.trailerDetailsField;
            }
            set
            {
                this.trailerDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public TransportMeansGrossMass TransportMeansGrossMass
        {
            get
            {
                return this.transportMeansGrossMassField;
            }
            set
            {
                this.transportMeansGrossMassField = value;
            }
        }

        /// <remarks/>
        public PIATBorderTransportDetailsPIATItineraryPointDetails PIATItineraryPointDetails
        {
            get
            {
                return this.pIATItineraryPointDetailsField;
            }
            set
            {
                this.pIATItineraryPointDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TransportMeansEntryPurposeCode
        {
            get
            {
                return this.transportMeansEntryPurposeCodeField;
            }
            set
            {
                this.transportMeansEntryPurposeCodeField = value;
            }
        }

        /// <remarks/>
        public PIATBorderTransportDetailsPermitTranspornationDocDetails PermitTranspornationDocDetails
        {
            get
            {
                return this.permitTranspornationDocDetailsField;
            }
            set
            {
                this.permitTranspornationDocDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class UnifiedTransportModeCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class TransportMeansRegId
    {

        private string countryCodeField;

        private string countryCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCodeListId
        {
            get
            {
                return this.countryCodeListIdField;
            }
            set
            {
                this.countryCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class TransportTypeCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class VehicleMakeCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATBorderTransportDetailsTrailerDetails
    {

        private TransportMeansRegId transportMeansRegIdField;

        private string vehicleIdField;

        private string vehicleChassisIdField;

        private string vehicleBodyIdField;

        private TransportTypeCode transportTypeCodeField;

        private VehicleMakeCode vehicleMakeCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public TransportMeansRegId TransportMeansRegId
        {
            get
            {
                return this.transportMeansRegIdField;
            }
            set
            {
                this.transportMeansRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleId
        {
            get
            {
                return this.vehicleIdField;
            }
            set
            {
                this.vehicleIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleChassisId
        {
            get
            {
                return this.vehicleChassisIdField;
            }
            set
            {
                this.vehicleChassisIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleBodyId
        {
            get
            {
                return this.vehicleBodyIdField;
            }
            set
            {
                this.vehicleBodyIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public TransportTypeCode TransportTypeCode
        {
            get
            {
                return this.transportTypeCodeField;
            }
            set
            {
                this.transportTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public VehicleMakeCode VehicleMakeCode
        {
            get
            {
                return this.vehicleMakeCodeField;
            }
            set
            {
                this.vehicleMakeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class TransportMeansGrossMass
    {

        private string measurementUnitCodeField;

        private string measurementUnitCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCode
        {
            get
            {
                return this.measurementUnitCodeField;
            }
            set
            {
                this.measurementUnitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCodeListId
        {
            get
            {
                return this.measurementUnitCodeListIdField;
            }
            set
            {
                this.measurementUnitCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATBorderTransportDetailsPIATItineraryPointDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string placeNameField;

        private string objectOrdinalField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string ObjectOrdinal
        {
            get
            {
                return this.objectOrdinalField;
            }
            set
            {
                this.objectOrdinalField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATBorderTransportDetailsPermitTranspornationDocDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        private string docStartDateField;

        private string docValidityDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class DocKindCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class PIATMainConsignmentDetails
    {

        private string tIRCarnetIndicatorField;

        private PIATMainConsignmentDetailsTIRCarnetIdDetails tIRCarnetIdDetailsField;

        private string declarationKindCodeField;

        private string transitProcedureCodeField;

        private string transitFeatureCodeField;

        private string loadingListsQuantityField;

        private string loadingListsPageQuantityField;

        private string goodsQuantityField;

        private string cargoQuantityField;

        private PIATMainConsignmentDetailsSealDetails sealDetailsField;

        private PIATMainConsignmentDetailsPITransitTransportMeansDetails pITransitTransportMeansDetailsField;

        private PIATMainConsignmentDetailsTransitTerminationDetails transitTerminationDetailsField;

        private PIATMainConsignmentDetailsPITranshipmentDetails pITranshipmentDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetails pIATConsignmentDetailsField;

        private PIATMainConsignmentDetailsTransitGuaranteeDetails transitGuaranteeDetailsField;

        private PIATMainConsignmentDetailsPITransitDeclarantDetails pITransitDeclarantDetailsField;

        private PIATMainConsignmentDetailsPIUnionCarrierDetails pIUnionCarrierDetailsField;

        private PIATMainConsignmentDetailsRailwayStampDetails railwayStampDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TIRCarnetIndicator
        {
            get
            {
                return this.tIRCarnetIndicatorField;
            }
            set
            {
                this.tIRCarnetIndicatorField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTIRCarnetIdDetails TIRCarnetIdDetails
        {
            get
            {
                return this.tIRCarnetIdDetailsField;
            }
            set
            {
                this.tIRCarnetIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string DeclarationKindCode
        {
            get
            {
                return this.declarationKindCodeField;
            }
            set
            {
                this.declarationKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TransitProcedureCode
        {
            get
            {
                return this.transitProcedureCodeField;
            }
            set
            {
                this.transitProcedureCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TransitFeatureCode
        {
            get
            {
                return this.transitFeatureCodeField;
            }
            set
            {
                this.transitFeatureCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string LoadingListsQuantity
        {
            get
            {
                return this.loadingListsQuantityField;
            }
            set
            {
                this.loadingListsQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string LoadingListsPageQuantity
        {
            get
            {
                return this.loadingListsPageQuantityField;
            }
            set
            {
                this.loadingListsPageQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsQuantity
        {
            get
            {
                return this.goodsQuantityField;
            }
            set
            {
                this.goodsQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoQuantity
        {
            get
            {
                return this.cargoQuantityField;
            }
            set
            {
                this.cargoQuantityField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsSealDetails SealDetails
        {
            get
            {
                return this.sealDetailsField;
            }
            set
            {
                this.sealDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPITransitTransportMeansDetails PITransitTransportMeansDetails
        {
            get
            {
                return this.pITransitTransportMeansDetailsField;
            }
            set
            {
                this.pITransitTransportMeansDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitTerminationDetails TransitTerminationDetails
        {
            get
            {
                return this.transitTerminationDetailsField;
            }
            set
            {
                this.transitTerminationDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPITranshipmentDetails PITranshipmentDetails
        {
            get
            {
                return this.pITranshipmentDetailsField;
            }
            set
            {
                this.pITranshipmentDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetails PIATConsignmentDetails
        {
            get
            {
                return this.pIATConsignmentDetailsField;
            }
            set
            {
                this.pIATConsignmentDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetails TransitGuaranteeDetails
        {
            get
            {
                return this.transitGuaranteeDetailsField;
            }
            set
            {
                this.transitGuaranteeDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPITransitDeclarantDetails PITransitDeclarantDetails
        {
            get
            {
                return this.pITransitDeclarantDetailsField;
            }
            set
            {
                this.pITransitDeclarantDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIUnionCarrierDetails PIUnionCarrierDetails
        {
            get
            {
                return this.pIUnionCarrierDetailsField;
            }
            set
            {
                this.pIUnionCarrierDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsRailwayStampDetails RailwayStampDetails
        {
            get
            {
                return this.railwayStampDetailsField;
            }
            set
            {
                this.railwayStampDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTIRCarnetIdDetails
    {

        private string tIRSeriesIdField;

        private string tIRIdField;

        private string tIRPageOrdinalField;

        private string tIRHolderIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TIRSeriesId
        {
            get
            {
                return this.tIRSeriesIdField;
            }
            set
            {
                this.tIRSeriesIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TIRId
        {
            get
            {
                return this.tIRIdField;
            }
            set
            {
                this.tIRIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TIRPageOrdinal
        {
            get
            {
                return this.tIRPageOrdinalField;
            }
            set
            {
                this.tIRPageOrdinalField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TIRHolderId
        {
            get
            {
                return this.tIRHolderIdField;
            }
            set
            {
                this.tIRHolderIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsSealDetails
    {

        private string sealQuantityField;

        private string sealDeviceIdField;

        private string sealIdField;

        private string descriptionTextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string SealQuantity
        {
            get
            {
                return this.sealQuantityField;
            }
            set
            {
                this.sealQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string SealDeviceId
        {
            get
            {
                return this.sealDeviceIdField;
            }
            set
            {
                this.sealDeviceIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SealId
        {
            get
            {
                return this.sealIdField;
            }
            set
            {
                this.sealIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DescriptionText
        {
            get
            {
                return this.descriptionTextField;
            }
            set
            {
                this.descriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPITransitTransportMeansDetails
    {

        private string equalIndicatorField;

        private UnifiedTransportModeCode unifiedTransportModeCodeField;

        private string transportMeansQuantityField;

        private PIATMainConsignmentDetailsPITransitTransportMeansDetailsTransportMeansRegistrationIdDetails transportMeansRegistrationIdDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedTransportModeCode UnifiedTransportModeCode
        {
            get
            {
                return this.unifiedTransportModeCodeField;
            }
            set
            {
                this.unifiedTransportModeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPITransitTransportMeansDetailsTransportMeansRegistrationIdDetails TransportMeansRegistrationIdDetails
        {
            get
            {
                return this.transportMeansRegistrationIdDetailsField;
            }
            set
            {
                this.transportMeansRegistrationIdDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPITransitTransportMeansDetailsTransportMeansRegistrationIdDetails
    {

        private TransportMeansRegId transportMeansRegIdField;

        private FirstTrailerRegId firstTrailerRegIdField;

        private SecondTrailerRegId secondTrailerRegIdField;

        private string docIdField;

        private string vehicleIdField;

        private TransportTypeCode transportTypeCodeField;

        private VehicleMakeCode vehicleMakeCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public TransportMeansRegId TransportMeansRegId
        {
            get
            {
                return this.transportMeansRegIdField;
            }
            set
            {
                this.transportMeansRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public FirstTrailerRegId FirstTrailerRegId
        {
            get
            {
                return this.firstTrailerRegIdField;
            }
            set
            {
                this.firstTrailerRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public SecondTrailerRegId SecondTrailerRegId
        {
            get
            {
                return this.secondTrailerRegIdField;
            }
            set
            {
                this.secondTrailerRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleId
        {
            get
            {
                return this.vehicleIdField;
            }
            set
            {
                this.vehicleIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public TransportTypeCode TransportTypeCode
        {
            get
            {
                return this.transportTypeCodeField;
            }
            set
            {
                this.transportTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public VehicleMakeCode VehicleMakeCode
        {
            get
            {
                return this.vehicleMakeCodeField;
            }
            set
            {
                this.vehicleMakeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class FirstTrailerRegId
    {

        private string countryCodeField;

        private string countryCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCodeListId
        {
            get
            {
                return this.countryCodeListIdField;
            }
            set
            {
                this.countryCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class SecondTrailerRegId
    {

        private string countryCodeField;

        private string countryCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCode
        {
            get
            {
                return this.countryCodeField;
            }
            set
            {
                this.countryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string countryCodeListId
        {
            get
            {
                return this.countryCodeListIdField;
            }
            set
            {
                this.countryCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitTerminationDetails
    {

        private CustomsOfficeDetails customsOfficeDetailsField;

        private string customsControlZoneIdField;

        private PIATMainConsignmentDetailsTransitTerminationDetailsRegisterDocumentIdDetails registerDocumentIdDetailsField;

        private SubjectAddressDetails subjectAddressDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public CustomsOfficeDetails CustomsOfficeDetails
        {
            get
            {
                return this.customsOfficeDetailsField;
            }
            set
            {
                this.customsOfficeDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CustomsControlZoneId
        {
            get
            {
                return this.customsControlZoneIdField;
            }
            set
            {
                this.customsControlZoneIdField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitTerminationDetailsRegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8", IsNullable = false)]
    public partial class CustomsOfficeDetails
    {

        private string customsOfficeCodeField;

        private string customsOfficeNameField;

        private UnifiedCountryCode unifiedCountryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CustomsOfficeCode
        {
            get
            {
                return this.customsOfficeCodeField;
            }
            set
            {
                this.customsOfficeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CustomsOfficeName
        {
            get
            {
                return this.customsOfficeNameField;
            }
            set
            {
                this.customsOfficeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitTerminationDetailsRegisterDocumentIdDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string registrationNumberIdField;

        private string reregistrationCodeField;

        private string aEORegistryKindCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RegistrationNumberId
        {
            get
            {
                return this.registrationNumberIdField;
            }
            set
            {
                this.registrationNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ReregistrationCode
        {
            get
            {
                return this.reregistrationCodeField;
            }
            set
            {
                this.reregistrationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string AEORegistryKindCode
        {
            get
            {
                return this.aEORegistryKindCodeField;
            }
            set
            {
                this.aEORegistryKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPITranshipmentDetails
    {

        private string cargoOperationKindCodeField;

        private string containerIndicatorField;

        private CACountryCode cACountryCodeField;

        private string shortCountryNameField;

        private string placeNameField;

        private CustomsOfficeDetails customsOfficeDetailsField;

        private PIATMainConsignmentDetailsPITranshipmentDetailsTranshipmentTransportDetails transhipmentTransportDetailsField;

        private string containerIdField;

        private string descriptionTextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoOperationKindCode
        {
            get
            {
                return this.cargoOperationKindCodeField;
            }
            set
            {
                this.cargoOperationKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ContainerIndicator
        {
            get
            {
                return this.containerIndicatorField;
            }
            set
            {
                this.containerIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CACountryCode CACountryCode
        {
            get
            {
                return this.cACountryCodeField;
            }
            set
            {
                this.cACountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ShortCountryName
        {
            get
            {
                return this.shortCountryNameField;
            }
            set
            {
                this.shortCountryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public CustomsOfficeDetails CustomsOfficeDetails
        {
            get
            {
                return this.customsOfficeDetailsField;
            }
            set
            {
                this.customsOfficeDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPITranshipmentDetailsTranshipmentTransportDetails TranshipmentTransportDetails
        {
            get
            {
                return this.transhipmentTransportDetailsField;
            }
            set
            {
                this.transhipmentTransportDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ContainerId
        {
            get
            {
                return this.containerIdField;
            }
            set
            {
                this.containerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DescriptionText
        {
            get
            {
                return this.descriptionTextField;
            }
            set
            {
                this.descriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class CACountryCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPITranshipmentDetailsTranshipmentTransportDetails
    {

        private UnifiedTransportModeCode unifiedTransportModeCodeField;

        private RegistrationNationalityCode registrationNationalityCodeField;

        private string transportMeansQuantityField;

        private PIATMainConsignmentDetailsPITranshipmentDetailsTranshipmentTransportDetailsTransportMeansRegistrationIdDetails transportMeansRegistrationIdDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedTransportModeCode UnifiedTransportModeCode
        {
            get
            {
                return this.unifiedTransportModeCodeField;
            }
            set
            {
                this.unifiedTransportModeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public RegistrationNationalityCode RegistrationNationalityCode
        {
            get
            {
                return this.registrationNationalityCodeField;
            }
            set
            {
                this.registrationNationalityCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TransportMeansQuantity
        {
            get
            {
                return this.transportMeansQuantityField;
            }
            set
            {
                this.transportMeansQuantityField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPITranshipmentDetailsTranshipmentTransportDetailsTransportMeansRegistrationIdDetails TransportMeansRegistrationIdDetails
        {
            get
            {
                return this.transportMeansRegistrationIdDetailsField;
            }
            set
            {
                this.transportMeansRegistrationIdDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class RegistrationNationalityCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPITranshipmentDetailsTranshipmentTransportDetailsTransportMeansRegistrationIdDetails
    {

        private TransportMeansRegId transportMeansRegIdField;

        private FirstTrailerRegId firstTrailerRegIdField;

        private SecondTrailerRegId secondTrailerRegIdField;

        private string docIdField;

        private string vehicleIdField;

        private TransportTypeCode transportTypeCodeField;

        private VehicleMakeCode vehicleMakeCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public TransportMeansRegId TransportMeansRegId
        {
            get
            {
                return this.transportMeansRegIdField;
            }
            set
            {
                this.transportMeansRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public FirstTrailerRegId FirstTrailerRegId
        {
            get
            {
                return this.firstTrailerRegIdField;
            }
            set
            {
                this.firstTrailerRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public SecondTrailerRegId SecondTrailerRegId
        {
            get
            {
                return this.secondTrailerRegIdField;
            }
            set
            {
                this.secondTrailerRegIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string VehicleId
        {
            get
            {
                return this.vehicleIdField;
            }
            set
            {
                this.vehicleIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public TransportTypeCode TransportTypeCode
        {
            get
            {
                return this.transportTypeCodeField;
            }
            set
            {
                this.transportTypeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public VehicleMakeCode VehicleMakeCode
        {
            get
            {
                return this.vehicleMakeCodeField;
            }
            set
            {
                this.vehicleMakeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetails
    {

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATTransportDocumentDetails pIATTransportDocumentDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsCustomsDocIdDetails customsDocIdDetailsField;

        private string cargoQuantityField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsDepartureCountryDetails departureCountryDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsDestinationCountryDetails destinationCountryDetailsField;

        private CAInvoiceValueAmount cAInvoiceValueAmountField;

        private UnifiedGrossMassMeasure unifiedGrossMassMeasureField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignorDetails pIATConsignorDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsigneeDetails pIATConsigneeDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPISellerDetails pISellerDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIBuyerDetails pIBuyerDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATLoadingLocationDetails pIATLoadingLocationDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATUnloadingLocationDetails pIATUnloadingLocationDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATDestinationDetails pIATDestinationDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIContainerDetails pIContainerDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetails unloadWarehouseDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetails[] pIATConsignmentItemDetailsField;

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATTransportDocumentDetails PIATTransportDocumentDetails
        {
            get
            {
                return this.pIATTransportDocumentDetailsField;
            }
            set
            {
                this.pIATTransportDocumentDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsCustomsDocIdDetails CustomsDocIdDetails
        {
            get
            {
                return this.customsDocIdDetailsField;
            }
            set
            {
                this.customsDocIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoQuantity
        {
            get
            {
                return this.cargoQuantityField;
            }
            set
            {
                this.cargoQuantityField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsDepartureCountryDetails DepartureCountryDetails
        {
            get
            {
                return this.departureCountryDetailsField;
            }
            set
            {
                this.departureCountryDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsDestinationCountryDetails DestinationCountryDetails
        {
            get
            {
                return this.destinationCountryDetailsField;
            }
            set
            {
                this.destinationCountryDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAInvoiceValueAmount CAInvoiceValueAmount
        {
            get
            {
                return this.cAInvoiceValueAmountField;
            }
            set
            {
                this.cAInvoiceValueAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedGrossMassMeasure UnifiedGrossMassMeasure
        {
            get
            {
                return this.unifiedGrossMassMeasureField;
            }
            set
            {
                this.unifiedGrossMassMeasureField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignorDetails PIATConsignorDetails
        {
            get
            {
                return this.pIATConsignorDetailsField;
            }
            set
            {
                this.pIATConsignorDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsigneeDetails PIATConsigneeDetails
        {
            get
            {
                return this.pIATConsigneeDetailsField;
            }
            set
            {
                this.pIATConsigneeDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPISellerDetails PISellerDetails
        {
            get
            {
                return this.pISellerDetailsField;
            }
            set
            {
                this.pISellerDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIBuyerDetails PIBuyerDetails
        {
            get
            {
                return this.pIBuyerDetailsField;
            }
            set
            {
                this.pIBuyerDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATLoadingLocationDetails PIATLoadingLocationDetails
        {
            get
            {
                return this.pIATLoadingLocationDetailsField;
            }
            set
            {
                this.pIATLoadingLocationDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATUnloadingLocationDetails PIATUnloadingLocationDetails
        {
            get
            {
                return this.pIATUnloadingLocationDetailsField;
            }
            set
            {
                this.pIATUnloadingLocationDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATDestinationDetails PIATDestinationDetails
        {
            get
            {
                return this.pIATDestinationDetailsField;
            }
            set
            {
                this.pIATDestinationDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIContainerDetails PIContainerDetails
        {
            get
            {
                return this.pIContainerDetailsField;
            }
            set
            {
                this.pIContainerDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetails UnloadWarehouseDetails
        {
            get
            {
                return this.unloadWarehouseDetailsField;
            }
            set
            {
                this.unloadWarehouseDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetails[] PIATConsignmentItemDetails
        {
            get
            {
                return this.pIATConsignmentItemDetailsField;
            }
            set
            {
                //this.pIATConsignmentItemDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATTransportDocumentDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        private string placeNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsCustomsDocIdDetails
    {

        private string customsOfficeCodeField;

        private string docCreationDateField;

        private string customsDocumentIdField;

        private string customsDocumentOrdinalIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CustomsOfficeCode
        {
            get
            {
                return this.customsOfficeCodeField;
            }
            set
            {
                this.customsOfficeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CustomsDocumentId
        {
            get
            {
                return this.customsDocumentIdField;
            }
            set
            {
                this.customsDocumentIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CustomsDocumentOrdinalId
        {
            get
            {
                return this.customsDocumentOrdinalIdField;
            }
            set
            {
                this.customsDocumentOrdinalIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsDepartureCountryDetails
    {

        private CACountryCode cACountryCodeField;

        private string shortCountryNameField;

        private string territoryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CACountryCode CACountryCode
        {
            get
            {
                return this.cACountryCodeField;
            }
            set
            {
                this.cACountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ShortCountryName
        {
            get
            {
                return this.shortCountryNameField;
            }
            set
            {
                this.shortCountryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsDestinationCountryDetails
    {

        private CACountryCode cACountryCodeField;

        private string shortCountryNameField;

        private string territoryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CACountryCode CACountryCode
        {
            get
            {
                return this.cACountryCodeField;
            }
            set
            {
                this.cACountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ShortCountryName
        {
            get
            {
                return this.shortCountryNameField;
            }
            set
            {
                this.shortCountryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class CAInvoiceValueAmount
    {

        private string currencyCodeField;

        private string currencyCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCodeListId
        {
            get
            {
                return this.currencyCodeListIdField;
            }
            set
            {
                this.currencyCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class UnifiedGrossMassMeasure
    {

        private string measurementUnitCodeField;

        private string measurementUnitCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCode
        {
            get
            {
                return this.measurementUnitCodeField;
            }
            set
            {
                this.measurementUnitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCodeListId
        {
            get
            {
                return this.measurementUnitCodeListIdField;
            }
            set
            {
                this.measurementUnitCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignorDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        private string equalIndicatorField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsigneeDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        private string equalIndicatorField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPISellerDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIBuyerDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATLoadingLocationDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string placeNameField;

        private string eventDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATUnloadingLocationDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string placeNameField;

        private string eventDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATDestinationDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string placeNameField;

        private SubjectAddressDetails subjectAddressDetailsField;

        private string customsOfficeCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CustomsOfficeCode
        {
            get
            {
                return this.customsOfficeCodeField;
            }
            set
            {
                this.customsOfficeCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIContainerDetails
    {

        private string containerIdField;

        private CACountryCode cACountryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ContainerId
        {
            get
            {
                return this.containerIdField;
            }
            set
            {
                this.containerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CACountryCode CACountryCode
        {
            get
            {
                return this.cACountryCodeField;
            }
            set
            {
                this.cACountryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetails
    {

        private GoodsLocationCode goodsLocationCodeField;

        private string placeNameField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsGoodsLocationDocDetails goodsLocationDocDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsRegisterDocumentIdDetails registerDocumentIdDetailsField;

        private string warehouseDateField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsStorageRequirementDetails storageRequirementDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public GoodsLocationCode GoodsLocationCode
        {
            get
            {
                return this.goodsLocationCodeField;
            }
            set
            {
                this.goodsLocationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PlaceName
        {
            get
            {
                return this.placeNameField;
            }
            set
            {
                this.placeNameField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsGoodsLocationDocDetails GoodsLocationDocDetails
        {
            get
            {
                return this.goodsLocationDocDetailsField;
            }
            set
            {
                this.goodsLocationDocDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsRegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string WarehouseDate
        {
            get
            {
                return this.warehouseDateField;
            }
            set
            {
                this.warehouseDateField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsStorageRequirementDetails StorageRequirementDetails
        {
            get
            {
                return this.storageRequirementDetailsField;
            }
            set
            {
                this.storageRequirementDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class GoodsLocationCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsGoodsLocationDocDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        private string docStartDateField;

        private string docValidityDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsRegisterDocumentIdDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string registrationNumberIdField;

        private string reregistrationCodeField;

        private string aEORegistryKindCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RegistrationNumberId
        {
            get
            {
                return this.registrationNumberIdField;
            }
            set
            {
                this.registrationNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ReregistrationCode
        {
            get
            {
                return this.reregistrationCodeField;
            }
            set
            {
                this.reregistrationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string AEORegistryKindCode
        {
            get
            {
                return this.aEORegistryKindCodeField;
            }
            set
            {
                this.aEORegistryKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsUnloadWarehouseDetailsStorageRequirementDetails
    {

        private string specialStorageRequirementIndicatorField;

        private string descriptionTextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string SpecialStorageRequirementIndicator
        {
            get
            {
                return this.specialStorageRequirementIndicatorField;
            }
            set
            {
                this.specialStorageRequirementIndicatorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DescriptionText
        {
            get
            {
                return this.descriptionTextField;
            }
            set
            {
                this.descriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetails
    {

        private string consignmentItemOrdinalField;

        private string commodityCodeField;

        private string goodsDescriptionTextField;

        private UnifiedGrossMassMeasure unifiedGrossMassMeasureField;

        private UnifiedNetMassMeasure unifiedNetMassMeasureField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsGoodsMeasureDetails goodsMeasureDetailsField;

        private string dTConsignmentItemOrdinalField;

        private string goodsMilitaryIndicatorField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsAddGoodsMeasureDetails addGoodsMeasureDetailsField;

        private string productionPlaceNameField;

        private string goodsLabelDescriptionTextField;

        private string goodsUsageDescriptionTextField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsManufacturerDetails manufacturerDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsVetReleaseOrganizationDetails vetReleaseOrganizationDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsCargoPackagePalletDetails cargoPackagePalletDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIContainerDetails pIContainerDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsOriginCountryDetails originCountryDetailsField;

        private CAValueAmount cAValueAmountField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIPrecedingDocDetails pIPrecedingDocDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetails pIGoodsDocDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIShipmentLocationDetails pIShipmentLocationDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ConsignmentItemOrdinal
        {
            get
            {
                return this.consignmentItemOrdinalField;
            }
            set
            {
                this.consignmentItemOrdinalField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CommodityCode
        {
            get
            {
                return this.commodityCodeField;
            }
            set
            {
                this.commodityCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsDescriptionText
        {
            get
            {
                return this.goodsDescriptionTextField;
            }
            set
            {
                this.goodsDescriptionTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedGrossMassMeasure UnifiedGrossMassMeasure
        {
            get
            {
                return this.unifiedGrossMassMeasureField;
            }
            set
            {
                this.unifiedGrossMassMeasureField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedNetMassMeasure UnifiedNetMassMeasure
        {
            get
            {
                return this.unifiedNetMassMeasureField;
            }
            set
            {
                this.unifiedNetMassMeasureField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsGoodsMeasureDetails GoodsMeasureDetails
        {
            get
            {
                return this.goodsMeasureDetailsField;
            }
            set
            {
                this.goodsMeasureDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string DTConsignmentItemOrdinal
        {
            get
            {
                return this.dTConsignmentItemOrdinalField;
            }
            set
            {
                this.dTConsignmentItemOrdinalField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsMilitaryIndicator
        {
            get
            {
                return this.goodsMilitaryIndicatorField;
            }
            set
            {
                this.goodsMilitaryIndicatorField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsAddGoodsMeasureDetails AddGoodsMeasureDetails
        {
            get
            {
                return this.addGoodsMeasureDetailsField;
            }
            set
            {
                this.addGoodsMeasureDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ProductionPlaceName
        {
            get
            {
                return this.productionPlaceNameField;
            }
            set
            {
                this.productionPlaceNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsLabelDescriptionText
        {
            get
            {
                return this.goodsLabelDescriptionTextField;
            }
            set
            {
                this.goodsLabelDescriptionTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsUsageDescriptionText
        {
            get
            {
                return this.goodsUsageDescriptionTextField;
            }
            set
            {
                this.goodsUsageDescriptionTextField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsManufacturerDetails ManufacturerDetails
        {
            get
            {
                return this.manufacturerDetailsField;
            }
            set
            {
                this.manufacturerDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsVetReleaseOrganizationDetails VetReleaseOrganizationDetails
        {
            get
            {
                return this.vetReleaseOrganizationDetailsField;
            }
            set
            {
                this.vetReleaseOrganizationDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsCargoPackagePalletDetails CargoPackagePalletDetails
        {
            get
            {
                return this.cargoPackagePalletDetailsField;
            }
            set
            {
                this.cargoPackagePalletDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIContainerDetails PIContainerDetails
        {
            get
            {
                return this.pIContainerDetailsField;
            }
            set
            {
                this.pIContainerDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsOriginCountryDetails OriginCountryDetails
        {
            get
            {
                return this.originCountryDetailsField;
            }
            set
            {
                this.originCountryDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAValueAmount CAValueAmount
        {
            get
            {
                return this.cAValueAmountField;
            }
            set
            {
                this.cAValueAmountField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIPrecedingDocDetails PIPrecedingDocDetails
        {
            get
            {
                return this.pIPrecedingDocDetailsField;
            }
            set
            {
                this.pIPrecedingDocDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetails PIGoodsDocDetails
        {
            get
            {
                return this.pIGoodsDocDetailsField;
            }
            set
            {
                this.pIGoodsDocDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIShipmentLocationDetails PIShipmentLocationDetails
        {
            get
            {
                return this.pIShipmentLocationDetailsField;
            }
            set
            {
                this.pIShipmentLocationDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class UnifiedNetMassMeasure
    {

        private string measurementUnitCodeField;

        private string measurementUnitCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCode
        {
            get
            {
                return this.measurementUnitCodeField;
            }
            set
            {
                this.measurementUnitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCodeListId
        {
            get
            {
                return this.measurementUnitCodeListIdField;
            }
            set
            {
                this.measurementUnitCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsGoodsMeasureDetails
    {

        private GoodsMeasure goodsMeasureField;

        private string measureUnitAbbreviationCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public GoodsMeasure GoodsMeasure
        {
            get
            {
                return this.goodsMeasureField;
            }
            set
            {
                this.goodsMeasureField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string MeasureUnitAbbreviationCode
        {
            get
            {
                return this.measureUnitAbbreviationCodeField;
            }
            set
            {
                this.measureUnitAbbreviationCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class GoodsMeasure
    {

        private string measurementUnitCodeField;

        private string measurementUnitCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCode
        {
            get
            {
                return this.measurementUnitCodeField;
            }
            set
            {
                this.measurementUnitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCodeListId
        {
            get
            {
                return this.measurementUnitCodeListIdField;
            }
            set
            {
                this.measurementUnitCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsAddGoodsMeasureDetails
    {

        private GoodsMeasure goodsMeasureField;

        private string measureUnitAbbreviationCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public GoodsMeasure GoodsMeasure
        {
            get
            {
                return this.goodsMeasureField;
            }
            set
            {
                this.goodsMeasureField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string MeasureUnitAbbreviationCode
        {
            get
            {
                return this.measureUnitAbbreviationCodeField;
            }
            set
            {
                this.measureUnitAbbreviationCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsManufacturerDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsVetReleaseOrganizationDetails
    {

        private string subjectNameField;

        private string veterinaryOrganizationIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string VeterinaryOrganizationId
        {
            get
            {
                return this.veterinaryOrganizationIdField;
            }
            set
            {
                this.veterinaryOrganizationIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsCargoPackagePalletDetails
    {

        private string packageAvailabilityCodeField;

        private string cargoQuantityField;

        private string cargoPartQuantityField;

        private string cargoKindNameField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsCargoPackagePalletDetailsPackagePalletDetails packagePalletDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PackageAvailabilityCode
        {
            get
            {
                return this.packageAvailabilityCodeField;
            }
            set
            {
                this.packageAvailabilityCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoQuantity
        {
            get
            {
                return this.cargoQuantityField;
            }
            set
            {
                this.cargoQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoPartQuantity
        {
            get
            {
                return this.cargoPartQuantityField;
            }
            set
            {
                this.cargoPartQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoKindName
        {
            get
            {
                return this.cargoKindNameField;
            }
            set
            {
                this.cargoKindNameField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsCargoPackagePalletDetailsPackagePalletDetails PackagePalletDetails
        {
            get
            {
                return this.packagePalletDetailsField;
            }
            set
            {
                this.packagePalletDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsCargoPackagePalletDetailsPackagePalletDetails
    {

        private string cargoPackageInfoKindCodeField;

        private PackageKindCode packageKindCodeField;

        private string packageQuantityField;

        private string cargoDescriptionTextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoPackageInfoKindCode
        {
            get
            {
                return this.cargoPackageInfoKindCodeField;
            }
            set
            {
                this.cargoPackageInfoKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public PackageKindCode PackageKindCode
        {
            get
            {
                return this.packageKindCodeField;
            }
            set
            {
                this.packageKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string PackageQuantity
        {
            get
            {
                return this.packageQuantityField;
            }
            set
            {
                this.packageQuantityField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CargoDescriptionText
        {
            get
            {
                return this.cargoDescriptionTextField;
            }
            set
            {
                this.cargoDescriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class PackageKindCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIContainerDetails
    {

        private string containerIdField;

        private CACountryCode cACountryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ContainerId
        {
            get
            {
                return this.containerIdField;
            }
            set
            {
                this.containerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CACountryCode CACountryCode
        {
            get
            {
                return this.cACountryCodeField;
            }
            set
            {
                this.cACountryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsOriginCountryDetails
    {

        private CACountryCode cACountryCodeField;

        private string shortCountryNameField;

        private string territoryCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CACountryCode CACountryCode
        {
            get
            {
                return this.cACountryCodeField;
            }
            set
            {
                this.cACountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ShortCountryName
        {
            get
            {
                return this.shortCountryNameField;
            }
            set
            {
                this.shortCountryNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TerritoryCode
        {
            get
            {
                return this.territoryCodeField;
            }
            set
            {
                this.territoryCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class CAValueAmount
    {

        private string currencyCodeField;

        private string currencyCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCodeListId
        {
            get
            {
                return this.currencyCodeListIdField;
            }
            set
            {
                this.currencyCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIPrecedingDocDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        private string docStartDateField;

        private string docValidityDateField;

        private UnifiedCountryCode unifiedCountryCodeField;

        private string authorityNameField;

        private string authorityIdField;

        private string formNumberIdField;

        private string registrationSeriesIdField;

        private string commodityCodeField;

        private string goodsDescriptionTextField;

        private string goodsLabelDescriptionTextField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsManufacturerDetails manufacturerDetailsField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsGoodsDisinfectionDetails goodsDisinfectionDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string AuthorityName
        {
            get
            {
                return this.authorityNameField;
            }
            set
            {
                this.authorityNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string AuthorityId
        {
            get
            {
                return this.authorityIdField;
            }
            set
            {
                this.authorityIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string FormNumberId
        {
            get
            {
                return this.formNumberIdField;
            }
            set
            {
                this.formNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RegistrationSeriesId
        {
            get
            {
                return this.registrationSeriesIdField;
            }
            set
            {
                this.registrationSeriesIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CommodityCode
        {
            get
            {
                return this.commodityCodeField;
            }
            set
            {
                this.commodityCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsDescriptionText
        {
            get
            {
                return this.goodsDescriptionTextField;
            }
            set
            {
                this.goodsDescriptionTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsLabelDescriptionText
        {
            get
            {
                return this.goodsLabelDescriptionTextField;
            }
            set
            {
                this.goodsLabelDescriptionTextField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsManufacturerDetails ManufacturerDetails
        {
            get
            {
                return this.manufacturerDetailsField;
            }
            set
            {
                this.manufacturerDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsGoodsDisinfectionDetails GoodsDisinfectionDetails
        {
            get
            {
                return this.goodsDisinfectionDetailsField;
            }
            set
            {
                this.goodsDisinfectionDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsManufacturerDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsGoodsDisinfectionDetails
    {

        private string disinfectionIndicatorField;

        private PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetails disinfectionDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string DisinfectionIndicator
        {
            get
            {
                return this.disinfectionIndicatorField;
            }
            set
            {
                this.disinfectionIndicatorField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetails DisinfectionDetails
        {
            get
            {
                return this.disinfectionDetailsField;
            }
            set
            {
                this.disinfectionDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIGoodsDocDetailsGoodsDisinfectionDetailsDisinfectionDetails
    {

        private string eventDateField;

        private string expositionDurationField;

        private string disinfectionMethodNameField;

        private string chemicalNameField;

        private string temperatureMeasureField;

        private ConcentrationMeasure concentrationMeasureField;

        private DoseMeasure doseMeasureField;

        private string descriptionTextField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ExpositionDuration
        {
            get
            {
                return this.expositionDurationField;
            }
            set
            {
                this.expositionDurationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string DisinfectionMethodName
        {
            get
            {
                return this.disinfectionMethodNameField;
            }
            set
            {
                this.disinfectionMethodNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ChemicalName
        {
            get
            {
                return this.chemicalNameField;
            }
            set
            {
                this.chemicalNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string TemperatureMeasure
        {
            get
            {
                return this.temperatureMeasureField;
            }
            set
            {
                this.temperatureMeasureField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public ConcentrationMeasure ConcentrationMeasure
        {
            get
            {
                return this.concentrationMeasureField;
            }
            set
            {
                this.concentrationMeasureField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public DoseMeasure DoseMeasure
        {
            get
            {
                return this.doseMeasureField;
            }
            set
            {
                this.doseMeasureField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DescriptionText
        {
            get
            {
                return this.descriptionTextField;
            }
            set
            {
                this.descriptionTextField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class ConcentrationMeasure
    {

        private string measurementUnitCodeField;

        private string measurementUnitCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCode
        {
            get
            {
                return this.measurementUnitCodeField;
            }
            set
            {
                this.measurementUnitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCodeListId
        {
            get
            {
                return this.measurementUnitCodeListIdField;
            }
            set
            {
                this.measurementUnitCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class DoseMeasure
    {

        private string measurementUnitCodeField;

        private string measurementUnitCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCode
        {
            get
            {
                return this.measurementUnitCodeField;
            }
            set
            {
                this.measurementUnitCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string measurementUnitCodeListId
        {
            get
            {
                return this.measurementUnitCodeListIdField;
            }
            set
            {
                this.measurementUnitCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIATConsignmentDetailsPIATConsignmentItemDetailsPIShipmentLocationDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private LocationCode locationCodeField;

        private string regionNameField;

        private string districtNameField;

        private string cityNameField;

        private string settlementNameField;

        private string eventDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public LocationCode LocationCode
        {
            get
            {
                return this.locationCodeField;
            }
            set
            {
                this.locationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string RegionName
        {
            get
            {
                return this.regionNameField;
            }
            set
            {
                this.regionNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DistrictName
        {
            get
            {
                return this.districtNameField;
            }
            set
            {
                this.districtNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CityName
        {
            get
            {
                return this.cityNameField;
            }
            set
            {
                this.cityNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SettlementName
        {
            get
            {
                return this.settlementNameField;
            }
            set
            {
                this.settlementNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class LocationCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetails
    {

        private TransitGuaranteeMeasureCode transitGuaranteeMeasureCodeField;

        private GuaranteeAmount guaranteeAmountField;

        private PIATMainConsignmentDetailsTransitGuaranteeDetailsGuaranteeCertificateIdDetails guaranteeCertificateIdDetailsField;

        private PIATMainConsignmentDetailsTransitGuaranteeDetailsTransitGuaranteeDocDetails transitGuaranteeDocDetailsField;

        private string nationalGuaranteeCodeField;

        private NonGuaranteeCountryCode nonGuaranteeCountryCodeField;

        private PIATMainConsignmentDetailsTransitGuaranteeDetailsRegisterDocumentIdDetails registerDocumentIdDetailsField;

        private string subjectBriefNameField;

        private string taxpayerIdField;

        private string bankIdField;

        private PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetails suretyDetailsField;

        private SubjectAddressDetails subjectAddressDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public TransitGuaranteeMeasureCode TransitGuaranteeMeasureCode
        {
            get
            {
                return this.transitGuaranteeMeasureCodeField;
            }
            set
            {
                this.transitGuaranteeMeasureCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public GuaranteeAmount GuaranteeAmount
        {
            get
            {
                return this.guaranteeAmountField;
            }
            set
            {
                this.guaranteeAmountField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetailsGuaranteeCertificateIdDetails GuaranteeCertificateIdDetails
        {
            get
            {
                return this.guaranteeCertificateIdDetailsField;
            }
            set
            {
                this.guaranteeCertificateIdDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetailsTransitGuaranteeDocDetails TransitGuaranteeDocDetails
        {
            get
            {
                return this.transitGuaranteeDocDetailsField;
            }
            set
            {
                this.transitGuaranteeDocDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string NationalGuaranteeCode
        {
            get
            {
                return this.nationalGuaranteeCodeField;
            }
            set
            {
                this.nationalGuaranteeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public NonGuaranteeCountryCode NonGuaranteeCountryCode
        {
            get
            {
                return this.nonGuaranteeCountryCodeField;
            }
            set
            {
                this.nonGuaranteeCountryCodeField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetailsRegisterDocumentIdDetails RegisterDocumentIdDetails
        {
            get
            {
                return this.registerDocumentIdDetailsField;
            }
            set
            {
                this.registerDocumentIdDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string BankId
        {
            get
            {
                return this.bankIdField;
            }
            set
            {
                this.bankIdField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetails SuretyDetails
        {
            get
            {
                return this.suretyDetailsField;
            }
            set
            {
                this.suretyDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class TransitGuaranteeMeasureCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class GuaranteeAmount
    {

        private string currencyCodeField;

        private string currencyCodeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string currencyCodeListId
        {
            get
            {
                return this.currencyCodeListIdField;
            }
            set
            {
                this.currencyCodeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetailsGuaranteeCertificateIdDetails
    {

        private string customsOfficeCodeField;

        private string docCreationDateField;

        private string customsDocumentIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CustomsOfficeCode
        {
            get
            {
                return this.customsOfficeCodeField;
            }
            set
            {
                this.customsOfficeCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string CustomsDocumentId
        {
            get
            {
                return this.customsDocumentIdField;
            }
            set
            {
                this.customsDocumentIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetailsTransitGuaranteeDocDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        private string docStartDateField;

        private string docValidityDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocStartDate
        {
            get
            {
                return this.docStartDateField;
            }
            set
            {
                this.docStartDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocValidityDate
        {
            get
            {
                return this.docValidityDateField;
            }
            set
            {
                this.docValidityDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9", IsNullable = false)]
    public partial class NonGuaranteeCountryCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetailsRegisterDocumentIdDetails
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private string registrationNumberIdField;

        private string reregistrationCodeField;

        private string aEORegistryKindCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RegistrationNumberId
        {
            get
            {
                return this.registrationNumberIdField;
            }
            set
            {
                this.registrationNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string ReregistrationCode
        {
            get
            {
                return this.reregistrationCodeField;
            }
            set
            {
                this.reregistrationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string AEORegistryKindCode
        {
            get
            {
                return this.aEORegistryKindCodeField;
            }
            set
            {
                this.aEORegistryKindCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetails
    {

        private PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsSuretyMainContractDetails suretyMainContractDetailsField;

        private PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsSuretyContractDetails suretyContractDetailsField;

        private PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsAddSuretyContractDetails addSuretyContractDetailsField;

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsSuretyMainContractDetails SuretyMainContractDetails
        {
            get
            {
                return this.suretyMainContractDetailsField;
            }
            set
            {
                this.suretyMainContractDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsSuretyContractDetails SuretyContractDetails
        {
            get
            {
                return this.suretyContractDetailsField;
            }
            set
            {
                this.suretyContractDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsAddSuretyContractDetails AddSuretyContractDetails
        {
            get
            {
                return this.addSuretyContractDetailsField;
            }
            set
            {
                this.addSuretyContractDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsSuretyMainContractDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsSuretyContractDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsTransitGuaranteeDetailsSuretyDetailsAddSuretyContractDetails
    {

        private DocKindCode docKindCodeField;

        private string docNameField;

        private string docIdField;

        private string docCreationDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public DocKindCode DocKindCode
        {
            get
            {
                return this.docKindCodeField;
            }
            set
            {
                this.docKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocName
        {
            get
            {
                return this.docNameField;
            }
            set
            {
                this.docNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPITransitDeclarantDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        private string equalIndicatorField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string EqualIndicator
        {
            get
            {
                return this.equalIndicatorField;
            }
            set
            {
                this.equalIndicatorField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIUnionCarrierDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        private PIATMainConsignmentDetailsPIUnionCarrierDetailsCarrierRepresentativeDetails carrierRepresentativeDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATMainConsignmentDetailsPIUnionCarrierDetailsCarrierRepresentativeDetails CarrierRepresentativeDetails
        {
            get
            {
                return this.carrierRepresentativeDetailsField;
            }
            set
            {
                this.carrierRepresentativeDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsPIUnionCarrierDetailsCarrierRepresentativeDetails
    {

        private FullNameDetails fullNameDetailsField;

        private string positionNameField;

        private CommunicationDetails communicationDetailsField;

        private IdentityDocV3Details identityDocV3DetailsField;

        private string roleCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public FullNameDetails FullNameDetails
        {
            get
            {
                return this.fullNameDetailsField;
            }
            set
            {
                this.fullNameDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string PositionName
        {
            get
            {
                return this.positionNameField;
            }
            set
            {
                this.positionNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public IdentityDocV3Details IdentityDocV3Details
        {
            get
            {
                return this.identityDocV3DetailsField;
            }
            set
            {
                this.identityDocV3DetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RoleCode
        {
            get
            {
                return this.roleCodeField;
            }
            set
            {
                this.roleCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8", IsNullable = false)]
    public partial class FullNameDetails
    {

        private string firstNameField;

        private string middleNameField;

        private string lastNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string FirstName
        {
            get
            {
                return this.firstNameField;
            }
            set
            {
                this.firstNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string MiddleName
        {
            get
            {
                return this.middleNameField;
            }
            set
            {
                this.middleNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string LastName
        {
            get
            {
                return this.lastNameField;
            }
            set
            {
                this.lastNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8", IsNullable = false)]
    public partial class CommunicationDetails
    {

        private string communicationChannelCodeField;

        private string communicationChannelNameField;

        private string communicationChannelIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CommunicationChannelCode
        {
            get
            {
                return this.communicationChannelCodeField;
            }
            set
            {
                this.communicationChannelCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CommunicationChannelName
        {
            get
            {
                return this.communicationChannelNameField;
            }
            set
            {
                this.communicationChannelNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string CommunicationChannelId
        {
            get
            {
                return this.communicationChannelIdField;
            }
            set
            {
                this.communicationChannelIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8", IsNullable = false)]
    public partial class IdentityDocV3Details
    {

        private UnifiedCountryCode unifiedCountryCodeField;

        private IdentityDocKindCode identityDocKindCodeField;

        private string docKindNameField;

        private string docSeriesIdField;

        private string docIdField;

        private string docCreationDateField;

        private string authorityIdField;

        private string authorityNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public UnifiedCountryCode UnifiedCountryCode
        {
            get
            {
                return this.unifiedCountryCodeField;
            }
            set
            {
                this.unifiedCountryCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public IdentityDocKindCode IdentityDocKindCode
        {
            get
            {
                return this.identityDocKindCodeField;
            }
            set
            {
                this.identityDocKindCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocKindName
        {
            get
            {
                return this.docKindNameField;
            }
            set
            {
                this.docKindNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocSeriesId
        {
            get
            {
                return this.docSeriesIdField;
            }
            set
            {
                this.docSeriesIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocId
        {
            get
            {
                return this.docIdField;
            }
            set
            {
                this.docIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string DocCreationDate
        {
            get
            {
                return this.docCreationDateField;
            }
            set
            {
                this.docCreationDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string AuthorityId
        {
            get
            {
                return this.authorityIdField;
            }
            set
            {
                this.authorityIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string AuthorityName
        {
            get
            {
                return this.authorityNameField;
            }
            set
            {
                this.authorityNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8", IsNullable = false)]
    public partial class IdentityDocKindCode
    {

        private string codeListIdField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string codeListId
        {
            get
            {
                return this.codeListIdField;
            }
            set
            {
                this.codeListIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATMainConsignmentDetailsRailwayStampDetails
    {

        private string railwayStationCodeField;

        private string eventDateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RailwayStationCode
        {
            get
            {
                return this.railwayStationCodeField;
            }
            set
            {
                this.railwayStationCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string EventDate
        {
            get
            {
                return this.eventDateField;
            }
            set
            {
                this.eventDateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class PIATCarrierDetails
    {

        private string subjectNameField;

        private string subjectBriefNameField;

        private CAUniqueCustomsNumberId cAUniqueCustomsNumberIdField;

        private string taxpayerIdField;

        private string taxRegistrationReasonCodeField;

        private string personIdField;

        private SubjectAddressDetails subjectAddressDetailsField;

        private PIATCarrierDetailsCarrierRepresentativeDetails carrierRepresentativeDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectName
        {
            get
            {
                return this.subjectNameField;
            }
            set
            {
                this.subjectNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string SubjectBriefName
        {
            get
            {
                return this.subjectBriefNameField;
            }
            set
            {
                this.subjectBriefNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public CAUniqueCustomsNumberId CAUniqueCustomsNumberId
        {
            get
            {
                return this.cAUniqueCustomsNumberIdField;
            }
            set
            {
                this.cAUniqueCustomsNumberIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxpayerId
        {
            get
            {
                return this.taxpayerIdField;
            }
            set
            {
                this.taxpayerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string TaxRegistrationReasonCode
        {
            get
            {
                return this.taxRegistrationReasonCodeField;
            }
            set
            {
                this.taxRegistrationReasonCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string PersonId
        {
            get
            {
                return this.personIdField;
            }
            set
            {
                this.personIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public SubjectAddressDetails SubjectAddressDetails
        {
            get
            {
                return this.subjectAddressDetailsField;
            }
            set
            {
                this.subjectAddressDetailsField = value;
            }
        }

        /// <remarks/>
        public PIATCarrierDetailsCarrierRepresentativeDetails CarrierRepresentativeDetails
        {
            get
            {
                return this.carrierRepresentativeDetailsField;
            }
            set
            {
                this.carrierRepresentativeDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class PIATCarrierDetailsCarrierRepresentativeDetails
    {

        private FullNameDetails fullNameDetailsField;

        private string positionNameField;

        private CommunicationDetails communicationDetailsField;

        private IdentityDocV3Details identityDocV3DetailsField;

        private string roleCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public FullNameDetails FullNameDetails
        {
            get
            {
                return this.fullNameDetailsField;
            }
            set
            {
                this.fullNameDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:SimpleDataObjects:v0.4.8")]
        public string PositionName
        {
            get
            {
                return this.positionNameField;
            }
            set
            {
                this.positionNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public CommunicationDetails CommunicationDetails
        {
            get
            {
                return this.communicationDetailsField;
            }
            set
            {
                this.communicationDetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:ComplexDataObjects:v0.4.8")]
        public IdentityDocV3Details IdentityDocV3Details
        {
            get
            {
                return this.identityDocV3DetailsField;
            }
            set
            {
                this.identityDocV3DetailsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string RoleCode
        {
            get
            {
                return this.roleCodeField;
            }
            set
            {
                this.roleCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9", IsNullable = false)]
    public partial class SparePartsDetails
    {

        private string sparePartsIndicatorField;

        private SparePartsDetailsSparePartsItemDetails sparePartsItemDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string SparePartsIndicator
        {
            get
            {
                return this.sparePartsIndicatorField;
            }
            set
            {
                this.sparePartsIndicatorField = value;
            }
        }

        /// <remarks/>
        public SparePartsDetailsSparePartsItemDetails SparePartsItemDetails
        {
            get
            {
                return this.sparePartsItemDetailsField;
            }
            set
            {
                this.sparePartsItemDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class SparePartsDetailsSparePartsItemDetails
    {

        private string goodsDescriptionTextField;

        private SparePartsDetailsSparePartsItemDetailsGoodsMeasureDetails goodsMeasureDetailsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string GoodsDescriptionText
        {
            get
            {
                return this.goodsDescriptionTextField;
            }
            set
            {
                this.goodsDescriptionTextField = value;
            }
        }

        /// <remarks/>
        public SparePartsDetailsSparePartsItemDetailsGoodsMeasureDetails GoodsMeasureDetails
        {
            get
            {
                return this.goodsMeasureDetailsField;
            }
            set
            {
                this.goodsMeasureDetailsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:EEC:M:CA:ComplexDataObjects:v1.4.9")]
    public partial class SparePartsDetailsSparePartsItemDetailsGoodsMeasureDetails
    {

        private GoodsMeasure goodsMeasureField;

        private string measureUnitAbbreviationCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public GoodsMeasure GoodsMeasure
        {
            get
            {
                return this.goodsMeasureField;
            }
            set
            {
                this.goodsMeasureField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:EEC:M:CA:SimpleDataObjects:v1.4.9")]
        public string MeasureUnitAbbreviationCode
        {
            get
            {
                return this.measureUnitAbbreviationCodeField;
            }
            set
            {
                this.measureUnitAbbreviationCodeField = value;
            }
        }
    }



}