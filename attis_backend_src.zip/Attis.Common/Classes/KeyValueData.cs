﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 02-11-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 02-11-2015
// ***********************************************************************
// <copyright file="KeyValueData.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Classes namespace.
/// </summary>
namespace Lawyers.Common.Classes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Class KeyValueData.
    /// </summary>
    public class KeyValueData
    {
        /// <summary>
        /// Gets the key.
        /// </summary>
        /// <value>The key.</value>
        public string Key { get; private set; }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <value>The value.</value>
        public string Value { get; private set; }

        /// <summary>
        /// Gets the data.
        /// </summary>
        /// <value>The data.</value>
        public Dictionary<string, string> Data { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="KeyValueData"/> class.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <param name="data">The data.</param>
        public KeyValueData(string key, string value, Dictionary<string, string> data)
        {
            this.Key = key;
            this.Value = value;
            this.Data = data;
        }
    }
}
