﻿
namespace Lawyers.Common.Metadata
{
	using System.Collections.Generic;
	using System.Xml.Serialization;
	using Common.Metadata;

	public class MetaTable
	{
		[XmlAttribute]
		public string Name { get; set; }

		[XmlAttribute]
		public string Comment { get; set; }

		[XmlArray]
		[XmlArrayItem("Column")]
		public List<MetaColumn> Columns { get; set; }

		[XmlArray]
		[XmlArrayItem("pk")]
		public List<MetaPrimaryKey> PrimaryKeys { get; set; }

		[XmlArray]
		[XmlArrayItem("fk")]
		public List<MetaForeignKey> ForeignKeys { get; set; }

		public MetaTable()
		{
			Columns = new List<MetaColumn>();
			PrimaryKeys = new List<MetaPrimaryKey>();
			ForeignKeys = new List<MetaForeignKey>();
		}
	}
}
