﻿using System;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Lawyers.Web.App.Helpers
{
    public static class GlobalisationHtmlHelperExtensions
    {
        public static object CultureHelpers { get; private set; }

        private static void AddOtherValues(RouteData routeData, RouteValueDictionary destinationRoute)
        {
            foreach (var routeInformation in routeData.Values)
            {
                if (routeInformation.Key == Helpers.GlobalisedRoute.CultureKey)
                {
                    continue; //Do not re-add, it will throw, this is the old value anyway.
                }
                destinationRoute.Add(routeInformation.Key, routeInformation.Value);
            }
        }

        public static RouteValueDictionary GlobalisedRoute(this HtmlHelper htmlHelper, String targetCultureName, RouteData routeData)
        {
            var globalisedRouteData = new RouteValueDictionary();
            globalisedRouteData.Add(Helpers.GlobalisedRoute.CultureKey, targetCultureName);
            AddOtherValues(routeData, globalisedRouteData);

            return globalisedRouteData;
        }

        public static MvcHtmlString LanguageLink(this HtmlHelper htmlHelper, String linkText, String targetCultureName,
                                                 RouteData routeData)
        {
            var span = new TagBuilder("span");
            span.AddCssClass("flag");
            span.AddCssClass(targetCultureName);

            var aInnerHtml = new StringBuilder();
            aInnerHtml.Append(span.ToString(TagRenderMode.Normal));

            var globalisedRouteUrl = htmlHelper.GlobalisedRoute(targetCultureName, routeData);

            var a = new TagBuilder("a");
            a.AddCssClass(String.Format("flag-link", targetCultureName));
            if (Thread.CurrentThread.CurrentCulture.Parent.IetfLanguageTag.StartsWith(targetCultureName))
            {
                a.AddCssClass("active");
            }
            a.InnerHtml = aInnerHtml.ToString();
            a.MergeAttribute("href", (new UrlHelper(HttpContext.Current.Request.RequestContext)).RouteUrl(globalisedRouteUrl));

            return MvcHtmlString.Create(a.ToString(TagRenderMode.Normal));
        }

        public static MvcHtmlString LanguageLinkText(this HtmlHelper htmlHelper, String linkText, String targetCultureName,
                                                 RouteData routeData)
        {
            var globalisedRouteUrl = htmlHelper.GlobalisedRoute(targetCultureName, routeData);
            var a = new TagBuilder("a");
            //a.AddCssClass(String.Format("flag-link", targetCultureName));
            if (Thread.CurrentThread.CurrentCulture.Parent.IetfLanguageTag.StartsWith(targetCultureName))
            {
                a.AddCssClass("active");
            }
            a.MergeAttribute("href", (new UrlHelper(HttpContext.Current.Request.RequestContext)).RouteUrl(globalisedRouteUrl));
            a.SetInnerText(linkText);
            return MvcHtmlString.Create(a.ToString(TagRenderMode.Normal));
        }
    }
}