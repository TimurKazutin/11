using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Xml;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using Microsoft.AspNet.Identity;
    using Newtonsoft.Json;
    using Lawyers.Web.App.Helpers;
    using System.Web.WebPages;
    using System.Web.SessionState;
    using Lawyers.Web.App.Models;
    using Lawyers.Web.App.Models.Enums;
    using Lawyers.Common.Classes;
    using System.IO;
    using System.Text;
    using System.Xml.Serialization;
    using Renci.SshNet;
    using System.Globalization;
    using System.Net.Mail;
    using System.Net;
    using log4net;
    using System.Linq;
    using Lawyers.Common.Enums;

    [SessionState(SessionStateBehavior.Disabled)]
    public class ContractController : Controller
    {
        private readonly ILog log = LogManager.GetLogger("Contract"); //log to file
        private IDataProvider Provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

        private string sftp_host = System.Configuration.ConfigurationManager.AppSettings["SFTPHost"];
        private string sftp_username = System.Configuration.ConfigurationManager.AppSettings["SFTPUser"];
        private string sftp_password = System.Configuration.ConfigurationManager.AppSettings["SFTPPassword"];

        // GET: contract
        public string Index(string customer_id, string language, string filter)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);
            string kpv = string.Empty;
            if (!String.IsNullOrEmpty(filter))
            {
                //query = $"SELECT kpved_subkind FROM kpved WHERE kpved_id='{filter}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                //kpv = Provider.RunQueryStr(query);
                kpv = "attis_contract_kpveds~'" + filter + "' AND ";
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} ((attis_contract_status ='0' OR attis_contract_status ='1') AND attis_contract_is_public = 1 AND (attis_contract_contragent='' OR attis_contract_contragent=null)) OR (attis_contract_status <> '3' AND attis_contract_contragent='{org_code}') OR (attis_contract_owner = '{user}' AND attis_contract_status <>'3') ORDER BY attis_contract_id DESC;";
            }
            else
                //if (customer_id != user) return "user id incorrect";
                //if (string.IsNullOrWhiteSpace(customer_id))
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE ((attis_contract_status ='0' OR attis_contract_status ='1') AND attis_contract_is_public = 1 AND (attis_contract_contragent='' OR attis_contract_contragent=null)) OR (attis_contract_status <> '3' AND attis_contract_contragent='{org_code}') OR (attis_contract_owner = '{user}' AND attis_contract_status <>'3') ORDER BY attis_contract_id DESC;";
            //else query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} attis_contract_owner = '{user}' AND (attis_contract_status ='0' OR attis_contract_status ='1' OR attis_contract_status ='2') OR (attis_contract_status ='1' AND attis_contract_contragent='{org_code}') ORDER BY attis_contract_id DESC;";
            //var query = $"SELECT attis_contract_id, attis_contract_create_date, attis_contract_desc, attis_contract_subject, attis_contract_date FROM attis_contracts WHERE attis_contract_owner = '{user}' OR ;";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";SELECT* FROM currencies WHERE LOWER(currency_name_ru) ~'{query}'
            lock (Provider.Locker)
            {
                var reader = Provider.RunQuery(query);
                var sellers = new List<Contr>();
                var mine = new List<Contr>();
                var contag = new List<Contr>();
                var list = new List<Orders>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Contr
                        {
                            id = (int)reader["attis_contract_id"],
                        };
                        rep.attis_contract_status = reader["attis_contract_status"].ToString();
                        rep.attis_contract_currency = reader["currency_name_ru"].ToString();
                        rep.attis_contract_desc = reader["attis_contract_desc"].ToString();
                        rep.attis_contract_subject = reader["attis_contract_subject"].ToString();
                        rep.attis_contract_owner = reader["attis_contract_owner"].ToString();
                        rep.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                        rep.attis_contract_date = reader["attis_contract_date"].ToString().Split(' ')[0];
                        rep.attis_contract_number = rep.id.ToString();// + "/2020" + rep.attis_contract_date?.ToString("yyyy");

                        sellers.Add(rep);
                    }
                    reader.Close();
                    foreach (var ln in sellers)
                    {
                        query = $"SELECT SUM(attis_cg_price*attis_cg_quantity) FROM attis_contract_goods WHERE attis_cg_contract_id = '{ln.id}';";
                        ln.attis_contract_amount = Provider.RunScalar(query);
                        if (!String.IsNullOrEmpty(ln.attis_contract_contragent))
                        {
                            query = $"SELECT org_name FROM organizations WHERE org_code= '{ln.attis_contract_contragent}'";
                            ln.attis_contract_contragent_name = Provider.RunQueryStr(query);
                        }
                        else ln.attis_contract_contragent_name = "";
                        query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                        ln.owner_org = Provider.RunQueryStr(query);
                        query = $"SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                        ln.owner_org_name = Provider.RunQueryStr(query);
                        if (ln.attis_contract_amount < 0) ln.attis_contract_amount = 0;
                        if (ln.attis_contract_owner == user) mine.Add(ln);
                        if (ln.attis_contract_contragent == org_code) contag.Add(ln);
                    }
                    var new1 = new Orders
                    {
                        title = "Новые",
                    };
                    new1.contracts = new List<Contr>(sellers);
                    var new2 = new Orders
                    {
                        title = "Мои",
                    };
                    new2.contracts = new List<Contr>(mine);
                    var new3 = new Orders
                    {
                        title = "Участвую",
                    };
                    new3.contracts = new List<Contr>(contag);
                    list.Add(new1); list.Add(new2); list.Add(new3);
                    //return Json(list, JsonRequestBehavior.AllowGet);
                    var settings = new JsonSerializerSettings
                    {
                        DateFormatString = "yyyy-MM-dd",
                        DateTimeZoneHandling = DateTimeZoneHandling.Utc
                    };
                    //return Json(san, JsonRequestBehavior.AllowGet);
                    return JsonConvert.SerializeObject(list, settings);
                }
            }
            return "[]";
        }
        /*
         * moved to deals controller
        public string Deals(string customer_id, string language, string filter)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);
            string kpv = string.Empty;
            if (!String.IsNullOrEmpty(filter))
            {
                //query = $"SELECT kpved_subkind FROM kpved WHERE kpved_id='{filter}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                //kpv = Provider.RunQueryStr(query);
                kpv = "attis_contract_kpveds~'" + filter + "' AND ";
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} attis_contract_status ='3' AND (attis_contract_contragent='{org_code}' OR attis_contract_owner = '{user}') ORDER BY attis_contract_id DESC;";
            }
            else
                //if (customer_id != user) return "user id incorrect";
                //if (string.IsNullOrWhiteSpace(customer_id))
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE attis_contract_status ='3' AND (attis_contract_contragent='{org_code}' OR attis_contract_owner = '{user}') ORDER BY attis_contract_id DESC;";
            //else query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} attis_contract_owner = '{user}' AND (attis_contract_status ='0' OR attis_contract_status ='1' OR attis_contract_status ='2') OR (attis_contract_status ='1' AND attis_contract_contragent='{org_code}') ORDER BY attis_contract_id DESC;";
            //var query = $"SELECT attis_contract_id, attis_contract_create_date, attis_contract_desc, attis_contract_subject, attis_contract_date FROM attis_contracts WHERE attis_contract_owner = '{user}' OR ;";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";SELECT* FROM currencies WHERE LOWER(currency_name_ru) ~'{query}'
            var reader = Provider.RunQuery(query);
            var sellers = new List<Contr>();
            var mine = new List<Contr>();
            var contag = new List<Contr>();
            var list = new List<Orders>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new Contr
                    {
                        id = (int)reader["attis_contract_id"],
                    };
                    rep.attis_contract_status = reader["attis_contract_status"].ToString();
                    rep.attis_contract_currency = reader["currency_name_ru"].ToString();
                    rep.attis_contract_desc = reader["attis_contract_desc"].ToString();
                    rep.attis_contract_subject = reader["attis_contract_subject"].ToString();
                    rep.attis_contract_owner = reader["attis_contract_owner"].ToString();
                    rep.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                    rep.attis_contract_date = reader["attis_contract_date"].ToString().Split(' ')[0];
                    rep.attis_contract_number = rep.id.ToString();// + "/2020" + rep.attis_contract_date?.ToString("yyyy");

                    sellers.Add(rep);
                }
                reader.Close();
                foreach (var ln in sellers)
                {
                    query = $"SELECT SUM(attis_cg_price*attis_cg_quantity) FROM attis_contract_goods WHERE attis_cg_contract_id = '{ln.id}';";
                    ln.attis_contract_amount = Provider.RunScalar(query);
                    if (!String.IsNullOrEmpty(ln.attis_contract_contragent))
                    {
                        query = $"SELECT org_name FROM organizations WHERE org_code= '{ln.attis_contract_contragent}'";
                        ln.attis_contract_contragent_name = Provider.RunQueryStr(query);
                    }
                    else ln.attis_contract_contragent_name = "";
                    query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                    ln.owner_org = Provider.RunQueryStr(query);
                    query = $"SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                    ln.owner_org_name = Provider.RunQueryStr(query);
                    if (ln.attis_contract_amount < 0) ln.attis_contract_amount = 0;
                    if (ln.attis_contract_owner == user) mine.Add(ln);
                    if (ln.attis_contract_contragent == org_code) contag.Add(ln);
                }
                var new1 = new Orders
                {
                    title = "Новые",
                };
                new1.contracts = new List<Contr>(sellers);
                var new2 = new Orders
                {
                    title = "Мои",
                };
                new2.contracts = new List<Contr>(mine);
                var new3 = new Orders
                {
                    title = "Участвую",
                };
                new3.contracts = new List<Contr>(contag);
                list.Add(new1); list.Add(new2); list.Add(new3);
                //return Json(list, JsonRequestBehavior.AllowGet);
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }
        *
        *moved to achives controller
        public string Archives(string customer_id, string language, string filter)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);
            string kpv = string.Empty;
            if (!String.IsNullOrEmpty(filter))
            {
                //query = $"SELECT kpved_subkind FROM kpved WHERE kpved_id='{filter}'"; // WHERE lang ='" + lang + "' ORDER BY date DESC;";
                //kpv = Provider.RunQueryStr(query);
                kpv = "attis_contract_kpveds~'" + filter + "' AND ";
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} attis_contract_is_public = 1 AND (attis_contract_status ='0' OR attis_contract_status ='1' OR attis_contract_status ='2' OR attis_contract_status ='3') ORDER BY attis_contract_id DESC;";
            }
            else
                //if (customer_id != user) return "user id incorrect";
                //if (string.IsNullOrWhiteSpace(customer_id))
                query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE attis_contract_status ='-1' AND (attis_contract_contragent='{org_code}' OR attis_contract_owner = '{user}') ORDER BY attis_contract_id DESC;";
            //else query = $"SELECT t2.currency_name_ru, t1.attis_contract_id, t1.attis_contract_currency, t1.attis_contract_owner, t1.attis_contract_contragent, t1.attis_contract_status, t1.attis_contract_create_date, t1.attis_contract_desc, t1.attis_contract_subject, t1.attis_contract_date FROM attis_contracts t1 LEFT JOIN currencies t2 ON t1.attis_contract_currency=t2.currency_code::varchar(255) WHERE {kpv} attis_contract_owner = '{user}' AND (attis_contract_status ='0' OR attis_contract_status ='1' OR attis_contract_status ='2') OR (attis_contract_status ='1' AND attis_contract_contragent='{org_code}') ORDER BY attis_contract_id DESC;";
            //var query = $"SELECT attis_contract_id, attis_contract_create_date, attis_contract_desc, attis_contract_subject, attis_contract_date FROM attis_contracts WHERE attis_contract_owner = '{user}' OR ;";
            //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";SELECT* FROM currencies WHERE LOWER(currency_name_ru) ~'{query}'
            var reader = Provider.RunQuery(query);
            var sellers = new List<Contr>();
            var mine = new List<Contr>();
            var contag = new List<Contr>();
            var list = new List<Orders>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new Contr
                    {
                        id = (int)reader["attis_contract_id"],
                    };
                    rep.attis_contract_status = reader["attis_contract_status"].ToString();
                    rep.attis_contract_currency = reader["currency_name_ru"].ToString();
                    rep.attis_contract_desc = reader["attis_contract_desc"].ToString();
                    rep.attis_contract_subject = reader["attis_contract_subject"].ToString();
                    rep.attis_contract_owner = reader["attis_contract_owner"].ToString();
                    rep.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                    rep.attis_contract_date = reader["attis_contract_date"].ToString().Split(' ')[0];
                    rep.attis_contract_number = rep.id.ToString();// + "/2020" + rep.attis_contract_date?.ToString("yyyy");

                    sellers.Add(rep);
                }
                reader.Close();
                foreach (var ln in sellers)
                {
                    query = $"SELECT SUM(attis_cg_price*attis_cg_quantity) FROM attis_contract_goods WHERE attis_cg_contract_id = '{ln.id}';";
                    ln.attis_contract_amount = Provider.RunScalar(query);
                    if (!String.IsNullOrEmpty(ln.attis_contract_contragent))
                    {
                        query = $"SELECT org_name FROM organizations WHERE org_code= '{ln.attis_contract_contragent}'";
                        ln.attis_contract_contragent_name = Provider.RunQueryStr(query);
                    }
                    else ln.attis_contract_contragent_name = "";
                    query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                    ln.owner_org = Provider.RunQueryStr(query);
                    query = $"SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{ln.attis_contract_owner}'";
                    ln.owner_org_name = Provider.RunQueryStr(query);
                    if (ln.attis_contract_amount < 0) ln.attis_contract_amount = 0;
                    if (ln.attis_contract_owner == user) mine.Add(ln);
                    if (ln.attis_contract_contragent == org_code) contag.Add(ln);
                }
                var new1 = new Orders
                {
                    title = "Новые",
                };
                new1.contracts = new List<Contr>(sellers);
                var new2 = new Orders
                {
                    title = "Мои",
                };
                new2.contracts = new List<Contr>(mine);
                var new3 = new Orders
                {
                    title = "Участвую",
                };
                new3.contracts = new List<Contr>(contag);
                list.Add(new1); list.Add(new2); list.Add(new3);
                //return Json(list, JsonRequestBehavior.AllowGet);
                var settings = new JsonSerializerSettings
                {
                    DateFormatString = "yyyy-MM-dd",
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                };
                //return Json(san, JsonRequestBehavior.AllowGet);
                return JsonConvert.SerializeObject(list, settings);
            }
            return "[]";
        }
        */
        public static DateTime GetDateTimeFromString(string inputDate)
        {
            var success = DateTime.TryParse(inputDate, out var tempDt);
            return success ? tempDt.Date : default;
        }
        

        public string GetContract(string attis_contract_id, string token)
        {
            //string user = User.Identity.GetUserId();
            var query = $"SELECT * FROM attis_contracts WHERE attis_contract_id = '{attis_contract_id}';";
            lock (Provider.Locker)
                {
                    var reader = Provider.RunQuery(query);
                    var sellers = new Sellers();
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            sellers.attis_contract_id = int.Parse(attis_contract_id);
                            sellers.attis_contract_owner = reader["attis_contract_owner"].ToString();
                            sellers.attis_contract_status = reader["attis_contract_status"].ToString();
                            sellers.attis_contract_type = (int)reader["attis_contract_type"] != 0;
                            sellers.attis_contract_case = (int)reader["attis_contract_case"] != 0;
                            sellers.attis_contract_subject = reader["attis_contract_subject"].ToString();
                            sellers.attis_contract_desc = reader["attis_contract_desc"].ToString();
                            sellers.attis_contract_currency = reader["attis_contract_currency"].ToString();
                            sellers.attis_contract_payment_type = reader["attis_contract_payment_type"].ToString();
                            sellers.attis_contract_delivery_term = reader["attis_contract_delivery_term"].ToString();
                            sellers.attis_contract_delivery_place = reader["attis_contract_delivery_place"].ToString();
                            sellers.attis_contract_date = GetDateTimeFromString(reader["attis_contract_date"].ToString());
                            sellers.attis_contract_deadline = GetDateTimeFromString(reader["attis_contract_deadline"].ToString());
                            sellers.attis_contract_create_date = GetDateTimeFromString(reader["attis_contract_create_date"].ToString());
                            sellers.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                            sellers.attis_contract_is_public = reader.GetFieldValueOrDefault<int>("attis_contract_is_public"); //.ToString().Trim(); 
                            sellers.attis_contract_kpveds = reader["attis_contract_kpveds"].ToString();
                            sellers.grace_period = reader.GetFieldValueOrDefault<int>("grace_period");
                            sellers.payment_date = GetDateTimeFromString(reader["payment_date"].ToString());
                            sellers.advance_payment = reader.GetFieldValueOrDefault<float>("advance_payment");
                            sellers.delay_days = reader.GetFieldValueOrDefault<int>("delay_days");
                            sellers.language = reader["language"].ToString();
                            sellers.overdue = reader.GetFieldValueOrDefault<float>("overdue");
                            sellers.packaging_transport_fees_included = reader.GetFieldValueOrDefault<int>("packaging_transport_fees_included");
                            sellers.goods_origin_country = reader["goods_origin_country"].ToString();
                            sellers.point_of_departure = reader["point_of_departure"].ToString();
                            sellers.destination_point = reader["destination_point"].ToString();
                            sellers.days_to_change_price = reader.GetFieldValueOrDefault<int>("days_to_change_price");
                            sellers.prepayment_percent = reader.GetFieldValueOrDefault<float>("prepayment_percent");
                            sellers.number_of_days_for_prepayment = reader.GetFieldValueOrDefault<int>("number_of_days_for_prepayment");
                            sellers.number_of_days_for_fullpayment = reader.GetFieldValueOrDefault<int>("number_of_days_for_fullpayment");
                            sellers.overdue_term = reader.GetFieldValueOrDefault<int>("overdue_term");
                            sellers.shipping_term = reader.GetFieldValueOrDefault<int>("shipping_term");
                            sellers.total_delivery_time = reader.GetFieldValueOrDefault<int>("total_delivery_time");
                            sellers.days_to_receive_goods = reader.GetFieldValueOrDefault<int>("days_to_receive_goods");
                            sellers.days_to_quality_receive_goods = reader.GetFieldValueOrDefault<int>("days_to_quality_receive_goods");
                            sellers.transfer_of_ownership = reader.GetFieldValueOrDefault<int>("transfer_of_ownership");
                            sellers.guaranty_term = reader.GetFieldValueOrDefault<int>("guaranty_term");
                            sellers.exceeding_guaranty_term = reader.GetFieldValueOrDefault<int>("exceeding_guaranty_term");
                            sellers.payment_overdue = reader.GetFieldValueOrDefault<float>("payment_overdue");
                            sellers.shipping_overdue = reader.GetFieldValueOrDefault<float>("shipping_overdue");
                            sellers.decline_due_to_overdue = reader.GetFieldValueOrDefault<float>("decline_due_to_overdue");
                            sellers.legal_country = reader["legal_country"].ToString();
                            sellers.arbitrage_country = reader["arbitrage_country"].ToString();
                            sellers.contract_language = reader["contract_language"].ToString();
                            sellers.contract_term = GetDateTimeFromString(reader["contract_term"].ToString());
                            sellers.notification_term = reader.GetFieldValueOrDefault<int>("notification_term");
                            sellers.is_signed_by_owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                            sellers.is_signed_by_counterparty = reader.GetFieldValueOrDefault<bool>("is_signed_by_counterparty");
                            sellers.how_is_signed_by_owner = reader["how_is_signed_by_owner"].ToString();
                            sellers.how_is_signed_by_counterparty = reader["how_is_signed_by_owner"].ToString();
                            sellers.cancel_term = reader.GetFieldValueOrDefault<int>("cancel_term");
                            sellers.consent_term = reader.GetFieldValueOrDefault<int>("consent_term");
                            sellers.inform_term = reader.GetFieldValueOrDefault<int>("inform_term");
                            sellers.location_term = reader.GetFieldValueOrDefault<int>("location_term");
                            sellers.when_is_signed_by_owner = reader["when_is_signed_by_owner"].ToString(); ;
                            sellers.when_is_signed_by_counterparty= reader["when_is_signed_by_counterparty"].ToString();
                            sellers.name_of_signature_owner = reader["sign_name"].ToString();
                            sellers.name_of_signature_counterparty = reader["sign_name1"].ToString();
                        }
                        reader.Close();
                        //if (sellers.attis_contract_is_public == "False") sellers.attis_contract_is_public = "false"; //else sellers.attis_contract_is_public = "1";
                        var query1 = $"SELECT attis_cg_good_name, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price, origin FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
                        var reader1 = Provider.RunQuery(query1);
                        var product = new List<Product>();
                        if (reader1 != null)
                        {
                            while (reader1.Read())
                            {
                                var rep1 = new Product
                                {
                                    attis_cg_good_name = reader1["attis_cg_good_name"].ToString(),
                                };
                                rep1.attis_cg_TNVED = reader1["attis_cg_TNVED"].ToString();
                                rep1.attis_cg_quantity = reader1["attis_cg_quantity"].ToString();
                                rep1.attis_cg_measures = reader1["attis_cg_measures"].ToString();
                                rep1.attis_cg_price = reader1["attis_cg_price"].ToString();
                                rep1.origin_country = reader1["origin"].ToString();
                            product.Add(rep1);
                            }
                            reader1.Close();
                        }

                        query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{attis_contract_id}' and doc_widget_id ='ktz'";
                        reader = Provider.RunQuery(query1);
                        var files = new List<Kfiles>();
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                var rep = new Kfiles
                                {
                                    id = reader["id"].ToString(), //"/picture/getfile/"
                                };
                                rep.name = reader["img_file_name"].ToString();
                                files.Add(rep);
                            }
                            reader.Close();
                        }
                        sellers.product = new List<Product>(product);
                        sellers.files = new List<Kfiles>(files);
                        var settings = new JsonSerializerSettings
                        {
                            DateFormatString = "yyyy-MM-dd HH:mm",
                            DateTimeZoneHandling = DateTimeZoneHandling.Utc
                        };
                        //return Json(san, JsonRequestBehavior.AllowGet);
                        return JsonConvert.SerializeObject(sellers, settings);
                    }

                    return Provider.lastError;
                }
        }        
        public string GetContractXML(string attis_contract_id, string token)
        {
            //string user = User.Identity.GetUserId();
            var query = $"SELECT * FROM attis_contracts WHERE attis_contract_id = '{attis_contract_id}';";
            lock (Provider.Locker)
                {
                    var reader = Provider.RunQuery(query);
                    var sellers = new Sellers();
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            sellers.attis_contract_id = int.Parse(attis_contract_id);
                            sellers.attis_contract_owner = reader["attis_contract_owner"].ToString();
                            sellers.attis_contract_status = reader["attis_contract_status"].ToString();
                            sellers.attis_contract_type = (int)reader["attis_contract_type"] != 0;
                            sellers.attis_contract_case = (int)reader["attis_contract_case"] != 0;
                            sellers.attis_contract_subject = reader["attis_contract_subject"].ToString();
                            sellers.attis_contract_desc = reader["attis_contract_desc"].ToString();
                            sellers.attis_contract_currency = reader["attis_contract_currency"].ToString();
                            sellers.attis_contract_payment_type = reader["attis_contract_payment_type"].ToString();
                            sellers.attis_contract_delivery_term = reader["attis_contract_delivery_term"].ToString();
                            sellers.attis_contract_delivery_place = reader["attis_contract_delivery_place"].ToString();
                            sellers.attis_contract_date = GetDateTimeFromString(reader["attis_contract_date"].ToString());
                            sellers.attis_contract_deadline = GetDateTimeFromString(reader["attis_contract_deadline"].ToString());
                            sellers.attis_contract_create_date = GetDateTimeFromString(reader["attis_contract_create_date"].ToString());
                            sellers.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                            sellers.attis_contract_is_public = reader.GetFieldValueOrDefault<int>("attis_contract_is_public");
                            sellers.attis_contract_kpveds = reader["attis_contract_kpveds"].ToString();
                            sellers.grace_period = reader.GetFieldValueOrDefault<int>("grace_period");
                            sellers.payment_date = GetDateTimeFromString(reader["payment_date"].ToString());
                            sellers.advance_payment = reader.GetFieldValueOrDefault<float>("advance_payment");
                            sellers.delay_days = reader.GetFieldValueOrDefault<int>("delay_days");
                            sellers.language = reader["language"].ToString();
                            sellers.overdue = reader.GetFieldValueOrDefault<float>("overdue");
                            sellers.packaging_transport_fees_included = reader.GetFieldValueOrDefault<int>("packaging_transport_fees_included");
                            sellers.goods_origin_country = reader["goods_origin_country"].ToString();
                            sellers.point_of_departure = reader["point_of_departure"].ToString();
                            sellers.destination_point = reader["destination_point"].ToString();
                            sellers.days_to_change_price = reader.GetFieldValueOrDefault<int>("days_to_change_price");
                            sellers.prepayment_percent = reader.GetFieldValueOrDefault<float>("prepayment_percent");
                            sellers.number_of_days_for_prepayment = reader.GetFieldValueOrDefault<int>("number_of_days_for_prepayment");
                            sellers.number_of_days_for_fullpayment = reader.GetFieldValueOrDefault<int>("number_of_days_for_fullpayment");
                            sellers.overdue_term = reader.GetFieldValueOrDefault<int>("overdue_term");
                            sellers.shipping_term = reader.GetFieldValueOrDefault<int>("shipping_term");
                            sellers.total_delivery_time = reader.GetFieldValueOrDefault<int>("total_delivery_time");
                            sellers.days_to_receive_goods = reader.GetFieldValueOrDefault<int>("days_to_receive_goods");
                            sellers.days_to_quality_receive_goods = reader.GetFieldValueOrDefault<int>("days_to_quality_receive_goods");
                            sellers.transfer_of_ownership = reader.GetFieldValueOrDefault<int>("transfer_of_ownership");
                            sellers.guaranty_term = reader.GetFieldValueOrDefault<int>("guaranty_term");
                            sellers.exceeding_guaranty_term = reader.GetFieldValueOrDefault<int>("exceeding_guaranty_term");
                            sellers.payment_overdue = reader.GetFieldValueOrDefault<float>("payment_overdue");
                            sellers.shipping_overdue = reader.GetFieldValueOrDefault<float>("shipping_overdue");
                            sellers.decline_due_to_overdue = reader.GetFieldValueOrDefault<float>("decline_due_to_overdue");
                            sellers.legal_country = reader["legal_country"].ToString();
                            sellers.arbitrage_country = reader["arbitrage_country"].ToString();
                            sellers.contract_language = reader["contract_language"].ToString();
                            sellers.contract_term = GetDateTimeFromString(reader["contract_term"].ToString());
                            sellers.notification_term = reader.GetFieldValueOrDefault<int>("notification_term");
                            sellers.cancel_term = reader.GetFieldValueOrDefault<int>("cancel_term");
                            sellers.consent_term = reader.GetFieldValueOrDefault<int>("consent_term");
                            sellers.inform_term = reader.GetFieldValueOrDefault<int>("inform_term");
                            sellers.location_term = reader.GetFieldValueOrDefault<int>("location_term");

                    }
                        reader.Close();
                        //if (sellers.attis_contract_is_public == "False") sellers.attis_contract_is_public = "false"; //else sellers.attis_contract_is_public = "1";
                        var query1 = $"SELECT attis_cg_good_name, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price, origin FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
                        var reader1 = Provider.RunQuery(query1);
                        var product = new List<Product>();
                        if (reader1 != null)
                        {
                            while (reader1.Read())
                            {
                                var rep1 = new Product
                                {
                                    attis_cg_good_name = reader1["attis_cg_good_name"].ToString(),
                                };
                                rep1.attis_cg_TNVED = reader1["attis_cg_TNVED"].ToString();
                                rep1.attis_cg_quantity = reader1["attis_cg_quantity"].ToString();
                                rep1.attis_cg_measures = reader1["attis_cg_measures"].ToString();
                                rep1.attis_cg_price = reader1["attis_cg_price"].ToString();
                                rep1.origin_country = reader1["origin"].ToString();
                            product.Add(rep1);
                            }
                            reader1.Close();
                        }

                        query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{attis_contract_id}' and doc_widget_id ='ktz'";
                        reader = Provider.RunQuery(query1);
                        var files = new List<Kfiles>();
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                var rep = new Kfiles
                                {
                                    id = reader["id"].ToString(), //"/picture/getfile/"
                                };
                                rep.name = reader["img_file_name"].ToString();
                                files.Add(rep);
                            }
                            reader.Close();
                        }
                        sellers.product = new List<Product>(product);
                        sellers.files = new List<Kfiles>(files);

                    XmlSerializer xsSubmit = new XmlSerializer(typeof(Sellers));
                    var xml = "";

                    using (var sww = new StringWriter())
                    {
                        using (XmlWriter writer = XmlWriter.Create(sww))
                        {
                            xsSubmit.Serialize(writer, sellers);
                            xml = sww.ToString(); // Your XML
                        }
                    }
                    return xml;
                }

                    return "";
                }
        }



        public string Ktg(string contract_id)
        {
            var qre1 = $"SELECT attis_contract_doc_id FROM attis_contract_docs WHERE attis_contract_doc_type=1 AND attis_contract_doc_contract = '{contract_id}'";
            var tt = Provider.RunScalar(qre1);

            var sellrs = new Ktgres();
            sellrs.status = 500;
            sellrs.message = "Не хватает данных";
            if (tt < 0)
                return JsonConvert.SerializeObject(sellrs);
            var query = $"SELECT * FROM attis_contracts WHERE attis_contract_id = '{contract_id}';";
            var reader = Provider.RunQuery(query);
            var sellers = new Sellers();
            if (reader != null)
            {
                while (reader.Read())
                {
                    sellers.attis_contract_id = int.Parse(contract_id);
                    sellers.attis_contract_owner = reader["attis_contract_owner"].ToString();
                    sellers.attis_contract_status = reader["attis_contract_status"].ToString();
                    sellers.attis_contract_type = (int)reader["attis_contract_type"] != 0;
                    sellers.attis_contract_case = (int)reader["attis_contract_case"] != 0;
                    sellers.attis_contract_subject = reader["attis_contract_subject"].ToString();
                    sellers.attis_contract_desc = reader["attis_contract_desc"].ToString();
                    sellers.attis_contract_currency = reader["attis_contract_currency"].ToString();
                    sellers.attis_contract_payment_type = reader["attis_contract_payment_type"].ToString();
                    sellers.attis_contract_delivery_term = reader["attis_contract_delivery_term"].ToString();
                    sellers.attis_contract_delivery_place = reader["attis_contract_delivery_place"].ToString();
                    sellers.attis_contract_date = GetDateTimeFromString(reader["attis_contract_date"].ToString());
                    sellers.attis_contract_deadline = GetDateTimeFromString(reader["attis_contract_deadline"].ToString());
                    sellers.attis_contract_create_date = GetDateTimeFromString(reader["attis_contract_create_date"].ToString());
                    sellers.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                    sellers.attis_contract_is_public = reader.GetFieldValueOrDefault<int>("attis_contract_is_public");
                    sellers.attis_contract_kpveds = reader["attis_contract_kpveds"].ToString();
                }
                reader.Close();
            }
            query = $"SELECT * FROM \"Invoice\" WHERE \"RefDocumentID\" = {tt};";
            reader = Provider.RunQuery(query);
            var list = new DocModel();
            var Origin = "KZ";
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.DocumentID = reader["DocumentID"].ToString();
                    //list.DocGuid = reader["doc_guid"].ToString();
                    list.DocumentNumber = reader["DocumentNumber"].ToString();
                    list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                    list.CurrencyCode = reader["CurrencyCode"].ToString();
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.PlacesDescription = reader["PlacesDescription"].ToString();
                    list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                    list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                    list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                    list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                    list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                    list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                    list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                    list.InvoiceByer = reader["InvoiceByer"].ToString();
                    list.InvoiceSeller = reader["InvoiceSeller"].ToString();
                }
                reader.Close();

                string quer1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                var reader1 = Provider.RunQuery(quer1);
                var product = new List<GoodsModel>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new GoodsModel
                        {
                            GoodsCode = reader1["GoodsCode"].ToString(),
                        };
                        rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                        rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                        rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                        rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                        rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                        rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                        rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                        rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                        rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                        product.Add(rep1);
                        Origin = rep1.OriginCountryCode;
                    }
                    reader1.Close();
                }
                list.product = new List<GoodsModel>(product);
            }
            query = $"SELECT org_name FROM organizations WHERE org_code= '{list.InvoiceSeller}'";
            var org_sel = Provider.RunQueryStr(query);
            query = $"SELECT org_name FROM organizations WHERE org_code= '{list.InvoiceByer}'";
            var org_buy = Provider.RunQueryStr(query);
            string g01 = "UNB+UNOY:4+" + org_sel + "::HOST+" + org_buy + "+::HOST+" + sellers.attis_contract_date?.ToString("YYYYMMDD:HHMM") + "+KZ0006168++IFTMIN_27' \n";
            string g02 = "UNH+" + sellers.attis_contract_id + "+IFTMIN:D:97A:UN:OSJD'\n";
            string g03 = "BGM+722+" + "00000001" + "+9'\n";
            string g04 = "DTM+143:" + sellers.attis_contract_deadline?.ToString("YYYYMMDDHHMM") + ":203'\n";
            string g05 = "TSR++" + '1' + ":::2+3'\n"; //1-transporter, 4 - sender

            query = $"SELECT currency_a3_code FROM currencies WHERE currency_code='{sellers.attis_contract_currency}'";
            string curr = Provider.RunQueryStr(query);
            string g06 = "CUX+1:" + curr + "+7:" + curr + "'\n";
            string g07 = "MOA+132:" + list.GCost + ":" + curr + "'\n";
            string g08 = "MOA+133:28576:KZT'\n";
            string g09 = "FTX+RQR+++" + 27708507 + "'\n";  // перечисление кодов выходных (и входных) пограничных станций через знак «/»  по правилам СМГС
            string g10 = "FTX+HAN'\n"; // Признак безбумажной перевозки
            string g11 = "TOD+6++SD'\n";
            string g12 = "GOR+1+5'\n";    //1 exp 3-transit
            string g13 = "TDT+21++2'\n";  //2 -railw
            query = $"SELECT company_address FROM organizations WHERE org_code= '{list.InvoiceSeller}'";
            var sel_adr = Provider.RunQueryStr(query);
            query = $"SELECT org_residency FROM organizations WHERE org_code= '{list.InvoiceSeller}'";
            var sel_ctr = Provider.RunQueryStr(query);
            query = $"SELECT org_residency FROM organizations WHERE org_code= '{list.InvoiceByer}'";
            var buy_ctr = Provider.RunQueryStr(query);
            string g14 = "LOC+5+27700007:37:288:" + sel_adr + "+КЗХ'\n"; //sender adr
            string g15 = "LOC+8+27708507:37:288:" + sellers.attis_contract_delivery_place + "+КЗХ'\n";
            string g16 = "LOC+17+27708507:37:288:" + sellers.attis_contract_delivery_place + "'\n";
            string g17 = "NAD+CN+1234:Z01++Китай:::::RU+++++KZ'\n"; //Z00=другой,Z01=ТГНЛ,Z02=ОКПО,Z03=ЕЛС,Z04=ИНН
            string g18 = "NAD+CN+99999999:Z02'\n";
            string g19 = "NAD+CZ+1335:Z01++" + org_sel + ":::::" + sel_ctr + "+" + sel_adr + "+++KZ'\n";
            /*string g20 = "NAD+CZ+40818621:Z02'";
            string g21 = "NAD+GS+10001774/4654172:Z00++ФАО "АСТЫ? ТРАНС"+АО "КТЖ-ГП"+0027'";
            string g22 = "NAD+GS+52216258:Z02'";
            string g23 = "NAD+CA+0027:Z13++АО "КТЖ-ГП"'";*/
            string g24 = "LOC+32+27700007:37:288:" + sel_adr + "'\n"; //sender adr
            string g25 = "LOC+56+27708507:37:288:" + sellers.attis_contract_delivery_place + "'\n";
            string g26 = "TCC+" + list.TransportCharges + "'\n";  //taxes
            string g27 = "EQN+" + Origin + "'\n"; //code
            /*string g28 = "MOA+26:28576:KZT'";
            string g29 = "MOA+27:28576:KZT'";
            string g30 = "MOA+128:28576:KZT'";
            string g31 = "MOA+131:28576:KZT'";*/
            string g32 = "QTY+49:875:KMT'\n"; //way len
            string g33 = "CPI+17'\n"; // Расчет провозных платежей по разделу перевозчика
            string g34 = "RFF+CT:КЗХ:2'\n"; //КЗХ номер или наименование применяемого тарифа 
            string g35 = "GID+1'\n"; //Номер строки с наименованием груза
            string g36 = "LOC+35+" + sel_ctr + ":162'\n"; //sender country
            string g37 = "LOC+28+" + buy_ctr + ":162'\n"; //recv country
            string g38 = "", g40 = "", g41 = "", g43 = "";
            foreach (var ln in list.product)
            {
                g38 = g38 + "PIA+5+99220000:HS::" + ln.GoodMarking + "'\n"; //cargo no.
                //string g39 = "PIA+5+421034:ET::288'"; // 
                g40 = g40 + "FTX+AAA+++" + ln.GoodsDescription + "'\n";
                g41 = g41 + "FTX+IRP++06+" + ln.NetWeightQuantity + "'\n"; //weight
                //string g42 = "FTX+PRD+++Вагоны железнодорожные, перевозимые на своих осях, не поименованные в:алфавите. Аренда ООО "Trans Vagon Group" 1 вагон(а) из под - 017016'";
                g43 = g43 + "MEA+WT+G+KGM:" + ln.GrossWeightQuantity + "'\n";
            }
            //string g44 = "MEA+AAH+G+KGM'";
            string g45 = "EQD+RR+29005311++++4'\n"; //vagon no.
            //string g46 = "MEA+SV++TNE:68'"; //vagon cap.
            string g47 = "MEA+NAX++PCE:4'\n"; //vag axes
            //string g48 = "MEA+WT+T+KGM:25300'";
            //string g49 = "MEA+ASW+T+KGM:25300'";
            string g50 = "FTX+AAA++017016:ET:288+Рис нешелушеный (рис-сырец)'\n";
            string g51 = "NAD+CW+25/О:36:12++ООО " + "Trans Vagon Group" + "'\n"; //vagon owner
            string g52 = "UNT+51+KZ0006168'\n"; //Количество сегментов в электронном сообщении, проставляется конвертером
            string g53 = "UNZ+1+KZ0006168'\n"; //Количество электронных сообщений в партии передачи, проставляется конвертером

            var comp = g01 + g02 + g03 + g04 + g05 + g06 + g07 + g08 + g09 + g10 + g11 + g12 + g13 + g14 + g15 + g16 + g17 + g18 + g19 + g24 + g25 + g26 + g27 + g32
                + g33 + g34 + g35 + g36 + g37 + g38 + g40 + g41 + g43 + g45 + g47 + g50 + g51 + g52 + g53;
            byte[] byteArray = Encoding.UTF8.GetBytes(comp);
            MemoryStream file = new MemoryStream(byteArray);

            var imgFile = new ImageFile
            {
                ID = 0,
                EntityId = contract_id,
                Name = "ktg_" + contract_id + ".txt",
                Length = 1000,
                Type = "text",
                Date = DateTime.Now,
                Image = file,
                WidgetId = "ktz"
            };

            Provider.SaveFile(imgFile);

            var query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{contract_id}' and doc_widget_id ='ktz'";
            reader = Provider.RunQuery(query1);
            var files = new List<Kfiles>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep = new Kfiles
                    {
                        id = reader["id"].ToString(), //"/picture/getfile/"
                    };
                    rep.name = reader["img_file_name"].ToString();
                    files.Add(rep);
                }
                reader.Close();
                sellrs.files = new List<Kfiles>(files);
                sellrs.status = 200;
                sellrs.message = "";
            }
            string user = User.Identity.GetUserId();
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id) " +
            $"VALUES('NOW()', '{(int)LogContract.NewKtg}', '{LogContract.NewKtg}', '{LogSection.Contract}', '{user}', '{contract_id}');";
            Provider.RunNonQuery(query);
            return JsonConvert.SerializeObject(sellrs);
            //return "";
        }

        public string LoadKtgXml(string contract_id)
        {
            var qre1 = $"SELECT attis_contract_doc_id FROM attis_contract_docs WHERE attis_contract_doc_type=1 AND attis_contract_doc_contract = '{contract_id}'";
            var tt = Provider.RunScalar(qre1);

            var sellrs = new Ktgres();
            sellrs.status = 500;
            sellrs.message = "Не хватает данных";
            if (tt < 0)
                return JsonConvert.SerializeObject(sellrs);
            var query = $"SELECT * FROM attis_contracts WHERE attis_contract_id = '{contract_id}';";
            var reader = Provider.RunQuery(query);
            var sellers = new Sellers();
            if (reader != null)
            {
                while (reader.Read())
                {
                    sellers.attis_contract_id = int.Parse(contract_id);
                    sellers.attis_contract_owner = reader["attis_contract_owner"].ToString();
                    sellers.attis_contract_status = reader["attis_contract_status"].ToString();
                    sellers.attis_contract_type = (int)reader["attis_contract_type"] != 0;
                    sellers.attis_contract_case = (int)reader["attis_contract_case"] != 0;
                    sellers.attis_contract_subject = reader["attis_contract_subject"].ToString();
                    sellers.attis_contract_desc = reader["attis_contract_desc"].ToString();
                    sellers.attis_contract_currency = reader["attis_contract_currency"].ToString();
                    sellers.attis_contract_payment_type = reader["attis_contract_payment_type"].ToString();
                    sellers.attis_contract_delivery_term = reader["attis_contract_delivery_term"].ToString();
                    sellers.attis_contract_delivery_place = reader["attis_contract_delivery_place"].ToString();
                    sellers.attis_contract_date = GetDateTimeFromString(reader["attis_contract_date"].ToString());
                    sellers.attis_contract_deadline = GetDateTimeFromString(reader["attis_contract_deadline"].ToString());
                    sellers.attis_contract_create_date = GetDateTimeFromString(reader["attis_contract_create_date"].ToString());
                    sellers.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                    sellers.attis_contract_is_public = reader.GetFieldValueOrDefault<int>("attis_contract_is_public");
                    sellers.attis_contract_kpveds = reader["attis_contract_kpveds"].ToString();
                }
                reader.Close();
            }
            query = $"SELECT * FROM \"Invoice\" WHERE \"RefDocumentID\" = {tt};";
            reader = Provider.RunQuery(query);
            var list = new DocModel();
            var Origin = "KZ";
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.DocumentID = reader["DocumentID"].ToString();
                    //list.DocGuid = reader["doc_guid"].ToString();
                    list.DocumentNumber = reader["DocumentNumber"].ToString();
                    list.DocumentDate = GetDateTimeFromString(reader["DocumentDate"].ToString());
                    list.CurrencyCode = reader["CurrencyCode"].ToString();
                    list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                    list.PlacesDescription = reader["PlacesDescription"].ToString();
                    list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                    list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                    list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                    list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                    list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                    list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                    list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                    list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                    list.InvoiceByer = reader["InvoiceByer"].ToString();
                    list.InvoiceSeller = reader["InvoiceSeller"].ToString();
                }
                reader.Close();

                string quer1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                var reader1 = Provider.RunQuery(quer1);
                var product = new List<GoodsModel>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new GoodsModel
                        {
                            GoodsCode = reader1["GoodsCode"].ToString(),
                        };
                        rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                        rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                        rep1.GoodMarking = reader1["GoodMarking"].ToString();
                        rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                        rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                        rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                        rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                        rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                        rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                        rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                        rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                        rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                        rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                        product.Add(rep1);
                        Origin = rep1.OriginCountryCode;
                    }
                    reader1.Close();
                }
                list.product = new List<GoodsModel>(product);
            }
            query = $"SELECT org_name FROM organizations WHERE org_code= '{list.InvoiceSeller}'";
            var org_sel = Provider.RunQueryStr(query);
            query = $"SELECT org_name FROM organizations WHERE org_code= '{list.InvoiceByer}'";
            var org_buy = Provider.RunQueryStr(query);
            string g01 = "UNB+UNOY:4+" + org_sel + "::HOST+" + org_buy + "+::HOST+" + sellers.attis_contract_date?.ToString("YYYYMMDD:HHMM") + "+KZ0006168++IFTMIN_27' \n";
            string g02 = "UNH+" + sellers.attis_contract_id + "+IFTMIN:D:97A:UN:OSJD'\n";
            string g03 = "BGM+722+" + "00000001" + "+9'\n";
            string g04 = "DTM+143:" + sellers.attis_contract_deadline?.ToString("YYYYMMDDHHMM") + ":203'\n";
            string g05 = "TSR++" + '1' + ":::2+3'\n"; //1-transporter, 4 - sender

            query = $"SELECT currency_a3_code FROM currencies WHERE currency_code='{sellers.attis_contract_currency}'";
            string curr = Provider.RunQueryStr(query);
            string g06 = "CUX+1:" + curr + "+7:" + curr + "'\n";
            string g07 = "MOA+132:" + list.GCost + ":" + curr + "'\n";
            string g08 = "MOA+133:28576:KZT'\n";
            string g09 = "FTX+RQR+++" + 27708507 + "'\n";  // перечисление кодов выходных (и входных) пограничных станций через знак «/»  по правилам СМГС
            string g10 = "FTX+HAN'\n"; // Признак безбумажной перевозки
            string g11 = "TOD+6++SD'\n";
            string g12 = "GOR+1+5'\n";    //1 exp 3-transit
            string g13 = "TDT+21++2'\n";  //2 -railw
            query = $"SELECT company_address FROM organizations WHERE org_code= '{list.InvoiceSeller}'";
            var sel_adr = Provider.RunQueryStr(query);
            query = $"SELECT org_residency FROM organizations WHERE org_code= '{list.InvoiceSeller}'";
            var sel_ctr = Provider.RunQueryStr(query);
            query = $"SELECT org_residency FROM organizations WHERE org_code= '{list.InvoiceByer}'";
            var buy_ctr = Provider.RunQueryStr(query);
            string g14 = "LOC+5+27700007:37:288:" + sel_adr + "+КЗХ'\n"; //sender adr
            string g15 = "LOC+8+27708507:37:288:" + sellers.attis_contract_delivery_place + "+КЗХ'\n";
            string g16 = "LOC+17+27708507:37:288:" + sellers.attis_contract_delivery_place + "'\n";
            string g17 = "NAD+CN+1234:Z01++Китай:::::RU+++++KZ'\n"; //Z00=другой,Z01=ТГНЛ,Z02=ОКПО,Z03=ЕЛС,Z04=ИНН
            string g18 = "NAD+CN+99999999:Z02'\n";
            string g19 = "NAD+CZ+1335:Z01++" + org_sel + ":::::" + sel_ctr + "+" + sel_adr + "+++KZ'\n";
            /*string g20 = "NAD+CZ+40818621:Z02'";
            string g21 = "NAD+GS+10001774/4654172:Z00++ФАО "АСТЫ? ТРАНС"+АО "КТЖ-ГП"+0027'";
            string g22 = "NAD+GS+52216258:Z02'";
            string g23 = "NAD+CA+0027:Z13++АО "КТЖ-ГП"'";*/
            string g24 = "LOC+32+27700007:37:288:" + sel_adr + "'\n"; //sender adr
            string g25 = "LOC+56+27708507:37:288:" + sellers.attis_contract_delivery_place + "'\n";
            string g26 = "TCC+" + list.TransportCharges + "'\n";  //taxes
            string g27 = "EQN+" + Origin + "'\n"; //code
            /*string g28 = "MOA+26:28576:KZT'";
            string g29 = "MOA+27:28576:KZT'";
            string g30 = "MOA+128:28576:KZT'";
            string g31 = "MOA+131:28576:KZT'";*/
            string g32 = "QTY+49:875:KMT'\n"; //way len
            string g33 = "CPI+17'\n"; // Расчет провозных платежей по разделу перевозчика
            string g34 = "RFF+CT:КЗХ:2'\n"; //КЗХ номер или наименование применяемого тарифа 
            string g35 = "GID+1'\n"; //Номер строки с наименованием груза
            string g36 = "LOC+35+" + sel_ctr + ":162'\n"; //sender country
            string g37 = "LOC+28+" + buy_ctr + ":162'\n"; //recv country
            string g38 = "", g40 = "", g41 = "", g43 = "";
            foreach (var ln in list.product)
            {
                g38 = g38 + "PIA+5+99220000:HS::" + ln.GoodMarking + "'\n"; //cargo no.
                //string g39 = "PIA+5+421034:ET::288'"; // 
                g40 = g40 + "FTX+AAA+++" + ln.GoodsDescription + "'\n";
                g41 = g41 + "FTX+IRP++06+" + ln.NetWeightQuantity + "'\n"; //weight
                //string g42 = "FTX+PRD+++Вагоны железнодорожные, перевозимые на своих осях, не поименованные в:алфавите. Аренда ООО "Trans Vagon Group" 1 вагон(а) из под - 017016'";
                g43 = g43 + "MEA+WT+G+KGM:" + ln.GrossWeightQuantity + "'\n";
            }
            //string g44 = "MEA+AAH+G+KGM'";
            string g45 = "EQD+RR+29005311++++4'\n"; //vagon no.
            //string g46 = "MEA+SV++TNE:68'"; //vagon cap.
            string g47 = "MEA+NAX++PCE:4'\n"; //vag axes
            //string g48 = "MEA+WT+T+KGM:25300'";
            //string g49 = "MEA+ASW+T+KGM:25300'";
            string g50 = "FTX+AAA++017016:ET:288+Рис нешелушеный (рис-сырец)'\n";
            string g51 = "NAD+CW+25/О:36:12++ООО " + "Trans Vagon Group" + "'\n"; //vagon owner
            string g52 = "UNT+51+KZ0006168'\n"; //Количество сегментов в электронном сообщении, проставляется конвертером
            string g53 = "UNZ+1+KZ0006168'\n"; //Количество электронных сообщений в партии передачи, проставляется конвертером

            var comp = g01 + g02 + g03 + g04 + g05 + g06 + g07 + g08 + g09 + g10 + g11 + g12 + g13 + g14 + g15 + g16 + g17 + g18 + g19 + g24 + g25 + g26 + g27 + g32
                + g33 + g34 + g35 + g36 + g37 + g38 + g40 + g41 + g43 + g45 + g47 + g50 + g51 + g52 + g53;

            XmlSerializer xsSubmit = new XmlSerializer(typeof(string));
            var xml = "";

            using (var sww = new StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(sww))
                {
                    xsSubmit.Serialize(writer, comp);
                    xml = sww.ToString(); // Your XML
                }
            }
            return xml;
            //return "";
        }

        [HttpPost]
        public JsonResult Copy(string id)
        {
            string user = User.Identity.GetUserId();
            if (user == null) return Json("login first");


            var query = $"SELECT * FROM attis_contracts where attis_contract_id = '{id}';";
            var reader = Provider.RunQuery(query);
            Sellers seller; new Sellers();
            if (reader.Read())
            {
                seller = new Sellers
                {
                    attis_contract_id = int.Parse(id),
                    attis_contract_owner = reader["attis_contract_owner"].ToString(),
                    attis_contract_status = reader["attis_contract_status"].ToString(),
                    attis_contract_type = (int)reader["attis_contract_type"] != 0,
                    attis_contract_case = (int)reader["attis_contract_case"] != 0,
                    attis_contract_subject = reader["attis_contract_subject"].ToString(),
                    attis_contract_desc = reader["attis_contract_desc"].ToString(),
                    attis_contract_currency = reader["attis_contract_currency"].ToString(),
                    attis_contract_payment_type = reader["attis_contract_payment_type"].ToString(),
                    attis_contract_delivery_term = reader["attis_contract_delivery_term"].ToString(),
                    attis_contract_delivery_place = reader["attis_contract_delivery_place"].ToString(),
                    attis_contract_date = GetDateTimeFromString(reader["attis_contract_date"].ToString()),
                    attis_contract_deadline = GetDateTimeFromString(reader["attis_contract_deadline"].ToString()),
                    attis_contract_create_date = GetDateTimeFromString(reader["attis_contract_create_date"].ToString()),
                    attis_contract_contragent = reader["attis_contract_contragent"].ToString(),
                    attis_contract_is_public = reader.GetFieldValueOrDefault<int>("attis_contract_is_public"),
                    attis_contract_kpveds = reader["attis_contract_kpveds"].ToString(),
                    grace_period = reader.GetFieldValueOrDefault<int>("grace_period"),
                    payment_date = GetDateTimeFromString(reader["payment_date"].ToString()),
                    advance_payment = reader.GetFieldValueOrDefault<float>("advance_payment"),
                    delay_days = reader.GetFieldValueOrDefault<int>("delay_days"),
                    language = reader["language"].ToString(),
                    overdue = reader.GetFieldValueOrDefault<float>("overdue"),
                    packaging_transport_fees_included = reader.GetFieldValueOrDefault<int>("packaging_transport_fees_included"),
                    goods_origin_country = reader["goods_origin_country"].ToString(),
                    point_of_departure = reader["point_of_departure"].ToString(),
                    destination_point = reader["destination_point"].ToString(),
                    days_to_change_price = reader.GetFieldValueOrDefault<int>("days_to_change_price"),
                    prepayment_percent = reader.GetFieldValueOrDefault<float>("prepayment_percent"),
                    number_of_days_for_prepayment = reader.GetFieldValueOrDefault<int>("number_of_days_for_prepayment"),
                    number_of_days_for_fullpayment = reader.GetFieldValueOrDefault<int>("number_of_days_for_fullpayment"),
                    overdue_term = reader.GetFieldValueOrDefault<int>("overdue_term"),
                    shipping_term = reader.GetFieldValueOrDefault<int>("shipping_term"),
                    total_delivery_time = reader.GetFieldValueOrDefault<int>("total_delivery_time"),
                    days_to_receive_goods = reader.GetFieldValueOrDefault<int>("days_to_receive_goods"),
                    days_to_quality_receive_goods = reader.GetFieldValueOrDefault<int>("days_to_quality_receive_goods"),
                    transfer_of_ownership = reader.GetFieldValueOrDefault<int>("transfer_of_ownership"),
                    guaranty_term = reader.GetFieldValueOrDefault<int>("guaranty_term"),
                    exceeding_guaranty_term = reader.GetFieldValueOrDefault<int>("exceeding_guaranty_term"),
                    payment_overdue = reader.GetFieldValueOrDefault<float>("payment_overdue"),
                    shipping_overdue = reader.GetFieldValueOrDefault<float>("shipping_overdue"),
                    decline_due_to_overdue = reader.GetFieldValueOrDefault<float>("decline_due_to_overdue"),
                    legal_country = reader["legal_country"].ToString(),
                    arbitrage_country = reader["arbitrage_country"].ToString(),
                    contract_language = reader["contract_language"].ToString(),
                    contract_term = GetDateTimeFromString(reader["contract_term"].ToString()),
                    notification_term = reader.GetFieldValueOrDefault<int>("notification_term"),
                    cancel_term = reader.GetFieldValueOrDefault<int>("cancel_term"),
                    consent_term = reader.GetFieldValueOrDefault<int>("consent_term"),
                    inform_term = reader.GetFieldValueOrDefault<int>("inform_term"),
                    location_term = reader.GetFieldValueOrDefault<int>("location_term"),
            };
                reader.Close();

                var query1 = $"SELECT attis_cg_good_name, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price, origin FROM attis_contract_goods WHERE attis_cg_contract_id = '{id}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<Product>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new Product
                        {
                            attis_cg_good_name = reader1["attis_cg_good_name"].ToString(),
                        };
                        rep1.attis_cg_TNVED = reader1["attis_cg_TNVED"].ToString();
                        rep1.attis_cg_quantity = reader1["attis_cg_quantity"].ToString();
                        rep1.attis_cg_measures = reader1["attis_cg_measures"].ToString();
                        rep1.attis_cg_price = reader1["attis_cg_price"].ToString();
                        rep1.origin_country = reader1["origin"].ToString();
                        product.Add(rep1);
                    }
                    reader1.Close();
                }

                query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{id}' and doc_widget_id ='ktz'";
                reader = Provider.RunQuery(query1);
                var files = new List<Kfiles>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        rep.name = reader["img_file_name"].ToString();
                        files.Add(rep);
                    }
                    reader.Close();
                }
                seller.product = new List<Product>(product);
                seller.files = new List<Kfiles>(files);
                //var settings = new JsonSerializerSettings
                //{
                //    DateFormatString = "yyyy-MM-dd",
                //    DateTimeZoneHandling = DateTimeZoneHandling.Utc
                //};

                int typ = seller.attis_contract_type ? 1 : 0;
                int cas = seller.attis_contract_case ? 1 : 0;
                string bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"), 
                    dd = DateTime.Now.ToString("yyyy.MM.dd"), ee = DateTime.Now.ToString("yyyy.MM.dd");
                if (seller.attis_contract_date != null)
                    bb = seller.attis_contract_date?.ToString("yyyy.MM.dd");
                if (seller.attis_contract_deadline != null)
                    cc = seller.attis_contract_deadline?.ToString("yyyy.MM.dd");
                if (seller.payment_date != null)
                    dd = seller.payment_date?.ToString("yyyy.MM.dd");
                if (seller.contract_term != null)
                    ee = seller.contract_term?.ToString("yyyy.MM.dd");
                //if (attis_contract_is_public == 1) sell.attis_contract_is_public = true; else sell.attis_contract_is_public = false;
                query = $"INSERT INTO attis_contracts (attis_contract_owner, attis_contract_status, attis_contract_type, attis_contract_case, attis_contract_is_public," +
                    $" attis_contract_subject, attis_contract_desc, attis_contract_currency, attis_contract_delivery_term, attis_contract_delivery_place," +
                    $" attis_contract_date, attis_contract_payment_type, attis_contract_deadline, language, attis_contract_create_date, " +
                    $"attis_contract_contragent, attis_contract_kpveds, grace_period, payment_date, advance_payment, delay_days, overdue, packaging_transport_fees_included, goods_origin_country, " +
                    $" point_of_departure, destination_point, days_to_change_price, prepayment_percent, number_of_days_for_prepayment, number_of_days_for_fullpayment," +
                    $" overdue_term, shipping_term, total_delivery_time, days_to_receive_goods, days_to_quality_receive_goods, transfer_of_ownership, guaranty_term, " +
                    $"exceeding_guaranty_term, payment_overdue, shipping_overdue, decline_due_to_overdue, legal_country, arbitrage_country, contract_language, " +
                    $"contract_term, notification_term, cancel_term, consent_term, inform_term, location_term)" +
                    $" VALUES ('{user}', '{seller.attis_contract_status}', '{typ}', '{cas}', '{seller.attis_contract_is_public}'," +
                    $" '{seller.attis_contract_subject}', '{seller.attis_contract_desc}', '{seller.attis_contract_currency}', '{seller.attis_contract_delivery_term}'," +
                    $" '{seller.attis_contract_delivery_place}', '{bb}', '{seller.attis_contract_payment_type}'," +
                    $" '{cc}', '{seller.language}', now(), '{seller.attis_contract_contragent}', '{seller.attis_contract_kpveds}', " +
                    $"{seller.grace_period.GetValueOrDefault()}, '{dd}', {seller.advance_payment.GetValueOrDefault()}, {seller.delay_days.GetValueOrDefault()}, " +
                        $"{seller.overdue.GetValueOrDefault()}, {seller.packaging_transport_fees_included.GetValueOrDefault()}, '{seller.goods_origin_country}'," +
                        $"'{seller.point_of_departure}', '{seller.destination_point}', {seller.days_to_change_price.GetValueOrDefault()}," +
                        $"{seller.prepayment_percent.GetValueOrDefault()}, {seller.number_of_days_for_prepayment.GetValueOrDefault()}, {seller.number_of_days_for_fullpayment.GetValueOrDefault()}," +
                        $"{seller.overdue_term.GetValueOrDefault()}, {seller.shipping_term.GetValueOrDefault()}, {seller.total_delivery_time.GetValueOrDefault()}, {seller.days_to_receive_goods.GetValueOrDefault()}," +
                        $"{seller.days_to_quality_receive_goods.GetValueOrDefault()}, {seller.transfer_of_ownership.GetValueOrDefault()}, {seller.guaranty_term.GetValueOrDefault()}, " +
                        $"{seller.exceeding_guaranty_term.GetValueOrDefault()}, {seller.payment_overdue.GetValueOrDefault()}, {seller.shipping_overdue.GetValueOrDefault()}, {seller.decline_due_to_overdue.GetValueOrDefault()}," +
                        $" '{seller.legal_country}', '{seller.arbitrage_country}', '{seller.contract_language}', '{ee}', {seller.notification_term.GetValueOrDefault()}," +
                        $"{seller.cancel_term.GetValueOrDefault()}, {seller.consent_term.GetValueOrDefault()}, {seller.inform_term.GetValueOrDefault()}, {seller.location_term.GetValueOrDefault()}) RETURNING attis_contract_id;";
                var newId = Provider.RunScalar(query); // '{sell.attis_contract_contragent}',
                if (seller.product != null)
                {
                    foreach (var ln in seller.product)
                    {
                        query = $"INSERT INTO attis_contract_goods (attis_cg_contract_id, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price, origin) " +
                        $"VALUES('{newId}', '{ln.attis_cg_good_name}', '{ln.attis_cg_TNVED}', '{ln.attis_cg_quantity}', '{ln.attis_cg_measures}', '{ln.attis_cg_price}', '{ln.origin_country}');";
                        Provider.RunNonQuery(query);
                    }
                }
                if (newId > 0)
                {
                    query = $"INSERT INTO docimages (doc_guid, img_file_name, doc_img_status, doc_img_date, doc_img_scan, doc_widget_id) SELECT '{newId}', img_file_name, doc_img_status, doc_img_date, doc_img_scan, doc_widget_id " +
                    $"FROM docimages WHERE doc_guid = '{id}';";
                    Provider.RunNonQuery(query);
                }

            }
            return Json("ok");


        }

        [HttpPost]
        public JsonResult Add(Sellers sell)
        {
            string user = User.Identity.GetUserId();
            try
            {
                if (user == null) return Json("login first");
                int typ = sell.attis_contract_type ? 1 : 0;
                int cas = sell.attis_contract_case ? 1 : 0;
                string ee= DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"), dd = DateTime.Now.ToString("yyyy.MM.dd");
                if (sell.attis_contract_date != null)
                    bb = sell.attis_contract_date?.ToString("yyyy.MM.dd");
                if (sell.attis_contract_deadline != null)
                    cc = sell.attis_contract_deadline?.ToString("yyyy.MM.dd");
                if (sell.payment_date != null)
                    dd = sell.payment_date?.ToString("yyyy.MM.dd");
                if (sell.contract_term != null)
                    ee = sell.contract_term?.ToString("yyyy.MM.dd");
                //if (attis_contract_is_public == 1) sell.attis_contract_is_public = true; else sell.attis_contract_is_public = false;
                var query = $"INSERT INTO attis_contracts (attis_contract_owner, attis_contract_status, attis_contract_type, attis_contract_case, attis_contract_is_public," +
                    $" attis_contract_subject, attis_contract_desc, attis_contract_currency, attis_contract_delivery_term, attis_contract_delivery_place," +
                    $" attis_contract_date, attis_contract_payment_type, attis_contract_deadline, language, attis_contract_create_date, attis_contract_contragent," +
                    $" attis_contract_kpveds, grace_period, payment_date, advance_payment, delay_days, overdue, packaging_transport_fees_included, goods_origin_country, " +
                    $" point_of_departure, destination_point, days_to_change_price, prepayment_percent, number_of_days_for_prepayment, number_of_days_for_fullpayment," +
                    $" overdue_term, shipping_term, total_delivery_time, days_to_receive_goods, days_to_quality_receive_goods, transfer_of_ownership, guaranty_term, " +
                    $"exceeding_guaranty_term, payment_overdue, shipping_overdue, decline_due_to_overdue, legal_country, arbitrage_country, contract_language, " +
                    $"contract_term, notification_term, cancel_term, consent_term, inform_term, location_term)" +
                    $" VALUES ('{user}', '{sell.attis_contract_status}', '{typ}', '{cas}', '{sell.attis_contract_is_public}'," +
                    $" '{sell.attis_contract_subject}', '{sell.attis_contract_desc}', '{sell.attis_contract_currency}', '{sell.attis_contract_delivery_term}'," +
                    $" '{sell.attis_contract_delivery_place}', '{bb}', '{sell.attis_contract_payment_type}'," +
                    $" '{cc}', '{sell.language}', now(), '{sell.attis_contract_contragent}', '{sell.attis_contract_kpveds}'," +
                    $" {sell.grace_period.GetValueOrDefault()}, '{dd}', {sell.advance_payment.GetValueOrDefault()}, {sell.delay_days.GetValueOrDefault()}, " +
                    $"{sell.overdue.GetValueOrDefault()}, {sell.packaging_transport_fees_included.GetValueOrDefault()}, '{sell.goods_origin_country}'," +
                    $"'{sell.point_of_departure}', '{sell.destination_point}', {sell.days_to_change_price.GetValueOrDefault()}," +
                    $"{sell.prepayment_percent.GetValueOrDefault()}, {sell.number_of_days_for_prepayment.GetValueOrDefault()}, {sell.number_of_days_for_fullpayment.GetValueOrDefault()}," +
                    $"{sell.overdue_term.GetValueOrDefault()}, {sell.shipping_term.GetValueOrDefault()}, {sell.total_delivery_time.GetValueOrDefault()}, {sell.days_to_receive_goods.GetValueOrDefault()}," +
                    $"{sell.days_to_quality_receive_goods.GetValueOrDefault()}, {sell.transfer_of_ownership.GetValueOrDefault()}, {sell.guaranty_term.GetValueOrDefault()}, " +
                    $"{sell.exceeding_guaranty_term.GetValueOrDefault()}, {sell.payment_overdue.GetValueOrDefault()}, {sell.shipping_overdue.GetValueOrDefault()}, {sell.decline_due_to_overdue.GetValueOrDefault()}," +
                    $" '{sell.legal_country}', '{sell.arbitrage_country}', '{sell.contract_language}', '{ee}', {sell.notification_term.GetValueOrDefault()}," +
                    $" {sell.cancel_term.GetValueOrDefault()}, {sell.consent_term.GetValueOrDefault()}, {sell.inform_term.GetValueOrDefault()}, {sell.location_term.GetValueOrDefault()}) RETURNING attis_contract_id;";
                var contr = Provider.RunScalar(query); // '{sell.attis_contract_contragent}',
                
                if (contr > 0)
                {
                    if (sell.product != null)
                        foreach (var ln in sell.product)
                        {
                            query = $"INSERT INTO attis_contract_goods (attis_cg_contract_id, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price, origin) " +
                            $"VALUES('{contr}', '{ln.attis_cg_good_name}', '{ln.attis_cg_TNVED}', '{ln.attis_cg_quantity}', '{ln.attis_cg_measures}', '{ln.attis_cg_price}', '{ln.origin_country}');";
                            Provider.RunNonQuery(query);
                        }

                    var r = new List<ImageFile>();

                    foreach (string fil in Request.Files)
                    {
                        var hpf = Request.Files[fil];
                        if (hpf.ContentLength == 0)
                            continue;

                        // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                        // hpf.SaveAs(savedFileName);
                        var imgFile = new ImageFile
                        {
                            ID = 0,
                            EntityId = contr.ToString(),
                            Name = hpf.FileName,
                            Length = hpf.ContentLength,
                            Type = hpf.ContentType,
                            Date = DateTime.Now,
                            Image = new MemoryStream(),
                            WidgetId = "ktz"
                        };

                        hpf.InputStream.CopyTo(imgFile.Image);

                        Provider.SaveFile(imgFile);

                        r.Add(imgFile);
                    }
                    log.Info("new contract " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogContract.NewContract}', '{LogContract.NewContract}', '{LogSection.Contract}', '{user}', '{contr}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return Json("ok");
                }
                else {
                    var err = Provider.lastError;
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogContract.NewContract}', '{LogContract.NewContract}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return Json("error"+err + contr);
                }
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                    $"VALUES('NOW()', '{(int)LogContract.NewContract}', '{LogContract.NewContract}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return Json("error");
            }
            

        }

        [HttpPost]
        public JsonResult Update(Sellers sell)
        {
            string user = User.Identity.GetUserId();
            try
            {
                var response = Request["attis_contract_id"];
                if (user == null) return Json("login first");
                string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{response}'";
                /*string cmp = Provider.RunQueryStr(query);
                if (cmp != user)
                {
                    return Json("Unauthorized");
                }
                else*/
                var r = new List<ImageFile>();

                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = response,
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "ktz"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }

                {
                    int typ = sell.attis_contract_type ? 1 : 0;
                    int cas = sell.attis_contract_case ? 1 : 0;
                    string ee = DateTime.Now.ToString("yyyy.MM.dd"), bb = DateTime.Now.ToString("yyyy.MM.dd"), cc = DateTime.Now.ToString("yyyy.MM.dd"), dd = DateTime.Now.ToString("yyyy.MM.dd");
                    if (sell.attis_contract_date != null)
                        bb = sell.attis_contract_date?.ToString("yyyy.MM.dd");
                    if (sell.attis_contract_deadline != null)
                        cc = sell.attis_contract_deadline?.ToString("yyyy.MM.dd");
                    if (sell.payment_date != null)
                        dd = sell.payment_date?.ToString("yyyy.MM.dd");
                    if (sell.contract_term != null)
                        ee = sell.contract_term?.ToString("yyyy.MM.dd");
                    //if (attis_contract_is_public == 1) sell.attis_contract_is_public = true; else sell.attis_contract_is_public = false;
                    query = $"UPDATE attis_contracts SET(attis_contract_type, attis_contract_case, attis_contract_is_public," +
                        $" attis_contract_subject, attis_contract_desc, attis_contract_currency, attis_contract_delivery_term, attis_contract_delivery_place, " +
                        $" attis_contract_date, attis_contract_payment_type, attis_contract_deadline, language, attis_contract_create_date, " +
                        $"attis_contract_contragent, attis_contract_kpveds, grace_period, payment_date, advance_payment, delay_days, overdue, packaging_transport_fees_included, goods_origin_country, " +
                    $" point_of_departure, destination_point, days_to_change_price, prepayment_percent, number_of_days_for_prepayment, number_of_days_for_fullpayment," +
                    $" overdue_term, shipping_term, total_delivery_time, days_to_receive_goods, days_to_quality_receive_goods, transfer_of_ownership, guaranty_term, " +
                    $"exceeding_guaranty_term, payment_overdue, shipping_overdue, decline_due_to_overdue, legal_country, arbitrage_country, contract_language, " +
                    $"contract_term, notification_term, cancel_term, consent_term, inform_term, location_term)" +
                        $" = ('{typ}', '{cas}', '{sell.attis_contract_is_public}'," +
                        $" '{sell.attis_contract_subject}', '{sell.attis_contract_desc}', '{sell.attis_contract_currency}', '{sell.attis_contract_delivery_term}'," +
                        $" '{sell.attis_contract_delivery_place}', '{bb}', '{sell.attis_contract_payment_type}'," +
                        $" '{cc}', '{sell.language}', now(), '{sell.attis_contract_contragent}', '{sell.attis_contract_kpveds}', " +
                        $"{sell.grace_period.GetValueOrDefault()}, '{dd}', {sell.advance_payment.GetValueOrDefault()}, {sell.delay_days.GetValueOrDefault()}, " +
                        $"{sell.overdue.GetValueOrDefault()}, {sell.packaging_transport_fees_included.GetValueOrDefault()}, '{sell.goods_origin_country}'," +
                        $"'{sell.point_of_departure}', '{sell.destination_point}', {sell.days_to_change_price.GetValueOrDefault()}," +
                        $"{sell.prepayment_percent.GetValueOrDefault()}, {sell.number_of_days_for_prepayment.GetValueOrDefault()}, {sell.number_of_days_for_fullpayment.GetValueOrDefault()}," +
                        $"{sell.overdue_term.GetValueOrDefault()}, {sell.shipping_term.GetValueOrDefault()}, {sell.total_delivery_time.GetValueOrDefault()}, {sell.days_to_receive_goods.GetValueOrDefault()}," +
                        $"{sell.days_to_quality_receive_goods.GetValueOrDefault()}, {sell.transfer_of_ownership.GetValueOrDefault()}, {sell.guaranty_term.GetValueOrDefault()}, " +
                        $"{sell.exceeding_guaranty_term.GetValueOrDefault()}, {sell.payment_overdue.GetValueOrDefault()}, {sell.shipping_overdue.GetValueOrDefault()}, {sell.decline_due_to_overdue.GetValueOrDefault()}," +
                        $" '{sell.legal_country}', '{sell.arbitrage_country}', '{sell.contract_language}', '{ee}', {sell.notification_term.GetValueOrDefault()}," +
                        $"{sell.cancel_term.GetValueOrDefault()}, {sell.consent_term.GetValueOrDefault()}, {sell.inform_term.GetValueOrDefault()}, {sell.location_term.GetValueOrDefault()}) WHERE attis_contract_id = '{response}';";
                    var contr = Provider.RunScalar(query); // '{sell.attis_contract_contragent}',
                    if (!Provider.lastError.IsEmpty())
                    {
                        query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.ContractUpdate}', '{LogContract.ContractUpdate}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                        Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    }
                    query = $"DELETE FROM attis_contract_goods WHERE attis_cg_contract_id='{response}'";
                    var del = Provider.RunScalar(query);
                    if (sell.product != null)
                        foreach (var ln in sell.product)
                        {
                            query = $"INSERT INTO attis_contract_goods (attis_cg_contract_id, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price, origin) " +
                            $"VALUES('{response}', '{ln.attis_cg_good_name}', '{ln.attis_cg_TNVED}', '{ln.attis_cg_quantity}', '{ln.attis_cg_measures}', '{ln.attis_cg_price}', '{ln.origin_country}');";
                            Provider.RunNonQuery(query);
                        }
                    log.Info("update contract " + user + JsonConvert.SerializeObject(sell));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.ContractUpdate}', '{LogContract.ContractUpdate}', '{LogSection.Contract}', '{user}', '{response}', '{JsonConvert.SerializeObject(sell)}', 0);";
                    Provider.RunNonQuery(query);
                    return Json("ok");
                }
            }
            catch(Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.ContractUpdate}', '{LogContract.ContractUpdate}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return Json("error");
            }
            
        }
        public string Delete(int id)
        {
            string user = User.Identity.GetUserId();
            try
            {
                /* todo org deletes
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_doc_contract={id}";
            string cmp = Provider.RunQueryStr(query);
            if (cmp != user)
                return "{\"status\":\"unauthorized\"}";*/
                var query = $"SELECT attis_contract_doc_type FROM attis_contract_docs WHERE attis_contract_doc_contract={id};";
                int typ = Provider.RunScalar(query);
                query = $"DELETE FROM attis_contract_docs WHERE attis_contract_doc_contract={id} RETURNING attis_contract_doc_id;";
                int ip = Provider.RunScalar(query);
                query = $"DELETE FROM attis_contract_goods WHERE attis_cg_contract_id={id}";
                Provider.RunNonQuery(query);
                query = $"DELETE FROM attis_contracts WHERE attis_contract_id={id}";
                Provider.RunNonQuery(query);

                if (!Provider.lastError.IsEmpty())
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogContract.ContractDelete}', '{LogContract.ContractDelete}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                }
                log.Info("delete contract " + user + JsonConvert.SerializeObject(id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.ContractDelete}', '{LogContract.ContractDelete}', '{LogSection.Contract}', '{user}', '{id}', '{JsonConvert.SerializeObject(id)}', 0);";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\"}";
            }
            catch(Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.ContractDelete}', '{LogContract.ContractDelete}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "{\"status\":\"error\"}";
            }
            
        }
        public class OfferModel
        {
            public int ID { get; set; }
            //public DateTime Date { get; set; }
            public string attis_contract_id { get; set; }
            //public string doc_guid { get; set; }
            //public string doc_name { get; set; }
            public string discount_percents { get; set; }
            public string name { get; set; }
            public string org_id { get; set; }
            public string discount_amount { get; set; }
            public string payment_type { get; set; }
            public string delivery_term { get; set; }
            public string contract_date { get; set; }
            public string offer { get; set; }
            public string shipping_cost { get; set; }
            public bool no_changes { get; set; }
            public bool can_show_chain { get; set; }
            public int status { get; set; }
            public string target_name { get; set; }
            public List<Kfiles> files { get; set; }
        }


        public class OfferGroup
        {
            public List<OfferModel> offers { get; set; }
        }

        public class InsuranceRequestGroup
        {
            public List<insurance_request> insurance_requests { get; set; }
            public bool is_insurer { get; set; }
        }
        public class OfferLst
        {
            public List<OfferModel> offers { get; set; }
            public List<Kfiles> files { get; set; }
        }
        public class OfferUser
        {
            public string id { get; set; }
            public string org_name { get; set; }
            public string org_code { get; set; }
        }
        public class OfferChange
        {
            public int ID { get; set; }
            public string attis_contract_offer_change_text { get; set; }
            public OfferUser attis_contract_offer_change_user { get; set; }
            public string attis_contract_offer_change_date { get; set; }
            public string shipping_cost { get; set; }

            public string attis_contract_offer_answer { get; set; }
            //public string attis_contract_offer_change_text { get; set; }

        }

        public class SearchModel
        {
            public int ID { get; set; }
            //public DateTime Date { get; set; }
            public int attis_contract_id { get; set; }
            public string contract_search_subj_country { get; set; }
            public string contract_search_subj_name { get; set; }
            public string contract_search_subj_contacts { get; set; }
            public string contract_search_subj_spheres { get; set; }
            public int attis_contract_offer_status { get; set; }
            //public string attis_contract_offer_change_text { get; set; }

        }
        /*
        contract_searches.contract_search_subj_subj_id
contract_searches.contract_search_subj_name
contract_searches.contract_search_subj_country
contract_searches.contract_search_subj_contacts
contract_searches.contract_search_subj_spheres*/

        private OfferGroup getOfferGroup(string query)
        {
            var reader = Provider.RunQuery(query);
            var offer = new List<OfferModel>();
            var list = new OfferGroup();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new OfferModel
                    {
                        offer = reader["offer"].ToString(),
                    };
                    rep1.ID = reader.GetFieldValueOrDefault<int>("attis_contract_offer_id");
                    rep1.attis_contract_id = reader["attis_contract_id"].ToString(); //reader.GetFieldValueOrDefault<int>("attis_contract_id");
                    rep1.discount_percents = reader["discount_percents"].ToString();
                    rep1.payment_type = reader["payment_type"].ToString();
                    rep1.delivery_term = reader["delivery_term"].ToString();
                    rep1.shipping_cost = reader["shipping_cost"].ToString();
                    rep1.discount_amount = reader["discount_amount"].ToString();
                    rep1.contract_date = reader["contract_date"].ToString();
                    rep1.name = reader["org_name"].ToString();
                    rep1.org_id = reader["org_id"].ToString();
                    rep1.no_changes = (bool)reader["no_changes"];
                    rep1.can_show_chain = (bool)reader["can_show_chain"];
                    rep1.status = rep1.status = reader.GetFieldValueOrDefault<int>("attis_contract_offer_status");
                    rep1.target_name = reader["target_name"].ToString();
                    //rep1.doc_guid = reader["doc_guid"].ToString();
                    //rep1.doc_name = reader["doc_name"].ToString();
                    //rep1.attis_contract_offer_change_text = reader["attis_contract_offer_change_text"].ToString();
                    offer.Add(rep1);
                }
                reader.Close();
                foreach (var item in offer)
                {
                    var query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{item.attis_contract_id}' and doc_widget_id ='offer'";
                    reader = Provider.RunQuery(query1);
                    var files = new List<Kfiles>();
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            var rep = new Kfiles
                            {
                                id = reader["id"].ToString(), //"/picture/getfile/"
                            };
                            rep.name = reader["img_file_name"].ToString();
                            files.Add(rep);
                        }
                        reader.Close();
                        item.files = new List<Kfiles>(files);
                    }
                }
                list.offers = new List<OfferModel>(offer);

            }
            return list;
        }
        public string getOffer(int attis_contract_id, string token)
        {
            lock (Provider.Locker) { 
                string user = User.Identity.GetUserId();
            var query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{attis_contract_id}'";
            var ck = Provider.RunQueryStr(query);// 
            if (ck == user)
                query = $"SELECT t1.*, t2.contract_search_subj_country, t2.contract_search_subj_name, t3.org_id, " +
                    $"t4.org_name, t7.org_name as target_name FROM attis_contract_offers t1 LEFT JOIN contract_searches t2 ON t1.attis_contract_id = t2.contract_search_contract" +
                    $" LEFT JOIN persons t3 ON t1.attis_contract_offer_subj = t3.user_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $" LEFT JOIN attis_contracts t5 on t5.attis_contract_id = '{attis_contract_id}'" +
                    $" LEFT JOIN persons t6 on t6.user_id = t5.attis_contract_owner" +
                    $" LEFT JOIN organizations t7 on t7.org_id = t6.org_id " +
                    $"WHERE t1.attis_contract_id = '{attis_contract_id}';";
            else query = $"SELECT t1.*, t2.contract_search_subj_country, t2.contract_search_subj_name, t3.org_id, " +
                $"t4.org_name, t7.org_name as target_name FROM attis_contract_offers t1 LEFT JOIN contract_searches t2 ON t1.attis_contract_id = t2.contract_search_contract" +
                $" LEFT JOIN persons t3 ON t1.attis_contract_offer_subj = t3.user_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                $" LEFT JOIN attis_contracts t5 on t5.attis_contract_id = '{attis_contract_id}'" +
                $" LEFT JOIN persons t6 on t6.user_id = t5.attis_contract_owner" +
                $" LEFT JOIN organizations t7 on t7.org_id = t6.org_id " +
                $"WHERE t1.attis_contract_offer_subj = '{user}' AND t1.attis_contract_id = '{attis_contract_id}';";
            var list = new OfferLst();

                var reader = Provider.RunQuery(query);

                var offer = new List<OfferModel>();

                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new OfferModel
                        {
                            offer = reader["offer"].ToString(),
                        };
                        rep1.ID = reader.GetFieldValueOrDefault<int>("attis_contract_offer_id");
                        rep1.attis_contract_id = reader["attis_contract_id"].ToString(); //reader.GetFieldValueOrDefault<int>("attis_contract_id");
                        rep1.discount_percents = reader["discount_percents"].ToString();
                        rep1.payment_type = reader["payment_type"].ToString();
                        rep1.delivery_term = reader["delivery_term"].ToString();
                        rep1.shipping_cost = reader["shipping_cost"].ToString();
                        rep1.discount_amount = reader["discount_amount"].ToString();
                        rep1.contract_date = reader["contract_date"].ToString();
                        rep1.name = reader["org_name"].ToString();
                        rep1.org_id = reader["org_id"].ToString();
                        rep1.no_changes = (bool)reader["no_changes"];
                        rep1.can_show_chain = (bool)reader["can_show_chain"];
                        rep1.status = rep1.status = reader.GetFieldValueOrDefault<int>("attis_contract_offer_status");
                        rep1.target_name = reader["target_name"].ToString();
                        //rep1.doc_guid = reader["doc_guid"].ToString();
                        //rep1.doc_name = reader["doc_name"].ToString();
                        //rep1.attis_contract_offer_change_text = reader["attis_contract_offer_change_text"].ToString();
                        offer.Add(rep1);
                    }
                    reader.Close();
                    list.offers = new List<OfferModel>(offer);
                    var query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{attis_contract_id}' and doc_widget_id ='offer'";
                    reader = Provider.RunQuery(query1);
                    var files = new List<Kfiles>();
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            var rep = new Kfiles
                            {
                                id = reader["id"].ToString(), //"/picture/getfile/"
                            };
                            rep.name = reader["img_file_name"].ToString();
                            files.Add(rep);
                        }
                        reader.Close();
                        list.files = new List<Kfiles>(files);
                    }
                    foreach(var obj in list.offers)
                    {
                        obj.files = list.files;
                    }

                }
                return JsonConvert.SerializeObject(list);
            }
        }
        public string CheckOfferAccepted(int attis_contract_id)
        {
            var query = $"SELECT t1.*, t2.contract_search_subj_country, t2.contract_search_subj_name, t3.org_id, " +
                    $"t4.org_name FROM attis_contract_offers t1 LEFT JOIN contract_searches t2 ON t1.attis_contract_id = t2.contract_search_contract" +
                    $" LEFT JOIN persons t3 ON t1.attis_contract_offer_subj = t3.user_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $"WHERE t1.attis_contract_id = '{attis_contract_id}' and t1.attis_contract_offer_status = 1;";
            var reader = Provider.RunQuery(query);
            var status = 0;
            if (reader != null)
            {
                while (reader.Read())
                {
                    status = 1;
                }
                reader.Close();
            }
            return JsonConvert.SerializeObject(status);
        }
        public class Offer
        {
            public int offer_id { get; set; }
            public int attis_contract_id { get; set; }
            public string discount_percents { get; set; }
            public string discount_amount { get; set; }
            public string payment_type { get; set; }
            public string delivery_term { get; set; }
            public string contract_date { get; set; }
            public string offer { get; set; }

            public string answer { get; set; }
            public string shipping_cost { get; set; }
        }

        public string answerOffer(Offer off)
        {
            string user = User.Identity.GetUserId();
            var query1 = $"SELECT attis_contract_offer_subj FROM attis_contract_offers WHERE attis_contract_offer_id={off.offer_id}";
            var kn = Provider.RunQueryStr(query1);
            try
            {
                var query = $"INSERT INTO attis_contract_offer_changes (offer_id, attis_contract_offer_change_text, attis_contract_offer_answer, attis_contract_offer_change_date, attis_contract_offer_change_user)" +
                $" VALUES ('{off.offer_id}', '{off.offer}', '{off.answer}', now(), '{user}')";
                Provider.RunNonQuery(query);
                var dt1 = GetDateTimeFromString(off.contract_date);
                query = $"UPDATE attis_contract_offers SET attis_contract_id = '{off.attis_contract_id}', no_changes = 'false', can_show_chain = 'true', attis_contract_offer_subj = '{user}', discount_percents = '{off.discount_percents}', offer = '{off.offer}', " +
                    $" payment_type = '{off.payment_type}', delivery_term = '{off.delivery_term}', shipping_cost = '{off.shipping_cost}', discount_amount = '{off.discount_amount}', contract_date = '{dt1.ToString("yyyy.MM.dd")}', attis_contract_offer_status = '0' " +
                    $" WHERE attis_contract_offer_id = '{off.offer_id}'" +
                    $" RETURNING attis_contract_offer_id;";
                var contr = Provider.RunScalar(query);
                if (!Provider.lastError.IsEmpty())
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.AnswerOffer}', '{LogOffer.AnswerOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                }
                query = $"SELECT attis_contract_id FROM attis_contract_offers WHERE attis_contract_offer_id='{off.offer_id}'";
                string cd = Provider.RunQueryStr(query);
                query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{cd}'";
                if (user.Equals(kn)) kn = Provider.RunQueryStr(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.NewBid,
                    CreatorId = user,
                    RecipientId = kn,
                    CreationDate = DateTime.Now,
                    ObjectId = off.offer_id,
                    Comment = cd
                });
              
                SendEmailNotification(kn, (int)NotificationType.NewBid, cd, off.offer_id);
                log.Info("answer offer " + user + JsonConvert.SerializeObject(off));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogOffer.AnswerOffer}', '{LogOffer.AnswerOffer}', '{LogSection.Offer}', '{user}', '{kn}', '{off.offer_id}', '{JsonConvert.SerializeObject(off)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            catch(Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogOffer.AnswerOffer}', '{LogOffer.AnswerOffer}', '{LogSection.Offer}', '{user}', '{kn}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }
            
        }
        /*
        private void SendEmailNotification(string id)
        {
            string query = "SELECT \"Email\" FROM \"AspNetUsers\" WHERE \"Id\" ='" + id + "';";
            var res = Provider.RunQueryStr(query);
            if (res != "") //check if email is entered
            {
                var eml = new eml();
                //var typ = (NotificationType)type;
                // not.Type = type.ToName();
                eml.subject = "New notification/Новое уведомление";
                eml.message = "You have new notification in ATTIS system/У Вас новое уведомление в системе ATTIS";
                eml.email = res;
                SendEmail(eml);
            }
        }*/
        private void SendEmailNotification(string id, int type, string contract, int code)
        { 
            string query = "SELECT \"Email\" FROM \"AspNetUsers\" WHERE \"Id\" ='" + id + "';";
            var res = Provider.RunQueryStr(query);
            query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + id + "';";
            var name = Provider.RunQueryStr(query);
            if (res != "") //check if email is entered
            {  
                var eml = new eml();
                var path = "";
                eml.subject = "New notification in ATTIS system/Новое уведомление  в системе ATTIS";
                switch (type)
                {
                    case (int)NotificationType.NewOffer: //1
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/offer/" + code;
                        eml.message = $"Уважаемый {name}, на Вашу Заявку поступило предложение, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, you have received Request on your Application, you can go to it <a href=\"http://{path}\">here</a>";

                        break;
                    case (int)NotificationType.AcceptOffer: //2
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}";
                        eml.message = $"'Уважаемый {name}, на Вашу Заявку поступил ответ, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, you have received a Respond on your Application, you can go to it <a href=\"http://{path}\">here</a>";
                        break;
                    case (int)NotificationType.DeclineOffer: //3
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/offer/" + code;
                        eml.message = $"Уважаемый {name}, на Ваше Предложение на Заявку поступил Отказ, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, You have received a declining on Your Application, You can go to it <a href=\"http://{path}\">here</a>"; ;
                        break;
                    case 4:
                        eml.message = "";
                        break; 
                    case (int)NotificationType.NewCourierOffer: //6
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/courier/" + code;
                        eml.message = $"Уважаемый {name}, Вам поступило предложение на перевозку товара, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, Your Application for goods transportation accepted, You can go to it <a href=\"http://{path}\">here</a>";
                        break;
                    case (int)NotificationType.CourierAccept: //7
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/courier/" + code; 
                        eml.message = $"Уважаемый {name}, на Вашу Заявку на перевозку поступило Согласие, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, You have received an Offer for goods transportation, You can go to it <a href=\"http://{path}\">here</a>";
                        break;
                    case (int)NotificationType.CourierDecline://8
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/courier/" + code;
                        eml.message = $"Уважаемый {name}, на Вашу Заявку на перевозку поступил Отказ, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, Your Application for goods transportation declined, You can go to it <a href=\"http://{path}\">here</a>";
                        break; 
                    case (int)NotificationType.CourierSelect: //9
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/courier/" + code;
                        eml.message = $"Уважаемый {name}, Ваша компания выбрана исполнителем на перевозку товара, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, Your company selected for goods delivery, You can go to it <a href=\"http://{path}\">here</a>";
                        break; 
                    case (int)NotificationType.NewBrokerOffer: //10
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/broker/" + code;
                        eml.message = $"Уважаемый {name}, Вам поступило предложение на оказание услуг таможенного брокера, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, You have received an Offer for customs brokerage services, You can go to it <a href=\"http://{path}\">here</a>";
                        break; 
                    case (int)NotificationType.BrokerAccept: //11
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/broker/" + code;
                        eml.message = $"Уважаемый {name}, Ваша компания выбрана исполнителем оказания услуг таможенного брокера, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, Your company selected for customs brokerage services, You can go to it <a href=\"http://{path}\">here</a>";
                        break;
                    case (int)NotificationType.BrokerDecline: //12
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/broker/" + code;
                        eml.message = $"Уважаемый {name}, на Вашу Заявку на оказание услуг таможенного брокера  поступило Согласие, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, your Application for customos brokerage services accepted, You can go to it <a href=\"http://{path}\">here</a>";
                        break;
                    case (int)NotificationType.BrokerSelect: //13
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/broker/" + code;
                        eml.message = $"Уважаемый {name}, на Вашу Заявку на оказание услуг таможенного брокера поступил Отказ, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, your Application for customs brokerage services declined, You can go to it <a href=\"http://{path}\">here</a>";
                        break; 
                    case (int)NotificationType.SignContract: //15
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}";
                        eml.message = $"Уважаемый {name}, Ваша Заявка подписана, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, Your Application has been signed, <a href=\"http://{path}\">link to the Application</a>";
                        break;
                    case (int)NotificationType.NewBid: //26
                        path = Request.Url.Authority + $"/ru/#/contracts/view/{contract}/offer/" + code;
                        eml.message = $"'Уважаемый {name}, на Вашу Заявку поступил ответ, пройдите по <a href=\"http://{path}\">ссылке</a><br>Dear {name}, you have received a Respond on your Application, You can go to it <a href=\"http://{path}\">here</a>";
                        break;
                    default:
                        eml.message = "You have new notification in ATTIS system/У Вас новое уведомление в системе ATTIS";
                        break;
                }
                
                eml.email = res;
                SendEmail(eml);
            }
        }
        public string chainOffer(int offer_id, string token)
        {
            var query = $"SELECT t1.*, t3.org_code, t3.org_name FROM attis_contract_offer_changes t1 LEFT JOIN" +
                $" persons t2 ON t1.attis_contract_offer_change_user = t2.user_id LEFT JOIN organizations t3" +
                $" ON t2.org_id = t3.org_id WHERE t1.offer_id='{offer_id}';";
            var reader = Provider.RunQuery(query);

            var offer = new List<OfferChange>();
            var list = new OfferUser();
            if (reader != null)
            {
                while (reader.Read())
                {
                    list.id = reader["attis_contract_offer_change_user"].ToString();
                    list.org_code = reader["org_code"].ToString();
                    list.org_name = reader["org_name"].ToString();
                    var rep1 = new OfferChange
                    {
                        ID = reader.GetFieldValueOrDefault<int>("attis_contract_offer_change_id"),
                    };
                    rep1.attis_contract_offer_change_text = reader["attis_contract_offer_change_text"].ToString();
                    rep1.attis_contract_offer_change_user = list;
                    rep1.attis_contract_offer_change_date = reader["attis_contract_offer_change_date"].ToString();
                    rep1.attis_contract_offer_answer = reader["attis_contract_offer_answer"].ToString();
                    //rep1.attis_contract_offer_change_text = reader["attis_contract_offer_change_text"].ToString();
                    rep1.shipping_cost = "112";
                    offer.Add(rep1);
                }
                reader.Close();
                return JsonConvert.SerializeObject(offer);
            }

            return "error";
        }
        public string acceptOffer(int offer_id, string token)
        {
            string user = User.Identity.GetUserId();
            var query = $"UPDATE attis_contract_offers SET attis_contract_offer_status = 1 WHERE attis_contract_offer_id={offer_id} RETURNING attis_contract_id";
            var cd = Provider.RunScalar(query);
            query = $"SELECT t2.org_code FROM attis_contract_offers LEFT JOIN persons t1 on t1.user_id = attis_contract_offer_subj " +
                    $"LEFT JOIN organizations t2 on t1.org_id = t2.org_id  WHERE attis_contract_offer_id={offer_id}";
            var org_cod = Provider.RunQueryStr(query);
            var query1 = $"UPDATE attis_contracts SET attis_contract_status = '2', attis_contract_contragent='{org_cod}'  WHERE attis_contract_id ='{cd}' RETURNING attis_contract_owner";
            var kn = Provider.RunQueryStr(query1);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.AcceptOffer}', '{LogOffer.AcceptOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
            }
            try
            {
                
                
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.AcceptOffer,
                    CreatorId = user,
                    RecipientId = kn,
                    CreationDate = DateTime.Now,
                    ObjectId = offer_id,
                    Comment = cd.ToString()
                });
                
                SendEmailNotification(kn, (int)NotificationType.NewBid, cd.ToString(), offer_id);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.AcceptOffer,
                    CreatorId = kn,
                    RecipientId = user,
                    CreationDate = DateTime.Now,
                    ObjectId = offer_id,
                    Comment = cd.ToString()
                });
                SendEmailNotification(user, (int)NotificationType.NewBid, cd.ToString(), offer_id);
                log.Info("accept offer " + user + JsonConvert.SerializeObject(offer_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.AcceptOffer}', '{LogOffer.AcceptOffer}', '{LogSection.Offer}', '{kn}', '{user}', '{offer_id}', '{JsonConvert.SerializeObject(offer_id)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id,log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.AcceptOffer}', '{LogOffer.AcceptOffer}', '{LogSection.Offer}', '{kn}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }
            
            
        }

        public string acceptContract(int id, string token)
        {
            string user = User.Identity.GetUserId();
            string query = $"UPDATE attis_contracts SET attis_contract_status = '3' WHERE attis_contract_id ='{id}' RETURNING attis_contract_owner";
            var kn = Provider.RunQueryStr(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogContract.AcceptContract}', '{LogContract.AcceptContract}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
            }
            try
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.AcceptOffer,
                    CreatorId = user,
                    RecipientId = kn,
                    CreationDate = DateTime.Now,
                    ObjectId = id,
                    Comment = ""
                });
                SendEmailNotification(kn, (int)NotificationType.AcceptOffer, id.ToString(), 0);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.AcceptOffer,
                    CreatorId = kn,
                    RecipientId = user,
                    CreationDate = DateTime.Now,
                    ObjectId = id,
                    Comment = ""
                });
                SendEmailNotification(user, (int)NotificationType.AcceptOffer, id.ToString(), 0);
                log.Info("accept contract " + user + JsonConvert.SerializeObject(id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.AcceptContract}', '{LogContract.AcceptContract}', '{LogSection.Contract}', '{kn}', '{user}', '{id}', '{JsonConvert.SerializeObject(id)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            catch(Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.AcceptContract}', '{LogContract.AcceptContract}', '{LogSection.Contract}', '{kn}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }
            
        }

        public string declineOffer(int offer_id, string token)
        {
            string user = User.Identity.GetUserId();
            var query = $"UPDATE attis_contract_offers SET attis_contract_offer_status = -1 WHERE attis_contract_offer_id='{offer_id}' RETURNING attis_contract_offer_subj";
            var kn = Provider.RunQueryStr(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.DeclineOffer}', '{LogOffer.DeclineOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
            }
            try
            {
                query = $"SELECT attis_contract_id FROM attis_contract_offers WHERE attis_contract_offer_id='{offer_id}'";
                string cd = Provider.RunQueryStr(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.DeclineOffer,
                    CreatorId = user,
                    RecipientId = kn,
                    CreationDate = DateTime.Now,
                    ObjectId = offer_id,
                    Comment = cd
                });
                SendEmailNotification(kn, (int)NotificationType.DeclineOffer, cd, offer_id);
                log.Info("decline offer " + user + JsonConvert.SerializeObject(offer_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.DeclineOffer}', '{LogOffer.DeclineOffer}', '{LogSection.Offer}', '{user}', '{kn}', '{offer_id}', '{JsonConvert.SerializeObject(offer_id)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            catch(Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, log_data, is_error) " +
               $"VALUES('NOW()', '{(int)LogOffer.DeclineOffer}', '{LogOffer.DeclineOffer}', '{LogSection.Offer}', '{user}', '{kn}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return "error";
            }
            
        }

        [HttpPost]
        public JsonResult SaveOffer(Offer off)
        {
            string user = User.Identity.GetUserId();
            try
            {
                string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{off.attis_contract_id}'";
                string cmp = Provider.RunQueryStr(query);
                //if (user.Equals(cmp))
                //{
                //    return Json("Не могу отправить себе предложение");
                //}
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = off.attis_contract_id.ToString(),
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "offer"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id = '{user}'";
                var org_cod = Provider.RunQueryStr(query);

                query = $"INSERT INTO attis_contract_offers (attis_contract_id, no_changes, attis_contract_offer_subj, discount_percents, offer, " +
                    $" payment_type, delivery_term, shipping_cost, discount_amount, contract_date, attis_contract_offer_status, doc_guid, doc_name)" +
                    $" VALUES ('{off.attis_contract_id}', 'false', '{user}', '{off.discount_percents}', '{off.offer}'," +
                    $" '{off.payment_type}', '{off.delivery_term}', '{off.shipping_cost}', '{off.discount_amount}', '{off.contract_date}', '0', '{rid}', '{type}') RETURNING attis_contract_offer_id;";
                var contr = Provider.RunScalar(query);
                if (!Provider.lastError.IsEmpty())
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.NewOffer}', '{LogOffer.NewOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                }
                query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id ='{off.attis_contract_id}'";
                var kn = Provider.RunQueryStr(query);

                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.NewOffer,
                    CreatorId = user,
                    RecipientId = kn,
                    CreationDate = DateTime.Now,
                    ObjectId = contr,
                    Comment = off.attis_contract_id.ToString()
                });
                SendEmailNotification(kn, (int)NotificationType.NewOffer, off.attis_contract_id.ToString(), contr);
                if (contr > 0)
                {
                    log.Info("new offer " + user + JsonConvert.SerializeObject(off));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.NewOffer}', '{LogOffer.NewOffer}', '{LogSection.Offer}', '{user}', '{kn}', '{contr}', '{JsonConvert.SerializeObject(off)}', 0);";
                    Provider.RunNonQuery(query);
                    return Json("ok");
                }
                else return Json("error" + contr);
            }
            catch (Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.NewOffer}', '{LogOffer.NewOffer}', '{LogSection.Offer}', '{user}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return Json("error" + off.attis_contract_id);
            }
            
        }

        [HttpPost]
        public JsonResult saveOfferSign(Offer off)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{off.attis_contract_id}'";
            string cmp = Provider.RunQueryStr(query);
            //if (user.Equals(cmp))
            //{
            //    return Json("Не могу отправить себе предложение");
            //}
            try
            {
                
                var r = new List<ImageFile>();
                int? rid = null; string type = "";
                foreach (string fil in Request.Files)
                {
                    var hpf = Request.Files[fil];
                    if (hpf.ContentLength == 0)
                        continue;

                    // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                    // hpf.SaveAs(savedFileName);
                    var imgFile = new ImageFile
                    {
                        ID = 0,
                        EntityId = off.attis_contract_id.ToString(),
                        Name = hpf.FileName,
                        Length = hpf.ContentLength,
                        Type = hpf.ContentType,
                        Date = DateTime.Now,
                        Image = new MemoryStream(),
                        WidgetId = "offer"
                    };

                    hpf.InputStream.CopyTo(imgFile.Image);

                    Provider.SaveFile(imgFile);

                    r.Add(imgFile);
                }
                if (r.Count > 0) { rid = r[0].ID; type = r[0].Name; }
                query = "SELECT org_id FROM persons WHERE user_id ='" + user + "';";
                var org_cod = Provider.RunQueryStr(query);

                query = $"INSERT INTO attis_contract_offers (attis_contract_id, no_changes, can_show_chain, attis_contract_offer_subj, discount_percents, offer, " +
                    $" payment_type, delivery_term, shipping_cost, discount_amount, contract_date, attis_contract_offer_status, doc_guid, doc_name)" +
                    $" VALUES ('{off.attis_contract_id}', 'true', 'true', '{user}', '{off.discount_percents}', '{off.offer}'," +
                    $" '{off.payment_type}', '{off.delivery_term}', '{off.shipping_cost}', '{off.discount_amount}', '{off.contract_date}', '0', '{rid}', '{type}') RETURNING attis_contract_offer_id;";
                var contr = Provider.RunScalar(query);
                if (!Provider.lastError.IsEmpty())
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.SignOffer}', '{LogOffer.SignOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                }
                query = $"UPDATE attis_contracts SET attis_contract_status = '2', attis_contract_contragent='{org_cod}' WHERE attis_contract_id ='{off.attis_contract_id}' RETURNING attis_contract_owner";
                var kn = Provider.RunQueryStr(query);

                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.NewOffer,
                    CreatorId = user,
                    RecipientId = kn,
                    CreationDate = DateTime.Now,
                    ObjectId = contr,
                    Comment = off.attis_contract_id.ToString()
                });
                SendEmailNotification(kn, (int)NotificationType.NewOffer, off.attis_contract_id.ToString(), contr);
                if (contr > 0)
                {
                    log.Info("sign oiffer " + user + JsonConvert.SerializeObject(off));
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id,log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.SignOffer}', '{LogOffer.SignOffer}', '{LogSection.Offer}', '{user}', '{kn}', '{contr}', '{JsonConvert.SerializeObject(off)}', 0);";
                    Provider.RunNonQuery(query);
                    return Json("ok");
                }
                else return Json("error" + contr);
            }
            catch(Exception ex)
            {
                var exception = JsonConvert.SerializeObject(new xp
                {
                    Exception = ex.Message,
                    InnerException = (ex.InnerException == null ? "" : ex.InnerException.Message)
                });
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id,log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.SignOffer}', '{LogOffer.SignOffer}', '{LogSection.Offer}', '{user}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, exception);
                return Json("error");
            }
           
        }

        public string DeleteOffer(string offer_id)
        {
            string user = User.Identity.GetUserId();
            try
            {
                var query = $"DELETE FROM attis_contract_offers WHERE attis_contract_offer_id='{offer_id}';";
                var contr = Provider.RunScalar(query);
                if (!Provider.lastError.IsEmpty())
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.DeleteOffer}', '{LogOffer.DeleteOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                }
                log.Info("delete offer " + user + JsonConvert.SerializeObject(offer_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.DeleteOffer}', '{LogOffer.DeleteOffer}', '{LogSection.Offer}', '{user}', '{offer_id}', '{JsonConvert.SerializeObject(offer_id)}', 0);";
                Provider.RunNonQuery(query);
                //if (contr > 0)
                return JsonConvert.SerializeObject("ok");
            }
            catch (Exception ex)
            {
                var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogOffer.DeleteOffer}', '{LogOffer.DeleteOffer}', '{LogSection.Offer}', '{user}', '{offer_id}', '{Json(ex.Message.ToString())}', 1);";
                Provider.RunNonQuery(query);
                return JsonConvert.SerializeObject("error");
            }
            
            
        }

        public class Srch
        {
            public string id { get; set; }
            public string country { get; set; }//: "Китай",
            public string name { get; set; }//: "Кандидат 1",
            public string contact { get; set; }//: "xxx@xxxx.com",
            public string sphere { get; set; }//: "Проиводство 1",
            public string email { get; set; }
            public bool Checked { get; set; }//: false
        }

        public class Sresult
        {
            public string search_id { get; set; }
            public string date { get; set; }
            public int number_results { get; set; }
            public List<Srch> search { get; set; }
        }

        [HttpPost]
        public string searchContr(string org_residency, string company_address, string company_main_sphere, string org_name, bool search_other)
        {
            var response = Request["contract_id"];
            string user = User.Identity.GetUserId();
            var list = new List<Srch>();
            string ors = "", cad = "", cms = "", onm = "";
            ors = $"org_residency ~ '{org_residency}' ";
            if (!String.IsNullOrEmpty(company_address)) cad = $"AND company_address ~ '{company_address}' ";
            if (!String.IsNullOrEmpty(company_main_sphere)) cms = $"AND company_main_sphere ~ '{company_main_sphere}' ";
            if (!String.IsNullOrEmpty(org_name)) onm = $"AND LOWER(org_name) ~ '{org_name.ToLower()}' ";
            var query = $"SELECT * FROM org_ext WHERE {ors}{cad}{cms}{onm};";

            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new Srch
                    {
                        id = reader["org_id"].ToString(),
                    };
                    rep1.country = reader["org_residency"].ToString();
                    rep1.name = reader["org_name"].ToString();
                    rep1.contact = reader["company_contacts"].ToString();
                    rep1.sphere = reader["company_main_sphere"].ToString();
                    rep1.email = reader["company_email"].ToString();
                    rep1.Checked = search_other;
                    list.Add(rep1);
                }
                reader.Close();
            }
            return JsonConvert.SerializeObject(list);
        }

        [HttpPost]
        public JsonResult saveSearchContr(string org_residency, string company_address, string company_main_sphere, string org_name, bool search_other)
        {
            var response = Request["contract_id"];
            string user = User.Identity.GetUserId();
            string query = $"SELECT subj_id FROM subjects WHERE user_id='{user}'";
            int subj = Provider.RunScalar(query);
            query = $"INSERT INTO contract_searches (contract_search_contract, contract_search_subj_country, company_address, company_main_sphere, contract_search_subj_name, contract_search_subj, contract_search_date)" +
                $" VALUES ('{response}', '{org_residency}', {company_address}, '{company_main_sphere}', '{org_name}', '{subj}', now() ) RETURNING contract_search_id;";
            int srh = Provider.RunScalar(query);
            var list = new List<Srch>();
            string ors = "", cad = "", cms = "", onm = "";
            ors = $"org_residency ~ '{org_residency}' ";
            if (!String.IsNullOrEmpty(company_address)) cad = $"AND company_address ~ '{company_address}' ";
            if (!String.IsNullOrEmpty(company_main_sphere)) cms = $"AND company_main_sphere ~ '{company_main_sphere}' ";
            if (!String.IsNullOrEmpty(org_name)) onm = $"AND LOWER(org_name) ~ '{org_name}' ";
            query = $"SELECT * FROM org_ext WHERE {ors}{cad}{cms}{onm};";

            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new Srch
                    {
                        id = reader["contract_search_subj_country"].ToString(),
                    };
                    rep1.country = reader["org_residency"].ToString();
                    rep1.name = reader["org_name"].ToString();
                    rep1.contact = reader["company_contacts"].ToString();
                    rep1.sphere = reader["company_main_sphere"].ToString();
                    rep1.email = reader["company_email"].ToString();
                    rep1.Checked = search_other;
                    list.Add(rep1);
                }
                reader.Close();
            }
            foreach (var ls in list)
            {
                query = $"INSERT INTO contracts_search_subj (contract_search_id, contract_search_subj_country, contract_search_subj_contacts, contract_search_subj_email, contract_search_subj_spheres, contract_search_subj_name, contract_search_checked)" +
                $" VALUES ('{srh}', '{ls.country}', '{ls.contact}', '{ls.email}', '{ls.sphere}', '{ls.name}', '{ls.Checked}');";
                Provider.RunNonQuery(query);
            }

            return Json("ok");
        }

        public string loadSavedSearches(int contract_id)
        {
            lock (Provider.Locker) { 
            string query = $"SELECT contract_search_id FROM contract_searches WHERE contract_search_contract='{contract_id}'";
            var search_id = Provider.RunScalar(query);
            //query = $"SELECT contract_search_date FROM contract_searches WHERE contract_search_contract='{contract_id}'";
            var contract_search_date = DateTime.Now.ToString();//Provider.RunQueryStr(query);
            var sell = new Sresult();
            sell.search_id = search_id.ToString();
            sell.date = contract_search_date;
            //if (reader != null)
            {/*
                while (reader.Read())
                {
                    sell.date = reader["contract_search_date"].ToString();
                    sell. = reader["contract_search_id"].ToString();
                }
                reader.Close();*/
                var list = new List<Srch>();
                //if (sell.search_id.Equals("")) sell.search_id = "0";
                query = $"SELECT * FROM contracts_search_subj WHERE contract_search_id='{search_id}';";
                var reader = Provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep1 = new Srch
                        {
                            id = reader["contract_search_id"].ToString(),
                        };
                        rep1.country = reader["contract_search_subj_country"].ToString();
                        rep1.name = reader["contract_search_subj_name"].ToString();
                        rep1.contact = reader["contract_search_subj_contacts"].ToString();
                        rep1.sphere = reader["contract_search_subj_spheres"].ToString();
                        rep1.email = reader["contract_search_subj_email"].ToString();
                        rep1.Checked = (bool)reader["contract_search_checked"];
                        list.Add(rep1);
                    }
                    reader.Close();
                }
                sell.search = new List<Srch>(list);
                sell.number_results = list.Count;
                return JsonConvert.SerializeObject(sell);
            }
            }
        }

        public class Countragent1
        {
            public string org_code { get; set; }
            public string org_name { get; set; }
        }

        public class Countragent2
        {
            public string org_code { get; set; }
            public string org_name { get; set; }
        }

        public class CourierOffer
        {
            public string ID { get; set; }
            public bool? is_accepted { get; set; }
            public Countragent1 countragent_1 { get; set; }
            public Countragent2 countragent_2 { get; set; }
            public string type_of_movement { get; set; }
            public string from_address { get; set; }
            public string to_address { get; set; }
            public float weight { get; set; }
            public float volume { get; set; }
            public double delivery_price { get; set; }
            public string delivery_price_currency { get; set; }
            public string packaging { get; set; }
            public string date_of_load { get; set; }
            public string date_of_delivery { get; set; }
            public string hazard_class { get; set; }
            public string comments { get; set; }
            public string offer_date { get; set; }
            public List<Kfiles> files { get; set; }
            //new
            public string cancel_term { get; set; }
            public string consent_term { get; set; }
            public string inform_term { get; set; }
            public string location_term { get; set; }
            public string fuel_percent { get; set; }
            public string currency_percent { get; set; }
            public string application_term { get; set; }
            public string customs_term { get; set; }
            public string delay_abroad_term { get; set; }
            public string delay_home_term { get; set; }
            public string courier_cis_delay_amount { get; set; }
            public string customer_cis_delay_amount { get; set; }
            public string courier_eu_delay_amount { get; set; }
            public string customer_eu_delay_amount { get; set; }
            public string courier_declination_percent { get; set; }
            public string penalty_percent { get; set; }
            public string penalty_never_more { get; set; }
            public string customer_declination_percent { get; set; }
            public string act_term { get; set; }
            public string repeats_term { get; set; }
            public string force_major_term { get; set; }
            public string claim_term { get; set; }
            public string resolve_term { get; set; }
            public string contract_term { get; set; }
            public string contract_cancel_term { get; set; }
            public bool is_signed_by_owner { get; set; }
            public bool is_signed_by_courier { get; set; }

            public bool is_selected { get; set; }

        }

        public class PostCourier
        {
            public string contract_id { get; set; }
            public string countragent_1 { get; set; } //: org_code создателя предложения(контрагента 1)
            public string type_of_movement { get; set; } // : строка, тип перевозки(auto/avia/sea/railway/post)
            public string from_address { get; set; } //: строка, адрес отправки
            public string to_address { get; set; } //: строка, адрес доставки
            public float? weight { get; set; } //: число, вес брутто
            public float? volume { get; set; } //: число, объем
            public float? delivery_price { get; set; } //: число, стоимость доставки
            public string delivery_price_currency { get; set; } //: валюта стоимость доставки
            public string date_of_load { get; set; } //: дата погрузки
            public string date_of_delivery { get; set; } //: дата доставки
            public string hazard_class { get; set; } //: строка, класс опасности(class0/class1/.../class9)
            public string comments { get; set; } //: строка, примечания
            public string invites { get; set; } //: [1, 23,..., 55]
            public string packaging { get; set; }
            public string cancel_term { get; set; }
            public string consent_term { get; set; }
            public string inform_term { get; set; }
            public string location_term { get; set; }
            public string fuel_percent { get; set; }
            public string currency_percent { get; set; }
            public string application_term { get; set; }
            public string customs_term { get; set; }
            public string delay_abroad_term { get; set; }
            public string delay_home_term { get; set; }
            public string courier_cis_delay_amount { get; set; }
            public string customer_cis_delay_amount { get; set; }
            public string courier_eu_delay_amount { get; set; }
            public string customer_eu_delay_amount { get; set; }
            public string courier_declination_percent { get; set; }
            public string penalty_percent { get; set; }
            public string penalty_never_more { get; set; }
            public string customer_declination_percent { get; set; }
            public string act_term { get; set; }
            public string repeats_term { get; set; }
            public string force_major_term { get; set; }
            public string claim_term { get; set; }
            public string resolve_term { get; set; }
            public string contract_term { get; set; }
            public string contract_cancel_term { get; set; }
        }

        public string getCourierOffers(string contract_id)
        {
            lock (Provider.Locker)
            {
                string user = User.Identity.GetUserId();
                string query = $"SELECT o.org_is_carrier, o.org_code, c.attis_contract_owner FROM persons p INNER JOIN organizations o on p.org_id = o.org_id INNER JOIN attis_contracts c on c.attis_contract_id = '{contract_id}' WHERE p.user_id = '{user}'";
                var reader = Provider.RunQuery(query);
                string ownerId = String.Empty;
                string orgCode = String.Empty;
                int isCarrier = 0;
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        ownerId = reader["attis_contract_owner"].ToString();
                        orgCode = reader["org_code"].ToString();
                        isCarrier = reader.GetFieldValueOrDefault<int>("org_is_carrier"); 
                    }
                    reader.Close();
                }
                if (ownerId == user)
                {
                    query = $"SELECT t1.*, t2.accepted, t2.price, t2.price_currency, t2.date_of_load as loadingDate, t2.date_of_delivery as deliveryDate, t2.comments as notes, t3.org_name as cont1, t4.org_name as cont2, t4.org_code as orc2 FROM courier_requests t1 LEFT JOIN courier_invite t2 ON t1.id=t2.req_id LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code WHERE t1.contract_id = '{contract_id}';";
                }
                else
                {
                    query = $"SELECT t1.*, t2.accepted, t2.price, t2.price_currency, t2.date_of_load as loadingDate, t2.date_of_delivery as deliveryDate, t2.comments as notes, t3.org_name as cont1, t4.org_name as cont2, t4.org_code as orc2 FROM courier_requests t1 LEFT JOIN courier_invite t2 ON t1.id=t2.req_id LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code WHERE t1.contract_id = '{contract_id}' and t4.org_code = '{orgCode}';";
                }
                reader = Provider.RunQuery(query);
                var couriers = new List<CourierOffer>();
                
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new CourierOffer
                        {
                            ID = reader["id"].ToString(),
                        };
                        rep.is_accepted = reader.GetFieldValueOrDefault<bool>("accepted");
                        rep.countragent_1 = new Countragent1();
                        rep.countragent_1.org_code = reader["countragent_1"].ToString();
                        rep.countragent_1.org_name = reader["cont1"].ToString();
                        rep.countragent_2 = new Countragent2();
                        rep.countragent_2.org_name = reader["cont2"].ToString();
                        rep.countragent_2.org_code = reader["orc2"].ToString();
                        rep.type_of_movement = reader["type_of_movement"].ToString();
                        rep.from_address = reader["from_address"].ToString();
                        rep.to_address = reader["to_address"].ToString();
                        rep.weight = reader.GetFieldValueOrDefault<float>("weight");
                        rep.volume = reader.GetFieldValueOrDefault<float>("volume");
                        rep.delivery_price = reader.GetFieldValueOrDefault<float>("price");
                        rep.delivery_price_currency = reader["price_currency"].ToString();
                        //rep.packaging = reader["shipping_cost"].ToString();
                        rep.date_of_load = reader["loadingDate"].ToString();
                        rep.date_of_delivery = reader["deliveryDate"].ToString();
                        rep.hazard_class = reader["hazard_class"].ToString();
                        rep.comments = reader["notes"].ToString();
                        rep.offer_date = reader["offer_date"].ToString();
                        rep.packaging = reader["packaging"].ToString();
                        //new
                        rep.cancel_term = reader["cancel_term"].ToString();
                        rep.consent_term = reader["consent_term"].ToString();
                        rep.inform_term = reader["inform_term"].ToString();
                        rep.location_term = reader["location_term"].ToString();
                        rep.fuel_percent = reader["fuel_percent"].ToString();
                        rep.currency_percent = reader["currency_percent"].ToString();
                        rep.application_term = reader["application_term"].ToString();
                        rep.customs_term = reader["customs_term"].ToString();
                        rep.delay_abroad_term = reader["delay_abroad_term"].ToString();
                        rep.delay_home_term = reader["delay_home_term"].ToString();
                        rep.courier_cis_delay_amount = reader["courier_cis_delay_amount"].ToString();
                        rep.customer_cis_delay_amount = reader["customer_cis_delay_amount"].ToString();
                        rep.courier_eu_delay_amount = reader["courier_eu_delay_amount"].ToString();
                        rep.customer_eu_delay_amount = reader["customer_eu_delay_amount"].ToString();
                        rep.courier_declination_percent = reader["courier_declination_percent"].ToString();
                        rep.penalty_percent = reader["penalty_percent"].ToString();
                        rep.penalty_never_more = reader["penalty_never_more"].ToString();
                        rep.customer_declination_percent = reader["customer_declination_percent"].ToString();
                        rep.act_term = reader["act_term"].ToString();
                        rep.repeats_term = reader["repeats_term"].ToString();
                        rep.force_major_term = reader["force_major_term"].ToString();
                        rep.claim_term = reader["claim_term"].ToString();
                        rep.resolve_term = reader["resolve_term"].ToString();
                        rep.contract_term = reader["contract_term"].ToString();
                        rep.contract_cancel_term = reader["contract_cancel_term"].ToString();
                        rep.is_signed_by_owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                        rep.is_signed_by_courier = reader.GetFieldValueOrDefault<bool>("is_signed_by_courier");
                        couriers.Add(rep);
                    }
                    reader.Close();
                    foreach (var cour in couriers)
                    {
                        query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{cour.ID}' and doc_widget_id ='courier'";
                        reader = Provider.RunQuery(query);
                        var files = new List<Kfiles>();
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                var rep = new Kfiles
                                {
                                    id = reader["id"].ToString(), //"/picture/getfile/"
                                };
                                rep.name = reader["img_file_name"].ToString();
                                files.Add(rep);
                            }
                            reader.Close();
                        }
                        cour.files = new List<Kfiles>(files);
                    }
                    return JsonConvert.SerializeObject(couriers);
                }
                return "";
            }
        }

        [HttpPost]
        public string acceptCourierOffer(int courier_offer_id, string comment, string loading_date, string delivery_date, float? price, string price_currency, PostCourier post)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);

            query = $"UPDATE courier_invite SET accepted=true, price='{price}', price_currency='{price_currency}', date_of_delivery='{delivery_date}', date_of_load='{loading_date}', comments='{comment}' WHERE org_id='{org_code}' AND req_id ='{courier_offer_id}'";
            Provider.RunNonQuery(query);
            query = $"UPDATE courier_requests SET (cancel_term, consent_term, inform_term, location_term, fuel_percent, currency_percent, application_term, " +
    $"customs_term, delay_abroad_term, delay_home_term, courier_cis_delay_amount, customer_cis_delay_amount, courier_eu_delay_amount, " +
    $"customer_eu_delay_amount, courier_declination_percent, penalty_percent, penalty_never_more, customer_declination_percent, " +
    $"act_term, repeats_term, force_major_term, claim_term, resolve_term, contract_term, contract_cancel_term)" +
$" = ( '{post.cancel_term}','{post.consent_term}','{post.inform_term}','{post.location_term}','{post.fuel_percent}','{post.currency_percent}'," +
$" '{post.application_term}','{post.customs_term}','{post.delay_abroad_term}','{post.delay_home_term}','{post.courier_cis_delay_amount}'," +
$" '{post.customer_cis_delay_amount}','{post.courier_eu_delay_amount}','{post.customer_eu_delay_amount}','{post.courier_declination_percent}'," +
$" '{post.penalty_percent}','{post.penalty_never_more}','{post.customer_declination_percent}','{post.act_term}','{post.repeats_term}'," +
$" '{post.force_major_term}','{post.claim_term}','{post.resolve_term}','{post.contract_term}','{post.contract_cancel_term}') WHERE id ={courier_offer_id};";
            Provider.RunNonQuery(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.CourierOffer}', '{LogOffer.CourierOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Provider.lastError;
            }
            var usrs = new List<string>();
            string contract = "0";
            query = $"SELECT t2.user_id, t3.contract_id FROM courier_requests t3 LEFT JOIN organizations t1 ON t3.countragent_1 = t1.org_code LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t3.id={courier_offer_id}";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    contract = reader["contract_id"].ToString();
                    string usr = reader["user_id"].ToString();
                    usrs.Add(usr);
                }
                reader.Close();
            }
            foreach (var usr in usrs)
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.CourierAccept,
                    CreatorId = user,
                    RecipientId = usr,
                    CreationDate = DateTime.Now,
                    ObjectId = courier_offer_id,
                    Comment = contract
                });
                SendEmailNotification(usr, (int)NotificationType.CourierAccept, contract, courier_offer_id);
            }
            log.Info("accept courier offer " + user + JsonConvert.SerializeObject(courier_offer_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.NewCourierOffer}', '{LogOffer.NewCourierOffer}', '{LogSection.Offer}', '{user}', '', '{courier_offer_id}', '{JsonConvert.SerializeObject(courier_offer_id)}', 0);";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}"; ;
        }
        [HttpGet]
        public string CanRequestForTransport(string contract_id)
        {
            bool result = false;
            var query = $"SELECT COUNT(1) FROM courier_requests req INNER JOIN courier_invite t1 on t1.req_id = req.id WHERE req.contract_id = '{contract_id}' and (t1.accepted = true or t1.accepted IS NULL)";
            int count = Provider.RunScalar(query);
            if (count > 0)
            {
                result = false;
            }
            else
            {
                result = true;
            }
            return "{\"status\":\"ok\", \"result\":\"" + result + "\"}";
        }

        [HttpGet]
        public string CanRequestForBroker(string contract_id)
        {
            bool result = false;
            var query = $"SELECT COUNT(1) FROM broker_requests req INNER JOIN broker_invite t1 on t1.req_id = req.id WHERE req.contract_id = '{contract_id}' and (t1.accepted = true or t1.accepted IS NULL)";
            int count = Provider.RunScalar(query);
            if (count > 0)
            {
                result = false;
            }
            else
            {
                result = true;
            }
            return "{\"status\":\"ok\", \"result\":\"" + result + "\"}";
        }

        [HttpPost]
        public string declineCourierOffer(int courier_offer_id, string comment)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);
            var usrs = new List<string>();
            //query = $"SELECT countragent_1 FROM courier_requests WHERE id='{courier_offer_id}';";
            //var contr1 = Provider.RunQueryStr(query);
            //query = $"SELECT t2.user_id FROM organizations t1 LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t1.org_code = '{contr1}';"; //item
            query = $"SELECT t2.user_id, t3.contract_id FROM courier_requests t3 LEFT JOIN organizations t1 ON t3.countragent_1 = t1.org_code LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t3.id={courier_offer_id}";
            var reader = Provider.RunQuery(query);
            string contract = "0";
            if (reader != null)
            {
                while (reader.Read())
                {
                    contract = reader["contract_id"].ToString();
                    string usr = reader["user_id"].ToString();
                    usrs.Add(usr);
                }
                reader.Close();
            }
            foreach (var usr in usrs)
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.CourierDecline,
                    CreatorId = user,
                    RecipientId = usr,
                    CreationDate = DateTime.Now,
                    ObjectId = courier_offer_id,
                    Comment = ""
                });
                SendEmailNotification(usr, (int)NotificationType.CourierDecline, contract, courier_offer_id);
            }

            query = $"UPDATE courier_invite SET accepted=false WHERE org_id='{org_code}' AND req_id ='{courier_offer_id}'";
            Provider.RunNonQuery(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.DeclineCourierOffer}', '{LogOffer.DeclineCourierOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return Provider.lastError;
            }
            log.Info("decline courier offer " + user + JsonConvert.SerializeObject(courier_offer_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.DeclineCourierOffer}', '{LogOffer.DeclineCourierOffer}', '{LogSection.Offer}', '{user}', '', '{courier_offer_id}', '{JsonConvert.SerializeObject(courier_offer_id)}', 0);";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string selectCourierOffer(string courier_id, int courier_offer_id, int contract_id)
        {
            string user = User.Identity.GetUserId();

            string query = $"SELECT user_id FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE org_code ='{courier_id}'";
            var usr = Provider.RunQueryStr(query);
            query = $"UPDATE courier_requests SET countragent='{courier_id}' WHERE contract_id='{contract_id}';";
            Provider.RunNonQuery(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.SelectCourierOffer}', '{LogOffer.SelectCourierOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error\"}";
            }
            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.CourierSelect,
                CreatorId = user,
                RecipientId = usr,
                CreationDate = DateTime.Now,
                ObjectId = courier_offer_id,
                Comment = contract_id.ToString()
            });
            SendEmailNotification(usr, (int)NotificationType.CourierSelect, contract_id.ToString(), courier_offer_id);
            log.Info("select courier offer " + user + JsonConvert.SerializeObject(contract_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.SelectCourierOffer}', '{LogOffer.SelectCourierOffer}', '{LogSection.Offer}', '{user}', '{usr}', '{contract_id}', '{JsonConvert.SerializeObject(courier_offer_id)}', 0);";
            Provider.RunNonQuery(query);
            return "{\"status\":200}";
        }

        public string selectedBrokerOffer(int contract_id)
        {
            var query = $"SELECT countragent FROM broker_requests WHERE contract_id='{contract_id}';";
            var org_id = Provider.RunQueryStr(query);
            if (!String.IsNullOrEmpty(org_id))
            {
                lock (Provider.Locker)
                {
                    var broker = new SelectedBroker();
                    var rsd = new resid();
                    query = $"SELECT p.given_name, p.last_name, p.middle_name, p.position, pp.person_phone_number, o.org_name, o.org_code, o.org_custom_code FROM organizations o INNER JOIN persons p ON p.org_id=o.org_id LEFT JOIN persons_phones pp on pp.person_id = p.person_id WHERE o.org_code ='{org_id}';";
                    var reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            broker.given_name = reader["given_name"].ToString();
                            broker.last_name = reader["last_name"].ToString();
                            broker.middle_name = reader["middle_name"].ToString();
                            broker.position = reader["position"].ToString();
                            broker.phone_number = reader["person_phone_number"].ToString();
                            broker.organization_name = reader["org_name"].ToString();
                            broker.org_code = reader["org_code"].ToString();
                            broker.org_itn = reader["org_custom_code"].ToString();
                        }
                        reader.Close();

                        return JsonConvert.SerializeObject(broker);
                    }
                    return "{}";
                }
            }
            else return "{}";
        }
        public string selectedCourierOffer(int contract_id)
        {
            var query = $"SELECT countragent FROM courier_requests WHERE contract_id='{contract_id}';";
            var org_id = Provider.RunQueryStr(query);
            if (!String.IsNullOrEmpty(org_id)) 
            {
                lock (Provider.Locker)
                {
                    var list = new Orgs();
                    var rsd = new resid();
                    query = $"SELECT t2.*, t3.* FROM organizations t2 LEFT JOIN countries t3 ON t2.org_residency=t3.country_2a_code WHERE t2.org_code ='{org_id}';";
                    var reader = Provider.RunQuery(query);
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            list.org_name = reader["org_name"].ToString();
                            list.org_code = reader["org_code"].ToString();
                            list.org_type = reader["org_type"].ToString();
                            list.org_reg_date = GetDateTimeFromString(reader["org_reg_date"].ToString()).ToString("yyyy.MM.dd");
                            list.company_region = reader["company_region"].ToString();
                            list.org_oked = reader["org_oked"].ToString();
                            list.company_contacts = reader["company_contacts"].ToString();
                            list.company_main_sphere = reader["company_main_sphere"].ToString();
                            list.company_additional_sphere = reader["company_additional_sphere"].ToString();
                            list.company_ceo = reader["company_ceo"].ToString();
                            list.company_founder = reader["company_founder"].ToString();
                            list.company_website = reader["company_website"].ToString();
                            list.company_email = reader["company_email"].ToString();
                            rsd.value = reader["org_residency"].ToString();
                            rsd.display_text = reader["country_name_ru"].ToString();
                        }
                        reader.Close();
                        //list.persons = per;
                        list.org_residency = rsd;
                        return JsonConvert.SerializeObject(list);
                    }
                    return "{}";
                }
            }
            else return "{}";
        }

        [HttpPost]
        public string createCourierRequest(PostCourier post)
        {
            string user = User.Identity.GetUserId();
            var r = new List<ImageFile>();
            if (String.IsNullOrEmpty(user)) return "login first";

            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);

            query = $"INSERT INTO courier_requests (contract_id, countragent_1, type_of_movement, from_address, to_address, weight, volume, " +
                $"delievery_price, delivery_price_currency, date_of_load, date_of_delivery, hazard_class, comments, invites, offer_date, " +
                $"packaging, cancel_term, consent_term, inform_term, location_term, fuel_percent, currency_percent, application_term, " +
                $"customs_term, delay_abroad_term, delay_home_term, courier_cis_delay_amount, customer_cis_delay_amount, courier_eu_delay_amount, " +
                $"customer_eu_delay_amount, courier_declination_percent, penalty_percent, penalty_never_more, customer_declination_percent, " +
                $"act_term, repeats_term, force_major_term, claim_term, resolve_term, contract_term, contract_cancel_term)" +
    $" VALUES ('{post.contract_id}', '{org_code}', '{post.type_of_movement}', '{post.from_address}', '{post.to_address}', '{post.weight.GetValueOrDefault()}'," +
    $" '{post.volume.GetValueOrDefault()}', '{post.delivery_price.GetValueOrDefault()}', '{post.delivery_price_currency}'," +
    $" '{post.date_of_load}', '{post.date_of_delivery}', '{post.hazard_class}', '{post.comments}', '{post.invites}', now(), '{post.packaging}'," +
    $" '{post.cancel_term}','{post.consent_term}','{post.inform_term}','{post.location_term}','{post.fuel_percent}','{post.currency_percent}'," +
    $" '{post.application_term}','{post.customs_term}','{post.delay_abroad_term}','{post.delay_home_term}','{post.courier_cis_delay_amount}'," +
    $" '{post.customer_cis_delay_amount}','{post.courier_eu_delay_amount}','{post.customer_eu_delay_amount}','{post.courier_declination_percent}'," +
    $" '{post.penalty_percent}','{post.penalty_never_more}','{post.customer_declination_percent}','{post.act_term}','{post.repeats_term}'," +
    $" '{post.force_major_term}','{post.claim_term}','{post.resolve_term}','{post.contract_term}','{post.contract_cancel_term}') RETURNING id;";
            var cd = Provider.RunScalar(query);

            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = cd.ToString(),
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "courier"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }

            string[] inv = post.invites.Split(',');
            foreach (var item in inv)
            {
                query = $"INSERT INTO courier_invite (org_id, req_id, price, price_currency, date_of_delivery, date_of_load, comments) VALUES ('{item}', '{cd}', '{post.delivery_price}', '{post.delivery_price_currency}', '{post.date_of_delivery}', '{post.date_of_load}', '{post.comments}')"; //item
                Provider.RunNonQuery(query);
                query = $"SELECT t2.user_id FROM organizations t1 LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t1.org_code = '{item}';"; //item
                var usr = Provider.RunQueryStr(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.NewCourierOffer,
                    CreatorId = user,
                    RecipientId = usr,
                    CreationDate = DateTime.Now,
                    ObjectId = cd,
                    Comment = post.contract_id
                });
                SendEmailNotification(usr, (int)NotificationType.CourierSelect, post.contract_id, cd);
            }
            if (cd > 0)
            {
                log.Info("new courier request " + user + JsonConvert.SerializeObject(post));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogOffer.AnswerOffer}', '{LogOffer.AnswerOffer}', '{LogSection.Offer}', '{user}', '', '{inv}', '{JsonConvert.SerializeObject(post)}', 0);";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\"}";
            }
            //return Json("ok");
            //else return Json("error " + cd);
            else  
            {
                if (!Provider.lastError.IsEmpty())
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.NewCourierOffer}', '{LogOffer.NewCourierOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
            }
            return "{\"status\":\"ok\"}";
        }

        public string GetCouriers(string guid)
        {
            lock (Provider.Locker)
            {
                string query = "SELECT org_code, org_name, org_id FROM organizations WHERE org_is_carrier = 1";
                var reader = Provider.RunQuery(query);
                var couriers = new List<Firm>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Firm();
                        rep.org_code = reader["org_code"].ToString();
                        rep.org_name = reader["org_name"].ToString();
                        couriers.Add(rep);
                    }
                    reader.Close();
                    return JsonConvert.SerializeObject(couriers);
                }
                else return "";
            }
        }

        public class FullOffers
        {
            public List<OfferGroup> contract_offer_groups { get; set; }
        }

        public class BrokerOffer
        {
            public string ID { get; set; }
            public bool? is_accepted { get; set; }
            public Countragent1 countragent_1 { get; set; }
            public Countragent2 countragent_2 { get; set; }
            public string delivery_term { get; set; }
            public float epi_price { get; set; }
            public float td_price { get; set; }
            public string epi_price_currency { get; set; }
            public string td_price_currency { get; set; }
            public string comments { get; set; }
            public string offer_date { get; set; }
            public List<Kfiles> files { get; set; }
            public List<Product> products { get; set; }

            public int broker_offer_id { get; set; }
            public string comment { get; set; }
            public string contract_id { get; set; }
            public string bc_number { get; set; }
            public string bc_city { get; set; }
            public float? bc_penalty_amount { get; set; }
            public string bc_date { get; set; }
            public string owner { get; set; }
            public string broker { get; set; }
            public string bc_agreement { get; set; }
            public string bc_currency { get; set; }
            public string bc_trial_city { get; set; }
            public string bc_trial_language { get; set; }
            public comp owner_info { get; set; }
            public comp broker_info { get; set; }

            public bool is_signed_by_broker { get; set; }
            public bool is_signed_by_owner { get; set; }

            public bool is_selected { get; set; }

        }
        public class PostBroker
        {
            public string contract_id { get; set; }
            public string countragent_1 { get; set; } //: org_code создателя предложения(контрагента 1)
            public string delivery_term { get; set; } // :значение условий поставки
            public float? epi_price { get; set; }
            public float? td_price { get; set; }
            public string epi_price_currency { get; set; }
            public string td_price_currency { get; set; }
            public string comments { get; set; } //: строка, примечания
            public string invites { get; set; } //: [1, 23,..., 55]
            public List<Product> product { get; set; }
        }

        public class PostBC
        {
            public int broker_offer_id { get; set; }
            public string comment { get; set; }
            public string contract_id { get; set; }
            public string bc_number { get; set; } 
            public string bc_city { get; set; } 
            public float? bc_penalty_amount { get; set; }
            public DateTime? bc_date { get; set; }
            public string owner { get; set; }
            public string broker { get; set; } 
            public string bc_agreement { get; set; }
            public string bc_currency { get; set; }
            public string bc_trial_city { get; set; }
            public string bc_trial_language { get; set; }
            public comp owner_info { get; set; }
            public comp broker_info { get; set; }
        }
        public string GetBrokers(string guid)
        {
            lock (Provider.Locker)
            {
                string query = "SELECT org_code, org_name, org_id FROM organizations WHERE org_is_broker = 1";
                var reader = Provider.RunQuery(query);
                var couriers = new List<Firm>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Firm();
                        rep.org_code = reader["org_code"].ToString();
                        rep.org_name = reader["org_name"].ToString();
                        couriers.Add(rep);
                    }
                    reader.Close();
                    return JsonConvert.SerializeObject(couriers);
                }
                else return "";
            }
        }

        public string getFullOffers()
        {
            string user = User.Identity.GetUserId();
            List<OfferGroup> groups = new List<OfferGroup>();
            // offers created by me
            var query = $"SELECT t1.*, t2.contract_search_subj_country, t2.contract_search_subj_name, t3.org_id, " +
                $"t4.org_name, t7.org_name as target_name FROM attis_contract_offers t1 LEFT JOIN contract_searches t2 ON t1.attis_contract_id = t2.contract_search_contract" +
                $" LEFT JOIN persons t3 ON t1.attis_contract_offer_subj = t3.user_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                $" LEFT JOIN attis_contracts t5 on t5.attis_contract_id = t1.attis_contract_id" +
                $" LEFT JOIN persons t6 on t6.user_id = t5.attis_contract_owner" +
                $" LEFT JOIN organizations t7 on t7.org_id = t6.org_id " +
                $"WHERE t1.attis_contract_offer_subj = '{user}';";


            groups.Add(getOfferGroup(query));

            // offers created for me
            query = $"SELECT t1.*, t2.contract_search_subj_country, t2.contract_search_subj_name, t3.org_id, " +
                    $"t4.org_name, t7.org_name as target_name FROM attis_contract_offers t1 LEFT JOIN contract_searches t2 ON t1.attis_contract_id = t2.contract_search_contract" +
                    $" LEFT JOIN persons t3 ON t1.attis_contract_offer_subj = t3.user_id LEFT JOIN organizations t4 ON t3.org_id = t4.org_id " +
                    $" LEFT JOIN attis_contracts t5 on t5.attis_contract_id = t1.attis_contract_id" +
                    $" LEFT JOIN persons t6 on t6.user_id = t5.attis_contract_owner" +
                    $" LEFT JOIN organizations t7 on t7.org_id = t6.org_id " +
                    $"WHERE t5.attis_contract_owner = '{user}';";

            groups.Add(getOfferGroup(query));

            
            FullOffers fullOffers = new FullOffers();
            fullOffers.contract_offer_groups = groups;
            return JsonConvert.SerializeObject(fullOffers);
        }

        public string getAllCourierOffers()
        {
            string user = User.Identity.GetUserId();
            lock (Provider.Locker)
            {
                string query = $"SELECT o.org_code FROM organizations o INNER JOIN persons p on p.org_id = o.org_id WHERE p.user_id = '{user}'";
                var orgCode = Provider.RunQueryStr(query);

                query = $"SELECT t1.*, t2.accepted, t2.price, t2.price_currency, t2.date_of_load as loadingDate, t2.date_of_delivery as deliveryDate, t2.comments as notes, t3.org_name as cont1, t4.org_name as cont2, t4.org_code as orc2 FROM courier_requests t1 LEFT JOIN courier_invite t2 ON t1.id=t2.req_id LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code WHERE t4.org_code = '{orgCode}';";
 
                var reader = Provider.RunQuery(query);
                var couriers = new List<CourierOffer>();

                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new CourierOffer
                        {
                            ID = reader["id"].ToString(),
                        };
                        rep.is_accepted = reader.GetFieldValueOrDefault<bool>("accepted");
                        rep.countragent_1 = new Countragent1();
                        rep.countragent_1.org_code = reader["countragent_1"].ToString();
                        rep.countragent_1.org_name = reader["cont1"].ToString();
                        rep.countragent_2 = new Countragent2();
                        rep.countragent_2.org_name = reader["cont2"].ToString();
                        rep.countragent_2.org_code = reader["orc2"].ToString();
                        rep.type_of_movement = reader["type_of_movement"].ToString();
                        rep.from_address = reader["from_address"].ToString();
                        rep.to_address = reader["to_address"].ToString();
                        rep.weight = reader.GetFieldValueOrDefault<float>("weight");
                        rep.volume = reader.GetFieldValueOrDefault<float>("volume");
                        rep.delivery_price = reader.GetFieldValueOrDefault<float>("price");
                        rep.delivery_price_currency = reader["price_currency"].ToString();
                        //rep.packaging = reader["shipping_cost"].ToString();
                        rep.date_of_load = reader["loadingDate"].ToString();
                        rep.date_of_delivery = reader["deliveryDate"].ToString();
                        rep.hazard_class = reader["hazard_class"].ToString();
                        rep.comments = reader["notes"].ToString();
                        rep.offer_date = reader["offer_date"].ToString();
                        rep.packaging = reader["packaging"].ToString();
                        //new
                        rep.cancel_term = reader["cancel_term"].ToString();
                        rep.consent_term = reader["consent_term"].ToString();
                        rep.inform_term = reader["inform_term"].ToString();
                        rep.location_term = reader["location_term"].ToString();
                        rep.fuel_percent = reader["fuel_percent"].ToString();
                        rep.currency_percent = reader["currency_percent"].ToString();
                        rep.application_term = reader["application_term"].ToString();
                        rep.customs_term = reader["customs_term"].ToString();
                        rep.delay_abroad_term = reader["delay_abroad_term"].ToString();
                        rep.delay_home_term = reader["delay_home_term"].ToString();
                        rep.courier_cis_delay_amount = reader["courier_cis_delay_amount"].ToString();
                        rep.customer_cis_delay_amount = reader["customer_cis_delay_amount"].ToString();
                        rep.courier_eu_delay_amount = reader["courier_eu_delay_amount"].ToString();
                        rep.customer_eu_delay_amount = reader["customer_eu_delay_amount"].ToString();
                        rep.courier_declination_percent = reader["courier_declination_percent"].ToString();
                        rep.penalty_percent = reader["penalty_percent"].ToString();
                        rep.penalty_never_more = reader["penalty_never_more"].ToString();
                        rep.customer_declination_percent = reader["customer_declination_percent"].ToString();
                        rep.act_term = reader["act_term"].ToString();
                        rep.repeats_term = reader["repeats_term"].ToString();
                        rep.force_major_term = reader["force_major_term"].ToString();
                        rep.claim_term = reader["claim_term"].ToString();
                        rep.resolve_term = reader["resolve_term"].ToString();
                        rep.contract_term = reader["contract_term"].ToString();
                        rep.contract_cancel_term = reader["contract_cancel_term"].ToString();
                        rep.is_signed_by_owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                        rep.is_signed_by_courier = reader.GetFieldValueOrDefault<bool>("is_signed_by_courier");

                        if (!String.IsNullOrEmpty(reader["countragent"].ToString())) {
                            rep.is_selected = true;
                        }
                        couriers.Add(rep);
                    }
                    reader.Close();
                    foreach (var cour in couriers)
                    {
                        query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{cour.ID}' and doc_widget_id ='courier'";
                        reader = Provider.RunQuery(query);
                        var files = new List<Kfiles>();
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                var rep = new Kfiles
                                {
                                    id = reader["id"].ToString(), //"/picture/getfile/"
                                };
                                rep.name = reader["img_file_name"].ToString();
                                files.Add(rep);
                            }
                            reader.Close();
                        }
                        cour.files = new List<Kfiles>(files);
                    }
                    return JsonConvert.SerializeObject(couriers);
                }
                return "";
            }
        }

        public string getAllBrokerOffers()
        {
            string user = User.Identity.GetUserId();
            lock (Provider.Locker)
            {
                string query = $"SELECT o.org_code FROM organizations o INNER JOIN persons p on p.org_id = o.org_id WHERE p.user_id = '{user}'";
                var orgCode = Provider.RunQueryStr(query);

                query = $"SELECT t1.*, t2.*, t2.id as inviteId, t2.td_price as tdp, t2.epi_price as epp, t2.comment as note, t3.org_name as cont1, " +
                $"t4.org_name as cont2, t4.org_code as orc2,t5.* FROM broker_requests t1 LEFT JOIN broker_invite t2 ON t1.id=t2.req_id " +
                $"LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code LEFT JOIN broker_contract t5 on CAST ( t5.contract_id AS int ) = t1.contract_id " +
                $"WHERE t4.org_code = '{orgCode}' ORDER BY t2.td_price ASC, t2.epi_price;";

         
                var reader = Provider.RunQuery(query);
                var brokers = new List<BrokerOffer>();

                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new BrokerOffer
                        {
                            ID = reader["inviteId"].ToString(),
                        };
                        rep.is_accepted = reader.GetFieldValueOrDefault<bool>("accepted");
                        rep.countragent_1 = new Countragent1();
                        rep.countragent_1.org_code = reader["countragent_1"].ToString();
                        rep.countragent_1.org_name = reader["cont1"].ToString();
                        rep.countragent_2 = new Countragent2();
                        rep.countragent_2.org_name = reader["cont2"].ToString();
                        rep.countragent_2.org_code = reader["orc2"].ToString();
                        rep.delivery_term = reader["delivery_term"].ToString();
                        rep.epi_price = reader.GetFieldValueOrDefault<float>("epp");
                        rep.td_price = reader.GetFieldValueOrDefault<float>("tdp");
                        rep.epi_price_currency = reader["epi_currency"].ToString();
                        //rep.packaging = reader["shipping_cost"].ToString();
                        rep.td_price_currency = reader["td_currency"].ToString();
                        rep.comments = reader["note"].ToString();
                        rep.offer_date = reader["offer_date"].ToString();
                        rep.contract_id = reader["contract_id"].ToString();

                        if (!String.IsNullOrEmpty(reader["countragent"].ToString()))
                        {
                            rep.is_selected = true;
                        }

                        if ((bool)rep.is_accepted)
                        {
                            
                            rep.bc_number = reader["bc_number"].ToString();
                            rep.bc_city = reader["bc_city"].ToString();
                            rep.bc_date = GetDateTimeFromString(reader["bc_date"].ToString()).ToString("yyyy.MM.dd");
                            rep.owner = reader["owner"].ToString();
                            rep.broker = reader["broker"].ToString();
                            rep.bc_agreement = reader["agreement"].ToString();
                            rep.bc_penalty_amount = reader.GetFieldValueOrDefault<float>("penalty_amount");
                            rep.bc_currency = reader["currency"].ToString();
                            rep.bc_trial_city = reader["trial_city"].ToString();
                            rep.bc_trial_language = reader["trial_language"].ToString();
                            rep.is_signed_by_broker = reader.GetFieldValueOrDefault<bool>("is_signed_by_broker");
                            rep.is_signed_by_owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                        }



                        brokers.Add(rep);
                    }
                    reader.Close();

                    foreach (var cour in brokers)
                    {
                        query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{cour.ID}' and doc_widget_id ='broker'";
                        reader = Provider.RunQuery(query);
                        var files = new List<Kfiles>();
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                var rep = new Kfiles
                                {
                                    id = reader["id"].ToString(), //"/picture/getfile/"
                                };
                                rep.name = reader["img_file_name"].ToString();
                                files.Add(rep);
                            }
                            reader.Close();
                        }

                        var query1 = $"SELECT attis_cg_good_name, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{cour.contract_id}'";
                        var reader1 = Provider.RunQuery(query1);
                        var product = new List<Product>();
                        if (reader1 != null)
                        {
                            while (reader1.Read())
                            {
                                var rep1 = new Product
                                {
                                    attis_cg_good_name = reader1["attis_cg_good_name"].ToString(),
                                };
                                rep1.attis_cg_TNVED = reader1["attis_cg_TNVED"].ToString();
                                rep1.attis_cg_quantity = reader1["attis_cg_quantity"].ToString();
                                rep1.attis_cg_measures = reader1["attis_cg_measures"].ToString();
                                rep1.attis_cg_price = reader1["attis_cg_price"].ToString();
                                product.Add(rep1);
                            }
                            reader1.Close();
                        }
                        cour.files = new List<Kfiles>(files);
                        cour.products = new List<Product>(product);
                    }
                    var settings = new JsonSerializerSettings
                    {
                        DateFormatString = "yyyy-MM-dd",
                        DateTimeZoneHandling = DateTimeZoneHandling.Utc
                    };
                    return JsonConvert.SerializeObject(brokers);
                }
                return "";
            }
        }

        // brok todo
        public string getBrokerOffers(string contract_id)
        {
            lock (Provider.Locker)
            {
                string user = User.Identity.GetUserId();
                string query = $"SELECT o.org_is_broker, o.org_code, c.attis_contract_owner FROM persons p INNER JOIN organizations o on p.org_id = o.org_id INNER JOIN attis_contracts c on c.attis_contract_id = '{contract_id}' WHERE p.user_id = '{user}'";
                var reader = Provider.RunQuery(query);
                string ownerId = String.Empty;
                string orgCode = String.Empty;
                int isBroker = 0;
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        ownerId = reader["attis_contract_owner"].ToString();
                        orgCode = reader["org_code"].ToString();
                        isBroker = reader.GetFieldValueOrDefault<int>("org_is_broker");
                    }
                    reader.Close();
                }
                if (ownerId == user)
                {
                    query = $"SELECT t1.*, t2.*, t2.id as inviteId, t2.td_price as tdp, t2.epi_price as epp, t2.comment as note, t3.org_name as cont1, " +
                    $"t4.org_name as cont2, t4.org_code as orc2,t5.* FROM broker_requests t1 LEFT JOIN broker_invite t2 ON t1.id=t2.req_id " +
                    $"LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code LEFT JOIN broker_contract t5 on t5.contract_id = '{contract_id}'" +
                    $"WHERE t1.contract_id = '{contract_id}' ORDER BY t2.td_price ASC, t2.epi_price;";
                }
                else
                {
                    query = $"SELECT t1.*, t2.*, t2.id as inviteId, t2.td_price as tdp, t2.epi_price as epp, t2.comment as note, t3.org_name as cont1, " +
                    $"t4.org_name as cont2, t4.org_code as orc2,t5.* FROM broker_requests t1 LEFT JOIN broker_invite t2 ON t1.id=t2.req_id " +
                    $"LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code LEFT JOIN broker_contract t5 on t5.contract_id = '{contract_id}'" +
                    $"WHERE t1.contract_id = '{contract_id}' and t4.org_code = '{orgCode}' ORDER BY t2.td_price ASC, t2.epi_price;";
                    
                }
                reader = Provider.RunQuery(query);
                var brokers = new List<BrokerOffer>();

                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new BrokerOffer
                        {
                            ID = reader["inviteId"].ToString(),
                        };
                        rep.is_accepted = reader.GetFieldValueOrDefault<bool>("accepted");
                        rep.countragent_1 = new Countragent1();
                        rep.countragent_1.org_code = reader["countragent_1"].ToString();
                        rep.countragent_1.org_name = reader["cont1"].ToString();
                        rep.countragent_2 = new Countragent2();
                        rep.countragent_2.org_name = reader["cont2"].ToString();
                        rep.countragent_2.org_code = reader["orc2"].ToString();
                        rep.delivery_term = reader["delivery_term"].ToString();
                        rep.epi_price = reader.GetFieldValueOrDefault<float>("epp");
                        rep.td_price = reader.GetFieldValueOrDefault<float>("tdp");
                        rep.epi_price_currency = reader["epi_currency"].ToString();
                        //rep.packaging = reader["shipping_cost"].ToString();
                        rep.td_price_currency = reader["td_currency"].ToString();
                        rep.comments = reader["note"].ToString();
                        rep.offer_date = reader["offer_date"].ToString();
                        
                        if ((bool)rep.is_accepted)
                        {
                            rep.contract_id = contract_id;
                            rep.bc_number = reader["bc_number"].ToString();
                            rep.bc_city = reader["bc_city"].ToString();
                            rep.bc_date = GetDateTimeFromString(reader["bc_date"].ToString()).ToString("yyyy.MM.dd");
                            rep.owner = reader["owner"].ToString();
                            rep.broker = reader["broker"].ToString();
                            rep.bc_agreement = reader["agreement"].ToString();
                            rep.bc_penalty_amount = reader.GetFieldValueOrDefault<float>("penalty_amount");
                            rep.bc_currency = reader["currency"].ToString();
                            rep.bc_trial_city = reader["trial_city"].ToString();
                            rep.bc_trial_language = reader["trial_language"].ToString();
                            rep.is_signed_by_broker = reader.GetFieldValueOrDefault<bool>("is_signed_by_broker");
                            rep.is_signed_by_owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                        }

                        

                        brokers.Add(rep);
                    }
                    reader.Close();

                    foreach (var cour in brokers)
                    {
                        query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{cour.ID}' and doc_widget_id ='broker'";
                        reader = Provider.RunQuery(query);
                        var files = new List<Kfiles>();
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                var rep = new Kfiles
                                {
                                    id = reader["id"].ToString(), //"/picture/getfile/"
                                };
                                rep.name = reader["img_file_name"].ToString();
                                files.Add(rep);
                            }
                            reader.Close();
                        }

                    var query1 = $"SELECT attis_cg_good_name, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{contract_id}'";
                        var reader1 = Provider.RunQuery(query1);
                        var product = new List<Product>();
                        if (reader1 != null)
                        {
                            while (reader1.Read())
                            {
                                var rep1 = new Product
                                {
                                    attis_cg_good_name = reader1["attis_cg_good_name"].ToString(),
                                };
                                rep1.attis_cg_TNVED = reader1["attis_cg_TNVED"].ToString();
                                rep1.attis_cg_quantity = reader1["attis_cg_quantity"].ToString();
                                rep1.attis_cg_measures = reader1["attis_cg_measures"].ToString();
                                rep1.attis_cg_price = reader1["attis_cg_price"].ToString();
                                product.Add(rep1);
                            }
                            reader1.Close();
                        }
                        cour.files = new List<Kfiles>(files);
                        cour.products = new List<Product>(product);
                    }
                    var settings = new JsonSerializerSettings
                    {
                        DateFormatString = "yyyy-MM-dd",
                        DateTimeZoneHandling = DateTimeZoneHandling.Utc
                    };
                    return JsonConvert.SerializeObject(brokers, settings);
                }
                return "";
            }
        }

        public string getBrokerOfferXml(string contract_id)
        {
            var query = $"SELECT t1.*, t2.*, t2.id as inviteId, t2.td_price as tdp, t2.epi_price as epp, t2.comment as note, t3.org_name as cont1, " +
                $"t4.org_name as cont2, t4.org_code as orc2,t5.* " +
                $"FROM broker_requests t1 LEFT JOIN broker_invite t2 ON t1.id=t2.req_id LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code LEFT JOIN broker_contract t5 on t5.contract_id = '{contract_id}' WHERE t1.contract_id='{contract_id}' and countragent is not null and t2.org_id = t1.countragent;";
            var reader = Provider.RunQuery(query);
            var rep = new BrokerOffer();
            if (reader != null)
            {

                while (reader.Read())
                {

                    rep.ID = reader["inviteId"].ToString();
                    rep.is_accepted = reader.GetFieldValueOrDefault<bool>("accepted");
                    rep.countragent_1 = new Countragent1();
                    rep.countragent_1.org_code = reader["countragent_1"].ToString();
                    rep.countragent_1.org_name = reader["cont1"].ToString();
                    rep.countragent_2 = new Countragent2();
                    rep.countragent_2.org_name = reader["cont2"].ToString();
                    rep.countragent_2.org_code = reader["orc2"].ToString();
                    rep.delivery_term = reader["delivery_term"].ToString();
                    rep.epi_price = reader.GetFieldValueOrDefault<float>("epp");
                    rep.td_price = reader.GetFieldValueOrDefault<float>("tdp");
                    rep.epi_price_currency = reader["epi_currency"].ToString();
                    //rep.packaging = reader["shipping_cost"].ToString();
                    rep.td_price_currency = reader["td_currency"].ToString();
                    rep.comments = reader["comments"].ToString();
                    rep.offer_date = reader["offer_date"].ToString();
                    rep.contract_id = contract_id;
                    rep.bc_number = reader["bc_number"].ToString();
                    rep.bc_city = reader["bc_city"].ToString();
                    rep.bc_date = GetDateTimeFromString(reader["bc_date"].ToString()).ToString("yyyy.MM.dd");
                    rep.owner = reader["owner"].ToString();
                    rep.broker = reader["broker"].ToString();
                    rep.bc_agreement = reader["agreement"].ToString();
                    rep.bc_penalty_amount = reader.GetFieldValueOrDefault<float>("penalty_amount");
                    rep.bc_currency = reader["currency"].ToString();
                    rep.bc_trial_city = reader["trial_city"].ToString();
                    rep.bc_trial_language = reader["trial_language"].ToString();
                }
            }
            reader.Close();
            if (rep != null)
            {
                query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{rep.ID}' and doc_widget_id ='broker'";
                reader = Provider.RunQuery(query);
                var files = new List<Kfiles>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var file = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        file.name = reader["img_file_name"].ToString();
                        files.Add(file);
                    }
                    reader.Close();
                }
                rep.files = new List<Kfiles>(files);
                XmlSerializer xsSubmit = new XmlSerializer(typeof(BrokerOffer));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, rep);
                        xml = sww.ToString();
                    }
                }
                return xml;
            }
            else return "{}";
        }

        public string getCourierOfferXml(string contract_id)
        {
            var query = $"SELECT t1.*, t2.accepted, t2.price, t2.price_currency, t2.date_of_load as loadingDate, t2.date_of_delivery as deliveryDate, t2.comments as notes, t3.org_name as cont1, t4.org_name as cont2, t4.org_code as orc2 FROM courier_requests t1 LEFT JOIN courier_invite t2 ON t1.id=t2.req_id LEFT JOIN organizations t3 ON t1.countragent_1 = t3.org_code LEFT JOIN organizations t4 ON t2.org_id = t4.org_code WHERE t1.contract_id = '{contract_id}' and countragent is not null and t2.org_id = t1.countragent;";
            var reader = Provider.RunQuery(query);
            var rep = new CourierOffer();
            if (reader != null)
            {
                while (reader.Read())
                {
                    rep.ID = reader["id"].ToString();
                    rep.is_accepted = reader.GetFieldValueOrDefault<bool>("accepted");
                    rep.countragent_1 = new Countragent1();
                    rep.countragent_1.org_code = reader["countragent_1"].ToString();
                    rep.countragent_1.org_name = reader["cont1"].ToString();
                    rep.countragent_2 = new Countragent2();
                    rep.countragent_2.org_name = reader["cont2"].ToString();
                    rep.countragent_2.org_code = reader["orc2"].ToString();
                    rep.type_of_movement = reader["type_of_movement"].ToString();
                    rep.from_address = reader["from_address"].ToString();
                    rep.to_address = reader["to_address"].ToString();
                    rep.weight = reader.GetFieldValueOrDefault<float>("weight");
                    rep.volume = reader.GetFieldValueOrDefault<float>("volume");
                    rep.delivery_price = reader.GetFieldValueOrDefault<float>("price");
                    rep.delivery_price_currency = reader["price_currency"].ToString();
                    //rep.packaging = reader["shipping_cost"].ToString();
                    rep.date_of_load = reader["loadingDate"].ToString();
                    rep.date_of_delivery = reader["deliveryDate"].ToString();
                    rep.hazard_class = reader["hazard_class"].ToString();
                    rep.comments = reader["notes"].ToString();
                    rep.offer_date = reader["offer_date"].ToString();
                    rep.packaging = reader["packaging"].ToString();
                    //new
                    rep.cancel_term = reader["cancel_term"].ToString();
                    rep.consent_term = reader["consent_term"].ToString();
                    rep.inform_term = reader["inform_term"].ToString();
                    rep.location_term = reader["location_term"].ToString();
                    rep.fuel_percent = reader["fuel_percent"].ToString();
                    rep.currency_percent = reader["currency_percent"].ToString();
                    rep.application_term = reader["application_term"].ToString();
                    rep.customs_term = reader["customs_term"].ToString();
                    rep.delay_abroad_term = reader["delay_abroad_term"].ToString();
                    rep.delay_home_term = reader["delay_home_term"].ToString();
                    rep.courier_cis_delay_amount = reader["courier_cis_delay_amount"].ToString();
                    rep.customer_cis_delay_amount = reader["customer_cis_delay_amount"].ToString();
                    rep.courier_eu_delay_amount = reader["courier_eu_delay_amount"].ToString();
                    rep.customer_eu_delay_amount = reader["customer_eu_delay_amount"].ToString();
                    rep.courier_declination_percent = reader["courier_declination_percent"].ToString();
                    rep.penalty_percent = reader["penalty_percent"].ToString();
                    rep.penalty_never_more = reader["penalty_never_more"].ToString();
                    rep.customer_declination_percent = reader["customer_declination_percent"].ToString();
                    rep.act_term = reader["act_term"].ToString();
                    rep.repeats_term = reader["repeats_term"].ToString();
                    rep.force_major_term = reader["force_major_term"].ToString();
                    rep.claim_term = reader["claim_term"].ToString();
                    rep.resolve_term = reader["resolve_term"].ToString();
                    rep.contract_term = reader["contract_term"].ToString();
                    rep.contract_cancel_term = reader["contract_cancel_term"].ToString();
                }
            }
            reader.Close();
            if (rep != null)
            {
                query = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{rep.ID}' and doc_widget_id ='courier'";
                reader = Provider.RunQuery(query);
                var files = new List<Kfiles>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var file = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        file.name = reader["img_file_name"].ToString();
                        files.Add(file);
                    }
                    reader.Close();
                }
                rep.files = new List<Kfiles>(files);
                XmlSerializer xsSubmit = new XmlSerializer(typeof(CourierOffer));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, rep);
                        xml = sww.ToString();
                    }
                }
                return xml;
            }
            else return "{}";
        }

        [HttpPost]
        public string offerBrokerPrice(int broker_offer_id, float td_price, float epi_price)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);

            query = $"UPDATE broker_invite SET (td_price, epi_price)=('{td_price}','{epi_price}') WHERE org_id='{org_code}' AND req_id ='{broker_offer_id}'";
            Provider.RunNonQuery(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.BrokerOfferPrice}', '{LogOffer.BrokerOfferPrice}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            log.Info("broker price offer " + user + JsonConvert.SerializeObject(broker_offer_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.BrokerOfferPrice}', '{LogOffer.BrokerOfferPrice}', '{LogSection.Offer}', '{user}', '', '{broker_offer_id}', '{JsonConvert.SerializeObject(broker_offer_id)}', 0);";
            Provider.RunNonQuery(query);
            return "ok";
        }

        [HttpPost]
        public string acceptBrokerOffer(PostBC contract, float? td_price, string td_price_currency, float? epi_price, string epi_price_currency)
        {
            int broker_offer_id = contract.broker_offer_id;
            string comment = contract.comment;
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);

            query = $"UPDATE broker_invite SET accepted=true, td_price={td_price}, epi_price={epi_price}, td_currency='{td_price_currency}', epi_currency='{epi_price_currency}', comment='{comment}' WHERE org_id='{org_code}' AND id ='{broker_offer_id}' RETURNING req_id";
            var req_id = Provider.RunScalar(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.AcceptBrokerOffer}', '{LogOffer.AcceptBrokerOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            //query = $"UPDATE broker_requests SET td_price = {td_price}, td_price_currency = {td_price_currency}, epi_price = {epi_price}, epi_price_currency={epi_price_currency} WHERE id = {req_id}";
            //Provider.RunNonQuery(query);
            //if (!Provider.lastError.IsEmpty())
            //{
            //    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            //    $"VALUES('NOW()', '{(int)LogOffer.AcceptBrokerOffer}', '{LogOffer.AcceptBrokerOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
            //    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
            //    return "{\"status\":\"error " + Provider.lastError + "\"}";
            //}
            var usrs = new List<string>();
            string contract_id = "";
            query = $"SELECT t2.user_id, t3.contract_id FROM broker_requests t3 LEFT JOIN organizations t1 ON t3.countragent_1 = t1.org_code LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t3.id={req_id}";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    string usr = reader["user_id"].ToString();
                    contract_id = reader["contract_id"].ToString();
                    usrs.Add(usr);
                }
                reader.Close();
            }
            if (!addBrokerContract(contract))
            {
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            foreach (var usr in usrs)
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.BrokerAccept,
                    CreatorId = user,
                    RecipientId = usr,
                    CreationDate = DateTime.Now,
                    ObjectId = broker_offer_id,
                    Comment = contract_id
                });
                SendEmailNotification(usr, (int)NotificationType.CourierSelect, contract_id, broker_offer_id);
            }
            log.Info("accept broker offer " + user + JsonConvert.SerializeObject(broker_offer_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.AcceptBrokerOffer}', '{LogOffer.AcceptBrokerOffer}', '{LogSection.Offer}', '{user}', '', '{broker_offer_id}', '{JsonConvert.SerializeObject(broker_offer_id)}', 0);";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}"; ;
        }

        [HttpPost]
        public string declineBrokerOffer(int broker_offer_id, string comment)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);
            var usrs = new List<string>();
            //query = $"SELECT countragent_1 FROM courier_requests WHERE id='{courier_offer_id}';";
            //var contr1 = Provider.RunQueryStr(query);
            //query = $"SELECT t2.user_id FROM organizations t1 LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t1.org_code = '{contr1}';"; //item
            query = $"SELECT t2.user_id, t3.contract_id FROM broker_requests t3 LEFT JOIN organizations t1 ON t3.countragent_1 = t1.org_code LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t3.id={broker_offer_id}";
            var reader = Provider.RunQuery(query);
            string contract_id = "";
            if (reader != null)
            {
                while (reader.Read())
                {
                    string usr = reader["user_id"].ToString();
                    contract_id = reader["contract_id"].ToString();
                    usrs.Add(usr);
                }
                reader.Close();
            }
            foreach (var usr in usrs)
            {
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.BrokerDecline,
                    CreatorId = user,
                    RecipientId = usr,
                    CreationDate = DateTime.Now,
                    ObjectId = broker_offer_id,
                    Comment = contract_id
                });
                SendEmailNotification(usr, (int)NotificationType.CourierSelect, contract_id, broker_offer_id);
            }

            query = $"UPDATE broker_invite SET accepted=false WHERE org_id='{org_code}' AND req_id ='{broker_offer_id}'";
            Provider.RunNonQuery(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.DeclineBrokerOffer}', '{LogOffer.DeclineBrokerOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            log.Info("decline broker offer " + user + JsonConvert.SerializeObject(broker_offer_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.DeclineBrokerOffer}', '{LogOffer.DeclineBrokerOffer}', '{LogSection.Offer}', '{user}', '', '{broker_offer_id}', '{JsonConvert.SerializeObject(broker_offer_id)}', 0);";
            Provider.RunNonQuery(query);
            return "{\"status\":\"ok\"}";
        }

        [HttpPost]
        public string selectBrokerOffer(string broker_id, int broker_offer_id, int contract_id)
        {
            string user = User.Identity.GetUserId();

            string query = $"SELECT user_id FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE org_code ='{broker_id}'";
            var usr = Provider.RunQueryStr(query);
            query = $"UPDATE broker_requests SET countragent='{broker_id}' WHERE contract_id='{contract_id}';";
            Provider.RunNonQuery(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.SelectBrokerOffer}', '{LogOffer.SelectBrokerOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            NotificationHelper.AddNotification(new Notification()
            {
                Type = NotificationType.BrokerSelect,
                CreatorId = user,
                RecipientId = usr,
                CreationDate = DateTime.Now,
                ObjectId = broker_offer_id,
                Comment = contract_id.ToString()
            });
            SendEmailNotification(usr, (int)NotificationType.NewBrokerOffer, contract_id.ToString(), broker_offer_id);
            log.Info("select broker offer " + user + JsonConvert.SerializeObject(broker_offer_id));
            query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.NewBrokerOffer}', '{LogOffer.NewBrokerOffer}', '{LogSection.Offer}', '{user}', '{usr}', '{contract_id}', '{JsonConvert.SerializeObject(broker_offer_id)}', 0);";
            Provider.RunNonQuery(query);
            return "{\"status\":200}";
        }

        [HttpPost]
        public string createBrokerRequest(PostBroker post)
        {
            string user = User.Identity.GetUserId();
            var r = new List<ImageFile>();
            if (String.IsNullOrEmpty(user)) return "login first";

            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var org_code = Provider.RunQueryStr(query);

            query = $"INSERT INTO broker_requests (contract_id, countragent_1, delivery_term, epi_price, td_price, epi_price_currency, " +
                $" td_price_currency, comments, invites, offer_date)" +
    $" VALUES ('{post.contract_id}', '{org_code}', '{post.delivery_term}', '{post.epi_price.GetValueOrDefault()}', '{post.td_price.GetValueOrDefault()}'," +
    $" '{post.epi_price_currency}', '{post.td_price_currency}', '{post.comments}', '{post.invites}', now() ) RETURNING id;";
            var cd = Provider.RunScalar(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogOffer.NewBrokerOffer}', '{LogOffer.NewBrokerOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                // string savedFileName = Path.Combine(Server.MapPath("~/App_Data"), Path.GetFileName(hpf.FileName));
                // hpf.SaveAs(savedFileName);
                var imgFile = new ImageFile
                {
                    ID = 0,
                    EntityId = cd.ToString(),
                    Name = hpf.FileName,
                    Length = hpf.ContentLength,
                    Type = hpf.ContentType,
                    Date = DateTime.Now,
                    Image = new MemoryStream(),
                    WidgetId = "broker"
                };

                hpf.InputStream.CopyTo(imgFile.Image);

                Provider.SaveFile(imgFile);

                r.Add(imgFile);
            }

            if (post.product != null)
                foreach (var ln in post.product)
                {
                    query = $"INSERT INTO broker_goods (attis_cg_contract_id, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price) " +
                    $"VALUES('{cd}', '{ln.attis_cg_good_name}', '{ln.attis_cg_TNVED}', '{ln.attis_cg_quantity}', '{ln.attis_cg_measures}', '{ln.attis_cg_price}');";
                    Provider.RunNonQuery(query);
                }

            string[] inv = post.invites.Split(',');
            foreach (var item in inv)
            {
                query = $"INSERT INTO broker_invite (org_id, req_id, epi_price, td_price, epi_currency, td_currency, comment) VALUES ('{item}', '{cd}', '{post.epi_price.GetValueOrDefault()}', '{post.td_price.GetValueOrDefault()}', '{post.epi_price_currency}', '{post.td_price_currency}', '{post.comments}')"; //item
                Provider.RunNonQuery(query);
                query = $"SELECT t2.user_id FROM organizations t1 LEFT JOIN persons t2 ON t1.org_id = t2.org_id WHERE t1.org_code = '{item}';"; //item
                var usr = Provider.RunQueryStr(query);
                NotificationHelper.AddNotification(new Notification()
                {
                    Type = NotificationType.NewBrokerOffer,
                    CreatorId = user,
                    RecipientId = usr,
                    CreationDate = DateTime.Now,
                    ObjectId = cd,
                    Comment = post.contract_id
                });
                SendEmailNotification(usr, (int)NotificationType.NewBrokerOffer, post.contract_id, cd);
            }
            if (cd > 0) {
                log.Info("new broker offer " + user + JsonConvert.SerializeObject(post));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogOffer.NewBrokerOffer}', '{LogOffer.NewBrokerOffer}', '{LogSection.Offer}', '{user}', '{inv}', '{post.contract_id}', '{JsonConvert.SerializeObject(post)}', 0);";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\"}";
            }
            //return Json("ok");
            //else return Json("error " + cd);
            else
            {
                if (!Provider.lastError.IsEmpty())
                {
                    query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogOffer.NewBrokerOffer}', '{LogOffer.NewBrokerOffer}', '{LogSection.Offer}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                return "{\"status\":\"error " + cd + "\"}";
            }
        }

        public bool addBrokerContract(PostBC post)
        {
            string user = User.Identity.GetUserId();
            //if (String.IsNullOrEmpty(user)) return "login first";

            //string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            //var org_code = Provider.RunQueryStr(query);

            var date = String.Empty;
            if (post.bc_date != null)
                date = "bc_date = '" + ((DateTime)post.bc_date).ToString("yyyy.MM.dd") + "'";

            var query = $"INSERT INTO broker_contract (contract_id, bc_number, bc_city, owner,	broker, agreement, penalty_amount, " +
                $"currency, trial_city, trial_language)" +
    $" VALUES ('{post.contract_id}', '{post.bc_number}', '{post.bc_city}', '{post.owner}', '{post.broker}', '{post.bc_agreement}'," +
    $" '{post.bc_penalty_amount.GetValueOrDefault()}', '{post.bc_currency}', '{post.bc_trial_city}', '{post.bc_trial_language}') RETURNING id;";
            var cd = Provider.RunScalar(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogContract.NewBrokerContract}', '{LogContract.NewBrokerContract}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return false;
            }
            else
            {
                if (!String.IsNullOrEmpty(date))
                {
                    query = $"UPDATE broker_contract set {date} where contract_id = '{post.contract_id}'";
                    Provider.RunNonQuery(query);
                }
                log.Info("new broker contract " + user + JsonConvert.SerializeObject(post));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogContract.NewBrokerContract}', '{LogContract.NewBrokerContract}', '{LogSection.Contract}', '{user}', '{post.broker}', '{post.contract_id}', '{JsonConvert.SerializeObject(post)}', 0);";
                Provider.RunNonQuery(query);
                return true;
            }
        }

        [HttpPost]
        public string updateBrokerContract(PostBC post)
        {
            string user = User.Identity.GetUserId();
            if (String.IsNullOrEmpty(user)) return "login first";

            //string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            //var org_code = Provider.RunQueryStr(query);

            var query = $"UPDATE broker_contract SET (contract_id, bc_number, bc_city,	bc_date, owner,	broker, agreement, penalty_amount, " +
                $"currency, trial_city, trial_language)" +
    $" = ('{post.contract_id}', '{post.bc_number}', '{post.bc_city}', now(), '{post.owner}', '{post.broker}', '{post.bc_agreement}'," +
    $" '{post.bc_penalty_amount.GetValueOrDefault()}', '{post.bc_currency}', '{post.bc_trial_city}', '{post.bc_trial_language}') WHERE id='{post.broker_offer_id}';";
            var cd = Provider.RunScalar(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogContract.UpdateBrokerContract}', '{LogContract.UpdateBrokerContract}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            else
            {
                log.Info("update broker contract " + user + JsonConvert.SerializeObject(post));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogContract.UpdateBrokerContract}', '{LogContract.UpdateBrokerContract}', '{LogSection.Contract}', '{user}', '{post.broker}', '{post.contract_id}', '{JsonConvert.SerializeObject(post)}', 0);";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\"}";
            }
        }

        [HttpPost]
        public string deleteBrokerContract(int id)
        {
            string user = User.Identity.GetUserId();
            if (String.IsNullOrEmpty(user)) return "login first";
            var query = $"DELETE FROM broker_contract WHERE id='{id}';";
            Provider.RunNonQuery(query);
            if (!Provider.lastError.IsEmpty())
            {
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
        $"VALUES('NOW()', '{(int)LogContract.UpdateBrokerContract}', '{LogContract.UpdateBrokerContract}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                Provider.RunNonQuery(query, JsonConvert.SerializeObject(Provider.lastError));
                return "{\"status\":\"error " + Provider.lastError + "\"}";
            }
            else {
                log.Info("delete broker contract " + user + JsonConvert.SerializeObject(id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogContract.UpdateBrokerContract}', '{LogContract.UpdateBrokerContract}', '{LogSection.Contract}', '{user}', '', '{id}', '{JsonConvert.SerializeObject(id)}', 0);";
                Provider.RunNonQuery(query);
                return "{\"status\":\"ok\"}";
            }
        }

        public PostBC getBrokerContract(string contract_id)
        {
            var query = $"SELECT * FROM broker_contract WHERE contract_id='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var list = new PostBC();
            if (reader != null)
            {
                while (reader.Read())
                {
                    //list.broker_offer_id = reader["id"].ToString();
                    list.contract_id = contract_id;
                    list.bc_number = reader["bc_number"].ToString();
                    list.bc_city = reader["bc_city"].ToString();
                    list.bc_date = GetDateTimeFromString(reader["bc_date"].ToString());
                    list.owner = reader["owner"].ToString();
                    list.broker = reader["broker"].ToString();
                    list.bc_agreement = reader["agreement"].ToString();
                    list.bc_penalty_amount = reader.GetFieldValueOrDefault<float>("penalty_amount"); 
                    list.bc_currency = reader["currency"].ToString();
                    list.bc_trial_city = reader["trial_city"].ToString();
                    list.bc_trial_language = reader["trial_language"].ToString();
                }
                reader.Close();
                var dc = new DocumentController();
                list.broker_info = dc.getComp(list.broker);
                list.owner_info = dc.getComp(list.owner);
            }
            return list;
        }
        public class ktzh
        {
            public int contract_id { get; set; }
            public DateTime? for_date { get; set; }
            public string bin { get; set; }
            public string movement_type { get; set; }
            public string participant_type { get; set; }
            public string expeditor { get; set; }
        }

        public class KtzhLog
        {
            public int? id { get; set; }
            public int contract_id { get; set; }
            public string for_date { get; set; }
            public string bin { get; set; }
            public string movement_type { get; set; }
            public string participant_type { get; set; }
            public string expeditor { get; set; }
        }

        public class eml
        {
            public string email { get; set; }
            public string subject { get; set; }
            [AllowHtml]
            public string message { get; set; }
        }
        /*
        public class Ktzhobject
        {
            public string ID { get; set; }
            public string type { get; set; }
            public string date { get; set; }
            public string file { get; set; }
            public Request request { get; set; }
            public Response response { get; set; }
        }

        public class Request
        {
            public string bin { get; set; }
            public string for_date { get; set; }
            public string movement_type { get; set; }
            public string participant_type { get; set; }
            public string expeditor_code { get; set; }
        }

        public class Response
        {
            public string unique_identifier { get; set; }
            public string expedition_number { get; set; }
            public Sender_Station sender_station { get; set; }
            public string sender_code { get; set; }
            public string cargo_code_etsng { get; set; }
            public string carriage_weight_capability { get; set; }
            public string sap_code { get; set; }
            public string carriage_number { get; set; }
            public string number_of_carriages { get; set; }
            public string cargo_weight { get; set; }
            public string sending_date { get; set; }
            public string container_number { get; set; }
            public International_Connection_Type international_connection_type { get; set; }
        }

        public class Sender_Station
        {
            public int value { get; set; }
            public string display_text { get; set; }
        }

        public class International_Connection_Type
        {
            public string value { get; set; }
            public string display_text { get; set; }
        }
        */
        public string ktzh_log(int contract_id)
        {
            var query = $"SELECT * FROM ktg_log WHERE contract_id='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var list = new List<KtzhLog>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new KtzhLog
                    {
                        contract_id = (int)reader["contract_id"],
                    };
                    rep1.id = (int)reader["id"];
                    rep1.for_date = reader["for_date"].ToString();
                    rep1.bin = reader["bin"].ToString();
                    rep1.movement_type = reader["movement_type"].ToString();
                    rep1.participant_type = reader["participant_type"].ToString();
                    rep1.expeditor = reader["expeditor"].ToString();
                    list.Add(rep1);
                }
                reader.Close();
                return JsonConvert.SerializeObject(list);
            }
            return "{}";
        }        
        
        public string ktzh_log_resp(int contract_id)
        {
            var query = $"SELECT *, t1.rw_naimstan as recive_station_name, t2.rw_naimstan as dest_station_name FROM ktg_response LEFT JOIN rw_stations t1 on CAST(t1.rw_code AS VARCHAR) = recive_station_code LEFT JOIN rw_stations t2 on CAST(t2.rw_code AS VARCHAR) = dest_station_code LEFT JOIN ktg_log t3 on t3.id = request_id  WHERE t3.contract_id='{contract_id}'";// WHERE contract_id='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var list = new List<CSVModel>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new CSVModel
                    {
                        id = (int)reader["id"],
                    }; 
                    rep1.invoice_un = reader["invoice_un"].ToString();
                    rep1.invoice_num = reader["invoice_num"].ToString();
                    rep1.recive_station_code = reader["recive_station_code"].ToString();
                    rep1.dest_station_code = reader["dest_station_code"].ToString();
                    rep1.recive_station_name = reader["recive_station_name"].ToString();
                    rep1.dest_station_name = reader["dest_station_name"].ToString();
                    rep1.sender_exp_no = reader["sender_exp_no"].ToString();
                    rep1.etsng_code = reader["etsng_code"].ToString();
                    rep1.fact_mass = reader.GetFieldValueOrDefault<float>("fact_mass"); 
                    rep1.payer_code = reader["payer_code"].ToString();
                    rep1.vag_no = reader["vag_no"].ToString();
                    rep1.vag_count = reader.GetFieldValueOrDefault<int>("vag_count"); 
                    rep1.gruz = reader.GetFieldValueOrDefault<float>("gruz"); 
                    rep1.invc_dt = GetDateTimeFromString(reader["invc_dt"].ToString());
                    rep1.container_no = reader["container_no"].ToString();
                    rep1.smgs_type = reader.GetFieldValueOrDefault<int>("smgs_type");
                    rep1.request_id= reader["request_id"].ToString();
                    list.Add(rep1);
                }
                reader.Close();
                return JsonConvert.SerializeObject(list);
            }
            return "{}";
        }

        [HttpPost]
        public string post_ktzh_sftp(ktzh post)
        {
            string user = User.Identity.GetUserId();
            //var r = new List<ImageFile>();
            if (String.IsNullOrEmpty(user)) return "login first";
            string aa = DateTime.Now.ToString("yyyy.MM.dd");
            if (post.for_date != null)
                aa = post.for_date?.ToString("yyyy.MM.dd");
            string dat = DateTime.Now.ToString("ddMMyyyy");
            var query = $"INSERT INTO ktg_log (contract_id, for_date, bin, movement_type, participant_type, expeditor) " +
            $" VALUES ('{post.contract_id}', '{aa}', '{post.bin}', '{post.movement_type}', '{post.participant_type}', '{post.expeditor}') RETURNING id;";
            var cl = Provider.RunScalar(query);            
            var cd = FileUploadSFTP(post.bin, post.movement_type, post.participant_type, post.expeditor, dat);
            if (cd.Equals("ok"))
              return "{\"status\":200}";
            return "{\"status\":201}";
            //else return Json("error " + cd);
            //else return "{\"status\":\"error " + cd + "\"}";
        }

        public ActionResult astana_1(int contract_id)
        {
            var query = $"SELECT * FROM attis_contracts WHERE attis_contract_id = '{contract_id}';";
            var reader = Provider.RunQuery(query);
            var sellers = new Sellers();
            if (reader != null)
            {
                while (reader.Read())
                {
                    sellers.attis_contract_id = contract_id;
                    sellers.attis_contract_owner = reader["attis_contract_owner"].ToString();
                    sellers.attis_contract_status = reader["attis_contract_status"].ToString();
                    sellers.attis_contract_type = (int)reader["attis_contract_type"] != 0;
                    sellers.attis_contract_case = (int)reader["attis_contract_case"] != 0;
                    sellers.attis_contract_subject = reader["attis_contract_subject"].ToString();
                    sellers.attis_contract_desc = reader["attis_contract_desc"].ToString();
                    sellers.attis_contract_currency = reader["attis_contract_currency"].ToString();
                    sellers.attis_contract_payment_type = reader["attis_contract_payment_type"].ToString();
                    sellers.attis_contract_delivery_term = reader["attis_contract_delivery_term"].ToString();
                    sellers.attis_contract_delivery_place = reader["attis_contract_delivery_place"].ToString();
                    sellers.attis_contract_date = GetDateTimeFromString(reader["attis_contract_date"].ToString());
                    sellers.attis_contract_deadline = GetDateTimeFromString(reader["attis_contract_deadline"].ToString());
                    sellers.attis_contract_create_date = GetDateTimeFromString(reader["attis_contract_create_date"].ToString());
                    sellers.attis_contract_contragent = reader["attis_contract_contragent"].ToString();
                    sellers.attis_contract_is_public = reader.GetFieldValueOrDefault<int>("attis_contract_is_public");
                    sellers.attis_contract_kpveds = reader["attis_contract_kpveds"].ToString();
                }
                reader.Close();
                //if (sellers.attis_contract_is_public == "False") sellers.attis_contract_is_public = "false"; //else sellers.attis_contract_is_public = "1";
                var query1 = $"SELECT attis_cg_good_name, attis_cg_good_name, \"attis_cg_TNVED\", attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{contract_id}'";
                var reader1 = Provider.RunQuery(query1);
                var product = new List<Product>();
                if (reader1 != null)
                {
                    while (reader1.Read())
                    {
                        var rep1 = new Product
                        {
                            attis_cg_good_name = reader1["attis_cg_good_name"].ToString(),
                        };
                        rep1.attis_cg_TNVED = reader1["attis_cg_TNVED"].ToString();
                        rep1.attis_cg_quantity = reader1["attis_cg_quantity"].ToString();
                        rep1.attis_cg_measures = reader1["attis_cg_measures"].ToString();
                        rep1.attis_cg_price = reader1["attis_cg_price"].ToString();
                        product.Add(rep1);
                    }
                    reader1.Close();
                }
                /*
                query1 = $"SELECT id, img_file_name FROM docimages WHERE doc_guid='{attis_contract_id}' and doc_widget_id ='ktz'";
                reader = Provider.RunQuery(query1);
                var files = new List<Kfiles>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var rep = new Kfiles
                        {
                            id = reader["id"].ToString(), //"/picture/getfile/"
                        };
                        rep.name = reader["img_file_name"].ToString();
                        files.Add(rep);
                    }
                    reader.Close();
                }*/
                sellers.product = new List<Product>(product);

                XmlSerializer xsSubmit = new XmlSerializer(typeof(Sellers));
                var xml = "";

                using (var sww = new StringWriter())
                {
                    using (XmlWriter writer = XmlWriter.Create(sww))
                    {
                        xsSubmit.Serialize(writer, sellers);
                        xml = sww.ToString(); // Your XML
                    }
                }
                //return xml;
                //var file = Provider.GetFileByID(id);
                var contentType = "text/xml";
                var bytes = Encoding.UTF8.GetBytes(xml);
                var result = new FileContentResult(bytes, contentType);
                var fn = DateTime.Now.ToString();
                result.FileDownloadName = "contract" + fn + ".xml";
                return result;
            }
            return null;
        }

        public string d_selector(int contract_id)
        {
            string query = $"SELECT attis_contract_doc_id FROM attis_contract_docs WHERE attis_contract_doc_type='1' and attis_contract_doc_contract ='{contract_id}';";
            var id = Provider.RunScalar(query);
            if (id > 0) { //xlsx exists
            query = $"SELECT id FROM docimages WHERE doc_guid='{id}' and doc_widget_id ='inv xls'";
            var res = Provider.RunScalar(query);
                if (res > 0)
                    return "{\"status\":200, \"file\":\"/picture/getfile/" + res + "\"}";
                else { //create xlsx 
                    var dc = new DocumentController();
                    dc.GetInvExcel(id.ToString());
                    query = $"SELECT id FROM docimages WHERE doc_guid='{id}' and doc_widget_id ='inv xls'";
                    res = Provider.RunScalar(query);
                    return "{\"status\":200, \"file\":\"/picture/getfile/" + res + "\"}";
                } 
            }
            return "{\"status\":201, \" нет данних\"}";
        }
        public string wsdl_astana_1(int contract_id)
        {
            //var dc = new DocumentController();
            //var res = dc.InvoiceExport(contract_id);
            //dc.InvoicExport()
            //if (res > 0) return "{\"status\":200}";
            return "{\"status\":\"wsdl serice not available\"}";
        }

        public string pdfNumber()
        {
            return DateTime.Now.ToString("yyyyMMddHHmmss");
        }

        public string listRequest(string contract_id)
        {

            var filelist = new List<Kfiles>();
            string remoteDirectory = "/request";
            //string remoteDirectory = "/response";

            using (SftpClient sftp = new SftpClient(sftp_host, sftp_username, sftp_password))
            {
                try
                {
                    sftp.Connect();

                    var files = sftp.ListDirectory(remoteDirectory);
                    
                    foreach (var file in files)
                    {
                        var tmp = new Kfiles();
                        tmp.name = file.Name;
                        tmp.date = file.LastWriteTime.ToString();
                        tmp.id = file.GroupId.ToString();
                        filelist.Add(tmp);
                    }

                    sftp.Disconnect();
                    return JsonConvert.SerializeObject(filelist);
                }
                catch (Exception e)
                {
                    //Console.WriteLine("An exception has been caught " + e.ToString());
                    return "error" + e.ToString();
                }
            }
        }
        public string listResponse(string contract_id)
        {
            var filelist = new List<Kfiles>();
            string remoteDirectory = "/response";

            using (SftpClient sftp = new SftpClient(sftp_host, sftp_username, sftp_password))
            {
                try
                {
                    sftp.Connect();

                    var files = sftp.ListDirectory(remoteDirectory);

                    foreach (var file in files)
                    {
                        var tmp = new Kfiles();
                        tmp.name = file.Name;
                        tmp.date = file.LastWriteTime.ToString();
                        tmp.id = file.GroupId.ToString();
                        filelist.Add(tmp);
                    }

                    sftp.Disconnect();
                    return JsonConvert.SerializeObject(filelist);
                }
                catch (Exception e)
                {
                    //Console.WriteLine("An exception has been caught " + e.ToString());
                    return "error" + e.ToString();
                }
            }
        }

        public class CSVModel
        {
            public int id;
            public string invoice_un { get; set; }
            public string invoice_num { get; set; }
            public string recive_station_code { get; set; }
            public string dest_station_code { get; set; }

            public string recive_station_name { get; set; }
            public string dest_station_name { get; set; }

            public string sender_exp_no { get; set; }
            public string etsng_code { get; set; }
            public float fact_mass { get; set; }
            public string payer_code { get; set; }
            public string vag_no { get; set; }
            public int vag_count { get; set; }
            public float gruz { get; set; }
            public DateTime? invc_dt { get; set; }
            public string container_no { get; set; }
            public int smgs_type { get; set; }
            public string request_id { get; set; }
        }



        public string FileDownloadSFTP(string file, string contract_id)
        {
            string user = User.Identity.GetUserId();
            if (string.IsNullOrEmpty(contract_id)) return "contract id not found";
            if (string.IsNullOrEmpty(file)) return "file name not found";
            using (var sftp = new SftpClient(sftp_host, sftp_username, sftp_password))
            {
                sftp.Connect();

                // Load remote file into a stream
                using (var remoteFileStream = sftp.OpenRead("/response/"+ file))
                {
                    var textReader = new System.IO.StreamReader(remoteFileStream);
                    string s = textReader.ReadToEnd();
                    string[] stringSeparators = new string[] { "\r\n" };
                    string[] lines = s.Split(stringSeparators, StringSplitOptions.None);
                    
                    foreach (var ln in lines)
                    {
                        string[] row = ln.Split(',');
                        int cnt = row.Length;
                        if (cnt == 14) { 
                        var ab = DateTime.ParseExact(row[11], "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);
                        var query0 = $"INSERT INTO ktg_response (contract_id, invoice_un, invoice_num, recive_station_code, dest_station_code, " +
                                $"sender_exp_no,etsng_code,fact_mass, payer_code, vag_no, vag_count, gruz,invc_dt, container_no, smgs_type)" +
                $" VALUES ('{contract_id}', '{row[0]}', '{row[1]}', '{row[2]}', '{row[3]}', '{row[4]}','{row[5]}','{row[6]}','{row[7]}','{row[8]}'," +
                $"'{row[9]}','{row[10]}','{ab.ToString("yyyy.MM.dd HH:mm")}','{row[12]}','{row[13]}') RETURNING id;"; 
                            Provider.RunScalar(query0);
                        }
                    }
                    if (!Provider.lastError.IsEmpty())
                    {
                        var query1 = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.SftpFileDownload}', '{LogContract.SftpFileDownload}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                        Provider.RunNonQuery(query1, JsonConvert.SerializeObject(Provider.lastError));
                        return "{\"status\":\"error " + Provider.lastError + "\"}";
                    }
                    log.Info("sftp download " + user + JsonConvert.SerializeObject(file));
                    var query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                            $"VALUES('NOW()', '{(int)LogContract.SftpFileDownload}', '{LogContract.SftpFileDownload}', '{LogSection.Contract}', '{user}', '', '{contract_id}', '{JsonConvert.SerializeObject(file)}', 0);";
                    Provider.RunNonQuery(query);
                    return "ok";
                }
            }
        }

        [HttpPost]
        public string ktzh_response_upload(string request_id)
        {
            string user = User.Identity.GetUserId();
            int result = 0;
            if (string.IsNullOrEmpty(request_id)) return "request_id is empty";
            var query = $"SELECT contract_id FROM ktg_log WHERE id='{request_id}'";
            int contract_id = Provider.RunScalar(query);
            foreach (string fil in Request.Files)
            {
                var hpf = Request.Files[fil];
                if (hpf.ContentLength == 0)
                    continue;

                StreamReader stream = new StreamReader(hpf.InputStream);
                string s = stream.ReadToEnd();
                string[] stringSeparators = new string[] { "\r\n" };
                string[] lines = s.Split(stringSeparators, StringSplitOptions.None);

                foreach (var ln in lines)
                {
                    string[] row = ln.Split(',');
                    int cnt = row.Length;
                    if (cnt == 14)
                    {
                        result++;
                        var ab = DateTime.ParseExact(row[11], "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);
                        var query0 = $"INSERT INTO ktg_response (contract_id, request_id, invoice_un, invoice_num, recive_station_code, dest_station_code, " +
                                $"sender_exp_no,etsng_code,fact_mass, payer_code, vag_no, vag_count, gruz,invc_dt, container_no, smgs_type)" +
                $" VALUES ({contract_id}, '{request_id}', '{row[0]}', '{row[1]}', '{row[2]}', '{row[3]}', '{row[4]}','{row[5]}','{row[6]}','{row[7]}','{row[8]}'," +
                $"'{row[9]}','{row[10]}','{ab.ToString("yyyy.MM.dd HH:mm")}','{row[12]}','{row[13]}') RETURNING id;";
                        Provider.RunScalar(query0);
                    }
                }
                if (!Provider.lastError.IsEmpty())
                {
                    var query1 = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_data, is_error) " +
            $"VALUES('NOW()', '{(int)LogContract.SftpFileDownload}', '{LogContract.SftpFileDownload}', '{LogSection.Contract}', '{user}', @p0::jsonb, 1);";
                    Provider.RunNonQuery(query1, JsonConvert.SerializeObject(Provider.lastError));
                    return "{\"status\":\"error " + Provider.lastError + "\"}";
                }
                if (result < 1)
                {
                    return "{\"status\":\"error: parser found 0 lines in file}";
                }
                log.Info("sftp download " + user + JsonConvert.SerializeObject(request_id));
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, log_target_user_id, doc_id, log_data, is_error) " +
                        $"VALUES('NOW()', '{(int)LogContract.SftpFileDownload}', '{LogContract.SftpFileDownload}', '{LogSection.Contract}', '{user}', '', '{request_id}', '{JsonConvert.SerializeObject(request_id)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            return "error - no file";
        }
        /*
        private string csvMain(string bin, string vsoob, string tip, string kod)
        {
            var records = new List<dynamic>();

            dynamic record = new ExpandoObject();
            record.BIN = bin;
            record.VSoob = vsoob;
            record.TipUper = tip;
            record.KodExp = kod;
            records.Add(record);
            string res = "";

            using (var writer = new StringWriter())
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(records);

                res = writer.ToString();
            }
            return res;
        }*/
        private string FileUploadSFTP(string BIN, string VSoob, string TipUper, string KodExp, string dat)
        {

            string s = BIN+","+ VSoob + ","+ TipUper + ","+ KodExp+";\n"; 
            byte[] csvFile = Encoding.UTF8.GetBytes(s);
            //string query = "";as
            //string bin =Provider.RunQueryStr(query);
            using (var client = new SftpClient(sftp_host, sftp_username, sftp_password))
            {
                client.Connect();
                if (client.IsConnected)
                {
                    //Debug.WriteLine("I'm connected to the client");
                    //client.ChangeDirectory("/response");
                    using (var ms = new MemoryStream(csvFile))
                    {
                        //client.BufferSize = (uint)ms.Length; // bypass Payload error large files
                        client.UploadFile(ms, "/request/"+BIN+dat+".csv"); //binDDMMGG
                    }
                    return "ok";
                }
                else
                {
                    return "error connecting";
                }
            }
        }

        [HttpPost]
        public string SendEmail(eml data)
        {
            var host = System.Configuration.ConfigurationManager.AppSettings["EmailSMTP"];
            var port = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["EmailPort"]);
            var sender = System.Configuration.ConfigurationManager.AppSettings["EmailSender"];
            var password = System.Configuration.ConfigurationManager.AppSettings["EmailSenderPass"];
            var mlclient = new SmtpClient(host, port);
            mlclient.EnableSsl = false;
            mlclient.UseDefaultCredentials = false;
            mlclient.Credentials = new NetworkCredential(sender, password);
            try
            {
                System.Net.Mail.MailMessage message1 = new System.Net.Mail.MailMessage();
                // Add receiver
                string[] multi = data.email.Split(',');
                foreach(var em in multi)
                { message1.To.Add(em); }                
                message1.From = new MailAddress(sender);
                message1.Subject = data.subject;
                message1.Body = data.message;
                message1.IsBodyHtml = true;
                mlclient.Send(message1);
                data.message = null;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            return "ok";
        }

        public class sign
        {
            public string signature { get; set; }
        }
        public string LoadSignature(int doc_id)
        {
            string user = User.Identity.GetUserId();            
            string own = "", contr = "", pers = "";
            bool owner = false, counter = false;
            var query = $"SELECT attis_contract_owner, attis_contract_contragent, is_signed_by_owner, is_signed_by_counterparty, person_id " +
                $"FROM attis_contracts t1 LEFT JOIN organizations t2 ON t1.attis_contract_contragent = t2.org_code LEFT JOIN persons t3 ON t2.org_id=t3.org_id WHERE attis_contract_id='{doc_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    own = reader["attis_contract_owner"].ToString();
                    contr = reader["attis_contract_contragent"].ToString();
                    pers = reader["person_id"].ToString();
                    owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    counter = reader.GetFieldValueOrDefault<bool>("is_signed_by_counterparty");

                }
                reader.Close();
            }
            var sig = new sign();
            if (own == user) //owner signing
            {
                if (!owner) return "no signature";
                query = $"SELECT sign_data from attis_contracts where attis_contract_id='{doc_id}'";
                sig.signature = Provider.RunQueryStr(query);
                if (string.IsNullOrEmpty(Provider.lastError))
                    return JsonConvert.SerializeObject(sig);
                else return JsonConvert.SerializeObject(Provider.lastError);
            }
            else if (counter && (pers == user))
            {
                query = $"SELECT sign_data1 from attis_contracts where attis_contract_id='{doc_id}'";
                sig.signature = Provider.RunQueryStr(query);
                if (string.IsNullOrEmpty(Provider.lastError))
                    return JsonConvert.SerializeObject(sig);
                else return JsonConvert.SerializeObject(Provider.lastError);
            }
            return "no signature";
        }
        [HttpPost]
        public string AddBrokerContractSignature(int contract_id, string signature, string type)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var user_org_code = Provider.RunQueryStr(query);
            string owner = "", broker = "", personId = "";
            bool isSignedByOwner = false, isSignedByBroker = false;
            query = $"SELECT t1.countragent, t1.countragent_1, t2.is_signed_by_owner, t2.is_signed_by_broker" +
                $" FROM broker_requests t1 LEFT JOIN broker_contract t2 on t2.contract_id = '{contract_id}' where t1.contract_id = '{contract_id}' and t1.countragent is not null;";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    owner = reader["countragent_1"].ToString();
                    broker = reader["countragent"].ToString();
                    //personId = reader["person_id"].ToString();
                    isSignedByOwner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    isSignedByBroker = reader.GetFieldValueOrDefault<bool>("is_signed_by_broker");

                }
                reader.Close();
            }
            if (owner == user_org_code) //owner signing
            {
                if (isSignedByOwner)//already signed
                    return "already signed";
                var query1 = $"UPDATE broker_contract SET sign_data='{signature}', when_is_signed_by_owner='now()'," +
                    $"is_signed_by_owner=true, owner_signature_type='{type}' WHERE contract_id ='{contract_id}';";
                Provider.RunNonQuery(query1);
            }
            else // contragent
            {
                if (!(user_org_code == broker)) //wrong contragent
                    return "you can not sign this contract";
                if (isSignedByBroker)
                    return "already signed";
                var query1 = $"UPDATE broker_contract SET sign_data1='{signature}', when_is_signed_by_broker='now()'," +
                    $"is_signed_by_broker=true, broker_signature_type='{type}' WHERE contract_id ='{contract_id}';";
                Provider.RunNonQuery(query1);
            }
            return "ok";
        }

        [HttpPost]
        public string AddCourierContractSignature(int contract_id, string signature, string type)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var user_org_code = Provider.RunQueryStr(query);
            string owner = "", courier = "", personId = "";
            bool isSignedByOwner = false, isSignedByCourier = false;

            query = $"SELECT countragent, countragent_1, is_signed_by_owner, is_signed_by_courier" +
                $" FROM courier_requests where contract_id = '{contract_id}' and countragent is not null;";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    owner = reader["countragent_1"].ToString();
                    courier = reader["countragent"].ToString();
                    //personId = reader["person_id"].ToString();
                    isSignedByOwner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    isSignedByCourier = reader.GetFieldValueOrDefault<bool>("is_signed_by_courier");

                }
                reader.Close();
            }
            if (owner == user_org_code) //owner signing
            {
                if (isSignedByOwner)//already signed
                    return "already signed";
                var query1 = $"UPDATE courier_requests SET sign_data='{signature}', when_is_signed_by_owner='now()'," +
                    $"is_signed_by_owner=true, owner_signature_type='{type}' WHERE contract_id ='{contract_id}';";
                Provider.RunNonQuery(query1);
            }
            else // contragent
            {
                if (!(user_org_code == courier)) //wrong contragent
                    return "you can not sign this contract";
                if(isSignedByCourier)
                    return "already signed";
                var query1 = $"UPDATE courier_requests SET sign_data1='{signature}', when_is_signed_by_courier='now()'," +
                    $"is_signed_by_courier=true, courier_signature_type='{type}' WHERE contract_id ='{contract_id}';";
                Provider.RunNonQuery(query1);
            }
            return "ok";
        }

        [HttpPost]
        public string AddSignature(int contract_id, string signature, string signature_name, string type)
        {
            string user = User.Identity.GetUserId();
            int status = 2;
            string own = "", contr = "", pers = "";
            bool owner = false, counter = false;
            var query = $"SELECT attis_contract_owner, attis_contract_contragent, is_signed_by_owner, is_signed_by_counterparty, person_id " +
                $"FROM attis_contracts t1 LEFT JOIN organizations t2 ON t1.attis_contract_contragent = t2.org_code LEFT JOIN persons t3 ON t2.org_id=t3.org_id WHERE attis_contract_id='{contract_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    own = reader["attis_contract_owner"].ToString();
                    contr = reader["attis_contract_contragent"].ToString();
                    pers = reader["person_id"].ToString();
                    owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    counter = reader.GetFieldValueOrDefault<bool>("is_signed_by_counterparty");

                }
                reader.Close();
            }
            query = "SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id='" + user + "';";
            var cod = Provider.RunQueryStr(query);
            if (own == user) //owner signing
            {
                if (owner)//already signed
                    return "already signed";
                if (contr == "Null" || contr == "" || pers == "Null" || pers == "" ) status = 3; //buyer is set by owner
                var query1 = $"UPDATE attis_contracts SET sign_name='{signature_name}', sign_data='{signature}', attis_contract_status = '{status}', when_is_signed_by_owner='now()'," +
                    $"is_signed_by_owner=true, how_is_signed_by_owner='{type}' WHERE attis_contract_id ='{contract_id}';";
                Provider.RunNonQuery(query1);
                if (counter)
                {
                    query = "SELECT t1.user_id FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE org_code'" + contr + "'; ";
                    var kn = Provider.RunQueryStr(query);
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.SignContract,
                        CreatorId = user,
                        RecipientId = kn,
                        CreationDate = DateTime.Now,
                        ObjectId = contract_id,
                        Comment = contract_id.ToString()
                    });
                    SendEmailNotification(kn, (int)NotificationType.SignContract, contract_id.ToString(), 0);
                }
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.SignByOwner}', '{LogContract.SignByOwner}', '{LogSection.Contract}', '{user}', '{contract_id}', '{JsonConvert.SerializeObject(signature)}', 0);";
                Provider.RunNonQuery(query);
                return "ok";
            }
            else // contragent
            {
                if (!(cod == contr)) //wrong contragent
                    return "you can not sign this contract";
                if (owner)
                {
                    status = 3;
                    NotificationHelper.AddNotification(new Notification()
                    {
                        Type = NotificationType.SignContract,
                        CreatorId = user,
                        RecipientId = own,
                        CreationDate = DateTime.Now,
                        ObjectId = contract_id,
                        Comment = contract_id.ToString()
                    });
                    SendEmailNotification(own, (int)NotificationType.SignContract, contract_id.ToString(), 0);
                }
                var query1 = $"UPDATE attis_contracts SET sign_name1='{signature_name}', sign_data1='{signature}', attis_contract_status = '{status}', when_is_signed_by_counterparty='now()'," +
                    $"is_signed_by_counterparty=true, how_is_signed_by_counterparty='{type}' WHERE attis_contract_id ='{contract_id}';";
                Provider.RunNonQuery(query1);
                query = $"INSERT INTO attis_logs (log_date, oper_code, log_text, log_section, log_source_user_id, doc_id, log_data, is_error) " +
                $"VALUES('NOW()', '{(int)LogContract.SignByContragent}', '{LogContract.SignByContragent}', '{LogSection.Contract}', '{user}', '{contract_id}', '{JsonConvert.SerializeObject(signature)}', 0);";
                Provider.RunNonQuery(query);


            }
            return "ok";
        }

        [HttpPost]
        public bool CheckBrokerContractSignature(string contract_id, string signature)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var user_org_code = Provider.RunQueryStr(query);
            string own = "", contr = "", sign = "", sign1 = "";
            bool owner = false, counter = false;
            query = $"SELECT sign_data, sign_data1, owner, broker, is_signed_by_owner, is_signed_by_broker " +
                $"FROM broker_contract WHERE contract_id ='{contract_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    sign = reader["sign_data"].ToString();
                    sign1 = reader["sign_data1"].ToString();
                    own = reader["owner"].ToString();
                    contr = reader["broker"].ToString();
                    owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    counter = reader.GetFieldValueOrDefault<bool>("is_signed_by_broker");

                }
                reader.Close();
            }
            if (user_org_code == own && signature == sign) //if owner signature ok
                return true;
            else if (signature == sign1) // if contragent signature ok
                return true;
            return false;
        }
        [HttpPost]
        public bool CheckCourierContractSignature(string contract_id, string signature)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var user_org_code = Provider.RunQueryStr(query);
            string own = "", contr = "", sign = "", sign1 = "";
            bool owner = false, counter = false;
            query = $"SELECT sign_data, sign_data1, countragent_1, countragent, is_signed_by_owner, is_signed_by_courier " +
                $"FROM courier_requests WHERE contract_id ='{contract_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    sign = reader["sign_data"].ToString();
                    sign1 = reader["sign_data1"].ToString();
                    own = reader["countragent_1"].ToString();
                    contr = reader["countragent"].ToString();
                    owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    counter = reader.GetFieldValueOrDefault<bool>("is_signed_by_courier");

                }
                reader.Close();
            }
            if (user_org_code == own && signature == sign) //if owner signature ok
                return true;
            else if (signature == sign1) // if contragent signature ok
                return true;
            return false;
        }

        public string LoadBrokerContractSignature(string contract_id)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var user_org_code = Provider.RunQueryStr(query);
            string own = "", contr = "", sign = "", sign1 = "";
            bool owner = false, counter = false;
            query = $"SELECT sign_data, sign_data1, owner, broker, is_signed_by_owner, is_signed_by_broker " +
                $"FROM broker_contract WHERE contract_id ='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var sig = new sign();
            if (reader != null)
            {
                while (reader.Read())
                {
                    sign = reader["sign_data"].ToString();
                    sign1 = reader["sign_data1"].ToString();
                    own = reader["owner"].ToString();
                    contr = reader["broker"].ToString();
                    owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    counter = reader.GetFieldValueOrDefault<bool>("is_signed_by_broker");

                }
                reader.Close();
            }
            if (user_org_code == own)
            {
                if (!owner) return "no signature";
                sig.signature = sign;
                return JsonConvert.SerializeObject(sig);
            }
            else if(user_org_code == contr)
            {
                if (!counter) return "no signature";
                sig.signature = sign1;
                return JsonConvert.SerializeObject(sig);
            }
            return "no signature";
        }

        public string LoadCourierContractSignature(string contract_id)
        {
            string user = User.Identity.GetUserId();
            string query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{user}'";
            var user_org_code = Provider.RunQueryStr(query);
            string own = "", contr = "", sign = "", sign1 = "";
            bool owner = false, counter = false;
            query = $"SELECT sign_data, sign_data1, countragent_1, countragent, is_signed_by_owner, is_signed_by_courier " +
                $"FROM courier_requests WHERE contract_id ='{contract_id}';";
            var reader = Provider.RunQuery(query);
            var sig = new sign();
            if (reader != null)
            {
                while (reader.Read())
                {
                    sign = reader["sign_data"].ToString();
                    sign1 = reader["sign_data1"].ToString();
                    own = reader["countragent_1"].ToString();
                    contr = reader["countragent"].ToString();
                    owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    counter = reader.GetFieldValueOrDefault<bool>("is_signed_by_courier");

                }
                reader.Close();
            }
            if (user_org_code == own)
            {
                if (!owner) return "no signature";
                sig.signature = sign;
                return JsonConvert.SerializeObject(sig);
            }
            else if (user_org_code == contr)
            {
                if (!counter) return "no signature";
                sig.signature = sign1;
                return JsonConvert.SerializeObject(sig);
            }
            return "no signature";
        }

        [HttpPost]
        public bool CheckSignature(string contract_id, string signature)
        {
            string user = User.Identity.GetUserId();
            string own = "", contr= "", sign= "", sign1 =""; 
            bool owner = false, counter = false;
            var query = $"SELECT sign_data, sign_data1, attis_contract_owner, attis_contract_contragent, is_signed_by_owner, is_signed_by_counterparty " +
                $"FROM attis_contracts WHERE attis_contract_id ='{contract_id}';";
            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    sign = reader["sign_data"].ToString();
                    sign1 = reader["sign_data1"].ToString();
                    own = reader["attis_contract_owner"].ToString();
                    contr = reader["attis_contract_contragent"].ToString();
                    owner = reader.GetFieldValueOrDefault<bool>("is_signed_by_owner");
                    counter = reader.GetFieldValueOrDefault<bool>("is_signed_by_counterparty");

                }
                reader.Close();
            }
            if (user == own && signature == sign) //if owner signature ok
                return true;
            else if (signature == sign1) // if contragent signature ok
                return true;
            return false;            
        }
        public string GetHistory(string contract_id)
        {
            string user = User.Identity.GetUserId();
            // Getting history by contract itself
            string query = $"SELECT oper_code, log_date, log_section, log_data, o.org_name FROM attis_logs INNER JOIN persons p on p.user_id = log_source_user_id INNER JOIN organizations o ON p.org_id = o.org_id WHERE doc_id ='{contract_id}' and log_section = 'Contract'";
            var reader = Provider.RunQuery(query);
            List<ContractHistory> list = new List<ContractHistory>();
            if (reader != null)
            {
                while (reader.Read())
                {
                    ContractHistory ch = new ContractHistory();
                    ch.action_created_by = reader["org_name"].ToString();
                    ch.action_type = reader["oper_code"].ToString();
                    ch.action_date = reader["log_date"].ToString();
                    ch.action_section = reader["log_section"].ToString();
                    ch.action_data = reader["log_data"].ToString();
                    list.Add(ch);
                }
                reader.Close();
            }

            query = $"SELECT oper_code, log_date,log_section, log_text, log_data, o.org_name FROM attis_logs INNER JOIN persons p on p.user_id = log_source_user_id INNER JOIN organizations o ON p.org_id = o.org_id INNER JOIN attis_contract_docs acd on  CAST(acd.attis_contract_doc_id as varchar) = doc_id " +
                $"WHERE acd.attis_contract_doc_contract = '{contract_id}' and log_section = 'Document' ";
            
            var reader1 = Provider.RunQuery(query);
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    ContractHistory ch = new ContractHistory();
                    ch.action_created_by = reader["org_name"].ToString();
                    ch.action_type = reader["oper_code"].ToString();
                    ch.action_date = reader["log_date"].ToString();
                    ch.action_section = reader["log_section"].ToString();
                    ch.action_data = reader["log_data"].ToString();
                    list.Add(ch);
                }
                reader1.Close();
            }

            query = $"SELECT oper_code, log_date,log_section, log_text, log_data, o.org_name FROM attis_logs INNER JOIN persons p on p.user_id = log_source_user_id INNER JOIN organizations o ON p.org_id = o.org_id INNER JOIN attis_contract_offers acd on  CAST(acd.attis_contract_offer_id as varchar) = doc_id " +
            $"WHERE acd.attis_contract_id = '{contract_id}' and log_section = 'Offer' ";

            var reader2 = Provider.RunQuery(query);
            if (reader2 != null)
            {
                while (reader2.Read())
                {
                    ContractHistory ch = new ContractHistory();
                    ch.action_created_by = reader["org_name"].ToString();
                    ch.action_type = reader["oper_code"].ToString();
                    ch.action_date = reader["log_date"].ToString();
                    ch.action_section = reader["log_section"].ToString();
                    ch.action_data = reader["log_data"].ToString();
                    list.Add(ch);
                }
                reader2.Close();
            }

            List<ContractHistory> history = list.OrderByDescending(o => o.action_date).ToList();
            return JsonConvert.SerializeObject(history);
        }

        public class ContractHistory
        {
            public string action_created_by { get; set; }
            public string action_type { get; set; }
            public string action_date { get; set; }
            public string action_section { get; set; }
            public string action_data { get; set; }
        }
        public class xp
        {
            public string Exception { get; set; }
            public string InnerException { get; set; }
        }
        //end  
    }
}