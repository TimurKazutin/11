﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-28-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-28-2014
// ***********************************************************************
// <copyright file="DataSourceType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
	using System.Xml.Serialization;
	/// <summary>
	/// Enum DataSourceType
	/// </summary>
	public enum DataSourceType
    {
        /// <summary>
        /// The none
        /// </summary>
        [XmlIgnore]
        None,
        /// <summary>
        /// The Oracle
        /// </summary>
        /// 
        [XmlEnum("Ora")]
		Oracle,
        /// <summary>
        /// The PostgreSQL
        /// </summary>
        /// 
        [XmlEnum("PG")]
        Postgres
	}
}
