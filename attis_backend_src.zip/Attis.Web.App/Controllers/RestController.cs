﻿using Lawyers.Common;
using Lawyers.Common.Interfaces;
using Lawyers.Web.App.Helpers;
using Lawyers.Web.App.Models;
using Lawyers.Web.App.Models.Enums;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;
using Lawyers.Engine.Configuration;
using System.Net.Http;
using System.Text;
using System.Net;
using Newtonsoft.Json;

namespace Lawyers.Web.App.Controllers
{
    public class RestController : Controller
    {
        // GET: Rest
        private static IDataProvider Provider => GlobalContainer.Instance.Get<Configuration>().DataProvider;
        //KalkanCryptCOMLib.KalkanCryptCOM KalkanCOMTest = new KalkanCryptCOMLib.KalkanCryptCOM();
        private static string key = "Vm6pCJM5SfYV30gtPbRXXDKNfapAoaM7";
        //2LetpXzKK30vxaQ2hZqRV2kyP8pPlxO2
        //1kVzPLAFSx3oGVm4BUeCz7acJhPRwdbG
        //dzSavW6eFlI2t33La5C99oisdNCoex7O

        //Authorize]
        public class statusmsg
        {
            public int statusCode;
            public string statusMessage;
            //"statusCode": 419,
            //"": "wrong security token"
        }
        public JsonResult GetStatus()
        {
            statusmsg res = new statusmsg();
            res.statusMessage = "ok";
            res.statusCode = 200;

            return Json(res, JsonRequestBehavior.AllowGet);
        }

        /*
        public JsonResult Search0(string query, string token)
        {
            statusmsg res = new statusmsg();
            res.statusMessage = "wrong security token";
            res.statusCode = 419;
            if (!key.Equals(token))
                return Json(res, JsonRequestBehavior.AllowGet);

            return Json(res, JsonRequestBehavior.AllowGet);
        }
        */
        public class Srch
        {
            public string id { get; set; }
            public string country { get; set; }
            public string org_name { get; set; }//: "Кандидат 1",
            public string contact { get; set; }//: "xxx@xxxx.com",
            public string sphere { get; set; }//: "Проиводство 1",
            public string email { get; set; }
            public string org_residency { get; set; }
            public string company_address { get; set; }
            public string company_main_sphere { get; set; }
            //public bool Checked { get; set; }//: false
        }
        //[HttpPost]
        public string searchContragent(string token,string org_residency, string company_address, string company_main_sphere, string org_name)
        {
            statusmsg res = new statusmsg();
            res.statusMessage = "wrong security token";
            res.statusCode = 419;
            if (!key.Equals(token))
                return JsonConvert.SerializeObject(res);
            var list = new List<Srch>();
            string ors = "", cad = "", cms = "", onm = "";
            ors = $"org_residency ~ '{org_residency}' ";
            if (!String.IsNullOrEmpty(company_address)) cad = $"AND company_address ~ '{company_address}' ";
            if (!String.IsNullOrEmpty(company_main_sphere)) cms = $"AND company_main_sphere ~ '{company_main_sphere}' ";
            if (!String.IsNullOrEmpty(org_name)) onm = $"AND LOWER(org_name) ~ '{org_name.ToLower()}' ";
            var query = $"SELECT * FROM org_ext WHERE {ors}{cad}{cms}{onm};";

            var reader = Provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    var rep1 = new Srch
                    {
                        id = reader["org_id"].ToString(),
                    };
                    rep1.country = reader["org_residency"].ToString();
                    rep1.org_name = reader["org_name"].ToString();
                    rep1.contact = reader["company_contacts"].ToString();
                    rep1.sphere = reader["company_main_sphere"].ToString();
                    rep1.email = reader["company_email"].ToString();
                    rep1.org_residency = reader["org_residency"].ToString();
                    rep1.company_address = reader["company_address"].ToString();
                    rep1.company_main_sphere = reader["company_main_sphere"].ToString();
                    list.Add(rep1);
                }
                reader.Close();
            }
            return JsonConvert.SerializeObject(list);
        }
        class Search
        {
            public string search_term { get; set; }
            public double fuzziness { get; set; }
            //public string share_url { get; set; }
        }
        public string checkReliability(string token, string query)
        {
            statusmsg res = new statusmsg();
            res.statusMessage = "wrong security token";
            res.statusCode = 419;
            if (!key.Equals(token))
                return JsonConvert.SerializeObject(res);
            var person = new Search();
            person.search_term = query;
            person.fuzziness = 0.6;
            //string sr = "{search_term:Dandong Hongxiang}";

            var json = JsonConvert.SerializeObject(person);
            //var data = new StringContent(json, Encoding.UTF8, "application/json");

            var url = "https://api.complyadvantage.com/searches?api_key=Bq0l7lG76InG8tYZKtXs2xMnZEyENRcn";
            //var client = new HttpClient();
            var aa = POSTData(json, url);
            //var response = client.PostAsync(url, data);

            //string result = response.Result.Content.ReadAsStringAsync().Result;
            return aa;
        }

        private static HttpClient _httpClient = new HttpClient();
        public string POSTData(string json, string url)
        {
            using (var content = new StringContent(json, Encoding.UTF8, "application/json"))
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
                                                | SecurityProtocolType.Ssl3;
                HttpResponseMessage result = _httpClient.PostAsync(url, content).Result;
                if (result.StatusCode == System.Net.HttpStatusCode.Created)
                    return "true";
                string returnValue = result.Content.ReadAsStringAsync().Result;
                return returnValue;
                //throw new Exception($"Failed to POST data: ({result.StatusCode}): {returnValue}");
            }
        }
    }
}