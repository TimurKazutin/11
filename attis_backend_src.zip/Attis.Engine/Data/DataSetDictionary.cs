﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 11-07-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-07-2014
// ***********************************************************************
// <copyright file="DataSetDictionary.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Engine.Data
{
    using System;
    using System.Collections.Generic;
    /// <summary>
    /// Class DataSetDictionary.
    /// </summary>
    public class DataSetDictionary : SortedDictionary<Guid, DataSet>
    {
    }
}
