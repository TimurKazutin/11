﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 11-09-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 8-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Models namespace.
/// </summary>
namespace Lawyers.Web.App.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Class UserRoles.
    /// </summary>
    public class UserRoles : Dictionary<int, string>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserRoles"/> class.
        /// </summary>
        public UserRoles()
        {
            this.Add(1, "Inventor");
            this.Add(2, "Manager");
            this.Add(4, "TTO officer");
            this.Add(8, "Administrator");
            this.Add(16, "None");
            this.Add(32, "Analytic");
        }
    }
}