﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lawyers.Web.App.Models.Enums
{
    /// <summary>
    /// Enum ManageMessageId
    /// </summary>
    public enum ManageMessageIdEnum
    {
        /// <summary>
        /// The add phone success
        /// </summary>
        AddPhoneSuccess,
        /// <summary>
        /// The change password success
        /// </summary>
        ChangePasswordSuccess,
        /// <summary>
        /// The set two factor success
        /// </summary>
        SetTwoFactorSuccess,
        /// <summary>
        /// The set password success
        /// </summary>
        SetPasswordSuccess,
        /// <summary>
        /// The remove login success
        /// </summary>
        RemoveLoginSuccess,
        /// <summary>
        /// The remove phone success
        /// </summary>
        RemovePhoneSuccess,
        /// <summary>
        /// The error
        /// </summary>
        Error
    }
}