﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-18-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-18-2014
// ***********************************************************************
// <copyright file="ConditionOperationType.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    using System.Xml.Serialization;

    /// <summary>
    /// Enum ConditionOperationType
    /// </summary>
    public enum ConditionOperationType
    {
        /// <summary>
        /// The equal
        /// </summary>
        [XmlEnum(Name = "equal")]
        Equal,
        /// <summary>
        /// The not equal
        /// </summary>
        [XmlEnum(Name = "does_not_equal")]
        NotEqual,
        /// <summary>
        /// The greater
        /// </summary>
        [XmlEnum(Name = "is_greater_then")]
        Greater,
        /// <summary>
        /// The less
        /// </summary>
        [XmlEnum(Name = "is_less_then")]
        Less,
        /// <summary>
        /// The greater or equal
        /// </summary>
        [XmlEnum(Name = "is_greater_then_or_equal_to")]
        GreaterOrEqual,
        /// <summary>
        /// The less or equal
        /// </summary>
        [XmlEnum(Name = "is_less_then_or_equal_to")]
        LessOrEqual,
        /// <summary>
        /// The blank
        /// </summary>
        [XmlEnum(Name = "is_blank")]
        Blank,
        /// <summary>
        /// The not blank
        /// </summary>
        [XmlEnum(Name = "is_not_blank")]
        NotBlank,
        /// <summary>
        /// The none
        /// </summary>
        [XmlIgnore]
        None,
        /// <summary>
        /// The starts
        /// </summary>
        [XmlEnum(Name = "starts")]
        Starts,
        /// <summary>
        /// The ends
        /// </summary>
        [XmlEnum(Name = "ends")]
        Ends,
        /// <summary>
        /// The contains
        /// </summary>
        [XmlEnum(Name = "contains")]
        Contains
    }
}
