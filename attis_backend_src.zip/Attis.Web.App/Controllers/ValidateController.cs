﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lawyers.Engine.Configuration;

namespace Lawyers.Web.App.Controllers
{
    using Common;
    using Common.Interfaces;
    using Lawyers.Common.Classes;
    using Common.Enums;
    using Newtonsoft.Json;
    using System.Net.Http;
    using Lawyers.Web.App.Models;
    using Microsoft.AspNet.Identity;
    using Lawyers.Web.App.Helpers;

    public class ValidateController : Controller
    {
        private static IDataProvider provider
        {
            get { return GlobalContainer.Instance.Get<Configuration>().DataProvider; }
        }

        // GET: Library
        public string Index(string org_code, string data)
        {
            var list = new List<ValidateModel>();
            string user = User.Identity.GetUserId();
            var query = $"SELECT t1.*, t2.*, t3.residency, t4.org_founders_person_name, t5.subj_bank_acc_number FROM organizations t1 LEFT JOIN subj_post_addresses t2 ON t1.org_id=t2.org_id " +
                $"LEFT JOIN persons t3 ON t1.org_id=t3.org_id LEFT JOIN organizations_founders t4 ON t1.org_id=t4.org_id " +
                $"LEFT JOIN subj_bank_accounts t5 ON t1.org_id=t5.org_id WHERE t3.user_id='{user}';";
            var reader1 = provider.RunQuery(query);
            int index = 0, country = 0, region = 0, district = 0, town = 0, city = 0, street = 0, house = 0, flat = 0, bank = 0, okd = 0;
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new OrgAdress();
                  
                    //rep1.subj_post_addr_type = reader1["subj_post_addr_type"].ToString();
                    rep1.post_addr_index = reader1["post_addr_index"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_index))
                        index = 1;
                    rep1.post_addr_country = reader1["post_addr_country"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_country))
                        country = 1;
                    rep1.post_addr_region = reader1["post_addr_region"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_region))
                        region = 1;
                        rep1.post_addr_district = reader1["post_addr_district"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_district))
                        district = 1;
                    rep1.post_addr_town = reader1["post_addr_town"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_town))
                        town = 1;
                    rep1.post_addr_city = reader1["post_addr_city"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_city))
                        city = 1;
                    rep1.post_addr_streethouse = reader1["post_addr_streethouse"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_streethouse))
                        street = 1;
                    rep1.post_addr_house = reader1["post_addr_house"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_house))
                        house = 1;
                    rep1.post_addr_room = reader1["post_addr_room"].ToString();
                    if (!string.IsNullOrEmpty(rep1.post_addr_room))
                        flat = 1;
                    var name = reader1["org_name"].ToString();
                    if (string.IsNullOrEmpty(name))
                        list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Company.ToString(),
                            "PA1.Main.E.001", "Наименование", "org_name", "Нет наименования компании", "Ошибка"));
                    var oked = reader1["org_oked"].ToString();
                    if (!string.IsNullOrEmpty(oked))
                        okd = 1;
                        
                    var type = reader1["org_type"].ToString();
                    if (string.IsNullOrEmpty(type))
                        list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Company.ToString(),
                            "PA1.Main.W.003", "Тип организации", "org_type", "Не указан тип организации", "Предупреждение"));
                    var contact = reader1["company_contacts"].ToString();
                    if (string.IsNullOrEmpty(contact))
                        list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Company.ToString(),
                            "PA1.Main.W.004", "Контакты", "company_contacts", "Не указаны контакты компании", "Предупреждение"));
                    var residen = reader1["org_residency"].ToString();
                    if (string.IsNullOrEmpty(residen))
                        list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Company.ToString(),
                            "PA1.Main.W.005", "Страна регистрации", "org_residency", "Не указана страна резидентства", "Предупреждение"));
                    var peres = reader1["org_residency"].ToString();
                    if (string.IsNullOrEmpty(peres))
                        list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Personal.ToString(),
                            "PA1.Main.W.001", "Резидентство", "persons.residency", "Не указана страна резидентства", "Предупреждение"));
                    var found = reader1["org_founders_person_name"].ToString();
                    if (string.IsNullOrEmpty(peres))
                        list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Founders.ToString(),
                            "PA1.Fndr.W.001", "Учредители", "org_founders_person_name", "Нет данных об учредителях", "Предупреждение"));
                    var bank1 = reader1["subj_bank_acc_number"].ToString();
                    if (!string.IsNullOrEmpty(bank1))
                        bank = 1;

                }
                reader1.Close();
                if (index < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.001", "Наличие юридического адреса", "post_addr_index", "Почтовый индекс не указан", "Предупреждение"));
                if (country < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.002", "Наличие юридического адреса", "post_addr_country", "Страна резидентства не указана", "Предупреждение"));
                if (region < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.003", "Наличие юридического адреса", "post_addr_region", "Регион (Наименование единицы административно-территориального деления первого уровня) не указан", "Предупреждение"));
                if (district < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.004", "Наличие юридического адреса", "post_addr_district", "Район не указан", "Предупреждение"));
                if (town < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.005", "Наличие юридического адреса", "post_addr_town", "Город не указан", "Предупреждение"));
                if (city < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.006", "Наличие юридического адреса", "post_addr_city", "Населенный пункт не указан", "Предупреждение"));
                if (street < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.007", "Наличие юридического адреса", "post_addr_streethouse", "Улица не указана", "Предупреждение"));
                if (house < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.008", "Наличие юридического адреса", "post_addr_house", "Обозначение дома, корпуса, строения не указано", "Предупреждение"));
                if (flat < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.CompanyAdress.ToString(),
                            "PA1.Addr.W.009", "Наличие юридического адреса", "post_addr_room", "Обозначение офиса или квартиры не указано", "Предупреждение"));
                if (bank < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Bank.ToString(),
                    "PA1.Acc.W.002", "Счета", "subj_bank_acc_number", "Нет данных о банковских счетах", "Предупреждение"));
                if (okd < 1)
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Company.ToString(),
                            "PA1.Main.W.002", "ОКЭД", "org_oked", "Не указан ОКЭД", "Предупреждение"));
                query = $"SELECT cert FROM signatures WHERE user_id='{user}'";
                var cert = provider.RunQueryStr(query);
                if(string.IsNullOrEmpty(cert))
                    list.Add(GetVal(org_code, ValidateSection.CompanyAccount.ToString(), SubSection.Personal.ToString(),
                            "PA2.Main.W.002", "ЭЦП", "signatures.cert", "ЭЦП не загружена", "Предупреждение"));

            }
            return JsonConvert.SerializeObject(list); 
        }


        public string Contract(int contract_id)
        {            
            var list = new List<ValidateModel>();
            var query = $"SELECT attis_contract_subject,attis_contract_desc,attis_contract_contragent FROM attis_contracts WHERE attis_contract_id = {contract_id};";
            var reader = provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {   
                    
                    var subject = reader["attis_contract_subject"].ToString();
                    if (string.IsNullOrEmpty(subject))
                        list.Add(GetVal(contract_id.ToString(), ValidateSection.Contract.ToString(), SubSection.Contract.ToString(),
                                "CN1.Main.W.001", "Тема", "attis_contract_subject", "Не указана тема контракта", "Предупреждение"));
                    var desc = reader["attis_contract_desc"].ToString();
                    if (string.IsNullOrEmpty(desc))
                        list.Add(GetVal(contract_id.ToString(), ValidateSection.Contract.ToString(), SubSection.Contract.ToString(),
                                "CN1.Main.W.002", "Описание", "attis_contract_desc", "Не указано описание контракта", "Предупреждение"));
                    var contragent = reader["attis_contract_contragent"].ToString();
                    if (string.IsNullOrEmpty(contragent))
                        list.Add(GetVal(contract_id.ToString(), ValidateSection.Contract.ToString(), SubSection.Contract.ToString(),
                                "CN1.Main.W.004", "Покупатель", "attis_contract_contragent", "Не указан контрагент по контракту", "Предупреждение"));
                }
                reader.Close();
                query = $"SELECT attis_cg_contract_id FROM attis_contract_goods WHERE attis_cg_contract_id = {contract_id}";
                int cg = provider.RunScalar(query);
                if (cg < 0)
                    list.Add(GetVal(contract_id.ToString(), ValidateSection.Contract.ToString(), SubSection.Contract.ToString(),
                                "CN1.Main.W.003", "Товары", "attis_cg_contract_id", "Не указаны товары в контракте", "Предупреждение"));
            }
            return JsonConvert.SerializeObject(list);
        }

        public string Invoice(int doc_id)
        {
            var list = new List<ValidateModel>();
            var query = $"SELECT t1.doc_guid, t1.attis_contract_doc_contract, t3.org_name, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" LEFT JOIN organizations t3 ON t2.\"InvoiceSeller\" = t3.org_code WHERE t1.attis_contract_doc_id = {doc_id};";
            string contract_id = "", cur = "", inv_id ="", buyer="", seller = "";
            float cost = 0;
            var reader = provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    inv_id = reader["DocumentID"].ToString();
                    buyer = reader["InvoiceByer"].ToString();
                    seller = reader["InvoiceSeller"].ToString();
                    
                    contract_id = reader["attis_contract_doc_contract"].ToString();
                    var dat = reader["DocumentDate"].ToString();
                    if (string.IsNullOrEmpty(dat))
                        list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                                "Inv.Main.E001", "Дата инвойса", "Invoice.DocumentDate", "Не указана дата инвойса", "Ошибка"));
                    cur = reader["CurrencyCode"].ToString().Trim();
                    if (string.IsNullOrEmpty(cur))
                        list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                                "Inv.Main.E002", "Валюта инвойса", "Invoice.CurrencyCode", "Не указана валюта инвойса", "Ошибка"));
                    var weig = reader["GrossWeightQuantity"].ToString();
                    if (string.IsNullOrEmpty(weig))
                        list.Add(GetVal(doc_id.ToString(), ValidateSection.Contract.ToString(), SubSection.Contract.ToString(),
                                "Inv.Main.W004", "Инвойс вес брутто", "Invoice.GrossWeightQuantity", "Не указан вес брутто", "Предупреждение"));
                    var weig1 = reader["NetWeightQuantity"].ToString();
                    if (string.IsNullOrEmpty(weig))
                        list.Add(GetVal(doc_id.ToString(), ValidateSection.Contract.ToString(), SubSection.Contract.ToString(),
                                "Inv.Main.W005", "Инвойс вес нетто", "Invoice.NetWeightQuantity", "Не указан вес нетто", "Предупреждение"));
                    cost = reader.GetFieldValueOrDefault<float>("TotalCost");
                    if (cost < 0.0001)
                        list.Add(GetVal(doc_id.ToString(), ValidateSection.Contract.ToString(), SubSection.Contract.ToString(),
                                "Inv.Main.W006", "Инвойс общая стоимость", "Invoice.TotalCost", "Не указана общая стоимость", "Предупреждение"));
                }
                reader.Close();
                query = $"SELECT attis_contract_currency FROM attis_contracts WHERE attis_contract_id = {contract_id};";
                var cr = provider.RunQueryStr(query).Trim();
                if (!cur.Equals(cr))
                   list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Main.E003", "Валюта инвойса", "Invoice.CurrencyCode", "Валюта инвойса и контракта не совпадают", "Ошибка"));
                query = $"SELECT SUM(attis_cg_price) FROM attis_contract_goods WHERE attis_cg_contract_id = {contract_id}";
                float sum = provider.RunScalar(query);
                if (Math.Abs(sum - cost) > 0.001)
                    list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Goods.E001", "Стоимость контракта и сумма общих стоимостей инвойсов", "attis_cg_price", "Стоимость контракта и инвойсов не совпадают", "Ошибка"));
                query = $"SELECT t1.\"GoodMarking\", t2.\"attis_cg_good_name\" from \"InvoiceGoods\" t1 INNER JOIN attis_contract_goods t2 ON t1.\"GoodsCode\" =t2.\"attis_cg_TNVED\" WHERE \"InvoiceId\" = '{inv_id}' AND attis_cg_contract_id={contract_id} Group BY (t1.\"InvoiceGoodId\", t2.\"attis_cg_TNVED\", t2.attis_cg_good_name);";
                reader = provider.RunQuery(query);
                //int row = 1;
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var mark = reader["GoodMarking"].ToString();
                        var name = reader["attis_cg_good_name"].ToString();
                        if (!mark.Equals(name))
                        {
                            list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Goods.E002", "Коммерческое наименование товаров инвойса и контракта", "GoodMarking <> attis_cg_good_name", "Коммерческое наименование товаров контракта и инвойсов не совпадают", "Ошибка"));
                            break;
                        }
                    }
                    reader.Close();
                }
                query = $"SELECT t1.\"GoodsCode\", t2.\"attis_cg_TNVED\" from \"InvoiceGoods\" t1 INNER JOIN attis_contract_goods t2 ON t1.\"GoodsCode\" =t2.\"attis_cg_TNVED\" WHERE \"InvoiceId\" = '{inv_id}' AND attis_cg_contract_id={contract_id} Group BY (t1.\"GoodsCode\", t2.\"attis_cg_TNVED\");";
                reader = provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var mark = reader["GoodsCode"].ToString().Trim();
                        var name = reader["attis_cg_TNVED"].ToString().Trim();
                        if (!mark.Equals(name)) { 
                            list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Goods.E003", "Код ТН ВЭД товаров инвойса и контракта", "GoodsCode <> attis_cg_TNVED", "Коды ТН ВЭД товаров контракта и инвойсов не совпадают", "Ошибка"));
                        break;
                    }
                    }
                    reader.Close();
                }
                query = $"SELECT t1.\"GoodsQuantity\", t1.\"MeasureUnitQualifierName\", t2.attis_cg_quantity, t2.attis_cg_measures from \"InvoiceGoods\" t1 INNER JOIN attis_contract_goods t2 ON t1.\"GoodsCode\"=t2.\"attis_cg_TNVED\" WHERE \"InvoiceId\" = '{inv_id}' AND attis_cg_contract_id={contract_id} Group BY (t1.\"GoodsQuantity\", t2.attis_cg_quantity,t2.attis_cg_measures );";
                reader = provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        int qt1 = reader.GetFieldValueOrDefault<int>("GoodsQuantity"); 
                        int qt2 = reader.GetFieldValueOrDefault<int>("attis_cg_quantity");
                        var ms1 = reader["MeasureUnitQualifierName"].ToString();
                        var ms2 = reader["attis_cg_measures"].ToString();
                        if (Math.Abs(qt1 - qt2) > 0 && (!ms1.Equals(ms2))) { 
                            list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Goods.E004", "Код ТН ВЭД товаров инвойса и контракта", "GoodsQuantity <> attis_cg_quantity", "Количество товаров контракта и инвойсов не совпадают", "Ошибка"));
                            break;
                        }
                    }

                    reader.Close();
                }

                query = $"SELECT t1.\"Price\", t2.attis_cg_price from \"InvoiceGoods\" t1 INNER JOIN attis_contract_goods t2 ON t1.\"GoodsCode\"=t2.\"attis_cg_TNVED\" WHERE \"InvoiceId\" = '{inv_id}' AND attis_cg_contract_id={contract_id} Group BY (t1.\"Price\", t2.attis_cg_price);";
                reader = provider.RunQuery(query);
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        float qt1 = reader.GetFieldValueOrDefault<float>("Price");
                        float qt2 = reader.GetFieldValueOrDefault<float>("attis_cg_price");
                        if (Math.Abs(qt1 - qt2) > 0) { 
                            list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Goods.E005", "Цены товаров инвойса и контракта", "Price<>attis_cg_price", "Цены товаров контракта и инвойсов не совпадают", "Ошибка"));
                        break;
                        }
                    }
                    reader.Close();
                }

                query = $"SELECT attis_contract_type FROM attis_contracts WHERE attis_contract_id = {contract_id}";
                int tp = provider.RunScalar(query);
                query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id = {contract_id}";
                var own = provider.RunQueryStr(query);
                query = "SELECT t2.org_name FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='" + own + "';";
                var own_org = provider.RunQueryStr(query);
                query = $"SELECT attis_contract_contragent FROM attis_contracts WHERE attis_contract_id = {contract_id}";
                var cont = provider.RunQueryStr(query);
                if (tp == 0)
                {                    
                    if (!own_org.Equals(buyer) || !cont.Equals(seller))
                        list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Goods.E006", "Покупатель контракта и инвойса", "InvoiceByer<>attis_contract_owner", "Покупатель контракта и инвойсов не совпадают", "Ошибка"));

                }
                if (tp == 1)
                {
                    if (!own_org.Equals(seller) || !cont.Equals(buyer))
                        list.Add(GetVal(doc_id.ToString(), ValidateSection.Document.ToString(), SubSection.Invoice.ToString(),
                        "Inv.Goods.E007", "Продавец контракта и инвойса", "InvoiceByer<>attis_contract_owner", "Продавец контракта и инвойсов не совпадают", "Ошибка"));

                }

            }
            return JsonConvert.SerializeObject(list);
        }


        public string PackingList(string doc_id)
        {
            var vallst = new List<ValidateModel>();
            var query = $"SELECT * FROM packing_list WHERE ref_document_id = '{doc_id}';";
            lock (provider.Locker)
            {
                var reader = provider.RunQuery(query);
                var lists = new List<PackingList>();
                var pklist = new List<PackingList>();
                if (reader != null)
                {
                    while (reader.Read())
                    {
                        var lis = new PackingList
                        {
                            list_id = reader.GetFieldValueOrDefault<int>("list_id"),
                        };
                        lis.DocumentID = reader["document_id"].ToString();
                        lists.Add(lis);
                    }
                    reader.Close();
                    var settings = new JsonSerializerSettings
                    {
                        DateFormatString = "yyyy-MM-dd",
                        DateTimeZoneHandling = DateTimeZoneHandling.Utc
                    };

                    foreach (var lst in lists)
                    {
                        query = $"SELECT t1.doc_guid, t1.attis_contract_doc_contract, t3.org_name, t2.* FROM attis_contract_docs t1 LEFT JOIN \"Invoice\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" LEFT JOIN organizations t3 ON t2.\"InvoiceSeller\" = t3.org_code WHERE t2.\"DocumentID\" = '{lst.DocumentID}';";
                        //var query1 = $"SELECT attis_cg_contract_id, attis_cg_good_name, attis_cg_SKU, attis_cg_TNVED, attis_cg_quantity, attis_cg_measures, attis_cg_price FROM attis_contract_goods WHERE attis_cg_contract_id = '{attis_contract_id}'";
                        reader = provider.RunQuery(query);
                        var list = new DocModel();
                        string contract_id = "";
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                contract_id = reader["attis_contract_doc_contract"].ToString();
                                list.DocumentID = reader["DocumentID"].ToString();
                                list.DocGuid = reader["doc_guid"].ToString();
                                list.DocumentNumber = reader["DocumentNumber"].ToString();
                                list.CurrencyCode = reader["CurrencyCode"].ToString();
                                list.PlacesQuantity = reader.GetFieldValueOrDefault<int>("PlacesQuantity"); //(int)reader["PlacesQuantity"];
                                list.PlacesDescription = reader["PlacesDescription"].ToString();
                                list.GrossWeightQuantity = reader.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader["GrossWeightQuantity"];
                                list.NetWeightQuantity = reader.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader["NetWeightQuantity"];
                                list.GCost = reader.GetFieldValueOrDefault<float>("GCost");  //(float)reader["GCost"];
                                list.Discount = reader.GetFieldValueOrDefault<float>("Discount"); //(float)reader["Discount"];
                                list.TransportCharges = reader.GetFieldValueOrDefault<float>("TransportCharges");  //(float)reader["TransportCharges"];
                                list.InsuranceCharges = reader.GetFieldValueOrDefault<float>("InsuranceCharges"); // (float)reader["InsuranceCharges"];
                                list.OtherCharges = reader.GetFieldValueOrDefault<float>("OtherCharges");
                                list.PaymentPeriod = reader.GetFieldValueOrDefault<int>("PaymentPeriod");  //(int)reader["PaymentPeriod"];
                                list.InvoiceByer = reader["InvoiceByer"].ToString();
                                list.InvoiceSeller = reader["InvoiceSeller"].ToString();
                                list.SellerName = reader["org_name"].ToString();
                            }
                            reader.Close();
                            reader = null;
                            lst.invoice = list;
                            var query1 = $"SELECT * FROM pkglist_goods WHERE list_id = '{list.DocumentID}'";
                            var reader1 = provider.RunQuery(query1);
                            var product = new List<pkglist_goods>();
                            if (reader1 != null)
                            {
                                while (reader1.Read())
                                {
                                    var rep1 = new pkglist_goods
                                    {
                                        goodsdescription = reader1["goodsdescription"].ToString(),
                                    };
                                    rep1.id = reader1.GetFieldValueOrDefault<int>("id");
                                    rep1.goodsquantity = reader1.GetFieldValueOrDefault<float>("goodsquantity");
                                    rep1.placegoodsquantity = reader1.GetFieldValueOrDefault<float>("placegoodsquantity");
                                    rep1.measureunitqualifiercode = reader1["measureunitqualifiercode"].ToString();
                                    rep1.grossweightquantity = reader1.GetFieldValueOrDefault<float>("grossweightquantity");
                                    rep1.netweightquantity = reader1.GetFieldValueOrDefault<float>("netweightquantity");
                                    //rep1.dimensions = reader1["dimensions"].ToString();
                                    //rep1.goodsvolume = reader1.GetFieldValueOrDefault<float>("goodsvolume");
                                    //rep1.volumeunitqualifier = new LibModel();
                                    //rep1.volumeunitqualifier.display_text = reader1["volumeunitqualifiername"].ToString();
                                    //rep1.measureunitqualifiername = reader1["measureunitqualifiername"].ToString();
                                    //rep1.measureunitqualifier = new LibModel();
                                    //rep1.measureunitqualifier.display_text = reader1["measureunitqualifiername"].ToString();
                                    //rep1.measureunitqualifier.value = reader1["measureunitqualifiercode"].ToString();
                                    //rep1.goodmarking = reader1["goodmarking"].ToString();
                                    product.Add(rep1);
                                }
                                reader1.Close();
                                reader1 = null;
                            }
                            lst.goods = new List<pkglist_goods>(product);
                            query1 = $"SELECT * FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{list.DocumentID}'";
                            reader1 = provider.RunQuery(query1);
                            var invprod = new List<GoodsModel>();
                            int wb = 0, wn = 0;
                            if (reader1 != null)
                            {
                                while (reader1.Read())
                                {
                                    var rep1 = new GoodsModel
                                    {
                                        GoodsCode = reader1["GoodsCode"].ToString(),
                                    };
                                    //rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                                    //rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                                    //rep1.GoodMarking = reader1["GoodMarking"].ToString();
                                    //rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                                    //rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                                    rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                                    rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                                    //rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                                    //rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                                    //rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                                    //rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                                    //rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                                    //rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                                    foreach (var gg in product)
                                    {
                                        if (Math.Abs(gg.grossweightquantity.GetValueOrDefault() - rep1.GrossWeightQuantity) < 0.0001)
                                            wb = 1;
                                        if (Math.Abs(gg.netweightquantity.GetValueOrDefault() - rep1.NetWeightQuantity) < 0.0001)
                                            wn = 1;                                                                               
                                    }
                                    
                                }
                                reader1.Close();
                                if (wb == 0)
                                vallst.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.PackingList.ToString(),
                        "PL.Pack.Main.E001", "Вес брутто товара", "pkglist_goods.grossweightquantity <> InvoiceGoods.GrossWeightQuantity", "Вес брутто товара не соответствует инвойсу", "Ошибка"));
                                if (wn == 0)
                                    vallst.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.PackingList.ToString(),
                            "PL.Pack.Main.E002", "Вес нетто товара", "pkglist_goods.netweightquantity <> InvoiceGoods.NetWeightQuantity", "Вес нетто товара не соответствует инвойсу", "Ошибка"));
                                query = $"SELECT SUM(placegoodsquantity) FROM pkglist_goods WHERE list_id = '{list.DocumentID}';";
                                int pl = provider.RunScalar(query);
                                query = $"SELECT attis_cg_quantity FROM FROM attis_contracts WHERE attis_contract_id = '{contract_id}';";
                                int cg = provider.RunScalar(query);
                                query = $"SELECT SUM(goodsquantity)FROM FROM pkglist_goods WHERE list_id = '{list.DocumentID}';";
                                int gq = provider.RunScalar(query);
                                if (cg != gq)
                                    vallst.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.PackingList.ToString(),
                           "PL.Pack.Main.E003", "Количество товара", "attis_contract_goods.attis_cg_quantity <> SUM(pkglist_goods.goodsquantity)", "Количество товара в упаковочном листе и контракте не совпадают", "Ошибка"));

                                if (pl != list.PlacesQuantity)
                                    vallst.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.PackingList.ToString(),
                           "PL.Pack.Main.E004", "Количество мест", "sum(pkglist_goods.placegoodsquantity) <> Invoices.PlacesQuantity", "Количество мест товаров в упаковочных листах и инвойсе не совпадают", "Ошибка"));
                            }
                        }
                    }
                    //return Json(san, JsonRequestBehavior.AllowGet);
                    return JsonConvert.SerializeObject(vallst, settings);
                }
            }

            return provider.lastError;

        }

        public string cmr(string doc_id)
        {
            var list = new List<ValidateModel>();
            string own = "", type ="", contr = "", send = "", recp = "";
            int cmrid = 0;
            var query = $"SELECT t2.cmr_id, t2.cmr_recipient_id, t2.cmr_sender_id FROM attis_contract_docs t1 " +
                $"LEFT JOIN \"CMR\" t2 ON t1.attis_contract_doc_id = t2.\"RefDocumentID\" " +
                $" WHERE t1.attis_contract_doc_id = '{doc_id}';";
            var reader = provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    cmrid = reader.GetFieldValueOrDefault<int>("cmr_id");
                    recp = reader["cmr_recipient_id"].ToString();
                    send = reader["cmr_sender_id"].ToString();
                }
                reader.Close();
            }
            query = $"SELECT attis_contract_doc_contract FROM attis_contract_docs WHERE attis_contract_doc_id = '{doc_id}';";
            var contract_id = provider.RunScalar(query);
            query = $"SELECT t2.org_code FROM persons t1 LEFT JOIN organizations t2 ON t1.org_id = t2.org_id WHERE user_id ='{own}';";
            var own_org = provider.RunQueryStr(query);
            query = $"SELECT attis_contract_type, attis_contract_owner, attis_contract_contragent FROM attis_contracts WHERE attis_contract_id={contract_id}";
            reader = provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    own = reader["attis_contract_owner"].ToString();
                    contr = reader["attis_contract_contragent"].ToString();
                    type = reader["attis_contract_type"].ToString(); 
                }
                reader.Close();
            }
            if (type == "1")
            {
                if (!send.Equals(contr))
                    list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                        "CMR.Main.W001", "Отправитель CMR", " CMR.cmr_sender_id <> sender in contract",
                        "Продавец контракта и CMR не совпадают", "Предупреждение"));
                if (!own_org.Equals(recp))
                    list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                        "CMR.Main.W002", "Получатель CMR", " CMR.cmr_recipient_id<> receiver in contract",
                        "Покупатель контракта и CMR не совпадают", "Предупреждение"));
            }
            if (type == "2")
            {
                if (!send.Equals(own_org))
                    list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                        "CMR.Main.W001", "Отправитель CMR", " CMR.cmr_sender_id <> sender in contract",
                        "Продавец контракта и инвойсов не совпадают", "Предупреждение"));
                if (!contr.Equals(recp))
                    list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                        "CMR.Main.W002", "Получатель CMR", " CMR.cmr_recipient_id <> receiver in contract",
                        "Покупатель контракта и инвойсов не совпадают", "Предупреждение"));
            }

            query = $"SELECT t1.\"DocumentID\", t3.* FROM \"Invoice\" t1 LEFT JOIN attis_contract_docs t2 ON t2.attis_contract_doc_id = t1.\"RefDocumentID\" LEFT JOIN \"InvoiceGoods\" t3 ON t1.\"DocumentID\" = t3.\"InvoiceId\" WHERE t2.attis_contract_doc_contract = {contract_id} AND t2.attis_contract_doc_type = 1;";
            var reader1 = provider.RunQuery(query);
            var product = new List<GoodsModel>();
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new GoodsModel
                    {
                        GoodsCode = reader1["GoodsCode"].ToString(),
                    };
                    rep1.OriginCountryCode = reader1["OriginCountryCode"].ToString();
                    rep1.SupplementaryQualifierName = reader1["SupplementaryQualifierName"].ToString();
                    rep1.GoodMarking = reader1["GoodMarking"].ToString();
                    rep1.GoodsDescription = reader1["GoodsDescription"].ToString();
                    rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                    rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                    rep1.NetWeightQuantity = reader1.GetFieldValueOrDefault<float>("NetWeightQuantity"); //(float)reader1["NetWeightQuantity"];
                    rep1.Price = reader1.GetFieldValueOrDefault<float>("Price"); //(float)reader1["Price"];
                    rep1.Discount = reader1.GetFieldValueOrDefault<float>("Discount"); //(float)reader1["Discount"];
                    rep1.DiscountPercentage = reader1.GetFieldValueOrDefault<float>("DiscountPercentage"); //(float)reader1["DiscountPercentage"];
                    rep1.ServiceCharges = reader1.GetFieldValueOrDefault<float>("ServiceCharges"); //(float)reader1["ServiceCharges"];
                    rep1.TransportCharges = reader1.GetFieldValueOrDefault<float>("TransportCharges"); //(float)reader1["TransportCharges"];
                    rep1.OtherCharges = reader1.GetFieldValueOrDefault<float>("OtherCharges"); //(float)reader1["OtherCharges"];
                    product.Add(rep1);
                }
                reader1.Close();
            }
            int invcount = product.Count;
            var query1 = $"SELECT * FROM \"CMRGoods\" WHERE \"CmrId\" = '{cmrid}'";
            reader1 = provider.RunQuery(query1);
            int pr = 0, wg = 0, cmrcount = 0;
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new CMRGoodsModel
                    {
                        GoodMarking = reader1["GoodsMarking"].ToString(),
                    };
                    //rep1.GoodMarking = reader1["GoodMarking"].ToString();
                    rep1.Id = reader1["cmr_good_id"].ToString();
                    rep1.GoodsNomenclatureCode = reader1["GoodsNomenclatureCode"].ToString().TrimEnd();
                    rep1.GoodsDescription = reader1["GoodsDescription"].ToString().TrimEnd();
                    rep1.GoodsPrice = reader1.GetFieldValueOrDefault<float>("GoodsPrice");
                    rep1.GoodsQuantity = reader1.GetFieldValueOrDefault<float>("GoodsQuantity"); //(float)reader1["GoodsQuantity"];
                    rep1.GrossWeightQuantity = reader1.GetFieldValueOrDefault<float>("GrossWeightQuantity"); //(float)reader1["GrossWeightQuantity"];
                    rep1.VolumeQuantity = reader1.GetFieldValueOrDefault<float>("VolumeQuantity"); //(float)reader1["Price"];
                    foreach (var gg in product)
                    {
                        if (Math.Abs(gg.GrossWeightQuantity - rep1.GrossWeightQuantity) < 0.0001)
                            wg = 1;
                        if (Math.Abs(gg.Price - rep1.GoodsPrice.GetValueOrDefault()) < 0.0001)
                            pr = 1;
                    }
                    cmrcount++;
                }
                reader1.Close();
            }
            query = $"SELECT SUM(packing_quantity) FROM places_list WHERE cmr_id = '{cmrid}'";
            int cmrplaces = provider.RunScalar(query);
            query = $"SELECT t1.document_id FROM packing_list t1 LEFT JOIN attis_contract_docs t2 ON t2.attis_contract_doc_id=t1.ref_document_id::bigint WHERE t2.attis_contract_doc_contract = {contract_id}";
            int listid = provider.RunScalar(query);
            query = $"SELECT SUM(t1.placesquantity) FROM pkglist_goods_placesquantity t1 LEFT JOIN pkglist_goods t2 ON t2.id=t1.goods_id WHERE t2.list_id = {listid};";
            int packplaces = provider.RunScalar(query);
            if (wg == 0)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                    "CMR.Main.E001", "Вес груза CMR", "CMRGoods.GrossWeightQuantity <> InvoiceGoods.GrossWeightQuantity",
                    "Вес брутто товара не совпадает с инвойсом", "Ошибка"));
            if (pr == 0)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                    "CMR.Main.E002", "Стоимость груза CMR", "CMRGoods.GoodsPrice <> InvoiceGoods.Price",
                    "Стоимость груза CMR не совпадает с инвойсом", "Ошибка"));
            if (invcount != cmrcount)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                    "CMR.Main.W003", "Количество товаров", "count(Invoice.InvoiceGoodId) <> count (CMRGoods.cmr_good_id)",
                    "Количество товаров в CMR и контракте не совпадают", "Предупреждение"));
            if (cmrplaces != packplaces)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.CMR.ToString(),
                    "CMR.Main.W004", "Количество грузовых мест", "sum(pkglist_goods_packinginfo.placesquantity)<> sum(places_list.packing_quantity)",
                    "Количество грузовых мест в упаковочных листах не совпадает с местами в CMR", "Предупреждение"));
            return JsonConvert.SerializeObject(list);
        }
            public string epi(string doc_id)
        {
            var list = new List<ValidateModel>();
            var query = $"SELECT t2.ap_main_id FROM attis_contract_docs t1 " +
                        $"LEFT JOIN ap_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id" +
                        //$"LEFT JOIN ap_goods t3 ON t2.ap_main_id = t3.ap_good_main_id " +
                        $" WHERE t1.attis_contract_doc_id = '{doc_id}';";
            int apd = provider.RunScalar(query);
            query = $"SELECT attis_contract_doc_contract FROM attis_contract_docs WHERE attis_contract_doc_id = '{doc_id}';";
            var contract_id = provider.RunScalar(query);

            var query1 = $"SELECT * FROM ap_good_data WHERE ap_main_id = '{apd}'";
            var reader1 = provider.RunQuery(query1);
            var product = new List<EpGoods>();
            if (reader1 != null)
            {
                while (reader1.Read())
                {
                    var rep1 = new EpGoods
                    {
                        ap_good_data_goods_numeric = reader1["ap_good_data_goods_numeric"].ToString(),
                    };
                    //rep1.GoodsCode = reader1["GoodsCode"].ToString();
                    rep1.ap_good_data_list_numeric = reader1["ap_good_data_list_numeric"].ToString();
                    rep1.ap_good_data_goods_description = reader1["ap_good_data_goods_description"].ToString();
                    rep1.ap_good_data_gross_weight_quantity = reader1.GetFieldValueOrDefault<float>("ap_good_data_gross_weight_quantity");
                    rep1.ap_good_data_net_weight_quantity = reader1.GetFieldValueOrDefault<float>("ap_good_data_net_weight_quantity");
                    rep1.ap_good_data_invoiced_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_invoiced_cost");
                    rep1.ap_good_data_customs_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_customs_cost");
                    rep1.ap_good_data_statistical_cost = reader1.GetFieldValueOrDefault<float>("ap_good_data_statistical_cost");
                    rep1.ap_good_data_goods_tnved_code = reader1["ap_good_data_goods_tnved_code"].ToString();
                    rep1.ap_good_data_origin_country_code = reader1["ap_good_data_origin_country_code"].ToString();
                    rep1.ap_good_data_delivery_terms_string_code = reader1["ap_good_data_delivery_terms_string_code"].ToString();
                    rep1.ap_good_data_quant = reader1.GetFieldValueOrDefault<float>("ap_good_data_quant");
                    rep1.ap_good_data_ext_measure = reader1["ap_good_data_ext_measure"].ToString();
                    rep1.ap_good_data_container_num = reader1["ap_good_data_container_num"].ToString();
                    rep1.ap_good_data_places = reader1.GetFieldValueOrDefault<float>("ap_good_data_places");
                    rep1.ap_good_data_places_name = reader1["ap_good_data_places_name"].ToString();
                    rep1.ap_good_data_packet = reader1.GetFieldValueOrDefault<int>("ap_good_data_packet");
                    product.Add(rep1);
                }
                reader1.Close();
            }
            query = $"SELECT t3.ap_good_total_package_number FROM attis_contract_docs t1 " +
                        $"LEFT JOIN ap_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                        $"LEFT JOIN ap_goods t3 ON t2.ap_main_id = t3.ap_good_main_id " +
                        $" WHERE t1.attis_contract_doc_id = '{doc_id}';";
            int pn = provider.RunScalar(query);
            query = $"select attis_contract_doc_id from attis_contract_docs where category = '1' and attis_contract_doc_contract = '{contract_id}'";
            int iid = provider.RunScalar(query);
            query = $"select count(*) FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{iid}'";
            int invcount = provider.RunScalar(query);
            if (pn != invcount)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.Epi.ToString(),
       "AP.Goods.W002", "Количество наименований товаров", "ap_goods.ap_good_total_goods_number <> count (InvoiceGoods.GoodsCode)", "Общее количество грузовых мест в ЭПИ не совпадает с Упаковочными листами", "Ошибка"));

            query = $"SELECT t3.ap_good_total_goods_number FROM attis_contract_docs t1 " +
                        $"LEFT JOIN ap_main t2 ON t1.attis_contract_doc_id = t2.ref_doc_id " +
                        $"LEFT JOIN ap_goods t3 ON t2.ap_main_id = t3.ap_good_main_id " +
                        $" WHERE t1.attis_contract_doc_id = '{doc_id}';";
            int gn = provider.RunScalar(query);

            query = $"SELECT sum(ap_good_data_gross_weight_quantity) FROM ap_good_data WHERE ap_main_id = '{apd}';";
            float gw = provider.RunScalar(query);
            query = $"select sum(\"GrossWeightQuantity\") FROM \"InvoiceGoods\" WHERE \"InvoiceId\" = '{iid}'";
            float invgr = provider.RunScalar(query);
            if (Math.Abs(gw - invgr) > 0.001)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.Epi.ToString(),
       "AP.Goods.W003", "Вес товара", "sum(InvoiceGoods.GrossWeightQuantity) <> ap_goods.ap_good_data_gross_weight_quantity", "Вес брутто товара не совпадает с инвойсом", "Ошибка"));

            query = $"select attis_contract_doc_id from attis_contract_docs where category = '7' and attis_contract_doc_contract = '{contract_id}'";
            int did = provider.RunScalar(query);
            query = $"SELECT list_id FROM packing_list WHERE ref_document_id = '{did}';";
            int list_id = provider.RunScalar(query);
            query = $"SELECT SUM(placegoodsquantity) FROM pkglist_goods WHERE list_id = '{list_id}';";
            int pl = provider.RunScalar(query);
            if (pl != pn)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.Epi.ToString(),
       "AP.Goods.W004", "Общее количество грузовых мест", "sum(pkglist_goods.placegoodsquantity) <> ap_goods.ap_good_total_package_number", "Общее количество грузовых мест в ЭПИ не совпадает с Упаковочными листами", "Предупреждение"));

            //AP.Goods.W002	Количество наименований товаров	attis_contracts.attis_contract_id	ap_goods.ap_good_total_goods_number <> count ("InvoiceGoods".GoodsCode)		Количество товаров в инвойсе и ЭПИ не совпадают	Ошибка
            //AP.Goods.W003	Вес товара	"Invoice"."DocumentID"	"InvoiceGoods".GrossWeightQuantity <> ap_goods.ap_good_data_gross_weight_quantity		Вес брутто товара не совпадает с инвойсом	Ошибка
            //AP.Goods.W004	Общее количество грузовых мест	attis_contracts.attis_contract_id	sum(pkglist_goods.placegoodsquantity) <> ap_goods.ap_good_total_package_number		Общее количество грузовых мест в ЭПИ не совпадает с Упаковочными листами	Предупреждение
            //AP.Goods.W005	Товарная часть - товары	attis_contracts.attis_contract_id	sum(ap_good_data.*) <> sum (CMRGoods.*)	Если есть CMR 	Количество товаров в CMR и ЭПИ не совпадают	Предупреждение
            query = $"select count(*) FROM ap_good_data WHERE ap_main_id = '{apd}'";
            int ap_count = provider.RunScalar(query);
            query = $"select attis_contract_doc_id from attis_contract_docs where category = '3' and attis_contract_doc_contract = '{contract_id}'";
            did = provider.RunScalar(query);
            query = $"SELECT cmr_id FROM \"CMR\" WHERE \"RefDocumentID\" = '{did}';";
            int cid = provider.RunScalar(query);
            query = $"select count(*) FROM \"CMRGoods\" WHERE \"CmrId\" = '{cid}'";
            int cmr_count = provider.RunScalar(query);
            if (ap_count != cmr_count)
                list.Add(GetVal(doc_id, ValidateSection.Document.ToString(), SubSection.Epi.ToString(),
       "AP.Goods.W005", "Товарная часть", "sum(ap_good_data.*) <> sum (CMRGoods.*)", "Количество товаров в CMR и ЭПИ не совпадают", "Предупреждение"));

            return JsonConvert.SerializeObject(list);
        }
        public string ContractFull(int contract_id)
        {
            var fullValidation = new List<ValidateModel>();
            List<ValidateModel> contractValidation = new List<ValidateModel>();
            var packingListIds = new List<string>();
            var invoiceListIds = new List<string>();
            var epiListIds = new List<string>();
            // check contract validation
            contractValidation = JsonConvert.DeserializeObject<List<ValidateModel>>(Contract(contract_id));
            fullValidation.AddRange(contractValidation);

            // All contract documents
            string query = $"SELECT attis_contract_owner FROM attis_contracts WHERE attis_contract_id='{contract_id}'";
            query = $"SELECT t1.*, t2.attis_doc_type_name_ru FROM attis_contract_docs t1 LEFT JOIN  attis_doc_types t2 ON t1.attis_contract_doc_type = t2.attis_doc_type_code WHERE attis_contract_doc_contract = '{contract_id}';";
            var reader = provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    if (reader["attis_doc_type_name_ru"].ToString() == "Инвойс")
                    {
                        invoiceListIds.Add(reader["attis_contract_doc_id"].ToString());
                    }
                    else if (reader["attis_doc_type_name_ru"].ToString() == "Пакинг лист")
                    {
                        packingListIds.Add(reader["attis_contract_doc_id"].ToString());
                    }
                    else if (reader["attis_doc_type_name_ru"].ToString() == "ЭПИ")
                    {
                        epiListIds.Add(reader["attis_contract_doc_id"].ToString());
                    }
                }
                reader.Close();


               
            }
            if (invoiceListIds.Count > 0)
            {
                foreach (var id in invoiceListIds)
                {
                    List<ValidateModel> invoice = JsonConvert.DeserializeObject<List<ValidateModel>>(Invoice(Int32.Parse(id)));
                    fullValidation.AddRange(invoice);
                }
            }
            if (packingListIds.Count > 0)
            {
                foreach (var id in packingListIds)
                {
                    List<ValidateModel> packing = JsonConvert.DeserializeObject<List<ValidateModel>>(PackingList(id));
                    fullValidation.AddRange(packing);
                }
            }
            if (epiListIds.Count > 0)
            {
                foreach (var id in epiListIds)
                {
                    List<ValidateModel> epiValidation = JsonConvert.DeserializeObject<List<ValidateModel>>(epi(id));
                    fullValidation.AddRange(epiValidation);
                }
            }
            return JsonConvert.SerializeObject(fullValidation);

        }
        private ValidateModel GetVal(string id, string sec, string sub, string con, string nam, string val, string txt, string lvl)
        {
            var res = new ValidateModel();
           //var aa =(ValidateSection)sec;
            res.Section = sec;
            res.Subsection = sub;
            res.ControlNo = con;
            res.Name = nam;
            res.Value = val;
            //res.EndData = end;
            res.Text = txt;
            res.Level = lvl;
            res.Id = id;
            return res;
        }
    }
}