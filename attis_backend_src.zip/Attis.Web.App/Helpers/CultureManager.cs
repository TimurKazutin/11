﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using Lawyers.Common;

namespace Lawyers.Web.App.Helpers
{
    public static class CultureManager
    {
        static CultureManager()
        {
            SupportedCultures = new Dictionary<string, CultureInfo>();

            AddSupportedCulture(Cultures.RussianCultureName);
            AddSupportedCulture(Cultures.KazakhCultureName);
            AddSupportedCulture(Cultures.EnglishCultureName);
        }

        public static CultureInfo DefaultCulture
        {
            get
            {
                return SupportedCultures[Cultures.RussianCultureName];
            }
        }

        private static Dictionary<string, CultureInfo> SupportedCultures { get; set; }


        private static void AddSupportedCulture(string name)
        {
            SupportedCultures.Add(name, CultureInfo.CreateSpecificCulture(Cultures.GetFullLanguage(name)));
        }

        private static string ConvertToShortForm(string code)
        {
            return code.Substring(0, 2);
        }

        public static bool CultureIsSupported(string code)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                return false;
            }

            code = code.ToLowerInvariant();

            if (code.Length == 2)
            {
                return SupportedCultures.ContainsKey(code);
            }

            return CultureFormatChecker.FormattedAsCulture(code) && SupportedCultures.ContainsKey(ConvertToShortForm(code));
        }

        public static string GetLanguage(string code)
        {
            if (!CultureIsSupported(code))
            {
                return DefaultCulture.TwoLetterISOLanguageName;
            }

            return ConvertToShortForm(code).ToLowerInvariant();
        }

        public static string GetLanguage()
        {
            var code = Thread.CurrentThread.CurrentUICulture.TwoLetterISOLanguageName;

            if (!CultureIsSupported(code))
            {
                return DefaultCulture.TwoLetterISOLanguageName;
            }

            return ConvertToShortForm(code).ToLowerInvariant();
        }

        private static CultureInfo GetCulture(String code)
        {
            if (!CultureIsSupported(code))
            {
                return DefaultCulture;
            }

            var shortForm = ConvertToShortForm(code).ToLowerInvariant(); ;

            return SupportedCultures[shortForm];
        }

        public static void SetCulture(String code)
        {
            var cultureInfo = GetCulture(code);

            Thread.CurrentThread.CurrentUICulture = cultureInfo;
            Thread.CurrentThread.CurrentCulture = cultureInfo;
        }
    }
}