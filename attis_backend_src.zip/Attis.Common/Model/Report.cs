﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 02-18-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 04-02-2015
// ***********************************************************************
// <copyright file="Report.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;
    using System.Xml.Serialization;
    using System.Xml.Xsl;

    /// <summary>
    /// Class Report.
    /// </summary>
    [XmlRoot("report")]
    public class Report
    {
        /// <summary>
        /// Gets the XSLT transform.
        /// </summary>
        /// <value>The XSLT transform.</value>
        [XmlIgnore]
        public XslCompiledTransform XsltTransform { get; private set; }

        /// <summary>
        /// Gets the XSLT transform excel.
        /// </summary>
        /// <value>The XSLT transform excel.</value>
        [XmlIgnore]
        public XslCompiledTransform XsltTransformExcel { get; private set; }

        /// <summary>
        /// The XSLT
        /// </summary>
        [XmlIgnore]
        private XmlNode xslt;

        /// <summary>
        /// The XSLT excel
        /// </summary>
        [XmlIgnore]
        private XmlNode xsltExcel;

        /// <summary>
        /// Gets or sets the query.
        /// </summary>
        /// <value>The query.</value>
        [XmlElement("query")]
        public string Query { get; set; }

        [XmlElement("queryLawyer")]
        public string QueryLawyer { get; set; }

        [XmlElement("queryCollegium")]
        public string QueryCollegium { get; set; }

        /// <summary>
        /// Gets or sets the XSLT.
        /// </summary>
        /// <value>The XSLT.</value>
        [XmlElement("xslt")]
        public XmlNode Xslt
        {
            get
            {
                return this.xslt;
            }
            set
            {
                this.xslt = value;

                using (XmlReader xmlReader = XmlReader.Create(new StringReader(this.xslt.OuterXml)))
                {
                    this.XsltTransform.Load(xmlReader);
                }
            }
        }

        /// <summary>
        /// Gets or sets the XSLT excel.
        /// </summary>
        /// <value>The XSLT excel.</value>
        [XmlElement("xsltExcel")]
        public XmlNode XsltExcel
        {
            get
            {
                return this.xsltExcel;
            }
            set
            {
                this.xsltExcel = value;

                using (XmlReader xmlReader = XmlReader.Create(new StringReader(this.xsltExcel.OuterXml)))
                {
                    this.XsltTransformExcel.Load(xmlReader);
                }
            }
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [XmlIgnore]
        public string Name { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Report"/> class.
        /// </summary>
        public Report()
        {
            this.XsltTransform = new XslCompiledTransform();
            this.XsltTransformExcel = new XslCompiledTransform();
        }

        /// <summary>
        /// Gets or sets the parameters.
        /// </summary>
        /// <value>The parameters.</value>
        [XmlArray("params")]
        [XmlArrayItem(Type = typeof(ReportParameter), ElementName = "param")]
        public List<ReportParameter> Parameters { get; set; }

        /// <summary>
        /// Clears the parameters values.
        /// </summary>
        public void ClearParametersValues()
        {
            foreach (var param in this.Parameters) param.Value = string.Empty;
        }
    }
}
