﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 11-05-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 05-20-2015
// ***********************************************************************
// <copyright file="RoleType.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    using System;

    /// <summary>
    /// Enum RoleType
    /// </summary>
    [Flags]
    public enum RoleType
    {
        /// <summary>
        /// The client
        /// </summary>
        Client = 1,
        /// <summary>
        /// The manager
        /// </summary>
        Manager = 2,
        /// <summary>
        /// The analyst
        /// </summary>
        Analyst = 4,
        /// <summary>
        /// The admin
        /// </summary>
        Admin = 8,
        /// <summary>
        /// The debtor
        /// </summary>
        Debtor = 16,
        /// <summary>
        /// The SKM
        /// </summary>
        SKM = 32
    }
}
