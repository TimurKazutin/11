﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 8-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Models namespace.
/// </summary>
namespace Lawyers.Web.App.Models
{
    using Microsoft.AspNet.Identity;
    using Microsoft.Owin.Security;
    using Resources;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    /// <summary>
    /// Class IndexViewModel.
    /// </summary>
    public class IndexViewModel
    {
        /// <summary>
        /// Gets or sets a value indicating whether this instance has password.
        /// </summary>
        /// <value><c>true</c> if this instance has password; otherwise, <c>false</c>.</value>
        public bool HasPassword { get; set; }
        /// <summary>
        /// Gets or sets the logins.
        /// </summary>
        /// <value>The logins.</value>
        public IList<UserLoginInfo> Logins { get; set; }
        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>The phone number.</value>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [two factor].
        /// </summary>
        /// <value><c>true</c> if [two factor]; otherwise, <c>false</c>.</value>
        public bool TwoFactor { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [browser remembered].
        /// </summary>
        /// <value><c>true</c> if [browser remembered]; otherwise, <c>false</c>.</value>
        public bool BrowserRemembered { get; set; }
    }

    /// <summary>
    /// Class ManageLoginsViewModel.
    /// </summary>
    public class ManageLoginsViewModel
    {
        /// <summary>
        /// Gets or sets the current logins.
        /// </summary>
        /// <value>The current logins.</value>
        public IList<UserLoginInfo> CurrentLogins { get; set; }
        /// <summary>
        /// Gets or sets the other logins.
        /// </summary>
        /// <value>The other logins.</value>
        public IList<AuthenticationDescription> OtherLogins { get; set; }
    }

    /// <summary>
    /// Class FactorViewModel.
    /// </summary>
    public class FactorViewModel
    {
        /// <summary>
        /// Gets or sets the purpose.
        /// </summary>
        /// <value>The purpose.</value>
        public string Purpose { get; set; }
    }

    /// <summary>
    /// Class SetPasswordViewModel.
    /// </summary>
    public class SetPasswordViewModel
    {
        /// <summary>
        /// Gets or sets the new password.
        /// </summary>
        /// <value>The new password.</value>
        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [StringLength(100, MinimumLength = 8, ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "SetPasswordViewModel_NewPasswordLength")]
        [DataType(DataType.Password)]
        [Display(Name = "SetPasswordViewModel_NewPassword", ResourceType = typeof(GlobalStrings))]
        public string NewPassword { get; set; }

        /// <summary>
        /// Gets or sets the confirm password.
        /// </summary>
        /// <value>The confirm password.</value>
        [DataType(DataType.Password)]
        [Display(Name = "SetPasswordViewModel_ConfirmNewPassword", ResourceType = typeof(GlobalStrings))]
        [Compare("NewPassword", ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "SetPasswordViewModel_PasswordNotMatch")]
        public string ConfirmPassword { get; set; }
    }

    /// <summary>
    /// Class ChangePasswordViewModel.
    /// </summary>
    public class ChangePasswordViewModel
    {
        /// <summary>
        /// Gets or sets the old password.
        /// </summary>
        /// <value>The old password.</value>
        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [DataType(DataType.Password)]
        [Display(Name = "Model_CurrentPassword", ResourceType =typeof(GlobalStrings))]
        public string OldPassword { get; set; }

        /// <summary>
        /// Gets or sets the new password.
        /// </summary>
        /// <value>The new password.</value>
        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [StringLength(100, MinimumLength = 8, ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "SetPasswordViewModel_NewPasswordLength")]
        [DataType(DataType.Password)]
        [Display(Name = "SetPasswordViewModel_NewPassword", ResourceType = typeof(GlobalStrings))]
        public string NewPassword { get; set; }

        /// <summary>
        /// Gets or sets the confirm password.
        /// </summary>
        /// <value>The confirm password.</value>
        [DataType(DataType.Password)]
        [Display(Name = "SetPasswordViewModel_ConfirmNewPassword", ResourceType = typeof(GlobalStrings))]
        [Compare("NewPassword", ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "SetPasswordViewModel_PasswordNotMatch")]
        public string ConfirmPassword { get; set; }
    }

    /// <summary>
    /// Class AddPhoneNumberViewModel.
    /// </summary>
    public class AddPhoneNumberViewModel
    {
        /// <summary>
        /// Gets or sets the number.
        /// </summary>
        /// <value>The number.</value>
        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [Phone(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Model_Phone")]
        [Display(Name = "Model_PhoneNumber", ResourceType = typeof(GlobalStrings))]
        public string Number { get; set; }
    }

    /// <summary>
    /// Class VerifyPhoneNumberViewModel.
    /// </summary>
    public class VerifyPhoneNumberViewModel
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [Display(Name = "Model_Code", ResourceType =typeof(GlobalStrings))]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>The phone number.</value>
        [Required(ErrorMessageResourceType =typeof(GlobalStrings), ErrorMessageResourceName ="Models_Required")]
        [Phone(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName ="Model_Phone")]
        [Display(Name = "Model_PhoneNumber", ResourceType =typeof(GlobalStrings))]
        public string PhoneNumber { get; set; }
    }

    /// <summary>
    /// Class ConfigureTwoFactorViewModel.
    /// </summary>
    public class ConfigureTwoFactorViewModel
    {
        /// <summary>
        /// Gets or sets the selected provider.
        /// </summary>
        /// <value>The selected provider.</value>
        public string SelectedProvider { get; set; }
        /// <summary>
        /// Gets or sets the providers.
        /// </summary>
        /// <value>The providers.</value>
        public ICollection<System.Web.Mvc.SelectListItem> Providers { get; set; }
    }
}