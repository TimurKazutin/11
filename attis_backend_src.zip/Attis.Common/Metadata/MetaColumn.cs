﻿
namespace Lawyers.Common.Metadata
{
	using System.Xml.Serialization;

	public class MetaColumn
	{
		[XmlAttribute]
		public string Name { get; set; }

		[XmlAttribute]
		public string DataType { get; set; }

		[XmlAttribute]
		public string Size { get; set; }

		[XmlAttribute]
		public bool Nullable { get; set; }

		[XmlAttribute]
		public string Comment { get; set; }
	}
}
