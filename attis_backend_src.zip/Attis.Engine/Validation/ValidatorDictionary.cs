﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 11-15-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-15-2014
// ***********************************************************************
// <copyright file="ValidatorDictionary.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Validation namespace.
/// </summary>
namespace Lawyers.Engine.Validation
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class ValidatorDictionary.
    /// </summary>
    public class ValidatorDictionary : SortedDictionary<Guid, Validator>
    {
    }
}
