﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 11-02-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 12-04-2014
// ***********************************************************************
// <copyright file="SqlQueryType.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Enums namespace.
/// </summary>
namespace Lawyers.Common.Enums
{
    /// <summary>
    /// Enum SqlQueryType
    /// </summary>
    public enum SqlQueryType
    {
        /// <summary>
        /// The select
        /// </summary>
        Select,
        /// <summary>
        /// The insert
        /// </summary>
        Insert,
        /// <summary>
        /// The update
        /// </summary>
        Update,
        /// <summary>
        /// The delete
        /// </summary>
        Delete
    }
}
