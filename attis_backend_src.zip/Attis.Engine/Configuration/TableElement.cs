﻿
namespace Lawyers.Engine.Configuration
{
	using System.Configuration;

	public class TableElement: ConfigurationElement
	{
		private TableElement() { }

		[ConfigurationProperty("name")]
		public string Name
		{
			get { return (string)this["name"]; }
			set { this["name"] = value; }
		}

		[ConfigurationProperty("templateField")]
		public string TemplateField
		{
			get { return (string)this["templateField"]; }
			set { this["templateField"] = value; }
		}

		[ConfigurationProperty("roleField")]
		public string RoleField
		{
			get { return (string)this["roleField"]; }
			set { this["roleField"] = value; }
		}
	}
}
