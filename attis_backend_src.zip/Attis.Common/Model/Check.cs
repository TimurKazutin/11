﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-18-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 11-16-2014
// ***********************************************************************
// <copyright file="Check.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Collections.Generic;
    using System.Xml.Serialization;

    /// <summary>
    /// Class Check.
    /// </summary>
    [XmlType]
    public class Check
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }


        /// <summary>
        /// Gets or sets the caption.
        /// </summary>
        /// <value>The caption.</value>
        public string Caption
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(CaptionRu))
                    return CaptionRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(CaptionKk))
                    return CaptionKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(CaptionEn))
                    return CaptionEn;
                return CaptionRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    CaptionRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    CaptionKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    CaptionEn = value;
                    return;
                }
                CaptionRu = value;
            }
        }

        /// <summary>
        /// Gets or sets the caption en.
        /// </summary>
        /// <value>The caption en.</value>
        [XmlAttribute(AttributeName = "caption_en")]
        public string CaptionEn { get; set; }

        /// <summary>
        /// Kazakh language Caption.
        /// <value>The caption Kazakhstan.</value>
        [XmlAttribute(AttributeName = "caption_kz")]
        public string CaptionKk { get; set; }

        /// <summary>
        /// Chinese language Caption.
        /// <value>The caption Chinese.</value>
        [XmlAttribute(AttributeName = "caption_ru")]
        public string CaptionRu { get; set; }

        /// <summary>
        /// Gets or sets the actions.
        /// </summary>
        /// <value>The actions.</value>
        [XmlElement(ElementName = "action")]
        public List<Action> Actions { get; set; }

        /// <summary>
        /// Gets or sets the condition.
        /// </summary>
        /// <value>The condition.</value>
        [XmlElement(ElementName = "condition")]
        public Condition Condition { get; set; }

        /// <summary>
        /// Determines whether the specified widget name contains widget.
        /// </summary>
        /// <param name="widgetName">Name of the widget.</param>
        /// <returns><c>true</c> if the specified widget name contains widget; otherwise, <c>false</c>.</returns>
        public bool ContainsWidget(string widgetName)
        {
            return Condition.ContainsWidget(widgetName);
        }
    }
}
