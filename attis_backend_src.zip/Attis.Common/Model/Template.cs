﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 10-28-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-28-2014
// ***********************************************************************
// <copyright file="Template.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
	using System;
    using System.Threading;
	using System.Collections.Generic;
	using System.Xml.Serialization;

	/// <summary>
	/// Class Template.
	/// </summary>
	[XmlRoot("template")]
    public class Template
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [XmlAttribute("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the unique identifier.
        /// </summary>
        /// <value>The unique identifier.</value>
        [XmlAttribute("template_guid")]
        public Guid Guid { get; set; }

        /// <summary>
        /// Gets or sets the group unique identifier.
        /// </summary>
        /// <value>The group unique identifier.</value>
        [XmlAttribute("template_group_guid")]
        public Guid GroupGuid { get; set; }

        /// <summary>
        /// Gets or sets the caption.
        /// </summary>
        /// <value>The caption.</value>
        public string Caption
        {
            get
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName && !string.IsNullOrEmpty(CaptionRu))
                    return CaptionRu;
                if (currentCulturePostfix == Cultures.KazakhCultureName && !string.IsNullOrEmpty(CaptionKk))
                    return CaptionKk;
                if (currentCulturePostfix == Cultures.EnglishCultureName && !string.IsNullOrEmpty(CaptionEn))
                    return CaptionEn;
                return CaptionRu;
            }
            set
            {
                var currentCulturePostfix = Cultures.GetLanguage();

                if (currentCulturePostfix == Cultures.RussianCultureName)
                {
                    CaptionRu = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.KazakhCultureName)
                {
                    CaptionKk = value;
                    return;
                }
                if (currentCulturePostfix == Cultures.EnglishCultureName)
                {
                    CaptionEn = value;
                    return;
                }
                CaptionRu = value;
            }
        }

        /// <summary>
        /// Gets or sets the caption en.
        /// </summary>
        /// <value>
        /// The caption en.
        /// </value>
        [XmlAttribute(AttributeName = "caption_en")]
        public string CaptionEn { get; set; }

        /// <summary>
        /// Kazakh language Caption.
        /// </summary>
        [XmlAttribute(AttributeName = "caption_kz")]
        public string CaptionKk { get; set; }

        /// <summary>
        /// Chinese language Caption.
        /// </summary>
        [XmlAttribute(AttributeName = "caption_ru")]
        public string CaptionRu { get; set; }

        //[XmlAttribute("caption_en")]
        //public string Caption { get; set; }

        /// <summary>
        /// Gets or sets the major version.
        /// </summary>
        /// <value>The major version.</value>
        [XmlAttribute("major_version_number")]
        public int MajorVersion { get; set; }

        /// <summary>
        /// Gets or sets the minor version.
        /// </summary>
        /// <value>The version minor.</value>
        [XmlAttribute("minor_version_number")]
        public int MinorVersion { get; set; }

        /// <summary>
        /// Gets or sets the document.
        /// </summary>
        /// <value>The document.</value>
        [XmlElement("document")]
        public Document Document { get; set; }

        /// <summary>
        /// Gets or sets the data sources.
        /// </summary>
        /// <value>The data sources.</value>
        [XmlArray("datasources")]
        [XmlArrayItem(Type = typeof(DataSource), ElementName = "datasource")]
        public List<DataSource> DataSources { get; set; }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>The title.</value>
        [XmlIgnore]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the roles.
        /// </summary>
        /// <value>The roles.</value>
        [XmlIgnore]
        public int Roles { get; set; }
    }
}
