﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 11-04-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 14-10-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Controllers namespace.
/// </summary>

using Lawyers.Engine.Configuration;
using Lawyers.Engine.Data;
using Lawyers.Engine.Validation;

namespace Lawyers.Web.App.Controllers
{
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Script.Serialization;
    using Lawyers.Common;
    using Lawyers.Common.Enums;
    using Common.Model;
    //using Lawyers.Database.Oracle;
    using Resources;

    /// <summary>
    /// Enum OperationType
    /// </summary>
    public enum OperationType
    {
        /// <summary>
        /// Delete
        /// </summary>
        Delete,
        /// <summary>
        /// Insert
        /// </summary>
        Insert,
        /// <summary>
        /// Update
        /// </summary>
        Update,
        /// <summary>
        /// List
        /// </summary>
        List
    }

    /// <summary>
    /// Class TemplateController.
    /// </summary>
    [Authorize]
	public class TemplateController : Controller
	{
		/// <summary>
		/// Gets the templates.
		/// </summary>
		/// <value>The templates.</value>
		private TemplateDictionary Templates
		{
			get
			{
				TemplateDictionary templates = (TemplateDictionary)HttpContext.Session["Templates"];

				if (templates == null) // Just created
				{
					templates = GlobalContainer.Instance.Get<Configuration>().GetTemplates();
					HttpContext.Session["Templates"] = templates;
				}

				return templates;
			}
		}

		/// <summary>
		/// Gets the data sets.
		/// </summary>
		/// <value>The data sets.</value>
		private DataSetDictionary DataSets
		{
			get
			{
				DataSetDictionary datasets = (DataSetDictionary)HttpContext.Session["DataSets"];

				if (datasets == null)
				{
					datasets = new DataSetDictionary();
					HttpContext.Session["DataSets"] = datasets;
				}

				return datasets;
			}
		}

		/// <summary>
		/// Gets the validators.
		/// </summary>
		/// <value>The validators.</value>
		private ValidatorDictionary Validators
		{
			get
			{
				ValidatorDictionary validators = (ValidatorDictionary)HttpContext.Session["Validators"];

				if (validators == null)
				{
					validators = new ValidatorDictionary();
					HttpContext.Session["Validators"] = validators;
				}

				return validators;
			}
		}

        /// <summary>
        /// Set widget type as form view
        /// </summary>
        /// <param name="p">The widget.</param>
        /// <returns>void.</returns>
        public void setWidgetType(Widget widget, WidgetType type)
        {
            widget.IsForm = type == WidgetType.Form;
            // Recursive logic 
            foreach (Widget child in widget.Children)
            {
                this.setWidgetType(child, type);  //set form for each children
            }
        }

        /// <summary>
        /// Set readonly
        /// </summary>
        /// <param name="p">The widget.</param>
        /// <returns>void.</returns>
        public void setWidgetReadOnly(Widget widget, bool read_only)
        {
            widget.ReadOnly = read_only;
            // Recursive logic 
            foreach (Widget child in widget.Children)
            {
                this.setWidgetReadOnly(child, read_only);  //set form for each children
            }
        }

		/// <summary>
		/// Errors the specified p.
		/// </summary>
		/// <param name="p">The p.</param>
		/// <returns>ActionResult.</returns>
		private ActionResult Error(string p)
		{
			ViewBag.Message = p;
			return View();
		}

        /// <summary>
        /// Gets dataset errors.
        /// </summary>
        /// <param name="p">DataSet.</param>
        /// <returns>string</returns>
        private string getDataSetErrorsAsString(DataSet ds)
        {
            string result = "";
            if (ds.errorsCount() > 0)
            {
                if (ds.Provider.IsDeveloper)
                {
                    foreach (string s in ds.Errors)
                    {
                        result += string.Format("\"{0}\",", HttpUtility.JavaScriptStringEncode(s));
                    }
                    result = result.Remove(result.Length - 1);
                }
                else
                {
                    result += GlobalStrings.Document_ConnectionWasLost;
                }
            }
            return result;
        }

        /// <summary>
        /// Gets dataset errors.
        /// </summary>
        /// <param name="p">DataSet.</param>
        /// <returns>List</returns>
        private List<string> getDataSetErrors(DataSet ds, OperationType type)
        {
            List<string> result = ds.Errors;
            if (ds.errorsCount() > 0 && !ds.Provider.IsDeveloper)
            {
                result.Clear();
                switch (type)
                {
                    case OperationType.Insert:
                        result.Add(GlobalStrings.Document_cannotInsert);
                        break;
                    case OperationType.Update:
                        result.Add(GlobalStrings.Document_cannotUpdate);
                        break;
                    case OperationType.Delete:
                        result.Add(GlobalStrings.Document_cannotDelete);
                        break;
                    default:
                        result.Add(GlobalStrings.Document_ConnectionWasLost);
                        break;
                }
            }
            return result;
        }

        /// <summary>
		/// Documents the specified identifier.
		/// </summary>
		/// <param name="id">The identifier.</param>
		/// <param name="key">The key.</param>
		/// <returns>ActionResult.</returns>
		/// <exception cref="System.Web.HttpException">403;You are not authorized</exception>
		public ActionResult Document(string id, string key)
		{
            int? keyID = (int?)null;

			Guid guid = Guid.Parse(id);
			ViewBag.TemplateGuid = id;
			Template template = Templates.ContainsKey(guid) ? Templates[guid] : null; // Always should be loaded earlier

            if (template != null)
            {
                if (key != null)
                {
                    keyID = int.Parse(key);
                    if (keyID < 0)  //FormView is activated if keyID is negative 
                    {
                        keyID = -keyID;
                        template.Document.Type = WidgetType.Form;
                        this.setWidgetType(template.Document, WidgetType.Form);  //set isForm=true option for each children
                    }
                    else if (template.Document.Type == WidgetType.Form)
                    {
                        template.Document.Type = WidgetType.DataGrid;
                        this.setWidgetType(template.Document, WidgetType.DataGrid);  //reset View to DataGrid. TODO improve logic, not always is OK
                    }
                }
                else if (template.Document.Type == WidgetType.Form)
                {
                    template.Document.Type = WidgetType.DataGrid;
                    this.setWidgetType(template.Document, WidgetType.DataGrid);  //reset View to DataGrid
                }
                //template.Document.Type = WidgetType.Form;
                //this.setWidgetType(template.Document, WidgetType.Form);  //set isForm=true option for each children

				var claims = ((System.Security.Claims.ClaimsIdentity)this.User.Identity).Claims;
				int role = int.Parse(claims.Where(c => c.Type == "user_role").First().Value); // roles as int

				if (template.Roles > role)
				{
					throw new HttpException(403, GlobalStrings.TemplateController_NotAuthorized);
				}

				DataSet ds = DataSets.ContainsKey(guid) ? DataSets[guid] : null;

				if (ds == null) // Create DataSet for template, if it's not exists
				{
					ds = new DataSet((System.Security.Claims.ClaimsIdentity)this.User.Identity, template.DataSources[0]);
                    ds.Initialize(template.Document);
					DataSets.Add(guid, ds);
				}

                ds.FillTableData(keyID);
				ds.BindData(template.Document);
                if(ds.errorsCount() > 0) {
                    List<string> err = getDataSetErrors(ds, OperationType.List);
                    foreach (string s in err) {
                        ModelState.AddModelError("Error", s);
                    }            
                    return View();
                }

                Validator validator = Validators.ContainsKey(guid) ? Validators[guid] : null;  //TODO check nesessity of this action. Validators applied also in DataGridList, and individually after update of each control. Check are performed before Save
				if (validator == null)
				{
                    validator = new Validator(template.Document, DataSets[guid], Helpers.CultureManager.DefaultCulture);
					Validators.Add(guid, validator);
				}

				List<string> errors = new List<string>();
				List<Common.Model.Action> actions = new List<Common.Model.Action>();
				this.Validators[guid].CheckWidget(template.Document, out errors, out actions, this.External);

                if (errors.Count > 0) {
                    foreach (string s in errors)  {
                        ModelState.AddModelError("Error", s);
                    }
                    return View();
                }

				return View(template);
			}
			else
            {
                ModelState.AddModelError("Error", GlobalStrings.TemplateController_DocumentTempalteNotFound);
                return View();
            }
		}

		/// <summary>
		/// Documents the save.
		/// </summary>
		/// <param name="id">The identifier.</param>
		/// <returns>string</returns>
		/*public string DocumentSave(string id)
		{
			Guid guid = Guid.Parse(id);
			Table table = this.DataSets[guid].Tables[this.Templates[guid].Document.TableName];
			DataSet ds = this.DataSets[guid];
            ds.SaveTableData(table, this.DataSets[guid]);
            JsonResult result = Json(new { Result = ds.Errors.Count > 0 ? "ERROR" : "OK", errors = getDataSetErrors(ds) });
			//JsonResult result = Json(new { Result = "OK" });
			return result;
		}*/

        /// <summary>
        /// Datas the grid list.
        /// </summary>
        /// <returns>System.String.</returns>
        [HttpPost]
        public string DataGridList(int jtStartIndex = 0, int jtPageSize = 0, string jtSorting = null)
        {
            string jsonString;
            this.HttpContext.Request.InputStream.Position = 0;
            using (StreamReader reader = new StreamReader(this.HttpContext.Request.InputStream, System.Text.Encoding.UTF8))
            {
                jsonString = reader.ReadToEnd();
            }

            dynamic json = JValue.Parse(jsonString);
            JToken jt = json.postRequest;

            Guid guid = Guid.Parse(jt["TemplateGuid"].ToString());
            Widget widget = this.Templates[guid].Document.FindChildByName(jt["WidgetName"].ToString());
            Table table = this.DataSets[guid].Tables[widget.TableName];

            TableFilters filters = new TableFilters();
            TableFilters filters_NAME = new TableFilters();
            JArray jFilters = (JArray)jt["filters"];
            for (int j = 0; j < jFilters.Count; j++)
            {
                if (jFilters[j]["FieldName"].ToString().EndsWith("_NAME") && !table.FieldList.Any(f => f.Name == jFilters[j]["FieldName"].ToString()))
                {
                    filters_NAME.Add(new TableFilter(table, jFilters[j]["FieldName"].ToString().Substring(0, jFilters[j]["FieldName"].ToString().Length - 5), jFilters[j]["FilterType"].ToString(), jFilters[j]["FilterValue"].ToString()));
                }
                else
                {
                    filters.Add(new TableFilter(table, jFilters[j]["FieldName"].ToString(), jFilters[j]["FilterType"].ToString(), jFilters[j]["FilterValue"].ToString()));
                }
            }

            //foreign key logic
            if (!string.IsNullOrEmpty(jt["ParentGuid"].ToString()) && !jt["ShowCurrent"].Value<bool>())
            {
                Table parentTable = this.DataSets[guid].Tables[table.ForeignKeys.First().Value.TableName];
                Guid recordGuid = Guid.Parse(jt["ParentGuid"].ToString());
                int parentID = (int)(parentTable.Records.First(r => r.Guid == recordGuid).Values[parentTable.PrimaryKeyIndexes[0]].Value ?? (int)-1);
                //this.DataSets[guid].FillTableData(this.Provider, table, parentID);

                filters.Add(new TableFilter(table, table.ForeignKeys.First().Key, ConditionOperationType.Equal, parentID.ToString()));
            }
            else
            {
                if (jt["foreign_key"].HasValues && ((JArray)jt["foreign_key"])[0].ToString().Length < 33)  
                {
                    filters.Add(new TableFilter(table, table.ForeignKeys.First().Key, ConditionOperationType.Equal, ((JArray)jt["foreign_key"])[0].ToString().Substring(1)));
                }
            }

            // Check for filters
            List<string> errors = new List<string>();
            List<Common.Model.Action> actions = new List<Common.Model.Action>();

            this.Validators[guid].CheckWidget(widget, out errors, out actions, this.External);
            //bool isFilter = false;

            foreach (var flt in widget.Filters.Where(f => f.Apply))
            {
                filters.Add(new TableFilter(table, flt.Name, flt.OperationType, widget.GetFilterValue(flt.Value, null, table.GetFieldIndexes(), this.DataSets[guid].Identity)));
            }

            foreach (var action in actions.Where(a => a.Type == ActionType.Filter && a.WidgetSource == widget.Name && a.Apply))
            {
                FieldFilter fltr = widget.Filters.First(f => f.Name == action.FieldFilterName);
                fltr.Apply = true;
                //isFilter = true;
                if (!filters.Any(f => f.Field.Name == fltr.Name))
                {
                    filters.Add(new TableFilter(table, fltr.Name, fltr.OperationType, widget.GetFilterValue(fltr.Value, null, table.GetFieldIndexes(), this.DataSets[guid].Identity)));
                }
                else
                {
                    // TODO: replace?
                }
            }

            if (!jt["ShowCurrent"].Value<bool>()) // if not new Record
            {
			    DataSet ds = this.DataSets[guid];
                ds.Errors.Clear();
                ds.FillTableData(table, filters);
                if (ds.errorsCount() > 0)
                {
                    string result = "{\"Result\":\"ERROR\",\"errors\":[" + getDataSetErrorsAsString(ds) + "], \"TotalRecordCount\":0}";
                    return result;
                }
            }

            string JsonResult = "{\"Result\":\"OK\",\"Records\":[";
            int filteredCount = 0;
            int itemCount = 0;
            int sorting = -1;
            //Sorting
            var tb = table.Records.Where(r=>r.State != RecordState.Delete).ToList();
            try { 
                if (jtSorting != null)
                {                  
                    string[] sort = jtSorting.Split(';'); 
                    sorting = table.GetFieldIndex(sort[0]);
                    if (sort[1].Equals("ASC") && sorting != -1)
                        tb = table.Records.OrderBy(r => r.Values[sorting].Value).ToList();
                    else if (sort[1].Equals("DESC") && sorting != -1)
                        tb = table.Records.OrderByDescending(r => r.Values[sorting].Value).ToList();
                }
            } catch { }
            foreach (Record record in tb.Where(r => r.State != RecordState.Delete))
            {
                bool filtered = true;
                //if (sorting != -1)
                string subJsonResult = "{\"Guid\":\"" + record.Guid.ToString() + "\",";
                if (jtStartIndex+jtPageSize == 0 || (itemCount >= jtStartIndex && itemCount < jtStartIndex + jtPageSize)) //enable work with and without paging
                {
                    for (int i = 0; i < table.FieldsCount; i++)
                    {
                        subJsonResult += "\"" + table[i].Name + "\":";
                        subJsonResult += record[i] == null ? "null," : string.Format("\"{0}\",", HttpUtility.JavaScriptStringEncode(record[i].ToString()));
                        Widget childWidget = widget.FindChildByField(table.Name, table[i].Name);
                        if (childWidget != null && (childWidget.Type == WidgetType.DBComboBox || childWidget.Type == WidgetType.List))
                        {
                            subJsonResult += "\"" + table[i].Name + "_NAME\":";
                            //string nameVal = record[i].Value == null ? "null," : string.Format("\"{0}\",", HttpUtility.JavaScriptStringEncode(childWidget.Items.FirstOrDefault(item => item.Key == record[i].ToString()).Value));
                            string nameVal;
                            if (record[i].Value == null)
                                nameVal = "null,";
                            else
                            {
                                string key = record[i].ToString();
                                Common.Classes.KeyValueData obj = childWidget.Items.FirstOrDefault(item => item.Key == key);
                                if (obj == null)
                                    nameVal = "null,";
                                else
                                    nameVal = string.Format("\"{0}\",", HttpUtility.JavaScriptStringEncode(obj.Value));
                            }
                            subJsonResult += nameVal;

                            TableFilter flt = filters_NAME.Where(f => f.Field.Name == table[i].Name).FirstOrDefault();

                            if (flt != null)
                            {
                                nameVal = nameVal.Substring(1, nameVal.Length - 3);

                                switch (flt.FilterType)
                                {
                                    case ConditionOperationType.Blank:
                                        filtered = nameVal == "ul";
                                        break;
                                    case ConditionOperationType.Equal:
                                        filtered = flt.FilterValue == nameVal;
                                        break;
                                    case ConditionOperationType.NotEqual:
                                        filtered = flt.FilterValue != nameVal;
                                        break;
                                    case ConditionOperationType.Less:
                                        filtered = String.Compare(flt.FilterValue, nameVal) > 0;
                                        break;
                                    case ConditionOperationType.LessOrEqual:
                                        filtered = String.Compare(flt.FilterValue, nameVal) >= 0;
                                        break;
                                    case ConditionOperationType.Greater:
                                        filtered = String.Compare(flt.FilterValue, nameVal) < 0;
                                        break;
                                    case ConditionOperationType.GreaterOrEqual:
                                        filtered = String.Compare(flt.FilterValue, nameVal) <= 0;
                                        break;
                                    case ConditionOperationType.Starts:
                                        filtered = nameVal.StartsWith(flt.FilterValue);
                                        break;
                                    case ConditionOperationType.Contains:
                                        filtered = nameVal.Contains(flt.FilterValue);
                                        break;
                                    case ConditionOperationType.Ends:
                                        filtered = nameVal.EndsWith(flt.FilterValue);
                                        break;
                                    default:
                                        filtered = false;
                                        break;
                                }
                            }
                        }
                    }
                    subJsonResult = subJsonResult.Remove(subJsonResult.Length - 1);
                    subJsonResult += "},";                
                    if (filtered)
                    {
                        JsonResult += subJsonResult;
                        filteredCount++;
                    }
                }
                itemCount++;
            }

			if (filteredCount > 0) JsonResult = JsonResult.Remove(JsonResult.Length - 1);
            JsonResult += "], \"TotalRecordCount\":" + itemCount + "}";
            return JsonResult;
		}

		/// <summary>
		/// Datas the grid add.
		/// </summary>
		/// <returns>System.String.</returns>
		[HttpPost]
		public string DataGridAdd()
		{
			string jsonString;
			this.HttpContext.Request.InputStream.Position = 0;
			using (StreamReader reader = new StreamReader(this.HttpContext.Request.InputStream, System.Text.Encoding.UTF8))
			{
				jsonString = reader.ReadToEnd();
			}

			dynamic json = JValue.Parse(jsonString);
			JToken jt = json.postRequest;

			Guid guid = Guid.Parse(jt["TemplateGuid"].ToString());
			Widget widget = this.Templates[guid].Document.FindChildByName(jt["WidgetName"].ToString());
			Table table = this.DataSets[guid].Tables[widget.TableName];

			Record newRecord = new Record(table) { State = RecordState.Insert };

			if (jt["ParentGuid"] != null && !string.IsNullOrEmpty(jt["ParentGuid"].ToString()))
			{
				Table parentTable = this.DataSets[guid].Tables[table.ForeignKeys.First().Value.TableName];
				Guid recordGuid = Guid.Parse(jt["ParentGuid"].ToString());
				newRecord.Values[table.GetFieldIndex(table.ForeignKeys.First().Key)].Value = parentTable.Records.First(r => r.Guid == recordGuid).Values[parentTable.PrimaryKeyIndexes[0]].Value;
			}

			table.Records.Add(newRecord);

			string JsonResult = "{\"Result\":\"OK\",\"Record\":";

			JsonResult += "{\"Guid\":\"" + newRecord.Guid.ToString() + "\",";
			for (int i = 0; i < table.FieldsCount; i++)
			{
				JsonResult += "\"" + table[i].Name + "\":";
				JsonResult += newRecord[i] == null ? "null," : string.Format("\"{0}\",", HttpUtility.JavaScriptStringEncode(newRecord[i].ToString()));
				Widget childWidget = widget.FindChildByField(table.Name, table[i].Name);
				if (childWidget != null && (childWidget.Type == WidgetType.DBComboBox || childWidget.Type == WidgetType.List))
				{
					JsonResult += "\"" + table[i].Name + "_NAME\":";
					//JsonResult += newRecord[i].Value == null ? "null," : string.Format("\"{0}\",", HttpUtility.JavaScriptStringEncode(childWidget.Items.FirstOrDefault(item => item.Key == newRecord[i].ToString()).Value));
                    string nameVal;
                    if (newRecord[i].Value == null)
                        nameVal = "null,";
                    else
                    {
                        string key = newRecord[i].ToString();
                        Common.Classes.KeyValueData obj = childWidget.Items.FirstOrDefault(item => item.Key == key);
                        if (obj == null)
                            nameVal = "null,";
                        else
                            nameVal = string.Format("\"{0}\",", HttpUtility.JavaScriptStringEncode(obj.Value));
                    }
                    JsonResult += nameVal;
				}
			}
			JsonResult = JsonResult.Remove(JsonResult.Length - 1);
			JsonResult += "}}";

			return JsonResult;
		}

		/// <summary>
		/// Datas the grid change.
		/// </summary>
		/// <param name="id">The identifier.</param>
		/// <param name="key">The key.</param>
		/// <returns>System.String.</returns>
		[HttpPost]
		public string DataGridChange(string id, string key)
		{
			Guid guid = Guid.Parse(id);
			Widget widget = this.Templates[guid].Document.FindChildByName(key);
			Table table = this.DataSets[guid].Tables[widget.TableName];

			string jsonString;
			this.HttpContext.Request.InputStream.Position = 0;
			using (StreamReader reader = new StreamReader(this.HttpContext.Request.InputStream, System.Text.Encoding.UTF8))
			{
				jsonString = reader.ReadToEnd();
			}

			dynamic json = JValue.Parse(jsonString);

			JToken jt = json.records;
			Record record = table.Records.First(r => r.Guid == Guid.Parse(jt["Guid"].ToString()));
			foreach (JProperty jp in jt)
			{
				if (jp.Name != "Guid" && table.ContainsField(jp.Name))
				{
					record[table.GetFieldIndex(jp.Name)].Value = jp.Value.ToString();
				}
			}

			if (record.State != RecordState.Insert) record.State = RecordState.Update;

            return jsonString;
		}

		/// <summary>
		/// Datas the grid change save.
		/// </summary>
		/// <param name="id">The identifier.</param>
		/// <param name="key">The key.</param>
		/// <returns>System.String.</returns>
		[HttpPost]
        public JsonResult DataGridChangeSave(string id, string key)
		{
            string jsonString = DataGridChange(id, key);

            Guid guid = Guid.Parse(id);
            DataSet ds = this.DataSets[guid];
            Table table = ds.Tables[this.Templates[guid].Document.TableName];
            ds.SaveTableData(table, ds);

            if(ds.Errors.Count == 0 && ds.LogTable != null)
            {
                Widget widget = this.Templates[guid].Document.FindChildByName(key);
                int subjId = Int32.Parse((ds.Identity).Claims.Where(c => c.Type == "subj_id").First().Value);
                dynamic json = JValue.Parse(jsonString);
                JArray log_records = (JArray)json.log_records;
                foreach (JObject log in log_records)
                {
                    Record newLogRecord = new Record(ds.LogTable) { State = RecordState.Insert };
                    newLogRecord[2].Value = log["type"]; //operation_type
                    newLogRecord[3].Value = DateTime.Now; //log_date
                    newLogRecord[4].Value = subjId; //user_id
                    int type = (int)log["type"];
                    if (type == 0) //insert record
                    {
                        Record record = table.Records.First(r => r.Guid == Guid.Parse(json.records["Guid"].ToString()));
                        newLogRecord[1].Value = record.Values[table.PrimaryKeyIndexes[0]].Value;
                    }
                    else  //update record
                    {
                        newLogRecord[1].Value = json.records[table.PrimaryKeys.First().Key]; //record_id
                        newLogRecord[5].Value = log["fieldName"].ToString(); //log_field
                        newLogRecord[6].Value = log["oldValue"].ToString(); //old_value
                        newLogRecord[7].Value = log["newValue"].ToString(); //new_value
                    }
                    ds.LogTable.Records.Add(newLogRecord);
                }
                ds.SaveData(ds.LogTable);
            }

            JsonResult result = Json(new { Result = ds.Errors.Count > 0 ? "ERROR" : "OK", errors = getDataSetErrors(ds, OperationType.Update) }); //TODO change to record state
            return result;
		}

		/// <summary>
		/// Datas the grid delete.
		/// </summary>
		/// <param name="id">The identifier.</param>
		/// <param name="key">The key.</param>
		/// <returns>System.String.</returns>
		[HttpPost]
        public JsonResult DataGridDelete(string id, string key)
		{
			Guid guid = Guid.Parse(id);
			Widget widget = this.Templates[guid].Document.FindChildByName(key);
            DataSet ds = this.DataSets[guid];
            Table table = ds.Tables[widget.TableName];

			string jsonString;
			this.HttpContext.Request.InputStream.Position = 0;
			using (StreamReader reader = new StreamReader(this.HttpContext.Request.InputStream, System.Text.Encoding.UTF8))
			{
				jsonString = reader.ReadToEnd();
			}

			dynamic json = JValue.Parse(jsonString);
			JToken jt = json.records;

            ds.DeleteTableData(table, Guid.Parse(jt["Guid"].ToString()));

            if (ds.Errors.Count == 0 && ds.LogTable != null)
            {
                int subjId = Int32.Parse((ds.Identity).Claims.Where(c => c.Type == "subj_id").First().Value);

                Record newLogRecord = new Record(ds.LogTable) { State = RecordState.Insert };
                newLogRecord[1].Value = json.records[table.PrimaryKeys.First().Key]; //record_id
                newLogRecord[2].Value = 2; //operation_type
                newLogRecord[3].Value = DateTime.Now; //log_date
                newLogRecord[4].Value = subjId; //user_id
                newLogRecord[5].Value = ""; //log_field
                newLogRecord[6].Value = ""; //old_value
                newLogRecord[7].Value = ""; //new_value

                ds.LogTable.Records.Add(newLogRecord);
                ds.SaveData(ds.LogTable);
            }

            JsonResult result = Json(new { Result = ds.Errors.Count > 0 ? "ERROR" : "OK", errors = getDataSetErrors(ds, OperationType.Delete) });
            return result;
		}

        /// <summary>
        /// Checks the rules.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="key">The key.</param>
        /// <returns>JsonResult.</returns>
        [HttpPost]
        public JsonResult CheckRules(string id, string key)
        {
            Guid guid = Guid.Parse(id);
            string widgetName = key.Substring(key.IndexOf("_") + 1);
            //remove language suffice from the widget name (note: in edit/add dialog inputs for all languages are present)
            if (widgetName.EndsWith("_en") || widgetName.EndsWith("_kz") || widgetName.EndsWith("_ru"))
                widgetName = widgetName.Substring(0, widgetName.Length - 3);
            Widget widget = this.Templates[guid].Document.FindChildByName(widgetName);
            Table table = this.DataSets[guid].Tables[widget.TableName];

            string jsonString;
            this.HttpContext.Request.InputStream.Position = 0;
            using (StreamReader reader = new StreamReader(this.HttpContext.Request.InputStream, System.Text.Encoding.UTF8))
            {
                jsonString = reader.ReadToEnd();
            }

            dynamic json = JValue.Parse(jsonString);
            JValue jValue = json.Value;
            JValue jGuid = json.Guid;
            JToken jRecord = json.Record;

            widget.Value = jValue.Value;

            Record record = new Record(table); // Virtual record, just for check
            foreach (JProperty jp in jRecord)
            {
                if (table.ContainsField(jp.Name))
                {
                    record[table.GetFieldIndex(jp.Name)].Value = jp.Value.ToString();
                }
            }

            //Record record = table.Records.First(r => r.Guid == Guid.Parse(jGuid.Value.ToString()));

            Validator validator = Validators[guid];

            List<string> errors;
            List<Common.Model.Action> actions;
            validator.Check(widget, table.GetFieldIndexes(), record, jValue.Value, out errors, out actions, this.External);
            /// TODO:
            JsonResult result = Json(new { Result = errors.Count > 0 ? "ERROR" : "OK", errors = errors, actions = actions });
            //string jsonStr = new JavaScriptSerializer().Serialize(result.Data);
            return result;
        }

        [HttpGet]
		public string External(string guid, string getParams)
		{
			Guid templateGuid = Guid.Parse(guid);
			Template template = Templates.ContainsKey(templateGuid) ? Templates[templateGuid] : null; // Always should be loaded earlier

			if (template != null)
			{
				DataSet ds = DataSets.ContainsKey(templateGuid) ? DataSets[templateGuid] : null;

				if (ds == null) // Create DataSet for template, if it's not exists
				{
					ds = new DataSet((System.Security.Claims.ClaimsIdentity)this.User.Identity, template.DataSources[0]);
					ds.Initialize(template.Document);
					ds.BindData(template.Document);
					DataSets.Add(templateGuid, ds);
				}

				// Loading parameters
				List<Widget> parameters = template.Document.FindChildrenByType(Common.Enums.WidgetType.Parameter);

				// setting parameters
				string[] ps = getParams.Split('/');

				for (int i = 0; i < ps.Length; i++)
				{
					parameters[i].Value = ps[i];
				}

				bool notFill = true;

				foreach (Widget param in parameters)
				{
					Table table = ds.Tables.FirstOrDefault(t => t.Value.PrimaryKeys.First().Value.Parameter == param.Name).Value;
					if (table != null)
					{
						notFill = false;
						//decimal paramValue = decimal.Parse(param.Value.ToString());
                        int paramValue = Convert.ToInt32(param.Value.ToString());
						ds.FillTableDataReverse(table, paramValue);
						var childTables = ds.Tables.Where(t => t.Value.ForeignKeys.Count > 0 && t.Value.ForeignKeys.First().Value.TableName == table.Name);

						foreach (var childTable in childTables)
						{
							ds.FillTableData(childTable.Value, paramValue);
						}
					}
				}

				if (notFill)
				{
                    ds.Errors.Clear();
					foreach (Table table in ds.Tables.Select(t => t.Value))
					{
						TableFilters filters = new TableFilters();
						Widget widget = template.Document.FindChildByTable(table.Name);
						foreach (var flt in widget.Filters.Where(f => f.Apply))
						{
							filters.Add(new TableFilter(table, flt.Name, flt.OperationType, widget.GetFilterValue(flt.Value, null, table.GetFieldIndexes(), ds.Identity)));
						}
						ds.FillTableData(table, filters);
					}
				}

				Validator validator = Validators.ContainsKey(templateGuid) ? Validators[templateGuid] : null;

				if (validator == null)
				{
                    validator = new Validator(template.Document, DataSets[templateGuid], Helpers.CultureManager.DefaultCulture);
					Validators.Add(templateGuid, validator);
				}

				Widget resultWidget = template.Document.FindChildrenByType(WidgetType.Result).FirstOrDefault();

				resultWidget.Value = resultWidget.DefaultValue;

				validator.CheckAll(this.External);

				return (resultWidget.Value ?? resultWidget.DefaultValue).ToString().Replace(',', '.');
			}
			else
				return "0";
		}

		[HttpPost]
		public string WidgetValuesSet(string id)
		{
			Guid guid = Guid.Parse(id);
			
			string jsonString;
			this.HttpContext.Request.InputStream.Position = 0;
			using (StreamReader reader = new StreamReader(this.HttpContext.Request.InputStream, System.Text.Encoding.UTF8))
			{
				jsonString = reader.ReadToEnd();
			}

			dynamic json = JValue.Parse(jsonString);
			JToken jt = json.postRequest;

			foreach (JProperty jp in jt)
			{
				Widget widget = this.Templates[guid].Document.FindChildByName(jp.Name.Substring(jp.Name.IndexOf('_') + 1));

				if (widget != null)
				{
					widget.Value = jp.Value;
				}
			}

				return "{\"Result\":\"OK\"}";
		}

        ///// <summary>
        ///// Sets template readonly (for preview reason).
        ///// </summary>
        ///// <param name="id">The identifier.</param>
        ///// <returns>JsonResult.</returns>
        //[HttpPost]
        //public JsonResult SetReadOnly(string id, string key)
        //{
        //    Guid guid = Guid.Parse(id);
        //    bool read_only = key == "1";
        //    this.setWidgetReadOnly(this.Templates[guid].Document, read_only); //sets all children (except document itself)
        //    JsonResult result = Json(new { Result = "OK" });
        //    return result;
        //}
	}
}
