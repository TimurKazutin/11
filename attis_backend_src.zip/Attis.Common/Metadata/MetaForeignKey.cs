﻿
namespace Lawyers.Common.Metadata
{
	using System.Xml.Serialization;

	public class MetaForeignKey
	{
		[XmlAttribute]
		public string Name { get; set; }

		[XmlAttribute]
		public string Table { get; set; }

		[XmlAttribute]
		public string Column { get; set; }
	}
}
