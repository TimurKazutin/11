﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 05-07-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 05-07-2015
// ***********************************************************************
// <copyright file="TableFilter.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Data namespace.
/// </summary>
namespace Lawyers.Engine.Data
{
	using Lawyers.Common.Enums;
	using Common.Model;

	/// <summary>
	/// Class TableFilter.
	/// </summary>
	public class TableFilter
    {
        /// <summary>
        /// Gets the field.
        /// </summary>
        /// <value>The field.</value>
        public Field Field { get; private set; }

        /// <summary>
        /// Gets or sets the type of the filter.
        /// </summary>
        /// <value>The type of the filter.</value>
        public ConditionOperationType FilterType { get; private set; }

        /// <summary>
        /// Gets or sets the filter value.
        /// </summary>
        /// <value>The filter value.</value>
        public string FilterValue { get; private set; }

        /// <summary>
        /// Gets the filter string.
        /// </summary>
        /// <value>The filter string.</value>
        public string FilterString
        {
            get
            {
                string fmtDataType = "'{1}'";

                switch(this.Field.DataType)
                {
                    case DataType.Date_:
                    case DataType.Date:
                        //fmtDataType = "to_date('{1}','yyyy.mm.dd')";
                        fmtDataType = "to_date('{1}','dd.mm.yyyy')";
                        break;
                    case DataType.Int2:
                    case DataType.Int4:
                    case DataType.Integer:
                        fmtDataType = "{1}";
                        break;
                    case DataType.Decimal:
                    case DataType.Numeric:
                        fmtDataType = "{1}";
                        break;
                    default:
                        break;
                }

                switch(this.FilterType)
                {
                    case ConditionOperationType.Blank:
                        fmtDataType = "{0} is null";
                        break;
                    case ConditionOperationType.NotBlank:
                        fmtDataType = "{0} is not null";
                        break;
                    case ConditionOperationType.Equal:
                        fmtDataType = "{0} = " + fmtDataType;
                        break;
                    case ConditionOperationType.NotEqual:
                        fmtDataType = "{0} <> " + fmtDataType;
                        break;
                    case ConditionOperationType.Greater:
                        fmtDataType = "{0} > " + fmtDataType;
                        break;
                    case ConditionOperationType.GreaterOrEqual:
                        fmtDataType = "{0} >= " + fmtDataType;
                        break;
                    case ConditionOperationType.Less:
                        fmtDataType = "{0} < " + fmtDataType;
                        break;
                    case ConditionOperationType.LessOrEqual:
                        fmtDataType = "{0} <= " + fmtDataType;
                        break;
                    case ConditionOperationType.Starts: // string only
                        fmtDataType = "{0} like '{1}%'";
                        break;
                    case ConditionOperationType.Ends: // string only
                        fmtDataType = "{0} like '%{1}'";
                        break;
                    case ConditionOperationType.Contains: // string only
                        fmtDataType = "{0} like '%{1}%'";
                        break;
                    default:
                        break;
                }

                return string.Format(fmtDataType, this.Field.Name, this.FilterValue);
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TableFilter"/> class.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <param name="FieldName">Name of the field.</param>
        /// <param name="FilterType">Type of the filter.</param>
        /// <param name="FilterValue">The filter value.</param>
        public TableFilter(Table table, string FieldName, string FilterType, string FilterValue)
        {
            this.Field = table[table.GetFieldIndex(FieldName)];
            this.FilterValue = FilterValue;
            
            switch(FilterType)
            {
                case "blank":
                    this.FilterType = ConditionOperationType.Blank;
                    break;
                case "equal":
                    this.FilterType = ConditionOperationType.Equal;
                    break;
                case "notequal":
                    this.FilterType = ConditionOperationType.NotEqual;
                    break;
                case "less":
                    this.FilterType = ConditionOperationType.Less;
                    break;
                case "lessorequal":
                    this.FilterType = ConditionOperationType.LessOrEqual;
                    break;
                case "greater":
                    this.FilterType = ConditionOperationType.Greater;
                    break;
                case "greaterorequal":
                    this.FilterType = ConditionOperationType.GreaterOrEqual;
                    break;
                case "starts":
                    this.FilterType = ConditionOperationType.Starts;
                    break;
                case "ends":
                    this.FilterType = ConditionOperationType.Ends;
                    break;
                case "contains":
                    this.FilterType = ConditionOperationType.Contains;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TableFilter"/> class.
        /// </summary>
        /// <param name="table">The table.</param>
        /// <param name="FieldName">Name of the field.</param>
        /// <param name="FilterType">Type of the filter.</param>
        /// <param name="FilterValue">The filter value.</param>
        public TableFilter(Table table, string FieldName, ConditionOperationType FilterType, string FilterValue)
        {
            this.Field = table[table.GetFieldIndex(FieldName)];
            this.FilterValue = FilterValue;
            this.FilterType = FilterType;
        }
    }
}
