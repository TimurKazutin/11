﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Web;
using System.Web.Mvc;
using Lawyers.Common;
using Lawyers.Common.Interfaces;
using Lawyers.Engine.Configuration;
using Lawyers.Web.App.Models;
using Lawyers.Web.App.Models.Enums;
using Microsoft.AspNet.Identity;

namespace Lawyers.Web.App.Helpers
{
    public class NotificationHelper
    {
        private static IDataProvider Provider => GlobalContainer.Instance.Get<Configuration>().DataProvider;

        public static List<Notification> GetAllNotifications()
        {
            var notifications = new List<Notification>();

            lock (Provider.Locker)
            {
                var query = $@"SELECT t1.*, 
t2.last_name || ' ' || t2.given_name || ' ' || coalesce (t2.middle_name,'') as creator_name,
t3.subj_name as creator_title,
sls.subj_law_supplier_name,
sls.subj_law_supplier_lic_num,
sls.subj_law_supplier_lic_date,
t2.gender as creator_gender,
t4.doc_img_scan as creator_img,
lc.law_collegium_name_ru,
p1.last_name || ' ' || p1.given_name || ' ' || coalesce (p1.middle_name,'') as recipient_name

FROM notifications t1

LEFT JOIN persons t2 ON t1.notification_creator = t2.user_id
LEFT JOIN subjects t3 ON t1.notification_creator = t3.user_id
LEFT JOIN subjects_law_suppliers sls ON sls.person_id = t1.notification_creator
LEFT JOIN law_collegiums lc ON lc.law_collegium_id = sls.law_collegium_id
LEFT JOIN docimages t4 ON t3.doc_guid = t4.doc_guid
LEFT JOIN persons p1 ON t1.notification_recipient = p1.user_id

WHERE notification_recipient ='{HttpContext.Current.User.Identity.GetUserId()}'
ORDER BY notification_type, notification_creation_date desc";
                var reader = Provider.RunQuery(query);

                while (reader.Read())
                {
                    notifications.Add(NotificationFromReader(reader));
                }

                reader.Close();
            }

            return notifications;
        }

        public static List<Notification> GetAllNotificationsCollegium()
        {
            var result = new List<Notification>();

            var query = $@"SELECT n.*, 
p.last_name || ' ' || p.given_name || ' ' || coalesce (p.middle_name,'') as creator_name,
s.subj_name as creator_title,
sls.subj_law_supplier_name,
sls.subj_law_supplier_lic_num,
sls.subj_law_supplier_lic_date,
p.gender as creator_gender,
di.doc_img_scan as creator_img,
lc.law_collegium_name_ru,
p1.last_name || ' ' || p1.given_name || ' ' || coalesce (p1.middle_name,'') as recipient_name

FROM notifications n

LEFT JOIN persons p ON n.notification_creator = p.user_id
LEFT JOIN subjects s ON n.notification_creator = s.user_id
LEFT JOIN subjects_law_suppliers sls ON sls.person_id = n.notification_creator
LEFT JOIN law_collegiums lc ON lc.law_collegium_id = sls.law_collegium_id
LEFT JOIN docimages di ON s.doc_guid = di.doc_guid
LEFT JOIN persons p1 ON n.notification_recipient = p.user_id

WHERE n.notification_recipient is null and sls.law_collegium_id = (
select law_collegium_id from subjects_law_suppliers
where person_id = '{HttpContext.Current.User.Identity.GetUserId()}')
ORDER BY notification_type, notification_creation_date desc";

            var reader = Provider.RunQuery(query);

            while (reader.Read())
            {
                result.Add(NotificationFromReader(reader));
            }

            reader.Close();

            return result;
        }

        public static Notification NotificationById(int id)
        {
            Notification notification = null;

            lock (Provider.Locker)
            {
                var query = @"SELECT t1.*, 
t2.last_name || ' ' || t2.given_name || ' ' || coalesce (t2.middle_name,'') as creator_name,
t3.subj_name as creator_title,
sls.subj_law_supplier_name,
sls.subj_law_supplier_lic_num,
sls.subj_law_supplier_lic_date,
t2.gender as creator_gender,
t4.doc_img_scan as creator_img,
lc.law_collegium_name_ru,
p1.last_name || ' ' || p1.given_name || ' ' || coalesce (p1.middle_name,'') as recipient_name

FROM notifications t1

LEFT JOIN persons t2 ON t1.notification_creator = t2.user_id
LEFT JOIN subjects t3 ON t1.notification_creator = t3.user_id
LEFT JOIN subjects_law_suppliers sls ON sls.person_id = t1.notification_creator
LEFT JOIN law_collegiums lc ON lc.law_collegium_id = sls.law_collegium_id
LEFT JOIN docimages t4 ON t3.doc_guid = t4.doc_guid
LEFT JOIN persons p1 ON t1.notification_recipient = p1.user_id

                            WHERE notification_id = " + id;
                var reader = Provider.RunQuery(query);

                if (reader.Read())
                {
                    notification = NotificationFromReader(reader);
                }

                reader.Close();
            }

            return notification;
        }

        public static int GetCount()
        {
            var notificationCount = 0;

            lock (Provider.Locker)
            {
                var query = @"SELECT COUNT(*) FROM notifications WHERE notification_read_date is null and notification_recipient = '" + HttpContext.Current.User.Identity.GetUserId() + "'";

                var reader = Provider.RunQuery(query);

                if (reader.Read())
                {
                    notificationCount = reader.GetInt32(0);
                }
                reader.Close();
            }

            return notificationCount;
        }

        public static int GetCountCollegium()
        {
            var notificationCount = 0;

            lock (Provider.Locker)
            {
                var query = @"SELECT Count(n.*)
FROM notifications n
JOIN subjects_law_suppliers sls ON sls.person_id = n.notification_creator
WHERE n.notification_read_date is null and n.notification_recipient is null and sls.law_collegium_id = (
select law_collegium_id from subjects_law_suppliers
where person_id = '" + HttpContext.Current.User.Identity.GetUserId() + "')";

                var reader = Provider.RunQuery(query);

                if (reader.Read())
                {
                    notificationCount = reader.GetInt32(0);
                }
                reader.Close();
            }

            return notificationCount;
        }

        private static Notification NotificationFromReader(IDataRecord reader)
        {
            return new Notification
            {
                Id = reader.GetInt32(reader.GetOrdinal("notification_id")),
                Type = (NotificationType)reader.GetInt32(reader.GetOrdinal("notification_type")),
                ObjectId = reader.IsDBNull(reader.GetOrdinal("notification_object_id")) ? (int?)null : reader.GetInt32(reader.GetOrdinal("notification_object_id")),
                Archived = reader.GetBoolean(reader.GetOrdinal("notification_archived")),
                CreationDate = reader.GetDateTime(reader.GetOrdinal("notification_creation_date")),
                ReadDate = reader.IsDBNull(reader.GetOrdinal("notification_read_date")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("notification_read_date")),
                CreatorId = reader["notification_creator"].ToString(),
                RecipientId = reader["notification_recipient"].ToString(),
                DocumentId = reader["notification_docguid"].ToString(),
                Comment = reader["notification_comment"].ToString(),
                CreatorName = reader["creator_name"].ToString(),
                CreatorPhoto = SetPhoto(reader["creator_img"], reader["creator_gender"].ToString()),
                CreatorTitle = reader["creator_title"].ToString(),
                Collegium = reader["law_collegium_name_ru"].ToString(),
                CreatorLicense = reader["subj_law_supplier_lic_num"].ToString(),
                CreatorLicenseDate = reader.IsDBNull(reader.GetOrdinal("subj_law_supplier_lic_date")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("subj_law_supplier_lic_date")),
                CreatorOrgName = reader["subj_law_supplier_name"].ToString(),
                RecipientName = reader["recipient_name"].ToString()
            };
        }

        public static int AddNotification(Notification notification)
        {
            lock (Provider.Locker)
            {
                var query = $@"INSERT INTO public.notifications(
    notification_type,
    notification_object_id,
    notification_creation_date,
    notification_creator,
    notification_recipient,
    notification_docguid,
    notification_comment)
VALUES(
    {(int) notification.Type},
    {(notification.ObjectId.HasValue ? notification.ObjectId.ToString() : "null")},
    'NOW()', '{notification.CreatorId}',
    {(string.IsNullOrEmpty(notification.RecipientId) ? "null" : $"'{notification.RecipientId}'")},
    '{(string.IsNullOrEmpty(notification.DocumentId) ? "null" : $"{notification.DocumentId}")}', 
    '{notification.Comment ?? string.Empty}')
returning notification_id";

                return Provider.RunScalar(query);
            }
        }

        public static void SaveNotification(Notification notification)
        {
            if (notification.Id == 0)
            {
                AddNotification(notification);
                return;
            }

            var query =
@"UPDATE public.notifications SET " +
    $"notification_type={notification.Type}, " +
    $"notification_object_id={notification.ObjectId}, " +
    $"notification_archived={notification.Archived}, " +
    $"notification_creation_date={notification.CreationDate}, " +
    $"notification_read_date={notification.ReadDate}, " +
    $"notification_creator={notification.CreatorId}, " +
    $"notification_recipient={notification.RecipientId}, " +
    $"notification_docguid={notification.DocumentId}, " +
    $"notification_comment={notification.Comment} " +
$@"WHERE notification_id = {notification.Id};";

            Provider.RunNonQuery(query);
        }

        public static void ReadNotification(int id)
        {
            var query =
                @"UPDATE public.notifications SET " +
                $"notification_read_date='{DateTime.Now:dd.MM.yyyy HH:mm:ss}' " +
                $"WHERE notification_id = {id};";

            Provider.RunNonQuery(query);
        }

        public static void ArchiveNotification(int id)
        {
            var query =
                @"UPDATE public.notifications SET notification_archived=1 " +
                $"WHERE notification_id = {id};";

            Provider.RunNonQuery(query);
        }

        public static string RenderNotification(Notification notification)
        {
            var result = string.Empty;

            var url = new UrlHelper(HttpContext.Current.Request.RequestContext);

            switch (notification.Type)
            {
                case NotificationType.RequestApprovalProfile:
                    result = @"<h3>Заявка на согласование профиля клиента</h3>" +
                             $"<p><b>ФИО клиента:</b >{notification.CreatorName}</p>" + // ФИО клиента
                             $"<p><b>Наименование организации:</b> {notification.CreatorOrgName}</p>" + // Наименование организации
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" + // Номер лицензии и дата выдачи
                             $"<p><a href=\"{url.Action("Lawyer", "Account", new { id = notification.ObjectId })}\"><b>Ссылка на заявку согласования профиля клиента</b></a></p>";  // Ссылка на заявку согласования профиля клиента 
                    break;

                case NotificationType.RequestApprovalProfileAccepted:
                    result = @"<h3>Заявка на согласование профиля клиента обработана: &laquo;Утверждена&raquo;</h3>" +
                             $"<p><b>ФИО исполнителя:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Дата обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Внимание! Для начала работы требуется повторная авторизация в системе. Спасибо.</b></p>"; 
                    break;

                case NotificationType.RequestApprovalProfileRejected:
                    result = @"<h3>Заявка на согласование профиля клиента обработана: &laquo;Отказано&raquo;</h3>" +
                             $"<p><b>ФИО исполнителя:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Дата обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>";
                    break;

                case NotificationType.RequestEditProfile:
                    result = @"<h3>Заявка на внесение изменений данных в профиле клиента</h3>" + 
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" + // ФИО клиента
                             $"<p><b>Наименование организации:</b> {notification.CreatorOrgName}</p>" + // Наименоваdние организации
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" + // Номер лицензии и дата выдачи
                             $"<p><a href=\"{url.Action("LawyerRequest", "Account", new {id = notification.ObjectId})}\"><b>Ссылка на заявку согласования профиля клиента</b></a></p>";  // Ссылка на заявку согласования профиля клиента
                    break;

                case NotificationType.RequestEditProfileAccepted:
                    result = @"<h3>Заявка на изменение данных профиля клиента обработана: &laquo;Утверждена&raquo;</h3>" +
                             $"<p><b>ФИО исполнителя:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Дата обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>";
                    break;

                case NotificationType.RequestEditProfileRejected:
                    result = @"<h3>Заявка на изменение данных профиля клиента обработана: &laquo;Отказано&raquo;</h3>" +
                             $"<p><b>ФИО исполнителя:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Дата обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>";
                    break;

                case NotificationType.RequestApprovalReportGgup:
                    result = @"<h3>Запрос на согласование документа клиента</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" + // ФИО клиента
                             $"<p><b>Наименование организации:</b> {notification.CreatorOrgName}</p>" + // Наименование организации
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" + // Номер лицензии и дата выдачи
                             $"<p><b>Отчетный период:</b></p>" + // Отчетный период
                             $"<p><a href=\"{url.Action("LawyerReport", "Report", new { id = notification.ObjectId })}\"><b>Ссылка на Заявку:</b></a></p>";  // Ссылка на Заявки
                    break;

                case NotificationType.RequestApprovalReportGgupAccepted:
                    result = @"<h3>Запрос на согласование Заявки обработан: &laquo;Согласован&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b>{notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><a href=\"{url.Action("LawyerReport", "Report", new { id = notification.ObjectId })}\"><b>Ссылка на Заявку:</b></a></p>";
                    break;

                case NotificationType.RequestApprovalReportGgupRejected:
                    result = @"<h3>Запрос на согласование Заявки обработан: &laquo;Отказано&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b>{notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>" +
                             $"<p><a href=\"{url.Action("LawyerReport", "Report", new { id = notification.ObjectId })}\"><b>Ссылка на Заявку:</b></a></p>";
                    break;

                case NotificationType.RequestEditReportGgup:
                    result = @"<h3>Запрос на корректировку Заявки</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" + // ФИО клиента
                             $"<p><b>Наименование организации:</b> {notification.CreatorOrgName}</p>" + // Наименование организации
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" + // Номер лицензии и дата выдачи
                             $"<p><b>Отчетный период:</b></p>" + // Отчетный период
                             $"<p><b>Номер отчета:</b></p>" + // Номер отчета подлежащего корректировки (ранее согласованного)
                             $"<p><b>Дата согласования отчета секретарем ТКА:</b></p>" + // Дата согласования отчета секретарем ТКА
                             $"<p><b>Комментарий:</b>{notification.Comment}</p>" + // Комментарий клиента запросившего корректировку
                             $"<p><a href=\"{url.Action("LawyerReport", "Report", new { id = notification.ObjectId })}\"><b>Ссылка на Заявку:</b></a></p>";  // Ссылка на Заявки
                    break;

                case NotificationType.RequestEditReportGgupAccepted:
                    result = @"<h3>Запрос на корректировку Заявки обработан: &laquo;Согласован&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" + 
                             $"<p><b>Наименование ТКА:</b>{notification.Collegium}</p>" + 
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата и время обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>"; 
                    break;

                case NotificationType.RequestEditReportGgupRejected:
                    result = @"<h3>Запрос на корректировку Заявки обработан: &laquo;Отклонен&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b>{notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата и время обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>";
                    break;
                    
                case NotificationType.RequestApprovalAdjustedReportGgup:
                    result = @"<h3>Запрос на согласование откорректированного Заявки</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование организации:</b> {notification.CreatorOrgName}</p>" +
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" +
                             $"<p><b>Отчетный период:</b></p>" +
                             $"<p><b>Номер откорректированного отчета:</b></p>" +
                             $"<p><b>Дата подтверждения запроса на корректировку Секретарем ТКА</b></p>" +
                             $"<p><a href=\"{url.Action("LawyerReport", "Report", new { id = notification.ObjectId })}\"><b>Ссылка на Заявку:</b></a></p>";
                    break;

                case NotificationType.RequestApprovalAdjustedReportGgupAccepted:
                    result = @"<h3>Запрос на согласование откорректированного Заявки обработан: &laquo;Согласован&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b>{notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата и время обработки:</b>{notification.CreationDate:dd.MM.yyyy HH:mm}</p>";
                    break;

                case NotificationType.RequestApprovalAdjustedReportGgupRejected:
                    result = @"<h3>Запрос на согласование откорректированного Заявки обработан: &laquo;Отклонен&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b>{notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата и время обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>";
                    break;
                    
                case NotificationType.RequestApprovalPreviouslyRejectedReportGgup:
                    result = @"<h3>Запрос на согласование ранее отклоненного Заявки</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование организации:</b> {notification.CreatorOrgName}</p>" +
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" +
                             $"<p><b>Отчетный период:</b></p>" +
                             $"<p><b>Дата отклонения отчета Секретарем ТКА</b></p>" +
                             $"<p><a href=\"{url.Action("LawyerReport", "Report", new { id = notification.ObjectId })}\"><b>Ссылка на Заявку:</b></a></p>";
                    break;

                case NotificationType.RequestApprovalPreviouslyRejectedReportGgupAccepted:
                    result = @"<h3>Запрос на согласование ранее отклоненного Заявки обработан: &laquo;Согласован&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата и время обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>";
                    break;

                case NotificationType.RequestApprovalPreviouslyRejectedReportGgupRejected:
                    result = @"<h3>Запрос на согласование ранее отклоненного Заявки обработан: &laquo;Отклонен&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.CreatorName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО ответственного исполнителя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Дата и время обработки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>";
                    break;

                case NotificationType.AccountLockedTka:
                    result = @"<h3>Ваша учетная запись заблокирована ТКА</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.RecipientName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО секретаря осуществившего блокирование пользователя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>" +
                             $"<p><b>Комментарии и документ:</b>{notification.Comment} <a href=\"/Picture/GetFileByGuid/{notification.DocumentId}\">Документ</a></p>";
                    break;

                case NotificationType.AccountUnlockedTka:
                    result = @"<h3>Ваша учетная запись разблокирована ТКА</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.RecipientName}</p>" +
                             $"<p><b>Наименование ТКА:</b> {notification.Collegium}</p>" +
                             $"<p><b>Должность и ФИО секретаря осуществившего блокирование пользователя:</b> {notification.CreatorOrgName} ,  {notification.CreatorName} </p>";
                    break;

                case NotificationType.AccountLockedWeb:
                    result = @"<h3>Ваша учетная запись заблокированна администрацией веб-портала &laquo;ТП КТЖ&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.RecipientName}</p>" +
                             $"<p><b>Дата и время блокировки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Комментарии исполнителя:</b> {notification.Comment}</p>" +
                             $"<p><b>Телефон для справок:</b></p>";
                    break;

                case NotificationType.AccountUnlockedWeb:
                    result = @"<h3>Ваша учетная запись разблокирована администрацией веб-портала &laquo;ТП КТЖ&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.RecipientName}</p>" +
                             $"<p><b>Дата и время блокировки:</b> {notification.CreationDate:dd.MM.yyyy HH:mm}</p>" +
                             $"<p><b>Телефон для справок:</b></p>";
                    break;

                case NotificationType.AccountUserLocked:
                    result = @"<h3>Пользователь заблокирован администрацией веб-портала &laquo;ТП КТЖ&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.RecipientName}</p>" +
                             $"<p><b>Наименование организации:</b></p>" +
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" +
                             $"<p><a href=\"{url.Action("Lawyer", "Account", new { id = notification.ObjectId })}\"><b>Ссылка на заявку согласования профиля клиента</b></a></p>";
                    break;

                case NotificationType.AccountUserUnlocked:
                    result = @"<h3>Пользователь разблокирован администрацией веб-портала &laquo;ТП КТЖ&raquo;</h3>" +
                             $"<p><b>ФИО клиента:</b> {notification.RecipientName}</p>" +
                             $"<p><b>Наименование организации:</b></p>" +
                             $"<p><b>Номер и дата выдачи документа:</b> {notification.CreatorLicense} от {notification.CreatorLicenseDate:dd.MM.yyyy}</p>" +
                             $"<p><a href=\"{url.Action("Lawyer", "Account", new { id = notification.ObjectId })}\"><b>Ссылка на заявку согласования профиля клиента</b></a></p>";
                    break;
            }
            
            return result;
        }

        private static byte[] SetPhoto(object photo, string gender)
        {
            if (!(photo is DBNull))
            {
                gender = "Y";
            }

            switch (gender)
            {
                case "M":
                    return File.ReadAllBytes(Path.Combine(HttpContext.Current.Server.MapPath("~/Content/Images"), Path.GetFileName("man.png")));
                case "F":
                    return File.ReadAllBytes(Path.Combine(HttpContext.Current.Server.MapPath("~/Content/Images"), Path.GetFileName("female.png")));
                case "Y":
                    return (byte[])photo;
            }

            return null;
        }
    }
}