﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 02-19-2015
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 02-19-2015
// ***********************************************************************
// <copyright file="ReportDictionary.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Model namespace.
/// </summary>
namespace Lawyers.Common.Model
{
    using System.Collections.Generic;

    /// <summary>
    /// Class ReportDictionary.
    /// </summary>
    public class ReportDictionary : SortedDictionary<int, Report>
    {
    }
}
