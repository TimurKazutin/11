﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-16-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-16-2014
// ***********************************************************************
// <copyright file="IFieldPrimaryKey.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Interfaces namespace.
/// </summary>
namespace Lawyers.Common.Interfaces
{
    /// <summary>
    /// Interface IFieldPrimaryKey
    /// </summary>
    public interface IFieldPrimaryKey
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        string Name { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        int Position { get; set; }
    }
}
