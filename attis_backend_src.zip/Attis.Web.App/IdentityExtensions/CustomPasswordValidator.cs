﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNet.Identity;

namespace Lawyers.Web.App.IdentityExtensions
{
    public class CustomPasswordValidator : IIdentityValidator<string>
    {
        public int RequiredLength { get; set; }
        public CustomPasswordValidator(int length)
        {
            RequiredLength = length;
        }

        public Task<IdentityResult> ValidateAsync(string item)
        {
            if (String.IsNullOrEmpty(item) || item.Length < RequiredLength)
            {
                return Task.FromResult(IdentityResult.Failed(String.Format("Пароль должен иметь длинну {0} символов", RequiredLength)));
            }

            //string pattern = @"^(?=.*[0-9])(?=.*[!@#$%^&*()])[0-9а-яА-ЯA-Za-z!@#$%^&()*0-9]{8,}$";
            string pattern = @"(?!^[0-9]*$)(?!^[a-zA-Z]*$)^(.{8,255})$";
            if (!Regex.IsMatch(item, pattern))
            {
                return Task.FromResult(IdentityResult.Failed("Пароль должен иметь, как минимум, одну цифру и один спецсимвол."));
            }
            return Task.FromResult(IdentityResult.Success);
        }
    }
}