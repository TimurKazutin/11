﻿// ***********************************************************************
// Assembly         : Lawyers.Web.App
// Author           : Alexey Shumeyko
// Created          : 10-11-2014
//
// Last Modified By : Victor Skakun
// Last Modified On : 18-07-2016
// ***********************************************************************
// <copyright file="IdentityUser.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace Lawyers.Web.App.Models
{
    using Resources;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Data;
    using System.Globalization;
    using System.Linq;
    using Common;
    using Common.Interfaces;
    using Engine.Configuration;
    using System;
    using Microsoft.AspNet.Identity;

    /// <summary>
    /// Class ExternalLoginConfirmationViewModel.
    /// </summary>
    public class ExternalLoginConfirmationViewModel
    {
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Model_Email", ResourceType = typeof(GlobalStrings))]
        public string Email { get; set; }
    }

    /// <summary>
    /// Class SendCodeViewModel.
    /// </summary>
    public class SendCodeViewModel
    {
        /// <summary>
        /// Gets or sets the selected provider.
        /// </summary>
        /// <value>The selected provider.</value>
        public string SelectedProvider { get; set; }
        /// <summary>
        /// Gets or sets the providers.
        /// </summary>
        /// <value>The providers.</value>
        public ICollection<System.Web.Mvc.SelectListItem> Providers { get; set; }
        /// <summary>
        /// Gets or sets the return URL.
        /// </summary>
        /// <value>The return URL.</value>
        public string ReturnUrl { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [remember me].
        /// </summary>
        /// <value><c>true</c> if [remember me]; otherwise, <c>false</c>.</value>
        public bool RememberMe { get; set; }
    }

    /// <summary>
    /// Class VerifyCodeViewModel.
    /// </summary>
    public class VerifyCodeViewModel
    {
        /// <summary>
        /// Gets or sets the provider.
        /// </summary>
        /// <value>The provider.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        public string Provider { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Account_VerifyCode_EnterVerCode", ResourceType = typeof(GlobalStrings))]
        public string Code { get; set; }
        /// <summary>
        /// Gets or sets the return URL.
        /// </summary>
        /// <value>The return URL.</value>
        public string ReturnUrl { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [remember browser].
        /// </summary>
        /// <value><c>true</c> if [remember browser]; otherwise, <c>false</c>.</value>
        [Display(Name = "Model_RememberBrowser", ResourceType = typeof(GlobalStrings))]
        public bool RememberBrowser { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [remember me].
        /// </summary>
        /// <value><c>true</c> if [remember me]; otherwise, <c>false</c>.</value>
        public bool RememberMe { get; set; }
    }

    /// <summary>
    /// Class ForgotViewModel.
    /// </summary>
    public class ForgotViewModel
    {
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "E-mail", ResourceType = typeof(GlobalStrings))]
        public string Email { get; set; }
    }

    /// <summary>
    /// Class LoginViewModel.
    /// </summary>
    public class LoginViewModel
    {
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Model_Email", ResourceType = typeof(GlobalStrings))]
        [EmailAddress]
        [RegularExpression("^[a-z0-9][-a-z0-9._]+@([-a-z0-9]+[.])+[a-z]{2,5}$", ErrorMessage = "Поле \"{0}\" недопустимое значение")]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        /// <value>The password.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [DataType(DataType.Password)]
        [Display(Name = "Model_Password", ResourceType = typeof(GlobalStrings))]
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [remember me].
        /// </summary>
        /// <value><c>true</c> if [remember me]; otherwise, <c>false</c>.</value>
        [Display(Name = "Model_RememberMe", ResourceType = typeof(GlobalStrings))]
        public bool RememberMe { get; set; }
    }


    public class Insurer
    {
        public int? id { get; set; }
        public int insurer_request_id { get; set; }
        public string insurer_id { get; set; }
        public string insurer_name { get; set; }
        public string insurer_orgname { get; set; }
        public string insurer_message { get; set; }
        public string status { get; set; }
        public int? select_status { get; set; }
        public int? offer_sent { get; set; }
        public float? price { get; set; }
        public float? franchise { get; set; }
        public int? is_signed { get; set; }
        public string sign_date { get; set; }
    }

    public class insurance_request
    {
        public int? id { get; set; }
        public int contract_id { get; set; }
        public string org_name { get; set; }
        public string ceo_name { get; set; }
        public string status { get; set; }//– enum (new, approved, returned)
        public string statute { get; set; } //file(устав)
        public string user_id { get; set; }
        public int insurance_type { get; set; }
        public string insurer_message { get; set; }
        public string registration_certificate { get; set; } // file(свидетельство о гос.регистрации)
        public string signature_right_certificate { get; set; } //file(документ о праве подписи)
        public string ceo_passport { get; set; } //file(паспорт директора)
        public string document_id { get; set; }
        public string certificate { get; set; }
        public float? amount { get; set; }
        public string date_time { get; set; }
        public List<Insurer> insurers { get; set; }
        public int? select_status { get; set; }
        public int? is_signed { get; set; }
        public string sign_date { get; set; }
    }
    public class CountryInfo
    {
        public string Country { get; set; }
        public string Name { get; set; }
    };

    public class UserTypesInfo
    {
        public int UserTypeID { get; set; }
        public string UserTypeName { get; set; }
    }

    /// <summary>
    /// Class RegisterViewModel.
    /// </summary>
    public class RegisterViewModel
    {
        public RegisterViewModel()
        {
            Residency = 1;
            Countries = new System.Web.Mvc.SelectList(GetCountries(), "Country", "Name");
            UserTypes = new System.Web.Mvc.SelectList(GetUserTypes(), "UserTypeID", "UserTypeName");
            Country = "KZ";
            UserType = "1";
        }

        public IEnumerable<CountryInfo> GetCountries()
        {
            return CultureInfo.GetCultures(CultureTypes.SpecificCultures)
                 .Select(x => new CountryInfo
                 {
                     Country = new RegionInfo(x.LCID).Name,
                     Name = new RegionInfo(x.LCID).DisplayName
                 })
                .GroupBy(c => c.Country)
                .Select(c => c.First())
                .OrderBy(x => x.Name);
        }

        public IEnumerable<UserTypesInfo> GetUserTypes()
        {
            List<UserTypesInfo> userTypes = new List<UserTypesInfo>();
            IDataProvider provider = GlobalContainer.Instance.Get<Configuration>().DataProvider;
            string query = "SELECT \"user_role_code\", \"user_role_name\" FROM public.\"users_roles\";";
            IDataReader reader = provider.RunQuery(query);
            if (reader != null)
            {
                while (reader.Read())
                {
                    userTypes.Add(new UserTypesInfo
                    {
                        UserTypeID = Convert.ToInt32(reader["user_role_code"]),
                        UserTypeName = reader["user_role_Name"].ToString()
                    });
                }
                reader.Close();
            }
            return userTypes;
        }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [MinLength(12, ErrorMessage = "ИИН должен содержать 12 цифр")]
        [MaxLength(12, ErrorMessage = "ИИН должен содержать 12 цифр")]
        [Display(Name = "Model_PersonCode", ResourceType = typeof(GlobalStrings))]
        [RegularExpression("^[0-9]*$", ErrorMessage = "ИИН должен содержать 12 цифр")]
        public string PersonCode { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Model_GivenName", ResourceType = typeof(GlobalStrings))]
        public string GivenName { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Model_Surname", ResourceType = typeof(GlobalStrings))]
        public string Surname { get; set; }

        [Display(Name = "Model_MiddleName", ResourceType = typeof(GlobalStrings))]
        public string MiddleName { get; set; }

        [Display(Name = "Model_FullName", ResourceType = typeof(GlobalStrings))]
        public string FullName { get; set; }

        [Display(Name = "Model_GivenNameKz", ResourceType = typeof(GlobalStrings))]
        public string GivenNameKz { get; set; }

        [Display(Name = "Model_SurnameKz", ResourceType = typeof(GlobalStrings))]
        public string SurnameKz { get; set; }

        [Display(Name = "Model_MiddleNameKz", ResourceType = typeof(GlobalStrings))]
        public string MiddleNameKz { get; set; }

        [Display(Name = "Model_Gender", ResourceType = typeof(GlobalStrings))]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Выбрать роль обязательно")]
        public string Role { get; set; }

        [Required(ErrorMessage = "Не подписан договор оферты")]
        public bool Agree { get; set; }

        //[Display(Name = "Model_Birthday", ResourceType = typeof(GlobalStrings))]
        //[DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}", ApplyFormatInEditMode = true)]
        //[Required(ErrorMessage = "Выбрать обязательно")]
        public DateTime? Birthday { get; set; }

        [Display(Name = "Model_Residency", ResourceType = typeof(GlobalStrings))]
        public int Residency { get; set; }

        [Display(Name = "Model_Country", ResourceType = typeof(GlobalStrings))]
        public string Country { get; set; }

        [Required]
        [Display(Name = "User_Type_Name", ResourceType = typeof(GlobalStrings))]
        public string UserType { get; set; }

        [Required]
        [Display(Name = "Law_Collegium", ResourceType = typeof(GlobalStrings))]
        public int LawCollegiumId { get; set; }
        public string PesonId { get; set; }

        [Display(Name = "Bin", ResourceType = typeof(GlobalStrings))]
        [Required(ErrorMessage = "Требуется значение БИН")]
        [MinLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        [MaxLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "БИН должен содержать 12 цифр")]
        public string Bin { get; set; }

        [Display(Name = "FirmName", ResourceType = typeof(GlobalStrings))]
        public string FirmName { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Model_Address", ResourceType = typeof(GlobalStrings))]
        public string Address { get; set; }

        public string Geocode { get; set; }

        [Phone(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Model_Phone", ErrorMessage = null)]
        [Display(Name = "Model_Phone", ResourceType = typeof(GlobalStrings))]
        public string Phone { get; set; }

        [Phone(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Model_Phone", ErrorMessage = null)]
        [Display(Name = "Model_Phone", ResourceType = typeof(GlobalStrings))]
        public string FirmPhone { get; set; }

        public System.Web.Mvc.SelectList Countries { get; set; }
        public IEnumerable<System.Web.Mvc.SelectListItem> Collegiums { get; set; }
        public System.Web.Mvc.SelectList UserTypes { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [EmailAddress]
        [RegularExpression("^[a-z0-9][-a-z0-9._]+@([-a-z0-9]+[.])+[a-z]{2,5}$", ErrorMessage = "Поле \"{0}\" недопустимое значение")]
        [Display(Name = "Model_Email", ResourceType = typeof(GlobalStrings))]
        public string Email { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [StringLength(100, ErrorMessage = "{0} должен иметь длину не менее {2} символов.", MinimumLength = 8)]
        [RegularExpression("(?!^[0-9]*$)(?!^[a-zA-Z]*$)^(.{8,255})$", ErrorMessage = "Не менее 8 символов, минимум одна цифра и один спецсимвол")]
        [DataType(DataType.Password)]
        [Display(Name = "Admin_GetHash_PassToHash", ResourceType = typeof(GlobalStrings))]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Подтвертиде пароль")]
        [Compare("Password", ErrorMessage = "Пароли не совпадают.")]
        public string ConfirmPassword { get; set; }

        public string Faceb { get; set; }
        public string Instag { get; set; }
        public string Skype { get; set; }
    }

    public class ResetPasswordViewModel
    {
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [EmailAddress]
        [Display(Name = "Model_Email", ResourceType = typeof(GlobalStrings))]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the password.
        /// </summary>
        /// <value>The password.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [StringLength(100, MinimumLength = 8, ErrorMessageResourceName = "Model_StringLength_PasswordLength", ErrorMessageResourceType = typeof(GlobalStrings))]
        [DataType(DataType.Password)]
        [Display(Name = "Model_Password", ResourceType = typeof(GlobalStrings))]
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the confirm password.
        /// </summary>
        /// <value>The confirm password.</value>
        [DataType(DataType.Password)]
        [Display(Name = "Model_RepeatPassword", ResourceType = typeof(GlobalStrings))]
        [Compare("Password", ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Model_Compare_EnteredPasswordNotMatch")]
        public string ConfirmPassword { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        public string Code { get; set; }
    }

    public class ForgotPasswordViewModel
    {
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [EmailAddress(ErrorMessageResourceName = "Model_EmailAddressAttribute_NotValid", ErrorMessageResourceType = typeof(GlobalStrings))]
        [Display(Name = "Account_ForgotPassword_EnterEmail", ResourceType = typeof(GlobalStrings))]
        public string Email { get; set; }
    }

    public class PersonalViewModel
    {
        public PersonalViewModel()
        {
            Countries = new System.Web.Mvc.SelectList(GetCountries(), "Country", "Name");
            Country = "KZ";
            processStartDate = DateTime.Now;
        }

        public IEnumerable<CountryInfo> GetCountries()
        {
            return CultureInfo.GetCultures(CultureTypes.SpecificCultures)
                 .Select(x => new CountryInfo
                 {
                     Country = new RegionInfo(x.LCID).Name,
                     Name = new RegionInfo(x.LCID).DisplayName
                 })
                .GroupBy(c => c.Country)
                .Select(c => c.First())
                .OrderBy(x => x.Name);
        }
        public string DocGuid { get; set; }

        [Display(Name = "Model_Name", ResourceType = typeof(GlobalStrings))]
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        public string Name { get; set; }

        [Display(Name = "Model_Surename", ResourceType = typeof(GlobalStrings))]
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        public string Surname { get; set; }

        [Display(Name = "Model_Middlename", ResourceType = typeof(GlobalStrings))]
        //[Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        public string Middlename { get; set; }

        [Display(Name = "Model_Name_KZ", ResourceType = typeof(GlobalStrings))]
        public string Name_KZ { get; set; }

        [Display(Name = "Model_Surename_KZ", ResourceType = typeof(GlobalStrings))]
        public string Surname_KZ { get; set; }

        [Display(Name = "Model_Middlename_KZ", ResourceType = typeof(GlobalStrings))]
        public string Middlename_KZ { get; set; }

        [Display(Name = "Model_Country", ResourceType = typeof(GlobalStrings))]
        public string Country { get; set; }

        [Display(Name = "Model_Gender", ResourceType = typeof(GlobalStrings))]
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        public string Gender { get; set; }

        [Display(Name = "Model_Residency", ResourceType = typeof(GlobalStrings))]
        public int Residency { get; set; }

        [Display(Name = "Model_UserID", ResourceType = typeof(GlobalStrings))]
        public string UserID { get; set; }

        [Display(Name = "Model_District", ResourceType = typeof(GlobalStrings))]
        public string District { get; set; }

        [Display(Name = "Model_Region", ResourceType = typeof(GlobalStrings))]
        public string Region { get; set; }

        [Display(Name = "Model_PostIndex", ResourceType = typeof(GlobalStrings))]
        public string PostIndex { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Model_Address", ResourceType = typeof(GlobalStrings))]
        public string Address { get; set; }

        public string Geocode { get; set; }

        [Phone(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Model_Phone", ErrorMessage = null)]
        [Display(Name = "Model_Phone", ResourceType = typeof(GlobalStrings))]
        public string Phone { get; set; }

        [Display(Name = "Model_PersonCode", ResourceType = typeof(GlobalStrings))]
        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [MinLength(12, ErrorMessage = "ИИН должен содержать 12 цифр")]
        [MaxLength(12, ErrorMessage = "ИИН должен содержать 12 цифр")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "ИИН должен содержать 12 цифр")]
        public string PersonalCode { get; set; }

        //[Display(Name = "Model_Birthday", ResourceType = typeof(GlobalStrings))]
        //[DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        //[Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        //[Required(ErrorMessage = "Выбрать обязательно")]
        public DateTime? Birthday { get; set; }

        public string Faceb { get; set; }
        public string Instag { get; set; }
        public string Skype { get; set; }
        public bool HasPassword { get; set; }

        public IList<UserLoginInfo> Logins { get; set; }

        public string PhoneNumber { get; set; }

        public bool TwoFactor { get; set; }

        public bool BrowserRemembered { get; set; }

        public List<CalendarEventModel> Events { get; set; }


        public System.Web.Mvc.SelectList Countries { get; set; }


        [EmailAddress]
        [Display(Name = "Model_Email", ResourceType = typeof(GlobalStrings))]
        public string Email { get; set; }

        public IEnumerable<System.Web.Mvc.SelectListItem> users { get; set; }

        [Required]
        public string processName { get; set; }

        [Required]
        public string processBody { get; set; }


        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime processStartDate { get; set; }

        [Display(Name = "Model_Time", ResourceType = typeof(GlobalStrings))]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:HH-mm}", ApplyFormatInEditMode = false)]
        public DateTime processStartTime { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime? processEndDate { get; set; }

        [DataType(DataType.Time)]
        [Display(Name = "Model_Time", ResourceType = typeof(GlobalStrings))]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd:HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime? processEndTime { get; set; }

        public string userId1 { get; set; }

        public LawyerStatusRequestViewModel lawyer { get; set; }
        public List<SubjectPhone> PhoneNumbers { get; set; }
        public List<SubjectPhone> CellPhoneNumbers { get; set; }
        public List<SubjectAddress> Addresses { get; set; }
        public List<SubjectEmail> Emails { get; set; }

        public int RequestStatus { get; set; }
    }

    public class LawyerViewModel
    {
        public IEnumerable<System.Web.Mvc.SelectListItem> OrgForms { get; set; }
        public IEnumerable<System.Web.Mvc.SelectListItem> Collegiums { get; set; }
        public IEnumerable<System.Web.Mvc.SelectListItem> Bureaues { get; set; }

        public int RequestId { get; set; }

        [Display(Name = "RequestStatus", ResourceType = typeof(GlobalStrings))]
        public int RequestStatus { get; set; }

        [Display(Name = "RequestSendTimestamp", ResourceType = typeof(GlobalStrings))]
        public DateTime RequestSendTimestamp { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Naimenovanie", ResourceType = typeof(GlobalStrings))]
        public string Name { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "OrgForma", ResourceType = typeof(GlobalStrings))]
        public int OrgForma { get; set; }
        public string OrgFormaName { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "LicenseNumber", ResourceType = typeof(GlobalStrings))]
        public string LicenseNumber { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "LicenseDate", ResourceType = typeof(GlobalStrings))]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? LicenseDate { get; set; }


        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "TerritorialCollegia", ResourceType = typeof(GlobalStrings))]
        public int Collegia { get; set; }
        public string CollegiaName { get; set; }


        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Home_Contact_DeveloperAddress", ResourceType = typeof(GlobalStrings))]
        public string Address { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Manage_AddPhoneNumber_Title", ResourceType = typeof(GlobalStrings))]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "MobilePhoneNumber", ResourceType = typeof(GlobalStrings))]
        public string CellPhoneNumber { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "WorkingDate", ResourceType = typeof(GlobalStrings))]
        public string WorkingDays { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "WorkingTime", ResourceType = typeof(GlobalStrings))]
        public string WorkTime { get; set; }

        [Display(Name = "Bin", ResourceType = typeof(GlobalStrings))]
        [Required]
        [MinLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        [MaxLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "БИН должен содержать 12 цифр")]
        public string Bin { get; set; }

        [Display(Name = "Consultation", ResourceType = typeof(GlobalStrings))]
        public int ConsultationId { get; set; }

        public string PersonalCode { get; set; }
        public string GivenName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string Gender { get; set; }

        public DateTime DateOfBirth { get; set; }
        public string PersonId { get; set; }
        public string RequestAnswer { get; set; }

        public string GetLawyerFIO()
        {
            return LastName + " " + GivenName + (String.IsNullOrEmpty(MiddleName) ? "" : " " + MiddleName);
        }
        public string GetRequestStatus()
        {
            switch (RequestStatus)
            {
                case 1:
                    return GlobalStrings.StatusNew;
                case 2:
                    return GlobalStrings.StatusRejected;
                case 3:
                    return GlobalStrings.StatusConfirmed;
                default:
                    return GlobalStrings.StatusNew;
            }
        }
    }

    public class LawyerStatusRequestViewModel
    {
        public IEnumerable<System.Web.Mvc.SelectListItem> OrgForms { get; set; }
        public IEnumerable<System.Web.Mvc.SelectListItem> Collegiums { get; set; }
        public IEnumerable<System.Web.Mvc.SelectListItem> Bureaues { get; set; }

        public int RequestId { get; set; }

        public int RequestStatus { get; set; }

        public int LawyerStatus { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Naimenovanie", ResourceType = typeof(GlobalStrings))]
        public string FIO { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "OrgForma", ResourceType = typeof(GlobalStrings))]
        public int? OrgForma { get; set; }
        public string OrgFormaName { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "LicenseNumber", ResourceType = typeof(GlobalStrings))]
        public string LicenseNumber { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "LicenseDate", ResourceType = typeof(GlobalStrings))]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? LicenseDate { get; set; }


        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "TerritorialCollegia", ResourceType = typeof(GlobalStrings))]
        public int Collegia { get; set; }
        public string CollegiaName { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Home_Contact_DeveloperAddress", ResourceType = typeof(GlobalStrings))]
        public string Address { get; set; }

        public string Geocode { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Manage_AddPhoneNumber_Title", ResourceType = typeof(GlobalStrings))]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "MobilePhoneNumber", ResourceType = typeof(GlobalStrings))]
        public string CellPhoneNumber { get; set; }

        [Display(Name = "Home_Contact_Fax", ResourceType = typeof(GlobalStrings))]
        public string Fax { get; set; }

        [Display(Name = "Model_Email", ResourceType = typeof(GlobalStrings))]
        [EmailAddress]
        public string Email { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "WorkingDate", ResourceType = typeof(GlobalStrings))]
        public string WorkingDays { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "WorkingTime", ResourceType = typeof(GlobalStrings))]
        public string WorkTime { get; set; }

        [Display(Name = "isGGUP", ResourceType = typeof(GlobalStrings))]
        public int? isGGUP { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "isWorking", ResourceType = typeof(GlobalStrings))]
        public int isWorking { get; set; }

        [Display(Name = "GGUPDocNumber", ResourceType = typeof(GlobalStrings))]
        public string GGUPDocNumber { get; set; }

        [Display(Name = "GGUPDocDate", ResourceType = typeof(GlobalStrings))]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? GGUPDocDate { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Model_GGUPNextYear", ResourceType = typeof(GlobalStrings))]
        public string GGUPNextYear { get; set; }

        [Display(Name = "Comment", ResourceType = typeof(GlobalStrings))]
        public string Comment { get; set; }

        [Display(Name = "Site", ResourceType = typeof(GlobalStrings))]
        public string Website { get; set; }

        [Display(Name = "Bin", ResourceType = typeof(GlobalStrings))]
        [Required]
        [MinLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        [MaxLength(12, ErrorMessage = "БИН должен содержать 12 цифр")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "БИН должен содержать 12 цифр")]
        public string Bin { get; set; }

        [Required(ErrorMessageResourceType = typeof(GlobalStrings), ErrorMessageResourceName = "Models_Required")]
        [Display(Name = "Consultation", ResourceType = typeof(GlobalStrings))]
        public int? ConsultationId { get; set; }

        [Display(Name = "ShouldPay", ResourceType = typeof(GlobalStrings))]
        public int? ShouldPay { get; set; }

        [Display(Name = "DownPaymentDoubtness", ResourceType = typeof(GlobalStrings))]
        public string DownPaymentIndebtness { get; set; }

        [Display(Name = "MonthlyPaymentDoubtness", ResourceType = typeof(GlobalStrings))]
        public string MonthlyPaymentIndebtness { get; set; }

        public int SubjectId { get; set; }

        [Display(Name = "IsRural", ResourceType = typeof(GlobalStrings))]
        public int? IsRural { get; set; }

        [Display(Name = "ContractOffer", ResourceType = typeof(GlobalStrings))]
        public string ContractOffer { get; set; }

        [Display(Name = "ContractOfferDate", ResourceType = typeof(GlobalStrings))]
        public string ContractOfferDate { get; set; }

        public List<SubjectPhone> PhoneNumbers { get; set; }
        public List<SubjectPhone> CellPhoneNumbers { get; set; }
        public List<SubjectAddress> Addresses { get; set; }
        public List<SubjectEmail> Emails { get; set; }

        public string PersonId { get; set; }

        public string GivenName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string GetLawyerFIO()
        {
            return LastName + " " + GivenName + (String.IsNullOrEmpty(MiddleName) ? "" : " " + MiddleName);
        }

        public string GetRequestStatus()
        {
            switch (RequestStatus)
            {
                case 1:
                    return GlobalStrings.StatusNew;
                case 2:
                    return GlobalStrings.StatusRejected;
                case 3:
                    return GlobalStrings.StatusConfirmed;
                default:
                    return GlobalStrings.StatusNew;
            }
        }

        public string GetLawyerStatus()
        {
            switch (LawyerStatus)
            {
                case 0:
                case 5:
                    return GlobalStrings.StatusBlocked;
                default:
                    return GlobalStrings.StatusUnblocked;
            }
        }

        public DateTime? RegistrationDate { get; set; }

        public DateTime? RequestAnswerDate { get; set; }

        public string RequestAnswer { get; set; }

        public string RequestStatusName()
        {
            var statusName = string.Empty;

            switch (RequestStatus)
            {
                case 0:
                    statusName = "0 - Новый";
                    break;
                case 1:
                    statusName = "1 - Утверждена";
                    break;
                case 5:
                    statusName = "5 - Отказано";
                    break;
                default:
                    statusName = "Введите название";
                    break;
            }

            return statusName;
        }
    }

    public class LawyerAllRequestsViewModel
    {
        public List<LawyerStatusRequestViewModel> Requests = new List<LawyerStatusRequestViewModel>();
    }

    public class LawyerEditDataRequestsViewModel
    {
        public List<LawyerStatusRequestViewModel> Requests = new List<LawyerStatusRequestViewModel>();
    }

    public class SubjectPhone
    {
        public int Id { get; set; }
        public string Number { get; set; }
        public int Type { get; set; }
        public int Status { get; set; }
        public int SubjectId { get; set; }
    }

    public class SubjectAddress
    {
        public int Id { get; set; }
        public int Status { get; set; }
        public int KatoId { get; set; }
        public int Type { get; set; }
        public int SubjectId { get; set; }
        public string Box { get; set; }
        public string Index { get; set; }
        public string Address { get; set; }
        public string Geocode { get; set; }
    }

    public class SubjectEmail
    {
        public int Id { get; set; }
        public int Type { get; set; }
        public int SubjectId { get; set; }
        public int Status { get; set; }
        public string Email { get; set; }
    }

    public class person
    {
        public string person_code { get; set; }
        public string given_name { get; set; }
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public int? gender { get; set; }
        public string position { get; set; }
        public string date_of_birth { get; set; }
        public string residency { get; set; }
        public string country { get; set; }
        public string post_address { get; set; }
        public string user_id { get; set; }
        public string person_email { get; set; }
        public string person_phone_number { get; set; }
        public string avatar { get; set; }
        public int? image_id { get; set; }
    }

    public class comp
    {
        public string org_name { get; set; }
        public string org_code { get; set; }
        public string org_type { get; set; }
        public string company_address { get; set; }
        public string org_post_infex { get; set; }
        public string org_reg_date { get; set; }
        public string company_region { get; set; }
        public string country { get; set; }
        public string org_custom_code { get; set; }
        public string org_oked { get; set; }
        public string oked_name { get; set; }
        public string sec_oked_name { get; set; }
        public string org_reregdate { get; set; }
        public string company_contacts { get; set; }
        public string company_main_sphere { get; set; }
        public string company_additional_sphere { get; set; }
        public string company_ceo { get; set; }
        public string company_ceo_date { get; set; }
        public string company_founder { get; set; }
        public string company_website { get; set; }
        public string company_email { get; set; }
        public string company_status { get; set; }
        public string company_filials { get; set; }
        public string org_residency { get; set; }
        public string logo { get; set; }
        public string skype { get; set; }
        public string linkedin { get; set; }
        public string fb { get; set; }
        public string instagram { get; set; }
        public string vk { get; set; }
        public string wechat { get; set; }
        public string organization_kpveds { get; set; }
        public int? org_is_broker { get; set; }
        public int? org_is_carrier { get; set; }
        public int? org_is_bank { get; set; }
        public int? org_is_insurer { get; set; }

        public int? org_is_twh { get; set; }
        public string secondary_oked { get; set; }

        //public List<BankModel> banks { get; set; }
        //public List<Founders> founders { get; set; }
        //public List<OrgAdress> adresses { get; set; }

    }
    public class BankModel
    {
        public string subj_bank { get; set; }
        public string subj_bank_acc_number { get; set; }
        public string subj_bank_acc_curr { get; set; }
        public string subj_bank_acc_status { get; set; }
        public string subj_bank_name { get; set; }
        public string subj_bank_address { get; set; }
        public string subj_bank_bin { get; set; }
    }
    public class social
    {
        public string skype { get; set; }
        public string linkedin { get; set; }
        public string fb { get; set; }
        public string instagram { get; set; }
        public string vk { get; set; }
        public string wechat { get; set; }
    }
    public class Founders
    {
        public string org_founders_person_name { get; set; }
        public string org_founders_company { get; set; }
        public string org_founders_country { get; set; }
        public string org_founders_share { get; set; }
        public Founder Founder { get; set; }
    }

    public class OrgAdress
    {
        public string subj_post_addr_type { get; set; }
        public string post_addr_index { get; set; }
        public string post_addr_country { get; set; }
        public string post_addr_region { get; set; }
        public string post_addr_district { get; set; }
        public string post_addr_town { get; set; }
        public string post_addr_city { get; set; }
        public string post_addr_streethouse { get; set; }
        public string post_addr_house { get; set; }
        public string post_addr_room { get; set; }
        public string post_addr_comm_kind { get; set; }
        public string post_addr_comm_number { get; set; }
    }

}

