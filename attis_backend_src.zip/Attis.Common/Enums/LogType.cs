﻿

namespace Lawyers.Common.Enums
{
    public enum LogSection
    {
        Account,
        Contract, 
        Document,
        Offer,

    }

    public enum LogAccount
    {
        Register,
        Logout,
        Login,
        PasswordChange,
        ChangeUserProfile,
        ChangeOrganizationDetails,
        ChangeSocialNetworks,
        ChangeUserDetails,
        ChangeBank,
        ChangeFounders,
        ChangeAddress,
        SetSignature,
        InsuranceRequest,
        insuranceApproved,
        AttachInsurance
    }

    public enum LogContract
    {
        NewContract,
        ContractUpdate,
        ContractDelete,
        AcceptContract,
        NewKtg,
        SftpFileDownload,
        DeleteDocument,
        NewBrokerContract,
        UpdateBrokerContract,
        DeleteBrokerContract,
        SignByOwner,
        SignByContragent,
    }

    public enum LogOffer
    {
        AnswerOffer,
        AcceptOffer,
        DeclineOffer,
        NewOffer,
        SignOffer,
        DeleteOffer,
        NewCourierOffer,
        CourierOffer,
        DeclineCourierOffer,
        SelectCourierOffer,
        BrokerOfferPrice,
        AcceptBrokerOffer,
        DeclineBrokerOffer,
        SelectBrokerOffer,
        NewBrokerOffer,
    }

    public enum LogDocument
    {
        NewInvoice,
        NewInvoiceGoods,
        InvoiceUpdate,
        NewCMR,
        NewCMRCargo,
        NewCMRGoods,
        CMRUpdate,
        NewFm1,
        Fm1Update,
        NewEpi,
        EpiUpdate,
        NewAWB,
        AWBUpdate,
        NewPackingList,
        PackingListUpdate,
        DeletePackingList,
        NewPlaces,
        PlacesUpdate,
        DeletePlaces,
        NewRWBill,
        UpdateRWBill,
        DeleteRWBill,
        NewInsurance,
        UpdateInsurance,
        DeleteInsurance,
        NewLiabilityInsurance,
        UpdateLiabilityInsurance,
        DeleteLiabilityInsurance,
        AddDocNotification,
        UpdateDocNotification,
        DeleteDocNotification,
        EditCWPassport,
        NewGTD,
        UpdateGTD,
        DeleteGTD
    }

}
