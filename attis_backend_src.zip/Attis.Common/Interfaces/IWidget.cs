﻿// ***********************************************************************
// Assembly         : Lawyers.Common
// Author           : Alexey Shumeyko
// Created          : 10-16-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 10-16-2014
// ***********************************************************************
// <copyright file="IWidget.cs" company="Algorithms & Systems JSC">
//     Copyright (c) Algorithms & Systems JSC. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Interfaces namespace.
/// </summary>
namespace Lawyers.Common.Interfaces
{
    using System.Collections.Generic;
    using Lawyers.Common.Enums;

    /// <summary>
    /// Interface IWidget
    /// </summary>
    public interface IWidget
    {
        /// <summary>
        /// Gets or sets the type of the data.
        /// </summary>
        /// <value>The type of the data.</value>
        DataType DataType { get; set; }

        /// <summary>
        /// Gets or sets the type of the group.
        /// </summary>
        /// <value>The type of the group.</value>
        GroupType GroupType { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        WidgetType Type { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is default expanded.
        /// </summary>
        /// <value><c>true</c> if this instance is default expanded; otherwise, <c>false</c>.</value>
        bool IsDefaultExpanded { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="IWidget"/> is mandatory.
        /// </summary>
        /// <value><c>true</c> if mandatory; otherwise, <c>false</c>.</value>
        bool Mandatory { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [read only].
        /// </summary>
        /// <value><c>true</c> if [read only]; otherwise, <c>false</c>.</value>
        bool ReadOnly { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="IWidget"/> is visible.
        /// </summary>
        /// <value><c>true</c> if visible; otherwise, <c>false</c>.</value>
        bool Visible { get; set; }

        /// <summary>
        /// Gets or sets the length.
        /// </summary>
        /// <value>The length.</value>
        int Length { get; set; }

        /// <summary>
        /// Gets or sets the caption.
        /// </summary>
        /// <value>The caption.</value>
        string Caption { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        string Code { get; set; }

        /// <summary>
        /// Gets or sets the default value.
        /// </summary>
        /// <value>The default value.</value>
        string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets the field.
        /// </summary>
        /// <value>The field.</value>
        string Field { get; set; }

        /// <summary>
        /// Gets or sets the name of the filter field.
        /// </summary>
        /// <value>The name of the filter field.</value>
        string FilterFieldName { get; set; }

        /// <summary>
        /// Gets or sets the filter field value.
        /// </summary>
        /// <value>The filter field value.</value>
        string FilterFieldValue { get; set; }

        /// <summary>
        /// Gets or sets the mask.
        /// </summary>
        /// <value>The mask.</value>
        string Mask { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        string Name { get; set; }

        /// <summary>
        /// Gets or sets the name of the table.
        /// </summary>
        /// <value>The name of the table.</value>
        string TableName { get; set; }

        /// <summary>
        /// Gets or sets the children.
        /// </summary>
        /// <value>The children.</value>
        IList<IWidget> Children { get; }

        /// <summary>
        /// Gets or sets the primary keys.
        /// </summary>
        /// <value>The primary keys.</value>
        IList<IFieldPrimaryKey> PrimaryKeys { get; }

        /// <summary>
        /// Gets or sets the foreign keys.
        /// </summary>
        /// <value>The foreign keys.</value>
        IList<IFieldForeignKey> ForeignKeys { get; }
    }
}
