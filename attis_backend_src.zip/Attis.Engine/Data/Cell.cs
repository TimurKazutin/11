﻿// ***********************************************************************
// Assembly         : Lawyers.Engine
// Author           : Alexey Shumeyko
// Created          : 11-02-2014
//
// Last Modified By : Alexey Shumeyko
// Last Modified On : 12-10-2014
// ***********************************************************************
// <copyright file="Cell.cs" company="SP Alexey Shumeyko">
//     Copyright ©  2014
// </copyright>
// <summary></summary>
// ***********************************************************************
/// <summary>
/// The Data namespace.
/// </summary>
namespace Lawyers.Engine.Data
{
    using System;
    using System.Globalization;

    /// <summary>
    /// Class Cell.
    /// </summary>
    public class Cell
    {
        /// <summary>
        /// The _value
        /// </summary>
        private object _value;

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public object Value
        {
            get { return this._value; }
            set
            {
                if (value is DBNull || value == null || value.ToString().Length == 0)
                    this._value = null;
                else
                {
                    switch (this.Type.Name)
                    {
                        case "String":
                            this._value = value.ToString();
                            break;
                        case "Int16":
                        case "Int32":
                            try
                            {
                                this._value = Convert.ToInt32(value);
                            }
                            catch (Exception)
                            {
                                this._value = null;
                            }
                            break;
                        case "Decimal":
                            try
                            {
                                this._value = Convert.ToDecimal(value, this.parent.Culture);
                            }
                            catch (Exception)
                            {
                                this._value = null;
                            }
                            break;
                        case "DateTime":
                            try
                            {
                                if (value.GetType() == typeof(DateTime))
                                    this._value = value;
                                else
                                {
                                    this._value = DateTime.ParseExact(value.ToString(), "yyyy-MM-dd", CultureInfo.InvariantCulture);
                                    //this._value = DateTime.ParseExact(value.ToString(), "yyyy.MM.dd", CultureInfo.InvariantCulture);
                                }
                            }
                            catch (Exception)
                            {
                                this._value = null;
                            }
                            break;
                        default:
                            this._value = value;
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Gets the type.
        /// </summary>
        /// <value>The type.</value>
        public Type Type { get; private set; }

        /// <summary>
        /// The parent
        /// </summary>
        private Record parent;

        /// <summary>
        /// Initializes a new instance of the <see cref="Cell"/> class.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="parent">The parent.</param>
        public Cell(Type type, Record parent)
        {
            this.parent = parent;
            this.Type = type;
        }

        /// <summary>
        /// Returns a <see cref="System.String" /> that represents this instance.
        /// </summary>
        /// <returns>A <see cref="System.String" /> that represents this instance.</returns>
        public override string ToString()
        {
            string result = string.Empty;
            if (this.Value != null)
            {
                switch(this.Type.Name)
                {
                    case "DateTime":
                        result = ((DateTime)this.Value).ToString("dd.MM.yyyy");
                        //result = ((DateTime)this.Value).ToString("yyyy.MM.dd");
                        break;
                    case "Int16":
                    case "Int32":
                        //result = ((int)this.Value).ToString();
                        result = Convert.ToString(this.Value);
                        break;
                    case "Decimal":
                        result = ((decimal)this.Value).ToString(this.parent.Culture);
                        break;
                    default:
                        result = (string)this.Value;
                        break;
                }
            }
            return result;
        }
    }
}
