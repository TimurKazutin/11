﻿
namespace Lawyers.Engine.Configuration
{
	using Common.Enums;
	using System.Configuration;

	public class MainConnectionElement : ConfigurationElement
	{
		private MainConnectionElement() { }

		[ConfigurationProperty("type")]
		public DataSourceType Type
		{
			get { return (DataSourceType)this["type"]; }
			set { this["type"] = value; }
		}

		[ConfigurationProperty("connectionString")]
		public string ConnectionString
		{
			get { return (string)this["connectionString"]; }
			set { this["connectionString"] = value; }
		}
	}
}
