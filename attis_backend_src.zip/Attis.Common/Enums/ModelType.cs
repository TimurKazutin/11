﻿namespace Lawyers.Common.Enums
{
    public enum ModelType
    {
        PersonalViewModel = 1
    }
}
