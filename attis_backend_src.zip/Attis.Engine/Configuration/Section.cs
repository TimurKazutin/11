﻿
namespace Lawyers.Engine.Configuration
{
	using System.Configuration;

	public class Section : ConfigurationSection
	{
		private Section() { }

		[ConfigurationProperty("MainConnection")]
		public MainConnectionElement MainConnection
		{
			get { return (MainConnectionElement)this["MainConnection"]; }
		}

		[ConfigurationProperty("TemplatesTable")]
		public TableElement TemplatesTable
		{
			get { return (TableElement)this["TemplatesTable"]; }
		}

		[ConfigurationProperty("ReportsTable")]
		public TableElement ReportsTable
		{
			get { return (TableElement)this["ReportsTable"]; }
		}
	}
}
